# Restaurant Billing System

A comprehensive Java/MySQL desktop application for restaurant management, billing, and invoicing.

## Prerequisites
- **Java**: Java 21 or higher.
- **MySQL**: MySQL 8.0 or higher.
- **Maven**: For building the project.

## MySQL Setup
1. Install MySQL Server and ensure it is running on `localhost:3306`.
2. Create the database:
   ```sql
   CREATE DATABASE restaurant_billing;
   ```
3. Create a user (or use root). By default, the application expects `root` and password `user123` on localhost, but this can be overridden.
4. Import the initial schema:
   ```bash
   mysql -u root -p restaurant_billing < database/schema.sql
   ```
5. (Optional) Run the Vegetarian Menu Seeder to populate the database with a full restaurant menu:
   ```bash
   mvn exec:java -D"exec.mainClass=com.restaurantbilling.seed.VegetarianMenuSeeder"
   ```

## Configuration & Environment Variables
The application uses `src/main/resources/db.properties` for database credentials. You can override these using system properties or environment variables.

### Environment Variables
- `DB_HOST`: Database host (default: localhost)
- `DB_PORT`: Database port (default: 3306)
- `DB_NAME`: Database name (default: restaurant_billing)
- `DB_USERNAME`: Database user
- `DB_PASSWORD`: Database password
- `PEXELS_API_KEY`: (Optional) Required if you want to automatically download high-quality food photography for your menu items via the Pexels API.

**Never hardcode your Pexels API Key or Database Password in the source code.**

## Build Instructions
To compile the project and build the executable JAR:
```bash
mvn clean package
```
This will generate `restaurant-billing-system-1.0-SNAPSHOT.jar` inside the `target/` directory, along with a `lib/` directory containing all required dependencies.

## Run Instructions
### Using Maven
```bash
mvn exec:java -D"exec.mainClass=com.restaurantbilling.Main"
```

### Using the Packaged JAR (Windows)
```cmd
java -cp "target/restaurant-billing-system-1.0-SNAPSHOT.jar;target/lib/*" com.restaurantbilling.Main
```

## Backup Guidance
The system periodically requires database backups for historical data safety.
Use standard MySQL tools to safely back up your data:
```cmd
mysqldump -u root -p restaurant_billing > backup_restaurant_billing.sql
```

## Common Errors
- **Connection Refused**: Ensure MySQL is running on the correct port and the credentials match your configuration.
- **Pexels Images Not Loading**: Verify that your `PEXELS_API_KEY` is set correctly and you have internet access. The application will continue to work normally for billing and orders even without internet access.
- **PDF Generation Fails**: Ensure the application has write permissions to the directory where PDFs are being saved.
