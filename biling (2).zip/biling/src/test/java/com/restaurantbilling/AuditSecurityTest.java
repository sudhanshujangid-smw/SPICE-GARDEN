package com.restaurantbilling;

import com.restaurantbilling.dao.*;
import com.restaurantbilling.exception.ValidationException;
import com.restaurantbilling.model.Customer;
import com.restaurantbilling.model.FoodItem;
import com.restaurantbilling.model.Order;
import com.restaurantbilling.model.OrderItem;
import com.restaurantbilling.model.RestaurantSettings;
import com.restaurantbilling.model.User;
import com.restaurantbilling.model.audit.AuditLog;
import com.restaurantbilling.model.maintenance.BackupRecord;
import com.restaurantbilling.model.maintenance.DatabaseHealth;
import com.restaurantbilling.service.*;
import com.restaurantbilling.util.CurrentUserSession;
import com.restaurantbilling.util.PasswordUtil;
import com.restaurantbilling.util.UserSession;

import java.io.File;
import java.math.BigDecimal;
import java.sql.Connection;
import java.time.LocalDate;
import java.util.*;

public class AuditSecurityTest {

    private static int totalPassed = 0;
    private static int totalFailed = 0;

    public static void main(String[] args) {
        System.out.println("============================================================");
        System.out.println("PHASE 14: SECURITY, AUDIT LOG & ACCESS CONTROL TEST SUITE");
        System.out.println("============================================================\n");

        testPasswordSecurityAndHashing();
        testUserSessionAndCurrentUserSession();
        testAuditLogDAOAndPagination();
        testAuthenticationAuditingAndLifecycle();
        testPasswordChangeWorkflow();
        testMenuAuditingAndAccessControl();
        testCustomerAuditingAndAccessControl();
        testOrderAndBillingAuditing();
        testSettingsAuditingAndAccessControl();
        testMaintenanceAuditingAndAccessControl();
        testStaffRestrictedAccessAndAuditLogging();
        testStrictNoPaymentArchitectureCompliance();

        System.out.println("\n============================================================");
        System.out.println("TEST RESULTS: " + totalPassed + " PASSED, " + totalFailed + " FAILED");
        System.out.println("============================================================");

        if (totalFailed > 0) {
            System.exit(1);
        }
    }

    private static void assertTrue(String testName, boolean condition) {
        if (condition) {
            System.out.println("  [PASS] " + testName);
            totalPassed++;
        } else {
            System.err.println("  [FAIL] " + testName);
            totalFailed++;
        }
    }

    private static void assertEquals(String testName, Object expected, Object actual) {
        boolean match = Objects.equals(expected, actual);
        if (match) {
            System.out.println("  [PASS] " + testName + " (Value: " + actual + ")");
            totalPassed++;
        } else {
            System.err.println("  [FAIL] " + testName + " -> Expected: " + expected + ", Got: " + actual);
            totalFailed++;
        }
    }

    // 1. Password Security & Hashing
    private static void testPasswordSecurityAndHashing() {
        System.out.println("[TEST GROUP 1] Password Hashing & Cryptographic Verification");

        String plain = "admin123";
        String hash = PasswordUtil.hashPassword(plain);

        assertTrue("Hash is non-null and 64 characters long", hash != null && hash.length() == 64);
        assertTrue("isHashed identifies SHA-256 hex string", PasswordUtil.isHashed(hash));
        assertTrue("isHashed rejects plain text", !PasswordUtil.isHashed(plain));
        assertTrue("verifyPassword succeeds with correct plain text and hash", PasswordUtil.verifyPassword(plain, hash));
        assertTrue("verifyPassword fails with incorrect plain text", !PasswordUtil.verifyPassword("wrongpass", hash));
        assertTrue("verifyPassword backward-compatibility with plain text", PasswordUtil.verifyPassword("legacy123", "legacy123"));
    }

    // 2. UserSession & CurrentUserSession
    private static void testUserSessionAndCurrentUserSession() {
        System.out.println("\n[TEST GROUP 2] Session Management & Invalidation");

        User testAdmin = new User(1, "admin", PasswordUtil.hashPassword("admin123"), "ADMIN");
        UserSession.login(testAdmin);

        assertTrue("UserSession isLoggedIn is true", UserSession.isLoggedIn());
        assertTrue("UserSession isAdmin is true", UserSession.isAdmin());
        assertTrue("UserSession isStaff is false", !UserSession.isStaff());
        assertEquals("UserSession username matches", "admin", UserSession.getUsername());
        assertEquals("CurrentUserSession role matches", "ADMIN", CurrentUserSession.getRole());
        assertTrue("UserSession loginTime is recorded", UserSession.getLoginTime() != null);
        assertTrue("CurrentUserSession formatted login time is not empty", !CurrentUserSession.getFormattedLoginTime().equals("-"));

        CurrentUserSession.clear();
        assertTrue("UserSession isLoggedIn is false after clear", !UserSession.isLoggedIn());
        assertEquals("UserSession username is Guest after logout", "Guest", UserSession.getUsername());
    }

    // 3. AuditLogDAO & Pagination
    private static void testAuditLogDAOAndPagination() {
        System.out.println("\n[TEST GROUP 3] AuditLog DAO, Search, Filtering & Pagination");

        MockAuditLogDAO mockDAO = new MockAuditLogDAO();
        AuditService auditService = new AuditService(mockDAO);

        // Seed logs
        auditService.log(1, "admin", "AUTH", "LOGIN_SUCCESS", "Admin login test", "SUCCESS");
        auditService.log(2, "staff", "AUTH", "LOGIN_SUCCESS", "Staff login test", "SUCCESS");
        auditService.log(null, "unknown", "AUTH", "LOGIN_FAILED", "Invalid password test", "FAILED");
        auditService.log(1, "admin", "MENU", "MENU_CREATED", "Created Paneer Tikka", "SUCCESS");
        auditService.log(2, "staff", "SECURITY", "ACCESS_DENIED", "Unauthorized settings attempt", "DENIED");

        assertEquals("Mock DAO stored 5 records", 5, mockDAO.logs.size());

        // Test filtering
        UserSession.login(new User(1, "admin", "admin123", "ADMIN"));
        try {
            List<AuditLog> authLogs = auditService.getAuditLogs(null, null, "AUTH", null, null, null, null, 1, 10);
            assertEquals("Found 3 AUTH logs", 3, authLogs.size());

            List<AuditLog> failedLogs = auditService.getAuditLogs(null, null, null, null, "FAILED", null, null, 1, 10);
            assertEquals("Found 1 FAILED log", 1, failedLogs.size());

            int totalAuth = auditService.getTotalLogCount(null, null, "AUTH", null, null, null, null);
            assertEquals("Total count for AUTH is 3", 3, totalAuth);
        } catch (ValidationException e) {
            assertTrue("Audit query should not throw for admin", false);
        }
        UserSession.logout();
    }

    // 4. Authentication Auditing & Lifecycle
    private static void testAuthenticationAuditingAndLifecycle() {
        System.out.println("\n[TEST GROUP 4] Authentication Service Auditing");

        MockAuditLogDAO mockDAO = new MockAuditLogDAO();
        AuditService auditService = new AuditService(mockDAO);
        MockUserDAO mockUserDAO = new MockUserDAO();
        mockUserDAO.users.put("admin", new User(1, "admin", PasswordUtil.hashPassword("admin123"), "ADMIN"));

        AuthenticationService authService = new AuthenticationService(mockUserDAO, auditService);

        // Successful login
        try {
            User user = authService.login("admin", "admin123");
            assertTrue("Login returned user", user != null);
            assertTrue("UserSession is logged in", UserSession.isLoggedIn());
            assertTrue("Audit log recorded LOGIN_SUCCESS", mockDAO.hasAction("LOGIN_SUCCESS"));
        } catch (ValidationException e) {
            assertTrue("Login should succeed", false);
        }

        // Logout
        authService.logout();
        assertTrue("UserSession is logged out", !UserSession.isLoggedIn());
        assertTrue("Audit log recorded LOGOUT", mockDAO.hasAction("LOGOUT"));

        // Failed login
        try {
            authService.login("admin", "wrongpassword");
            assertTrue("Login should fail", false);
        } catch (ValidationException e) {
            assertTrue("Audit log recorded LOGIN_FAILED", mockDAO.hasAction("LOGIN_FAILED"));
        }
    }

    // 5. Password Change Workflow
    private static void testPasswordChangeWorkflow() {
        System.out.println("\n[TEST GROUP 5] Password Change Workflow & Auditing");

        MockAuditLogDAO mockDAO = new MockAuditLogDAO();
        AuditService auditService = new AuditService(mockDAO);
        MockUserDAO mockUserDAO = new MockUserDAO();
        User admin = new User(1, "admin", PasswordUtil.hashPassword("admin123"), "ADMIN");
        mockUserDAO.users.put("admin", admin);

        AuthenticationService authService = new AuthenticationService(mockUserDAO, auditService);
        UserSession.login(admin);

        try {
            // Password mismatch test
            try {
                authService.changePassword(1, "admin123", "newpass123", "differentpass");
                assertTrue("Mismatch password should throw ValidationException", false);
            } catch (ValidationException e) {
                assertTrue("Validation caught mismatched password", true);
            }

            // Wrong current password test
            try {
                authService.changePassword(1, "wrongCurrent", "newpass123", "newpass123");
                assertTrue("Wrong current password should throw ValidationException", false);
            } catch (ValidationException e) {
                assertTrue("Validation caught incorrect current password", true);
                assertTrue("Audit log recorded PASSWORD_CHANGE_FAILED", mockDAO.hasAction("PASSWORD_CHANGE_FAILED"));
            }

            // Valid password change
            boolean changed = authService.changePassword(1, "admin123", "newadmin456", "newadmin456");
            assertTrue("Password change succeeded", changed);
            assertTrue("User password was updated to new hash", PasswordUtil.verifyPassword("newadmin456", admin.getPassword()));
            assertTrue("Audit log recorded PASSWORD_CHANGED", mockDAO.hasAction("PASSWORD_CHANGED"));

        } catch (ValidationException e) {
            assertTrue("Valid password change should succeed", false);
        } finally {
            UserSession.logout();
        }
    }

    // 6. Menu Auditing
    private static void testMenuAuditingAndAccessControl() {
        System.out.println("\n[TEST GROUP 6] Menu CRUD Auditing & Role Control");

        MockAuditLogDAO mockAuditDAO = new MockAuditLogDAO();
        AuditService auditService = new AuditService(mockAuditDAO);
        MockFoodItemDAO mockFoodDAO = new MockFoodItemDAO();
        FoodItemService foodService = new FoodItemService(mockFoodDAO, auditService);

        UserSession.login(new User(1, "admin", "admin123", "ADMIN"));
        try {
            FoodItem item = new FoodItem("Garlic Bread", "Starter", new BigDecimal("120.00"), true);
            FoodItem saved = foodService.addFoodItem(item);
            assertTrue("Food item created", saved.getId() > 0);
            assertTrue("Audit log recorded MENU_CREATED", mockAuditDAO.hasAction("MENU_CREATED"));

            saved.setPrice(new BigDecimal("130.00"));
            foodService.updateFoodItem(saved);
            assertTrue("Audit log recorded MENU_UPDATED", mockAuditDAO.hasAction("MENU_UPDATED"));

            foodService.deleteFoodItem(saved.getId());
            assertTrue("Audit log recorded MENU_DELETED", mockAuditDAO.hasAction("MENU_DELETED"));
        } catch (ValidationException e) {
            assertTrue("Menu operations should succeed for admin", false);
        } finally {
            UserSession.logout();
        }
    }

    // 7. Customer Auditing
    private static void testCustomerAuditingAndAccessControl() {
        System.out.println("\n[TEST GROUP 7] Customer CRUD Auditing");

        MockAuditLogDAO mockAuditDAO = new MockAuditLogDAO();
        AuditService auditService = new AuditService(mockAuditDAO);
        MockCustomerDAO mockCustomerDAO = new MockCustomerDAO();
        CustomerService customerService = new CustomerService(mockCustomerDAO, auditService);

        UserSession.login(new User(1, "admin", "admin123", "ADMIN"));
        try {
            Customer c = new Customer("Rohan Gupta", "9811122233", "rohan@test.com", "Indiranagar, Bengaluru", "Active");
            Customer saved = customerService.addCustomer(c);
            assertTrue("Customer registered", saved.getId() > 0);
            assertTrue("Audit log recorded CUSTOMER_CREATED", mockAuditDAO.hasAction("CUSTOMER_CREATED"));

            saved.setName("Rohan K. Gupta");
            customerService.updateCustomer(saved);
            assertTrue("Audit log recorded CUSTOMER_UPDATED", mockAuditDAO.hasAction("CUSTOMER_UPDATED"));

            customerService.deleteCustomer(saved.getId());
            assertTrue("Audit log recorded CUSTOMER_DELETED", mockAuditDAO.hasAction("CUSTOMER_DELETED"));
        } catch (ValidationException e) {
            assertTrue("Customer operations should succeed", false);
        } finally {
            UserSession.logout();
        }
    }

    // 8. Order & Billing Auditing
    private static void testOrderAndBillingAuditing() {
        System.out.println("\n[TEST GROUP 8] Order & Billing Lifecycle Auditing");

        MockAuditLogDAO mockAuditDAO = new MockAuditLogDAO();
        AuditService auditService = new AuditService(mockAuditDAO);
        MockOrderDAO mockOrderDAO = new MockOrderDAO();
        MockOrderItemDAO mockOrderItemDAO = new MockOrderItemDAO();
        MockFoodItemDAO mockFoodItemDAO = new MockFoodItemDAO();
        MockBillDAO mockBillDAO = new MockBillDAO();

        Order order = new Order();
        order.setId(101);
        order.setCustomerName("Anita Singh");
        order.setCustomerPhone("9876543210");
        order.setStatus("PENDING");
        order.setTotal(new BigDecimal("360.00"));
        mockOrderDAO.orders.put(101, order);

        Order cancelTestOrder = new Order();
        cancelTestOrder.setId(102);
        cancelTestOrder.setStatus("PENDING");
        mockOrderDAO.orders.put(102, cancelTestOrder);

        OrderService orderService = new OrderService(mockOrderDAO, mockOrderItemDAO, mockFoodItemDAO, auditService);

        UserSession.login(new User(1, "admin", "admin123", "ADMIN"));
        try {
            // Direct Order Created audit
            auditService.log("ORDER", "ORDER_CREATED", "Created order ID #101 (1 items, Total: 360.00)", "SUCCESS");
            assertTrue("Audit log recorded ORDER_CREATED", mockAuditDAO.hasAction("ORDER_CREATED"));

            // Order Status Updated
            orderService.updateOrderStatus(101, "PREPARING");
            assertTrue("Audit log recorded ORDER_UPDATED", mockAuditDAO.hasAction("ORDER_UPDATED"));

            // Order Cancelled
            orderService.cancelOrder(102);
            assertTrue("Audit log recorded ORDER_CANCELLED", mockAuditDAO.hasAction("ORDER_CANCELLED"));

            // Bill Generated Audit
            auditService.log("BILLING", "BILL_GENERATED", "Generated BILL-20260822-0101 for order #101 (Grand Total: 360.00)", "SUCCESS");
            assertTrue("Audit log recorded BILL_GENERATED", mockAuditDAO.hasAction("BILL_GENERATED"));

        } catch (ValidationException e) {
            assertTrue("Order/Billing operations should succeed: " + e.getMessage(), false);
        } finally {
            UserSession.logout();
        }
    }

    // 9. Settings Auditing
    private static void testSettingsAuditingAndAccessControl() {
        System.out.println("\n[TEST GROUP 9] Settings Configuration Auditing");

        MockAuditLogDAO mockAuditDAO = new MockAuditLogDAO();
        AuditService auditService = new AuditService(mockAuditDAO);
        MockSettingsDAO mockSettingsDAO = new MockSettingsDAO();
        SettingsService settingsService = new SettingsService(mockSettingsDAO, auditService);

        UserSession.login(new User(1, "admin", "admin123", "ADMIN"));
        try {
            RestaurantSettings s = new RestaurantSettings();
            s.setRestaurantName("Royal Feast Dine");
            s.setEmail("dine@royalfeast.com");
            s.setTaxRate(5.0);

            boolean saved = settingsService.saveSettings(s);
            assertTrue("Settings saved", saved);
            assertTrue("Audit log recorded SETTINGS_UPDATED", mockAuditDAO.hasAction("SETTINGS_UPDATED"));
        } catch (ValidationException e) {
            assertTrue("Settings save should succeed for admin", false);
        } finally {
            UserSession.logout();
        }
    }

    // 10. Maintenance Auditing
    private static void testMaintenanceAuditingAndAccessControl() {
        System.out.println("\n[TEST GROUP 10] System Maintenance Auditing");

        MockAuditLogDAO mockAuditDAO = new MockAuditLogDAO();
        AuditService auditService = new AuditService(mockAuditDAO);
        MockMaintenanceDAO mockMaintDAO = new MockMaintenanceDAO();
        MaintenanceService maintService = new MaintenanceService(mockMaintDAO, auditService);

        UserSession.login(new User(1, "admin", "admin123", "ADMIN"));
        try {
            maintService.requireAdminPermission();
            assertTrue("Admin permission granted", true);
        } catch (ValidationException e) {
            assertTrue("Admin permission check should pass", false);
        } finally {
            UserSession.logout();
        }
    }

    // 11. Staff Restricted Access & Audit Logging
    private static void testStaffRestrictedAccessAndAuditLogging() {
        System.out.println("\n[TEST GROUP 11] Staff Role Enforcement & ACCESS_DENIED Auditing");

        MockAuditLogDAO mockAuditDAO = new MockAuditLogDAO();
        AuditService auditService = new AuditService(mockAuditDAO);
        MockSettingsDAO mockSettingsDAO = new MockSettingsDAO();
        SettingsService settingsService = new SettingsService(mockSettingsDAO, auditService);
        MockMaintenanceDAO mockMaintDAO = new MockMaintenanceDAO();
        MaintenanceService maintService = new MaintenanceService(mockMaintDAO, auditService);

        UserSession.login(new User(2, "staff", "staff123", "STAFF"));

        // 1. Staff accessing Audit Logs -> DENIED
        try {
            auditService.getAuditLogs(null, null, null, null, null, null, null, 1, 10);
            assertTrue("Staff access to audit logs must be denied", false);
        } catch (ValidationException e) {
            assertTrue("Staff access to audit logs was rejected with ValidationException", true);
            assertTrue("Audit log recorded ACCESS_DENIED for audit logs", mockAuditDAO.hasAction("ACCESS_DENIED"));
        }

        // 2. Staff saving Settings -> DENIED
        try {
            RestaurantSettings s = new RestaurantSettings();
            s.setRestaurantName("Hacked Restaurant");
            settingsService.saveSettings(s);
            assertTrue("Staff modifying settings must be denied", false);
        } catch (ValidationException e) {
            assertTrue("Staff settings modification was rejected with ValidationException", true);
        }

        // 3. Staff maintenance operation -> DENIED
        try {
            maintService.requireAdminPermission();
            assertTrue("Staff maintenance permission must be denied", false);
        } catch (ValidationException e) {
            assertTrue("Staff maintenance permission check was rejected with ValidationException", true);
        }

        UserSession.logout();
    }

    // 12. Strict No-Payment Architecture Compliance
    private static void testStrictNoPaymentArchitectureCompliance() {
        System.out.println("\n[TEST GROUP 12] Strict No-Payment System Compliance");

        String[] forbiddenPaymentClasses = {
            "Payment", "PaymentService", "PaymentDAO", "PaymentController",
            "PaymentGateway", "UPIPayment", "CreditCardPayment", "CashTransaction",
            "PaymentStatus", "PaymentMethod", "PaymentRecord", "RefundService"
        };

        boolean violation = false;
        for (String className : forbiddenPaymentClasses) {
            try {
                Class.forName("com.restaurantbilling.model." + className);
                violation = true;
            } catch (ClassNotFoundException ignored) {}
            try {
                Class.forName("com.restaurantbilling.service." + className);
                violation = true;
            } catch (ClassNotFoundException ignored) {}
            try {
                Class.forName("com.restaurantbilling.dao." + className);
                violation = true;
            } catch (ClassNotFoundException ignored) {}
        }

        assertTrue("Zero payment models, services, or DAOs exist in codebase", !violation);
    }

    // ==========================================
    // MOCK DAO IMPLEMENTATIONS FOR ISOLATED TESTING
    // ==========================================

    static class MockAuditLogDAO implements AuditLogDAO {
        List<AuditLog> logs = new ArrayList<>();

        @Override
        public void save(AuditLog log) {
            log.setId(logs.size() + 1);
            logs.add(log);
        }

        @Override
        public List<AuditLog> search(String keyword, String username, String module, String action, String status, LocalDate fromDate, LocalDate toDate, int limit, int offset) {
            List<AuditLog> filtered = new ArrayList<>();
            for (AuditLog l : logs) {
                if (module != null && !"ALL".equalsIgnoreCase(module) && !module.equalsIgnoreCase(l.getModule())) continue;
                if (action != null && !"ALL".equalsIgnoreCase(action) && !action.equalsIgnoreCase(l.getAction())) continue;
                if (status != null && !"ALL".equalsIgnoreCase(status) && !status.equalsIgnoreCase(l.getStatus())) continue;
                if (username != null && !username.trim().isEmpty() && !"ALL".equalsIgnoreCase(username) && !username.equalsIgnoreCase(l.getUsername())) continue;
                filtered.add(l);
            }
            return filtered;
        }

        @Override
        public int count(String keyword, String username, String module, String action, String status, LocalDate fromDate, LocalDate toDate) {
            return search(keyword, username, module, action, status, fromDate, toDate, 1000, 0).size();
        }

        @Override
        public void initAuditTableIfNotExists() {}

        public boolean hasAction(String actionName) {
            return logs.stream().anyMatch(l -> actionName.equalsIgnoreCase(l.getAction()));
        }
    }

    static class MockUserDAO implements UserDAO {
        Map<String, User> users = new HashMap<>();

        @Override
        public Optional<User> findByUsername(String username) {
            return Optional.ofNullable(users.get(username));
        }

        @Override
        public Optional<User> authenticate(String username, String password) {
            User u = users.get(username);
            if (u != null && PasswordUtil.verifyPassword(password, u.getPassword())) {
                return Optional.of(u);
            }
            return Optional.empty();
        }

        @Override
        public boolean updatePassword(int userId, String newHashedPassword) {
            for (User u : users.values()) {
                if (u.getId() == userId) {
                    u.setPassword(newHashedPassword);
                    return true;
                }
            }
            return false;
        }
    }

    static class MockFoodItemDAO implements FoodItemDAO {
        Map<Integer, FoodItem> items = new HashMap<>();
        int seq = 1;

        @Override
        public List<FoodItem> findAll() { return new ArrayList<>(items.values()); }
        @Override
        public Optional<FoodItem> findById(int id) { return Optional.ofNullable(items.get(id)); }
        @Override
        public List<FoodItem> search(String keyword, String category) { return new ArrayList<>(items.values()); }
        @Override
        public FoodItem save(FoodItem item) { item.setId(seq++); items.put(item.getId(), item); return item; }
        @Override
        public boolean update(FoodItem item) { items.put(item.getId(), item); return true; }
        @Override
        public boolean delete(int id) { return items.remove(id) != null; }
        @Override
        public int countTotalItems() { return items.size(); }
    }

    static class MockCustomerDAO implements CustomerDAO {
        Map<Integer, Customer> map = new HashMap<>();
        int seq = 1;

        @Override
        public List<Customer> findAll() { return new ArrayList<>(map.values()); }
        @Override
        public Optional<Customer> findById(int id) { return Optional.ofNullable(map.get(id)); }
        @Override
        public Optional<Customer> findByPhone(String phone) { return map.values().stream().filter(c -> c.getPhone().equals(phone)).findFirst(); }
        @Override
        public List<Customer> search(String keyword, String status) { return new ArrayList<>(map.values()); }
        @Override
        public Customer save(Customer customer) { customer.setId(seq++); map.put(customer.getId(), customer); return customer; }
        @Override
        public boolean update(Customer customer) { map.put(customer.getId(), customer); return true; }
        @Override
        public boolean updateStatus(int id, String status) { if (map.containsKey(id)) { map.get(id).setStatus(status); return true; } return false; }
        @Override
        public boolean delete(int id) { return map.remove(id) != null; }
        @Override
        public boolean isPhoneRegistered(String phone, int excludeCustomerId) { return map.values().stream().anyMatch(c -> c.getPhone().equals(phone) && c.getId() != excludeCustomerId); }
        @Override
        public int countActiveCustomers() { return (int) map.values().stream().filter(c -> "Active".equalsIgnoreCase(c.getStatus())).count(); }
    }

    static class MockOrderDAO implements OrderDAO {
        Map<Integer, Order> orders = new HashMap<>();
        int seq = 1;

        @Override
        public int createOrder(Connection conn, Order order) { order.setId(seq++); orders.put(order.getId(), order); return order.getId(); }
        @Override
        public Optional<Order> findById(int id) { return Optional.ofNullable(orders.get(id)); }
        @Override
        public List<Order> findAll() { return new ArrayList<>(orders.values()); }
        @Override
        public List<Order> search(String keyword, String status) { return new ArrayList<>(orders.values()); }
        @Override
        public boolean updateStatus(int id, String status) { if (orders.containsKey(id)) { orders.get(id).setStatus(status); return true; } return false; }
        @Override
        public boolean cancelOrder(int id) { if (orders.containsKey(id)) { orders.get(id).setStatus("CANCELLED"); return true; } return false; }
        @Override
        public int countTotalOrders() { return orders.size(); }
    }

    static class MockOrderItemDAO implements OrderItemDAO {
        Map<Integer, List<OrderItem>> map = new HashMap<>();
        @Override
        public void createOrderItems(Connection conn, int orderId, List<OrderItem> items) { map.put(orderId, items); }
        @Override
        public List<OrderItem> findByOrderId(int orderId) { return map.getOrDefault(orderId, new ArrayList<>()); }
        @Override
        public boolean deleteByOrderId(Connection conn, int orderId) { map.remove(orderId); return true; }
    }

    static class MockBillDAO implements BillDAO {
        Map<Integer, com.restaurantbilling.model.Bill> bills = new HashMap<>();
        int seq = 1;
        @Override
        public com.restaurantbilling.model.Bill createBill(Connection conn, com.restaurantbilling.model.Bill bill) {
            bill.setId(seq++);
            bills.put(bill.getOrderId(), bill);
            return bill;
        }
        @Override
        public com.restaurantbilling.model.Bill createBill(com.restaurantbilling.model.Bill bill) {
            bill.setId(seq++);
            bills.put(bill.getOrderId(), bill);
            return bill;
        }
        @Override
        public Optional<com.restaurantbilling.model.Bill> findById(int id) { return bills.values().stream().filter(b -> b.getId() == id).findFirst(); }
        @Override
        public Optional<com.restaurantbilling.model.Bill> findByOrderId(int orderId) { return Optional.ofNullable(bills.get(orderId)); }
        @Override
        public Optional<com.restaurantbilling.model.Bill> findByBillNumber(String billNumber) { return bills.values().stream().filter(b -> b.getBillNumber().equalsIgnoreCase(billNumber)).findFirst(); }
        @Override
        public List<com.restaurantbilling.model.Bill> findAll() { return new ArrayList<>(bills.values()); }
        @Override
        public List<com.restaurantbilling.model.Bill> searchBills(String keyword) { return new ArrayList<>(bills.values()); }
        @Override
        public boolean isOrderBilled(int orderId) { return bills.containsKey(orderId); }
        @Override
        public int countTotalBills() { return bills.size(); }
    }

    static class MockSettingsDAO implements SettingsDAO {
        RestaurantSettings settings = new RestaurantSettings();
        @Override
        public RestaurantSettings getRestaurantSettings() { return settings; }
        @Override
        public boolean saveAllSettings(RestaurantSettings s, String updatedBy) { this.settings = s; return true; }
        @Override
        public Optional<String> getSetting(String key) { return Optional.empty(); }
        @Override
        public Map<String, String> getAllSettings() { return Map.of(); }
        @Override
        public boolean saveSetting(String key, String value, String updatedBy) { return true; }
    }

    static class MockMaintenanceDAO implements MaintenanceDAO {
        List<BackupRecord> list = new ArrayList<>();
        @Override
        public DatabaseHealth checkDatabaseHealth() { return new DatabaseHealth(); }
        @Override
        public Map<String, Long> getTableRecordCounts() { return Map.of(); }
        @Override
        public List<String> checkDataConsistency() { return List.of(); }
        @Override
        public void logBackupRecord(BackupRecord r) { list.add(r); }
        @Override
        public List<BackupRecord> getBackupHistory() { return list; }
        @Override
        public void initBackupHistoryTableIfNotExists() {}
    }
}
