package com.restaurantbilling;

import com.restaurantbilling.model.Order;
import com.restaurantbilling.model.OrderItem;
import com.restaurantbilling.util.FormatUtil;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class OrderServiceTest {
    public static void main(String[] args) {
        System.out.println("Running Phase 9 Order Calculation & Business Logic Tests...");
        int passed = 0;
        int failed = 0;

        // Test 1: Single item line total
        try {
            OrderItem item = new OrderItem(1, "Pizza", 2, new BigDecimal("250.00"));
            if (new BigDecimal("500.00").compareTo(item.getSubtotal()) == 0) {
                System.out.println("[PASS] Test 1: Single item line total (250 * 2 = 500)");
                passed++;
            } else {
                System.err.println("[FAIL] Test 1: Expected 500.00 but got " + item.getSubtotal());
                failed++;
            }
        } catch (Exception e) {
            System.err.println("[FAIL] Test 1: " + e.getMessage());
            failed++;
        }

        // Test 2: Multiple items Subtotal
        try {
            List<OrderItem> items = new ArrayList<>();
            items.add(new OrderItem(1, "Pizza", 2, new BigDecimal("250.00"))); // 500
            items.add(new OrderItem(2, "Burger", 1, new BigDecimal("150.00"))); // 150
            items.add(new OrderItem(3, "Coke", 2, new BigDecimal("50.00")));    // 100

            BigDecimal subtotal = BigDecimal.ZERO;
            for (OrderItem item : items) {
                subtotal = subtotal.add(item.getSubtotal());
            }

            if (new BigDecimal("750.00").compareTo(subtotal) == 0) {
                System.out.println("[PASS] Test 2: Multiple items subtotal (500 + 150 + 100 = 750)");
                passed++;
            } else {
                System.err.println("[FAIL] Test 2: Expected 750.00 but got " + subtotal);
                failed++;
            }
        } catch (Exception e) {
            System.err.println("[FAIL] Test 2: " + e.getMessage());
            failed++;
        }

        // Test 3: Grand Total Calculation (Subtotal - Discount + Tax)
        try {
            BigDecimal subtotal = new BigDecimal("1000.00");
            BigDecimal discount = new BigDecimal("100.00");
            BigDecimal tax = new BigDecimal("50.00");
            BigDecimal total = subtotal.subtract(discount).add(tax);

            if (new BigDecimal("950.00").compareTo(total) == 0) {
                System.out.println("[PASS] Test 3: Total calculation (1000 - 100 + 50 = 950)");
                passed++;
            } else {
                System.err.println("[FAIL] Test 3: Expected 950.00 but got " + total);
                failed++;
            }
        } catch (Exception e) {
            System.err.println("[FAIL] Test 3: " + e.getMessage());
            failed++;
        }

        // Test 4: Currency formatting
        try {
            String formatted = FormatUtil.formatCurrency(new BigDecimal("1250.50"));
            if (formatted.contains("1,250.50")) {
                System.out.println("[PASS] Test 4: Currency formatting (₹1,250.50)");
                passed++;
            } else {
                System.err.println("[FAIL] Test 4: Formatted output mismatch: " + formatted);
                failed++;
            }
        } catch (Exception e) {
            System.err.println("[FAIL] Test 4: " + e.getMessage());
            failed++;
        }

        // Test 5: Historical price preservation in OrderItem
        try {
            BigDecimal historicalPrice = new BigDecimal("150.00");
            OrderItem item = new OrderItem(1, "Burger", 2, historicalPrice);
            // Simulate menu price changing later to 180.00
            BigDecimal updatedMenuPrice = new BigDecimal("180.00");

            if (item.getUnitPrice().compareTo(historicalPrice) == 0 && item.getSubtotal().compareTo(new BigDecimal("300.00")) == 0) {
                System.out.println("[PASS] Test 5: Historical price preserved in OrderItem");
                passed++;
            } else {
                System.err.println("[FAIL] Test 5: Historical price altered");
                failed++;
            }
        } catch (Exception e) {
            System.err.println("[FAIL] Test 5: " + e.getMessage());
            failed++;
        }

        System.out.println("--------------------------------------------------");
        System.out.println("Tests Completed: " + (passed + failed) + " | Passed: " + passed + " | Failed: " + failed);
    }
}
