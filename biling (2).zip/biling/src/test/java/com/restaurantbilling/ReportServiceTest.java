package com.restaurantbilling;

import com.restaurantbilling.exception.ValidationException;
import com.restaurantbilling.model.report.*;
import com.restaurantbilling.report.ReportGenerator;
import com.restaurantbilling.service.ReportService;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class ReportServiceTest {
    public static void main(String[] args) {
        System.out.println("Running Phase 11 Reports & Analytics Tests...");
        int passed = 0;
        int failed = 0;

        ReportService reportService = new ReportService();

        // Test 1: Valid Date Range
        try {
            reportService.validateDateRange("2026-08-01", "2026-08-31");
            System.out.println("[PASS] Test 1: Valid date range accepted (2026-08-01 to 2026-08-31)");
            passed++;
        } catch (Exception e) {
            System.err.println("[FAIL] Test 1: " + e.getMessage());
            failed++;
        }

        // Test 2: Invalid Date Range (From > To)
        try {
            reportService.validateDateRange("2026-08-31", "2026-08-01");
            System.err.println("[FAIL] Test 2: Inverted date range was not rejected");
            failed++;
        } catch (ValidationException e) {
            System.out.println("[PASS] Test 2: Inverted date range rejected -> " + e.getMessage());
            passed++;
        }

        // Test 3: Invalid Date Format
        try {
            reportService.validateDateRange("01/08/2026", "31/08/2026");
            System.err.println("[FAIL] Test 3: Invalid date format was not rejected");
            failed++;
        } catch (ValidationException e) {
            System.out.println("[PASS] Test 3: Invalid date format rejected -> " + e.getMessage());
            passed++;
        }

        // Test 4: Bill Summary DTO calculation
        try {
            BillSummaryDTO summary = new BillSummaryDTO(
                10,
                new BigDecimal("5000.00"),
                new BigDecimal("500.00"),
                new BigDecimal("1200.00"),
                new BigDecimal("150.00")
            );
            if (summary.getTotalBills() == 10 && summary.getAverageBillAmount().compareTo(new BigDecimal("500.00")) == 0) {
                System.out.println("[PASS] Test 4: BillSummaryDTO calculations verified");
                passed++;
            } else {
                System.err.println("[FAIL] Test 4: BillSummaryDTO mismatch");
                failed++;
            }
        } catch (Exception e) {
            System.err.println("[FAIL] Test 4: " + e.getMessage());
            failed++;
        }

        // Test 5: Item Sales DTO sorting / structure
        try {
            ItemSalesDTO item1 = new ItemSalesDTO(1, "Paneer Tikka", "Starter", 50, new BigDecimal("9000.00"));
            ItemSalesDTO item2 = new ItemSalesDTO(2, "Veg Biryani", "Main Course", 80, new BigDecimal("17600.00"));
            if (item1.getQuantitySold() == 50 && item2.getRevenue().compareTo(new BigDecimal("17600.00")) == 0) {
                System.out.println("[PASS] Test 5: ItemSalesDTO revenue and metrics verified");
                passed++;
            } else {
                System.err.println("[FAIL] Test 5: ItemSalesDTO mismatch");
                failed++;
            }
        } catch (Exception e) {
            System.err.println("[FAIL] Test 5: " + e.getMessage());
            failed++;
        }

        // Test 6: Report Generator text formatting and strict No-Payment compliance
        try {
            BillSummaryDTO billSum = new BillSummaryDTO(5, new BigDecimal("2500.00"), new BigDecimal("500.00"), new BigDecimal("800.00"), new BigDecimal("200.00"));
            OrderSummaryDTO ordSum = new OrderSummaryDTO(5, 5, 0, 0, 0, new BigDecimal("2500.00"));
            CustomerSummaryDTO custSum = new CustomerSummaryDTO(10, 8, 5, 0.5);

            List<ItemSalesDTO> items = new ArrayList<>();
            items.add(new ItemSalesDTO(1, "Paneer Tikka", "Starter", 10, new BigDecimal("1800.00")));

            ReportGenerator gen = new ReportGenerator("Executive Monthly Report", "2026-08-01 to 2026-08-31", billSum, ordSum, custSum, items);
            String reportText = gen.generateTextReport();

            boolean validContent = reportText.contains("RESTAURANT BILLING & ANALYTICS REPORT") &&
                                   reportText.contains("Total Bills Generated : 5") &&
                                   reportText.contains("Paneer Tikka");

            String lower = reportText.toLowerCase();
            boolean noPayment = !lower.contains("cash report") &&
                                !lower.contains("card report") &&
                                !lower.contains("upi report") &&
                                !lower.contains("payment method") &&
                                !lower.contains("transaction ref");

            if (validContent && noPayment) {
                System.out.println("[PASS] Test 6: ReportGenerator output & No-Payment compliance verified");
                passed++;
            } else {
                System.err.println("[FAIL] Test 6: Report formatting or payment compliance failure");
                failed++;
            }
        } catch (Exception e) {
            System.err.println("[FAIL] Test 6: " + e.getMessage());
            failed++;
        }

        System.out.println("--------------------------------------------------");
        System.out.println("Tests Completed: " + (passed + failed) + " | Passed: " + passed + " | Failed: " + failed);
    }
}
