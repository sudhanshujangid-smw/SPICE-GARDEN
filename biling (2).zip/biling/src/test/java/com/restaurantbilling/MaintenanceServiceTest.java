package com.restaurantbilling;

import com.restaurantbilling.dao.MaintenanceDAO;
import com.restaurantbilling.exception.DatabaseException;
import com.restaurantbilling.exception.ValidationException;
import com.restaurantbilling.model.User;
import com.restaurantbilling.model.maintenance.BackupRecord;
import com.restaurantbilling.model.maintenance.DatabaseHealth;
import com.restaurantbilling.service.MaintenanceService;
import com.restaurantbilling.util.DatabaseBackupUtil;
import com.restaurantbilling.util.DatabaseRestoreUtil;
import com.restaurantbilling.util.UserSession;

import java.io.File;
import java.nio.file.Files;
import java.time.LocalDateTime;
import java.util.*;

public class MaintenanceServiceTest {

    // Test Stub DAO for deterministic testing
    static class StubMaintenanceDAO implements MaintenanceDAO {
        private final List<BackupRecord> records = new ArrayList<>();

        @Override
        public DatabaseHealth checkDatabaseHealth() {
            DatabaseHealth h = new DatabaseHealth();
            h.setConnected(true);
            h.setDatabaseName("restaurant_billing");
            h.setServerHost("localhost:3306");
            h.setDatabaseVersion("MySQL 8.3.0-Community");
            h.setMissingTables(Collections.emptyList());
            Map<String, Long> counts = new HashMap<>();
            counts.put("food_items", 25L);
            counts.put("customers", 40L);
            counts.put("orders", 120L);
            counts.put("bills", 115L);
            counts.put("system_settings", 12L);
            h.setTableCounts(counts);
            h.setConsistencyIssues(Collections.emptyList());
            h.setStatus(DatabaseHealth.HealthStatus.HEALTHY);
            return h;
        }

        @Override
        public Map<String, Long> getTableRecordCounts() {
            Map<String, Long> map = new LinkedHashMap<>();
            map.put("food_items", 25L);
            map.put("customers", 40L);
            map.put("orders", 120L);
            map.put("bills", 115L);
            map.put("system_settings", 12L);
            return map;
        }

        @Override
        public List<String> checkDataConsistency() {
            return Collections.emptyList();
        }

        @Override
        public void logBackupRecord(BackupRecord record) {
            record.setId(records.size() + 1);
            records.add(record);
        }

        @Override
        public List<BackupRecord> getBackupHistory() {
            return new ArrayList<>(records);
        }

        @Override
        public void initBackupHistoryTableIfNotExists() {
        }
    }

    public static void main(String[] args) {
        System.out.println("============================================================");
        System.out.println("Running Phase 13 Backup, Data Management & Maintenance Tests");
        System.out.println("============================================================");

        int passed = 0;
        int failed = 0;

        MaintenanceDAO stubDao = new StubMaintenanceDAO();
        MaintenanceService service = new MaintenanceService(stubDao);

        // Test 1: Admin Permission Allowed
        try {
            User admin = new User(1, "admin", "admin123", "ADMIN");
            UserSession.login(admin);
            service.requireAdminPermission();
            System.out.println("[PASS] Test 1: Admin user granted maintenance permission.");
            passed++;
        } catch (Exception e) {
            System.err.println("[FAIL] Test 1: " + e.getMessage());
            failed++;
        }

        // Test 2: Staff User Restricted from Destructive Maintenance
        try {
            User staff = new User(2, "staff", "staff123", "STAFF");
            UserSession.login(staff);
            service.requireAdminPermission();
            System.err.println("[FAIL] Test 2: Staff user was not restricted!");
            failed++;
        } catch (ValidationException e) {
            System.out.println("[PASS] Test 2: Staff user correctly restricted -> " + e.getMessage());
            passed++;
        }

        // Restore admin session
        UserSession.login(new User(1, "admin", "admin123", "ADMIN"));

        // Test 3: Database Health & Metadata Retrieval
        try {
            DatabaseHealth health = service.getHealthStatus();
            if (health != null && health.isConnected() && health.getStatus() == DatabaseHealth.HealthStatus.HEALTHY) {
                System.out.println("[PASS] Test 3: Database health check executed (Status: " + health.getStatus() + ", DB: " + health.getDatabaseName() + ", Engine: " + health.getDatabaseVersion() + ")");
                passed++;
            } else {
                System.err.println("[FAIL] Test 3: Health status mismatch.");
                failed++;
            }
        } catch (Exception e) {
            System.err.println("[FAIL] Test 3: " + e.getMessage());
            failed++;
        }

        // Test 4: Live Data Summary Counts
        try {
            Map<String, Long> summary = service.getDataSummary();
            if (summary != null && summary.containsKey("food_items") && summary.containsKey("orders") && summary.get("food_items") == 25L) {
                System.out.println("[PASS] Test 4: Live data summary retrieved for tables: " + summary);
                passed++;
            } else {
                System.err.println("[FAIL] Test 4: Data summary missing required table keys.");
                failed++;
            }
        } catch (Exception e) {
            System.err.println("[FAIL] Test 4: " + e.getMessage());
            failed++;
        }

        // Test 5: Non-Destructive Data Consistency Verification
        try {
            List<String> consistency = service.checkDataConsistency();
            if (consistency != null && consistency.isEmpty()) {
                System.out.println("[PASS] Test 5: Non-destructive data consistency check completed (No issues detected).");
                passed++;
            } else {
                System.err.println("[FAIL] Test 5: Consistency issues detected unexpectedly.");
                failed++;
            }
        } catch (Exception e) {
            System.err.println("[FAIL] Test 5: " + e.getMessage());
            failed++;
        }

        // Test 6: Backup File Validation Logic
        try {
            File validBackupFile = new File("target/test-backups/sample_backup.sql");
            if (!validBackupFile.getParentFile().exists()) {
                validBackupFile.getParentFile().mkdirs();
            }
            Files.writeString(validBackupFile.toPath(), "-- Restaurant Billing System SQL Dump\nCREATE TABLE IF NOT EXISTS food_items (id INT);\nINSERT INTO food_items VALUES (1);");

            DatabaseBackupUtil.validateBackupFile(validBackupFile);
            System.out.println("[PASS] Test 6: SQL backup file structure validated successfully.");
            passed++;
        } catch (Exception e) {
            System.err.println("[FAIL] Test 6: " + e.getMessage());
            failed++;
        }

        // Test 7: Invalid Backup Validation & Rejection
        try {
            // 7A: Empty file
            File emptyFile = new File("target/test-backups/empty_backup.sql");
            Files.writeString(emptyFile.toPath(), "");
            try {
                DatabaseRestoreUtil.validateRestoreFile(emptyFile);
                System.err.println("[FAIL] Test 7A: Empty backup was not rejected.");
                failed++;
            } catch (ValidationException ex) {
                System.out.println("[PASS] Test 7A: Empty backup rejected -> " + ex.getMessage());
                passed++;
            }

            // 7B: Non-.sql file
            File invalidExtFile = new File("target/test-backups/test_backup.txt");
            Files.writeString(invalidExtFile.toPath(), "test data");
            try {
                DatabaseRestoreUtil.validateRestoreFile(invalidExtFile);
                System.err.println("[FAIL] Test 7B: Non-.sql backup was not rejected.");
                failed++;
            } catch (ValidationException ex) {
                System.out.println("[PASS] Test 7B: Invalid extension rejected -> " + ex.getMessage());
                passed++;
            }

            // 7C: Non-existent file
            File nonExistent = new File("target/test-backups/does_not_exist.sql");
            try {
                DatabaseRestoreUtil.validateRestoreFile(nonExistent);
                System.err.println("[FAIL] Test 7C: Non-existent backup was not rejected.");
                failed++;
            } catch (ValidationException ex) {
                System.out.println("[PASS] Test 7C: Non-existent file rejected -> " + ex.getMessage());
                passed++;
            }

        } catch (Exception e) {
            System.err.println("[FAIL] Test 7: " + e.getMessage());
            failed++;
        }

        // Test 8: Backup History Logging & Retrieval
        try {
            BackupRecord r = new BackupRecord(1, "restaurant_backup_2026-08-22.sql", "C:/backups/restaurant_backup_2026-08-22.sql", 1048576L, LocalDateTime.now(), "admin", "SUCCESS", "MANUAL");
            stubDao.logBackupRecord(r);

            List<BackupRecord> history = service.getBackupHistory();
            if (history != null && !history.isEmpty() && "restaurant_backup_2026-08-22.sql".equals(history.get(0).getBackupName())) {
                System.out.println("[PASS] Test 8: Backup history logged and retrieved successfully (Entry: " + history.get(0).getBackupName() + ")");
                passed++;
            } else {
                System.err.println("[FAIL] Test 8: Backup history is empty or mismatched.");
                failed++;
            }
        } catch (Exception e) {
            System.err.println("[FAIL] Test 8: " + e.getMessage());
            failed++;
        }

        // Test 9: Tool Discovery (mysqldump & mysql path search)
        try {
            String dumpPath = DatabaseBackupUtil.findMysqldumpPath();
            String mysqlPath = DatabaseRestoreUtil.findMysqlPath();
            System.out.println("[PASS] Test 9: MySQL binary utility detection executed (mysqldump: " + dumpPath + ", mysql: " + mysqlPath + ")");
            passed++;
        } catch (Exception e) {
            System.err.println("[FAIL] Test 9: " + e.getMessage());
            failed++;
        }

        // Test 10: Strict No-Payment Compliance
        try {
            boolean noPaymentMethods = true;
            for (java.lang.reflect.Method m : MaintenanceService.class.getDeclaredMethods()) {
                if (m.getName().toLowerCase().contains("payment")) {
                    noPaymentMethods = false;
                    break;
                }
            }
            for (java.lang.reflect.Field f : DatabaseHealth.class.getDeclaredFields()) {
                if (f.getName().toLowerCase().contains("payment")) {
                    noPaymentMethods = false;
                    break;
                }
            }
            if (noPaymentMethods) {
                System.out.println("[PASS] Test 10: Strict No-Payment compliance verified in Maintenance module.");
                passed++;
            } else {
                System.err.println("[FAIL] Test 10: Forbidden payment member detected!");
                failed++;
            }
        } catch (Exception e) {
            System.err.println("[FAIL] Test 10: " + e.getMessage());
            failed++;
        }

        System.out.println("============================================================");
        System.out.println("Total Tests: " + (passed + failed) + " | Passed: " + passed + " | Failed: " + failed);
        System.out.println("============================================================");
    }
}
