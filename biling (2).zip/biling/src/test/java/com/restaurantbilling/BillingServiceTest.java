package com.restaurantbilling;

import com.restaurantbilling.invoice.InvoiceGenerator;
import com.restaurantbilling.model.Bill;
import com.restaurantbilling.model.OrderItem;
import com.restaurantbilling.util.FormatUtil;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

public class BillingServiceTest {
    public static void main(String[] args) {
        System.out.println("Running Phase 10 Bill Generation & Invoice Tests...");
        int passed = 0;
        int failed = 0;

        // Test 1: Bill calculation (Subtotal - Discount + Tax = Final Amount)
        try {
            BigDecimal subtotal = new BigDecimal("850.00");
            BigDecimal discount = new BigDecimal("50.00");
            BigDecimal tax = new BigDecimal("40.00");
            BigDecimal finalAmount = subtotal.subtract(discount).add(tax);

            Bill bill = new Bill(101, "BILL-20260822-0101", subtotal, discount, tax, finalAmount);
            if (bill.getFinalAmount().compareTo(new BigDecimal("840.00")) == 0) {
                System.out.println("[PASS] Test 1: Bill calculation (850 - 50 + 40 = 840.00)");
                passed++;
            } else {
                System.err.println("[FAIL] Test 1: Calculation mismatch");
                failed++;
            }
        } catch (Exception e) {
            System.err.println("[FAIL] Test 1: " + e.getMessage());
            failed++;
        }

        // Test 2: Invoice formatting and structure
        try {
            Bill bill = new Bill(101, "BILL-20260822-0101", new BigDecimal("650.00"), BigDecimal.ZERO, BigDecimal.ZERO, new BigDecimal("650.00"));
            bill.setCustomerName("Rahul Sharma");
            bill.setCustomerPhone("9876543210");
            bill.setBillDate(new Timestamp(System.currentTimeMillis()));

            List<OrderItem> items = new ArrayList<>();
            items.add(new OrderItem(1, "Paneer Tikka", 2, new BigDecimal("180.00")));
            items.add(new OrderItem(2, "Veg Biryani", 1, new BigDecimal("220.00")));
            items.add(new OrderItem(3, "Garlic Naan", 1, new BigDecimal("70.00")));
            bill.setItems(items);

            InvoiceGenerator generator = new InvoiceGenerator(bill);
            String receipt = generator.generateTextReceipt();
            String currentRestaurantName = com.restaurantbilling.util.ApplicationSettings.getInstance().getRestaurantName();

            if (receipt.contains(currentRestaurantName) &&
                receipt.contains("BILL-20260822-0101") &&
                receipt.contains("Rahul Sharma") &&
                receipt.contains("Paneer Tikka") &&
                receipt.contains("GRAND TOTAL:")) {
                System.out.println("[PASS] Test 2: Professional text receipt generation verified");
                passed++;
            } else {
                System.err.println("[FAIL] Test 2: Receipt output missing expected tokens");
                failed++;
            }
        } catch (Exception e) {
            System.err.println("[FAIL] Test 2: " + e.getMessage());
            failed++;
        }

        // Test 3: NO Payment functionality compliance test
        try {
            Bill bill = new Bill(102, "BILL-20260822-0102", new BigDecimal("500.00"), BigDecimal.ZERO, BigDecimal.ZERO, new BigDecimal("500.00"));
            InvoiceGenerator generator = new InvoiceGenerator(bill);
            String receipt = generator.generateTextReceipt().toLowerCase();

            boolean containsPaymentTerms = receipt.contains("payment method") ||
                                          receipt.contains("amount received") ||
                                          receipt.contains("change returned") ||
                                          receipt.contains("transaction id") ||
                                          receipt.contains("paid status");

            if (!containsPaymentTerms) {
                System.out.println("[PASS] Test 3: Strict No-Payment compliance verified in generated invoice");
                passed++;
            } else {
                System.err.println("[FAIL] Test 3: Found prohibited payment terms in invoice");
                failed++;
            }
        } catch (Exception e) {
            System.err.println("[FAIL] Test 3: " + e.getMessage());
            failed++;
        }

        // Test 4: HTML Invoice Generation
        try {
            Bill bill = new Bill(103, "BILL-20260822-0103", new BigDecimal("300.00"), BigDecimal.ZERO, BigDecimal.ZERO, new BigDecimal("300.00"));
            bill.setCustomerName("Priya Patel");
            InvoiceGenerator generator = new InvoiceGenerator(bill);
            String html = generator.generateHtmlInvoice();

            if (html.contains("<!DOCTYPE html>") && html.contains("BILL-20260822-0103") && html.contains("Priya Patel")) {
                System.out.println("[PASS] Test 4: HTML printable invoice generation verified");
                passed++;
            } else {
                System.err.println("[FAIL] Test 4: HTML invoice generation failed");
                failed++;
            }
        } catch (Exception e) {
            System.err.println("[FAIL] Test 4: " + e.getMessage());
            failed++;
        }

        System.out.println("--------------------------------------------------");
        System.out.println("Tests Completed: " + (passed + failed) + " | Passed: " + passed + " | Failed: " + failed);
    }
}
