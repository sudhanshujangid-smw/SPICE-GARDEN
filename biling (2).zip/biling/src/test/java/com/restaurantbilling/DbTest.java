package com.restaurantbilling;

import com.restaurantbilling.dao.impl.UserDAOImpl;
import com.restaurantbilling.model.User;
import java.util.Optional;

public class DbTest {
    public static void main(String[] args) {
        System.out.println("Testing UserDAOImpl...");
        try {
            UserDAOImpl dao = new UserDAOImpl();
            Optional<User> user = dao.findByUsername("admin");
            System.out.println("User found: " + user.isPresent());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
