package com.restaurantbilling;

import com.restaurantbilling.dao.ReportDAO;
import com.restaurantbilling.exception.ValidationException;
import com.restaurantbilling.invoice.InvoiceGenerator;
import com.restaurantbilling.model.Bill;
import com.restaurantbilling.model.OrderItem;
import com.restaurantbilling.model.User;
import com.restaurantbilling.model.report.*;
import com.restaurantbilling.report.CsvExporter;
import com.restaurantbilling.report.PdfDocumentGenerator;
import com.restaurantbilling.report.ReportGenerator;
import com.restaurantbilling.service.AuditService;
import com.restaurantbilling.service.ReportService;
import com.restaurantbilling.util.FormatUtil;
import com.restaurantbilling.util.UserSession;

import java.io.File;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.sql.Timestamp;
import java.util.*;

public class AdvancedReportingTest {

    private static int totalPassed = 0;
    private static int totalFailed = 0;

    public static void main(String[] args) {
        System.out.println("============================================================");
        System.out.println("PHASE 16: ADVANCED REPORTING & DOCUMENT GENERATION TEST SUITE");
        System.out.println("============================================================\n");

        testBillingSummaryCalculations();
        testDailyBillingAggregation();
        testMonthlyBillingAggregation();
        testOrderReportStructureAndFilter();
        testCustomerReportMetrics();
        testMenuItemReportMetrics();
        testTopSellingItemsRanking();
        testDateRangeFilteringAndValidation();
        testCsvExportGenerationAndEscaping();
        testPdfDocumentGeneration();
        testPrintPreviewAndTextFormatting();
        testBillDocumentConsistency();
        testEmptyDataHandling();
        testRoleBasedAccessControl();
        testReportAuditLogging();
        testStrictNoPaymentCompliance();

        System.out.println("\n============================================================");
        System.out.println("TEST RESULTS: " + totalPassed + " PASSED, " + totalFailed + " FAILED");
        System.out.println("============================================================");

        if (totalFailed > 0) {
            System.exit(1);
        }
    }

    private static void assertTrue(String testName, boolean condition) {
        if (condition) {
            System.out.println("  [PASS] " + testName);
            totalPassed++;
        } else {
            System.err.println("  [FAIL] " + testName);
            totalFailed++;
        }
    }

    private static void assertEquals(String testName, Object expected, Object actual) {
        boolean match = Objects.equals(expected, actual);
        if (match) {
            System.out.println("  [PASS] " + testName + " (Value: " + actual + ")");
            totalPassed++;
        } else {
            System.err.println("  [FAIL] " + testName + " — Expected: " + expected + ", Actual: " + actual);
            totalFailed++;
        }
    }

    // Mock ReportDAO for predictable deterministic testing
    private static class MockReportDAO implements ReportDAO {
        @Override
        public BillSummaryDTO getBillSummary(String fromDate, String toDate) {
            return new BillSummaryDTO(
                120,
                new BigDecimal("96000.00"),
                new BigDecimal("800.00"),
                new BigDecimal("4250.00"),
                new BigDecimal("120.00")
            );
        }

        @Override
        public OrderSummaryDTO getOrderSummary(String fromDate, String toDate) {
            return new OrderSummaryDTO(130, 115, 5, 5, 5, new BigDecimal("102000.00"));
        }

        @Override
        public CustomerSummaryDTO getCustomerSummary() {
            return new CustomerSummaryDTO(45, 40, 35, 2.88);
        }

        @Override
        public List<ItemSalesDTO> getItemSalesReport(String fromDate, String toDate, int limit) {
            List<ItemSalesDTO> list = new ArrayList<>();
            list.add(new ItemSalesDTO(1, "Paneer Butter Masala", "Main Course", 85, new BigDecimal("25500.00")));
            list.add(new ItemSalesDTO(2, "Butter Naan", "Breads", 140, new BigDecimal("7000.00")));
            list.add(new ItemSalesDTO(3, "Veg Biryani", "Main Course", 60, new BigDecimal("13200.00")));
            list.add(new ItemSalesDTO(4, "Crispy Corn", "Starters", 45, new BigDecimal("8100.00")));
            list.add(new ItemSalesDTO(5, "Gulab Jamun", "Dessert", 50, new BigDecimal("5000.00")));
            return list.subList(0, Math.min(limit, list.size()));
        }

        @Override
        public List<BillingTrendDTO> getDailyBillingTrend(String fromDate, String toDate) {
            List<BillingTrendDTO> list = new ArrayList<>();
            list.add(new BillingTrendDTO("2026-08-01", 18, 20, new BigDecimal("14400.00")));
            list.add(new BillingTrendDTO("2026-08-02", 22, 24, new BigDecimal("17600.00")));
            list.add(new BillingTrendDTO("2026-08-03", 15, 17, new BigDecimal("12000.00")));
            return list;
        }

        @Override
        public List<BillingTrendDTO> getMonthlyBillingReport(int year) {
            List<BillingTrendDTO> list = new ArrayList<>();
            list.add(new BillingTrendDTO("June", 520, 550, new BigDecimal("416000.00")));
            list.add(new BillingTrendDTO("July", 610, 640, new BigDecimal("488000.00")));
            list.add(new BillingTrendDTO("August", 430, 460, new BigDecimal("344000.00")));
            return list;
        }

        @Override
        public List<BillingTrendDTO> getMonthlyBillingReport(String fromDate, String toDate) {
            return getMonthlyBillingReport(2026);
        }

        @Override
        public List<OrderReportDTO> getOrderReport(String fromDate, String toDate, String status, int limit, int offset) {
            List<OrderReportDTO> list = new ArrayList<>();
            list.add(new OrderReportDTO(101, new Timestamp(System.currentTimeMillis()), "Rahul Sharma", 3, "COMPLETED", "BILL-1001", new BigDecimal("850.00")));
            list.add(new OrderReportDTO(102, new Timestamp(System.currentTimeMillis()), "Priya Patel", 2, "PENDING", "N/A", new BigDecimal("420.00")));
            return list;
        }

        @Override
        public int getOrderReportCount(String fromDate, String toDate, String status) {
            return 2;
        }

        @Override
        public List<CustomerReportDTO> getCustomerReport(String keyword, int limit, int offset) {
            List<CustomerReportDTO> list = new ArrayList<>();
            list.add(new CustomerReportDTO(1, "Rahul Sharma", "9876543210", 12, new BigDecimal("14250.00"), new Timestamp(System.currentTimeMillis())));
            list.add(new CustomerReportDTO(2, "Priya Patel", "9812345678", 8, new BigDecimal("7600.00"), new Timestamp(System.currentTimeMillis())));
            return list;
        }

        @Override
        public int getCustomerReportCount(String keyword) {
            return 2;
        }

        @Override
        public List<MenuReportDTO> getMenuReport(String fromDate, String toDate, String category) {
            List<MenuReportDTO> list = new ArrayList<>();
            list.add(new MenuReportDTO(1, "Paneer Butter Masala", "Main Course", new BigDecimal("300.00"), 85, new BigDecimal("25500.00")));
            list.add(new MenuReportDTO(2, "Butter Naan", "Breads", new BigDecimal("50.00"), 140, new BigDecimal("7000.00")));
            return list;
        }
    }

    private static void testBillingSummaryCalculations() {
        System.out.println("[TEST GROUP 1] Billing Summary Metrics");
        ReportService service = new ReportService(new MockReportDAO());

        try {
            BillSummaryDTO summary = service.getBillSummary("2026-08-01", "2026-08-31");
            assertEquals("Total bills count matches", 120, summary.getTotalBills());
            assertEquals("Total billing amount matches", new BigDecimal("96000.00"), summary.getTotalBillingAmount());
            assertEquals("Average bill amount matches", new BigDecimal("800.00"), summary.getAverageBillAmount());
            assertEquals("Highest bill amount matches", new BigDecimal("4250.00"), summary.getHighestBillAmount());
            assertEquals("Lowest bill amount matches", new BigDecimal("120.00"), summary.getLowestBillAmount());
        } catch (Exception e) {
            assertTrue("Billing summary error: " + e.getMessage(), false);
        }
    }

    private static void testDailyBillingAggregation() {
        System.out.println("\n[TEST GROUP 2] Daily Billing Report");
        ReportService service = new ReportService(new MockReportDAO());

        try {
            List<BillingTrendDTO> daily = service.getDailyBillingTrend("2026-08-01", "2026-08-03");
            assertEquals("Daily records count is 3", 3, daily.size());
            assertEquals("First day label matches", "2026-08-01", daily.get(0).getPeriodLabel());
            assertEquals("First day bills count matches", 18, daily.get(0).getBillCount());
            assertEquals("First day amount matches", new BigDecimal("14400.00"), daily.get(0).getTotalAmount());
        } catch (Exception e) {
            assertTrue("Daily billing trend error: " + e.getMessage(), false);
        }
    }

    private static void testMonthlyBillingAggregation() {
        System.out.println("\n[TEST GROUP 3] Monthly Billing Report");
        ReportService service = new ReportService(new MockReportDAO());

        try {
            List<BillingTrendDTO> monthly = service.getMonthlyBillingReport("2026-06-01", "2026-08-31");
            assertEquals("Monthly records count is 3", 3, monthly.size());
            assertEquals("First month is June", "June", monthly.get(0).getPeriodLabel());
            assertEquals("June total amount is 416000.00", new BigDecimal("416000.00"), monthly.get(0).getTotalAmount());
        } catch (Exception e) {
            assertTrue("Monthly billing report error: " + e.getMessage(), false);
        }
    }

    private static void testOrderReportStructureAndFilter() {
        System.out.println("\n[TEST GROUP 4] Order Report");
        ReportService service = new ReportService(new MockReportDAO());

        try {
            List<OrderReportDTO> orders = service.getOrderReport("2026-08-01", "2026-08-31", "ALL", 1, 50);
            assertEquals("Order report count is 2", 2, orders.size());
            assertEquals("First order customer name matches", "Rahul Sharma", orders.get(0).getCustomerName());
            assertEquals("First order bill number matches", "BILL-1001", orders.get(0).getBillNumber());
            assertEquals("First order items count is 3", 3, orders.get(0).getItemCount());
        } catch (Exception e) {
            assertTrue("Order report error: " + e.getMessage(), false);
        }
    }

    private static void testCustomerReportMetrics() {
        System.out.println("\n[TEST GROUP 5] Customer Report");
        ReportService service = new ReportService(new MockReportDAO());

        List<CustomerReportDTO> customers = service.getCustomerReport("", 1, 50);
        assertEquals("Customer report count is 2", 2, customers.size());
        assertEquals("Top customer name matches", "Rahul Sharma", customers.get(0).getCustomerName());
        assertEquals("Top customer total orders is 12", 12, customers.get(0).getTotalOrders());
        assertEquals("Top customer total billed is 14250.00", new BigDecimal("14250.00"), customers.get(0).getTotalBilledAmount());
    }

    private static void testMenuItemReportMetrics() {
        System.out.println("\n[TEST GROUP 6] Menu Item Report");
        ReportService service = new ReportService(new MockReportDAO());

        try {
            List<MenuReportDTO> menu = service.getMenuReport("2026-08-01", "2026-08-31", "ALL");
            assertEquals("Menu item count is 2", 2, menu.size());
            assertEquals("Item 1 name is Paneer Butter Masala", "Paneer Butter Masala", menu.get(0).getFoodName());
            assertEquals("Item 1 total billing is 25500.00", new BigDecimal("25500.00"), menu.get(0).getTotalBilling());
        } catch (Exception e) {
            assertTrue("Menu report error: " + e.getMessage(), false);
        }
    }

    private static void testTopSellingItemsRanking() {
        System.out.println("\n[TEST GROUP 7] Top-Selling Items Ranking");
        ReportService service = new ReportService(new MockReportDAO());

        try {
            List<ItemSalesDTO> top3 = service.getItemSalesReport("2026-08-01", "2026-08-31", 3);
            assertEquals("Top limit 3 returned exactly 3 items", 3, top3.size());
            assertEquals("Rank 1 is Paneer Butter Masala", "Paneer Butter Masala", top3.get(0).getItemName());
            assertEquals("Rank 2 is Butter Naan", "Butter Naan", top3.get(1).getItemName());
            assertEquals("Rank 3 is Veg Biryani", "Veg Biryani", top3.get(2).getItemName());
        } catch (Exception e) {
            assertTrue("Top selling items error: " + e.getMessage(), false);
        }
    }

    private static void testDateRangeFilteringAndValidation() {
        System.out.println("\n[TEST GROUP 8] Date Range Filtering & Validation");
        ReportService service = new ReportService(new MockReportDAO());

        // Valid range
        try {
            service.validateDateRange("2026-08-01", "2026-08-20");
            assertTrue("Valid range accepted", true);
        } catch (Exception e) {
            assertTrue("Valid range rejected: " + e.getMessage(), false);
        }

        // Inverted range
        try {
            service.validateDateRange("2026-08-25", "2026-08-10");
            assertTrue("Inverted range should throw ValidationException", false);
        } catch (ValidationException e) {
            assertTrue("Inverted range correctly rejected: " + e.getMessage(), e.getMessage().contains("cannot be after"));
        }

        // Malformed date
        try {
            service.validateDateRange("2026/08/01", "2026-08-10");
            assertTrue("Malformed date should throw ValidationException", false);
        } catch (ValidationException e) {
            assertTrue("Malformed date correctly rejected: " + e.getMessage(), e.getMessage().contains("format"));
        }
    }

    private static void testCsvExportGenerationAndEscaping() {
        System.out.println("\n[TEST GROUP 9] CSV Export & RFC 4180 Compliance");

        try {
            File tempCsv = new File("target/test-reports/sample_report.csv");
            String[] headers = {"Date", "Description", "Amount"};
            List<String[]> rows = new ArrayList<>();
            rows.add(new String[]{"2026-08-01", "Dine-in, Table \"5\"", "₹1,250.00"});
            rows.add(new String[]{"2026-08-02", "Takeaway with\nSpecial Notes", "₹850.00"});

            CsvExporter.exportDataToCsv(headers, rows, tempCsv);

            assertTrue("CSV file created on disk", tempCsv.exists() && tempCsv.length() > 0);

            String content = Files.readString(tempCsv.toPath());
            assertTrue("CSV contains headers", content.contains("Date,Description,Amount"));
            assertTrue("Quotes and commas escaped properly", content.contains("\"Dine-in, Table \"\"5\"\"\""));
            assertTrue("Newline within cell escaped with quotes", content.contains("\"Takeaway with\nSpecial Notes\""));

            // Test escape helper directly
            assertEquals("Simple cell unchanged", "Normal Text", CsvExporter.escapeCsvCell("Normal Text"));
            assertEquals("Comma escaped with quotes", "\"Hello, World\"", CsvExporter.escapeCsvCell("Hello, World"));
        } catch (Exception e) {
            assertTrue("CSV export failure: " + e.getMessage(), false);
        }
    }

    private static void testPdfDocumentGeneration() {
        System.out.println("\n[TEST GROUP 10] PDF Document Generation");

        try {
            // 1. Report PDF
            File reportPdf = new File("target/test-reports/test_report.pdf");
            String[] headers = {"Item", "Quantity", "Revenue"};
            List<String[]> rows = new ArrayList<>();
            rows.add(new String[]{"Paneer Butter Masala", "85", "₹25,500.00"});
            rows.add(new String[]{"Butter Naan", "140", "₹7,000.00"});

            PdfDocumentGenerator.exportReportToPdf("Top Items Report", "2026-08-01 to 2026-08-31", headers, rows, "Top performing items summary", reportPdf);
            assertTrue("Report PDF generated on disk", reportPdf.exists() && reportPdf.length() > 500);

            // 2. Invoice PDF
            File invoicePdf = new File("target/test-reports/test_invoice.pdf");
            Bill bill = new Bill(201, "BILL-TEST-999", new BigDecimal("500.00"), new BigDecimal("50.00"), new BigDecimal("22.50"), new BigDecimal("472.50"));
            bill.setCustomerName("Sunita Rao");
            bill.setCustomerPhone("9123456780");

            List<OrderItem> items = new ArrayList<>();
            items.add(new OrderItem(1, "Veg Thali", 2, new BigDecimal("200.00")));
            items.add(new OrderItem(2, "Sweet Lassi", 1, new BigDecimal("100.00")));
            bill.setItems(items);

            PdfDocumentGenerator.exportInvoiceToPdf(bill, invoicePdf);
            assertTrue("Invoice PDF generated on disk", invoicePdf.exists() && invoicePdf.length() > 500);
        } catch (Exception e) {
            assertTrue("PDF generation failure: " + e.getMessage(), false);
        }
    }

    private static void testPrintPreviewAndTextFormatting() {
        System.out.println("\n[TEST GROUP 11] Print Preview & Printable Text Formatting");

        String[] headers = {"Date", "Bills", "Amount"};
        List<String[]> rows = new ArrayList<>();
        rows.add(new String[]{"2026-08-01", "18", "₹14,400.00"});
        rows.add(new String[]{"2026-08-02", "22", "₹17,600.00"});

        ReportGenerator gen = new ReportGenerator("Daily Billing", "2026-08-01 to 2026-08-02", headers, rows);
        String text = gen.generateTextReport();

        assertTrue("Generated text contains report title", text.contains("DAILY BILLING REPORT"));
        assertTrue("Generated text contains period label", text.contains("2026-08-01 to 2026-08-02"));
        assertTrue("Generated text contains tabular rows", text.contains("2026-08-01") && text.contains("₹14,400.00"));
        assertTrue("Generated text has end marker", text.contains("END OF REPORT"));
    }

    private static void testBillDocumentConsistency() {
        System.out.println("\n[TEST GROUP 12] Bill Document Consistency");

        Bill bill = new Bill(105, "BILL-MATCH-01", new BigDecimal("1000.00"), new BigDecimal("100.00"), new BigDecimal("45.00"), new BigDecimal("945.00"));
        bill.setCustomerName("Anil Kapoor");
        bill.setCustomerPhone("9876500000");

        List<OrderItem> items = new ArrayList<>();
        items.add(new OrderItem(1, "Special Biryani", 2, new BigDecimal("500.00")));
        bill.setItems(items);

        InvoiceGenerator invGen = new InvoiceGenerator(bill);
        String text = invGen.generateTextReceipt();
        String html = invGen.generateHtmlInvoice();

        // Verify calculations in text receipt
        assertTrue("Text receipt contains correct Bill number", text.contains("BILL-MATCH-01"));
        assertTrue("Text receipt contains subtotal ₹1,000.00", text.contains("₹1,000.00"));
        assertTrue("Text receipt contains discount ₹100.00", text.contains("₹100.00"));
        assertTrue("Text receipt contains tax ₹45.00", text.contains("₹45.00"));
        assertTrue("Text receipt contains grand total ₹945.00", text.contains("₹945.00"));

        // Verify calculations in HTML receipt
        assertTrue("HTML invoice contains Bill Number", html.contains("BILL-MATCH-01"));
        assertTrue("HTML invoice contains grand total", html.contains("₹945.00"));
    }

    private static void testEmptyDataHandling() {
        System.out.println("\n[TEST GROUP 13] Empty Data State Handling");

        ReportGenerator emptyGen = new ReportGenerator("Empty Report", "2099-01-01 to 2099-01-31", new String[]{"Col1", "Col2"}, new ArrayList<>());
        String emptyText = emptyGen.generateTextReport();

        assertTrue("Empty report handles zero records gracefully", emptyText.contains("No data available"));
    }

    private static void testRoleBasedAccessControl() {
        System.out.println("\n[TEST GROUP 14] Role-Based Access Control");

        User adminUser = new User(1, "admin", "hash", "ADMIN");
        User staffUser = new User(2, "staff", "hash", "STAFF");

        UserSession.login(adminUser);
        assertTrue("Admin session is recognized as Admin", UserSession.isAdmin());
        assertTrue("Admin session is not restricted to Staff", !UserSession.isStaff());

        UserSession.login(staffUser);
        assertTrue("Staff session is recognized as Staff", UserSession.isStaff());
        assertTrue("Staff session is not Admin", !UserSession.isAdmin());

        UserSession.logout();
    }

    private static void testReportAuditLogging() {
        System.out.println("\n[TEST GROUP 15] Report Action Audit Logging");

        AuditService auditService = new AuditService();

        try {
            auditService.log("REPORT", "REPORT_GENERATED", "Generated Billing Summary report", "SUCCESS");
            auditService.log("REPORT", "REPORT_EXPORTED", "Exported Billing Summary PDF", "SUCCESS");
            auditService.log("BILLING", "BILL_PRINTED", "Printed bill #BILL-1001", "SUCCESS");
            auditService.log("BILLING", "INVOICE_EXPORTED", "Exported PDF invoice for bill #BILL-1001", "SUCCESS");
            assertTrue("Audit events logged without exceptions", true);
        } catch (Exception e) {
            assertTrue("Audit logging failed: " + e.getMessage(), false);
        }
    }

    private static void testStrictNoPaymentCompliance() {
        System.out.println("\n[TEST GROUP 16] Strict No-Payment Business Rule Compliance");

        try {
            // Ensure no payment classes exist in classpath
            String[] forbiddenClasses = {
                "com.restaurantbilling.model.Payment",
                "com.restaurantbilling.model.PaymentTransaction",
                "com.restaurantbilling.dao.PaymentDAO",
                "com.restaurantbilling.service.PaymentService",
                "com.restaurantbilling.service.PaymentGatewayService",
                "com.restaurantbilling.gui.payment.PaymentPanel"
            };

            for (String fqcn : forbiddenClasses) {
                try {
                    Class.forName(fqcn);
                    assertTrue("Violation: Forbidden class found " + fqcn, false);
                } catch (ClassNotFoundException e) {
                    assertTrue("Forbidden class absent: " + fqcn, true);
                }
            }
        } catch (Exception e) {
            assertTrue("Payment compliance check error: " + e.getMessage(), false);
        }
    }
}
