package com.restaurantbilling;

import com.restaurantbilling.exception.ValidationException;
import com.restaurantbilling.model.Customer;
import com.restaurantbilling.util.ValidationUtil;

public class CustomerValidationTest {
    public static void main(String[] args) {
        System.out.println("Running Customer Validation Tests...");
        int passed = 0;
        int failed = 0;

        // Test 1: Valid customer
        try {
            Customer valid = new Customer("Rahul Sharma", "9876543210", "rahul@example.com", "MG Road", "Active");
            ValidationUtil.validateCustomer(valid);
            System.out.println("[PASS] Test 1: Valid customer accepted");
            passed++;
        } catch (Exception e) {
            System.err.println("[FAIL] Test 1: " + e.getMessage());
            failed++;
        }

        // Test 2: Empty Name
        try {
            Customer c = new Customer("", "9876543210", "rahul@example.com", "MG Road", "Active");
            ValidationUtil.validateCustomer(c);
            System.err.println("[FAIL] Test 2: Empty name was not rejected");
            failed++;
        } catch (ValidationException e) {
            System.out.println("[PASS] Test 2: Empty name rejected -> " + e.getMessage());
            passed++;
        }

        // Test 3: Invalid Phone
        try {
            Customer c = new Customer("Rahul Sharma", "12345", "rahul@example.com", "MG Road", "Active");
            ValidationUtil.validateCustomer(c);
            System.err.println("[FAIL] Test 3: Invalid phone was not rejected");
            failed++;
        } catch (ValidationException e) {
            System.out.println("[PASS] Test 3: Invalid phone rejected -> " + e.getMessage());
            passed++;
        }

        // Test 4: Invalid Email
        try {
            Customer c = new Customer("Rahul Sharma", "9876543210", "invalid-email@", "MG Road", "Active");
            ValidationUtil.validateCustomer(c);
            System.err.println("[FAIL] Test 4: Invalid email was not rejected");
            failed++;
        } catch (ValidationException e) {
            System.out.println("[PASS] Test 4: Invalid email rejected -> " + e.getMessage());
            passed++;
        }

        // Test 5: Optional empty email allowed
        try {
            Customer c = new Customer("Rahul Sharma", "9876543210", "", "MG Road", "Active");
            ValidationUtil.validateCustomer(c);
            System.out.println("[PASS] Test 5: Empty email allowed");
            passed++;
        } catch (Exception e) {
            System.err.println("[FAIL] Test 5: " + e.getMessage());
            failed++;
        }

        System.out.println("----------------------------------------");
        System.out.println("Tests Completed: " + (passed + failed) + " | Passed: " + passed + " | Failed: " + failed);
    }
}
