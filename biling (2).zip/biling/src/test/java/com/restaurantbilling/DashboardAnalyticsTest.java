package com.restaurantbilling;

import com.restaurantbilling.dao.DashboardDAO;
import com.restaurantbilling.exception.ValidationException;
import com.restaurantbilling.model.Bill;
import com.restaurantbilling.model.Order;
import com.restaurantbilling.model.User;
import com.restaurantbilling.model.dashboard.DashboardSummaryDTO;
import com.restaurantbilling.model.dashboard.OrderTrendDTO;
import com.restaurantbilling.model.report.BillingTrendDTO;
import com.restaurantbilling.model.report.ItemSalesDTO;
import com.restaurantbilling.service.DashboardService;
import com.restaurantbilling.util.FormatUtil;
import com.restaurantbilling.util.UserSession;

import java.math.BigDecimal;
import java.util.*;

public class DashboardAnalyticsTest {

    private static int totalPassed = 0;
    private static int totalFailed = 0;

    public static void main(String[] args) {
        System.out.println("============================================================");
        System.out.println("PHASE 15: ADVANCED DASHBOARD & KPI ANALYTICS TEST SUITE");
        System.out.println("============================================================\n");

        testDashboardKpiCalculations();
        testDateFilterValidation();
        testBillingAndOrderTrends();
        testTopMenuItemsRanking();
        testRecentBillsAndOrdersRetrieval();
        testEmptyDatabaseStateHandling();
        testRoleBasedDashboardLogic();
        testStrictNoPaymentArchitectureCompliance();

        System.out.println("\n============================================================");
        System.out.println("TEST RESULTS: " + totalPassed + " PASSED, " + totalFailed + " FAILED");
        System.out.println("============================================================");

        if (totalFailed > 0) {
            System.exit(1);
        }
    }

    private static void assertTrue(String testName, boolean condition) {
        if (condition) {
            System.out.println("  [PASS] " + testName);
            totalPassed++;
        } else {
            System.err.println("  [FAIL] " + testName);
            totalFailed++;
        }
    }

    private static void assertEquals(String testName, Object expected, Object actual) {
        boolean match = Objects.equals(expected, actual);
        if (match) {
            System.out.println("  [PASS] " + testName + " (Value: " + actual + ")");
            totalPassed++;
        } else {
            System.err.println("  [FAIL] " + testName + " -> Expected: " + expected + ", Got: " + actual);
            totalFailed++;
        }
    }

    // 1. Dashboard KPI Calculations
    private static void testDashboardKpiCalculations() {
        System.out.println("[TEST GROUP 1] Dashboard KPI Calculations");

        MockDashboardDAO mockDAO = new MockDashboardDAO();
        mockDAO.kpiDTO = new DashboardSummaryDTO(
            150,
            new BigDecimal("45000.00"),
            160,
            85,
            40,
            new BigDecimal("300.00")
        );

        DashboardService service = new DashboardService(mockDAO);

        try {
            DashboardSummaryDTO kpis = service.getDashboardKPIs("2026-08-01", "2026-08-31");
            assertEquals("Total bills count matches", 150, kpis.getTotalBills());
            assertEquals("Total billed amount matches", new BigDecimal("45000.00"), kpis.getTotalBilledAmount());
            assertEquals("Total orders count matches", 160, kpis.getTotalOrders());
            assertEquals("Total customers count matches", 85, kpis.getTotalCustomers());
            assertEquals("Total menu items count matches", 40, kpis.getTotalMenuItems());
            assertEquals("Average bill amount calculation", new BigDecimal("300.00"), kpis.getAverageBillAmount());
        } catch (ValidationException e) {
            assertTrue("KPI retrieval should succeed with valid dates", false);
        }
    }

    // 2. Date Filter Validation
    private static void testDateFilterValidation() {
        System.out.println("\n[TEST GROUP 2] Date Filter Validation");

        MockDashboardDAO mockDAO = new MockDashboardDAO();
        DashboardService service = new DashboardService(mockDAO);

        // Valid date range
        try {
            service.validateDateRange("2026-08-01", "2026-08-31");
            assertTrue("Valid date range accepted (2026-08-01 to 2026-08-31)", true);
        } catch (ValidationException e) {
            assertTrue("Valid date range should pass", false);
        }

        // Inverted dates: From > To
        try {
            service.validateDateRange("2026-08-31", "2026-08-01");
            assertTrue("Inverted date range must be rejected", false);
        } catch (ValidationException e) {
            assertTrue("Inverted date range correctly rejected -> " + e.getMessage(), true);
        }

        // Invalid date format
        try {
            service.validateDateRange("01/08/2026", "31/08/2026");
            assertTrue("Invalid date format must be rejected", false);
        } catch (ValidationException e) {
            assertTrue("Invalid date format correctly rejected -> " + e.getMessage(), true);
        }

        // Null / empty dates allowed for all-time queries
        try {
            service.validateDateRange("", "");
            service.validateDateRange(null, null);
            assertTrue("Empty / null date range accepted for All-Time mode", true);
        } catch (ValidationException e) {
            assertTrue("Empty date range should be allowed", false);
        }
    }

    // 3. Billing & Order Trends
    private static void testBillingAndOrderTrends() {
        System.out.println("\n[TEST GROUP 3] Billing & Order Trends Aggregation");

        MockDashboardDAO mockDAO = new MockDashboardDAO();
        mockDAO.billingTrends.add(new BillingTrendDTO("2026-08-01", 10, new BigDecimal("3200.00")));
        mockDAO.billingTrends.add(new BillingTrendDTO("2026-08-02", 15, new BigDecimal("4800.00")));

        mockDAO.orderTrends.add(new OrderTrendDTO("2026-08-01", 12));
        mockDAO.orderTrends.add(new OrderTrendDTO("2026-08-02", 18));

        DashboardService service = new DashboardService(mockDAO);

        try {
            List<BillingTrendDTO> bTrends = service.getBillingTrend("2026-08-01", "2026-08-02");
            assertEquals("Billing trend size matches", 2, bTrends.size());
            assertEquals("First day billing amount matches", new BigDecimal("3200.00"), bTrends.get(0).getTotalAmount());

            List<OrderTrendDTO> oTrends = service.getOrderTrend("2026-08-01", "2026-08-02");
            assertEquals("Order trend size matches", 2, oTrends.size());
            assertEquals("Second day order count matches", 18, oTrends.get(1).getOrderCount());
        } catch (ValidationException e) {
            assertTrue("Trends query should succeed", false);
        }
    }

    // 4. Top Menu Items Ranking
    private static void testTopMenuItemsRanking() {
        System.out.println("\n[TEST GROUP 4] Top Menu Items Ranking");

        MockDashboardDAO mockDAO = new MockDashboardDAO();
        mockDAO.topItems.add(new ItemSalesDTO("Paneer Tikka", "Starter", 120, new BigDecimal("21600.00")));
        mockDAO.topItems.add(new ItemSalesDTO("Veg Biryani", "Main Course", 95, new BigDecimal("20900.00")));
        mockDAO.topItems.add(new ItemSalesDTO("Butter Naan", "Breads", 80, new BigDecimal("3600.00")));

        DashboardService service = new DashboardService(mockDAO);

        try {
            List<ItemSalesDTO> items = service.getTopMenuItems("2026-08-01", "2026-08-31", 5);
            assertEquals("Top items count matches", 3, items.size());
            assertEquals("Top item rank #1 is Paneer Tikka", "Paneer Tikka", items.get(0).getItemName());
            assertEquals("Paneer Tikka quantity sold matches", 120, items.get(0).getQuantitySold());
            assertEquals("Paneer Tikka revenue matches", new BigDecimal("21600.00"), items.get(0).getRevenue());
        } catch (ValidationException e) {
            assertTrue("Top items query should succeed", false);
        }
    }

    // 5. Recent Bills & Recent Orders
    private static void testRecentBillsAndOrdersRetrieval() {
        System.out.println("\n[TEST GROUP 5] Recent Activity Retrieval");

        MockDashboardDAO mockDAO = new MockDashboardDAO();
        Bill b1 = new Bill(1, "BILL-20260822-0001", new BigDecimal("500.00"), BigDecimal.ZERO, BigDecimal.ZERO, new BigDecimal("500.00"));
        b1.setCustomerName("Rahul Sharma");
        mockDAO.recentBills.add(b1);

        Order o1 = new Order();
        o1.setId(101);
        o1.setCustomerName("Rahul Sharma");
        o1.setStatus("COMPLETED");
        o1.setTotal(new BigDecimal("500.00"));
        mockDAO.recentOrders.add(o1);

        DashboardService service = new DashboardService(mockDAO);

        List<Bill> bills = service.getRecentBills(5);
        assertEquals("Recent bills returned", 1, bills.size());
        assertEquals("Recent bill number matches", "BILL-20260822-0001", bills.get(0).getBillNumber());
        assertEquals("Recent bill customer matches", "Rahul Sharma", bills.get(0).getCustomerName());

        List<Order> orders = service.getRecentOrders(5);
        assertEquals("Recent orders returned", 1, orders.size());
        assertEquals("Recent order ID matches", 101, orders.get(0).getId());
        assertEquals("Recent order status matches", "COMPLETED", orders.get(0).getStatus());
    }

    // 6. Empty Database State Handling
    private static void testEmptyDatabaseStateHandling() {
        System.out.println("\n[TEST GROUP 6] Empty Database State Handling");

        MockDashboardDAO emptyDAO = new MockDashboardDAO();
        DashboardService service = new DashboardService(emptyDAO);

        try {
            DashboardSummaryDTO kpis = service.getDashboardKPIs(null, null);
            assertEquals("Empty state total bills is 0", 0, kpis.getTotalBills());
            assertEquals("Empty state total billed amount is 0", BigDecimal.ZERO, kpis.getTotalBilledAmount());
            assertEquals("Empty state average bill is 0", BigDecimal.ZERO, kpis.getAverageBillAmount());

            List<BillingTrendDTO> trends = service.getBillingTrend(null, null);
            assertTrue("Empty state billing trends list is empty", trends.isEmpty());

            List<ItemSalesDTO> topItems = service.getTopMenuItems(null, null, 5);
            assertTrue("Empty state top items list is empty", topItems.isEmpty());

            List<Bill> recentBills = service.getRecentBills(5);
            assertTrue("Empty state recent bills list is empty", recentBills.isEmpty());
        } catch (ValidationException e) {
            assertTrue("Empty state should not throw exception", false);
        }
    }

    // 7. Role-Based Dashboard Logic
    private static void testRoleBasedDashboardLogic() {
        System.out.println("\n[TEST GROUP 7] Role-Based Access Controls in Dashboard");

        User admin = new User(1, "admin", "admin123", "ADMIN");
        UserSession.login(admin);
        assertTrue("Admin session isAdmin is true", UserSession.isAdmin());
        assertTrue("Admin session isStaff is false", !UserSession.isStaff());

        User staff = new User(2, "staff", "staff123", "STAFF");
        UserSession.login(staff);
        assertTrue("Staff session isStaff is true", UserSession.isStaff());
        assertTrue("Staff session isAdmin is false", !UserSession.isAdmin());

        UserSession.logout();
    }

    // 8. Strict No-Payment System Compliance
    private static void testStrictNoPaymentArchitectureCompliance() {
        System.out.println("\n[TEST GROUP 8] Strict No-Payment Architecture Compliance");

        String[] forbiddenPaymentClasses = {
            "Payment", "PaymentService", "PaymentDAO", "PaymentController",
            "PaymentGateway", "UPIPayment", "CreditCardPayment", "CashTransaction",
            "PaymentStatus", "PaymentMethod", "PaymentRecord", "RefundService"
        };

        boolean violation = false;
        for (String className : forbiddenPaymentClasses) {
            try {
                Class.forName("com.restaurantbilling.model." + className);
                violation = true;
            } catch (ClassNotFoundException ignored) {}
            try {
                Class.forName("com.restaurantbilling.service." + className);
                violation = true;
            } catch (ClassNotFoundException ignored) {}
            try {
                Class.forName("com.restaurantbilling.dao." + className);
                violation = true;
            } catch (ClassNotFoundException ignored) {}
        }

        assertTrue("Zero payment models, services, or DAOs exist in codebase", !violation);
    }

    // ==========================================
    // MOCK DASHBOARD DAO FOR ISOLATED TESTING
    // ==========================================

    static class MockDashboardDAO implements DashboardDAO {
        DashboardSummaryDTO kpiDTO = new DashboardSummaryDTO();
        List<BillingTrendDTO> billingTrends = new ArrayList<>();
        List<OrderTrendDTO> orderTrends = new ArrayList<>();
        List<ItemSalesDTO> topItems = new ArrayList<>();
        List<Bill> recentBills = new ArrayList<>();
        List<Order> recentOrders = new ArrayList<>();

        @Override
        public DashboardSummaryDTO getDashboardKPIs(String fromDate, String toDate) {
            return kpiDTO;
        }

        @Override
        public List<BillingTrendDTO> getBillingTrend(String fromDate, String toDate) {
            return billingTrends;
        }

        @Override
        public List<OrderTrendDTO> getOrderTrend(String fromDate, String toDate) {
            return orderTrends;
        }

        @Override
        public List<ItemSalesDTO> getTopMenuItems(String fromDate, String toDate, int limit) {
            return topItems;
        }

        @Override
        public List<Bill> getRecentBills(int limit) {
            return recentBills;
        }

        @Override
        public List<Order> getRecentOrders(int limit) {
            return recentOrders;
        }
    }
}
