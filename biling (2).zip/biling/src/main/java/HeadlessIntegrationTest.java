import com.restaurantbilling.api.pexels.PexelsPhoto;
import com.restaurantbilling.dao.impl.FoodItemDAOImpl;
import com.restaurantbilling.model.FoodItem;
import com.restaurantbilling.service.PexelsImageService;

import java.math.BigDecimal;
import java.util.List;

public class HeadlessIntegrationTest {
    public static void main(String[] args) {
        System.out.println("Starting Headless Pexels + Database Integration Test...");

        try {
            PexelsImageService imageService = new PexelsImageService();
            FoodItemDAOImpl dao = new FoodItemDAOImpl();

            // Test 1: Burger
            System.out.println("TEST 1: Searching for 'Burger'...");
            List<PexelsPhoto> photos = imageService.searchFoodImages("Burger");
            if (photos.isEmpty()) {
                throw new Exception("No photos found for Burger.");
            }
            System.out.println("Found " + photos.size() + " photos for 'Burger'.");
            
            PexelsPhoto selected = photos.get(0);
            System.out.println("Selected Photo ID: " + selected.getId());
            System.out.println("Photographer: " + selected.getPhotographer());
            System.out.println("URL: " + selected.getSrc().getMedium());

            // Test 2: Save to Database
            System.out.println("\nTEST 2: Saving 'Burger' to Database...");
            FoodItem item = new FoodItem(0, "Ultimate Burger", "Fast Food", new BigDecimal("12.99"), true);
            item.setImageSource("Pexels");
            item.setPexelsPhotoId(selected.getId());
            item.setImageUrl(selected.getSrc().getMedium());
            item.setPhotographerName(selected.getPhotographer());
            item.setPhotographerUrl(selected.getPhotographerUrl());

            FoodItem saved = dao.save(item);
            System.out.println("Successfully saved FoodItem with ID: " + saved.getId());
            System.out.println("Verified Database Integration: SUCCESS");
            
            // Cleanup
            dao.delete(saved.getId());
            System.out.println("Cleanup complete. Test passed.");

        } catch (Exception e) {
            e.printStackTrace();
            System.exit(1);
        }
    }
}
