package com.restaurantbilling.gui;

import com.restaurantbilling.database.DatabaseConnection;
import com.restaurantbilling.exception.ValidationException;
import com.restaurantbilling.gui.theme.UIHelper;
import com.restaurantbilling.gui.theme.UITheme;
import com.restaurantbilling.gui.util.CustomDialogs;
import com.restaurantbilling.model.User;
import com.restaurantbilling.service.AuthenticationService;

import javax.swing.*;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import java.awt.*;

public class LoginFrame extends JFrame {

    private final AuthenticationService authService;
    private JTextField txtUsername;
    private JPasswordField txtPassword;
    private JButton btnLogin;
    private JLabel lblStatus;
    private JProgressBar progressLogin;

    public LoginFrame() {
        this.authService = new AuthenticationService();

        setTitle("Restaurant Billing System — Sign In");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(460, 560);
        setLocationRelativeTo(null);
        setResizable(false);

        initComponents();
    }

    private void initComponents() {
        // Outer Container with subtle dark/slate background
        JPanel rootPanel = new JPanel(new GridBagLayout());
        rootPanel.setBackground(UITheme.HEADER_BG);
        setContentPane(rootPanel);

        // Centered Floating Card
        JPanel card = new JPanel(new BorderLayout(0, 20));
        card.setBackground(UITheme.CARD_BG);
        card.setPreferredSize(new Dimension(380, 480));
        card.setBorder(new CompoundBorder(
            new LineBorder(new Color(51, 65, 85), 1, true),
            new EmptyBorder(30, 30, 25, 30)
        ));

        // 1. Header with Restaurant Branding & Logo
        JPanel brandPanel = new JPanel();
        brandPanel.setLayout(new BoxLayout(brandPanel, BoxLayout.Y_AXIS));
        brandPanel.setOpaque(false);

        JLabel lblLogo = new JLabel("🍽️", SwingConstants.CENTER);
        lblLogo.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 40));
        lblLogo.setAlignmentX(Component.CENTER_ALIGNMENT);
        brandPanel.add(lblLogo);

        brandPanel.add(Box.createVerticalStrut(8));

        JLabel lblTitle = new JLabel("RESTAURANT BILLING", SwingConstants.CENTER);
        lblTitle.setFont(UITheme.FONT_TITLE_LARGE);
        lblTitle.setForeground(UITheme.TEXT_PRIMARY);
        lblTitle.setAlignmentX(Component.CENTER_ALIGNMENT);
        brandPanel.add(lblTitle);

        JLabel lblSubtitle = new JLabel("Point of Sale & Billing Management", SwingConstants.CENTER);
        lblSubtitle.setFont(UITheme.FONT_BODY_MEDIUM);
        lblSubtitle.setForeground(UITheme.TEXT_SECONDARY);
        lblSubtitle.setAlignmentX(Component.CENTER_ALIGNMENT);
        brandPanel.add(lblSubtitle);

        card.add(brandPanel, BorderLayout.NORTH);

        // 2. Center Form Panel
        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setOpaque(false);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 0, 5, 0);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1.0;
        gbc.gridx = 0;
        gbc.gridy = 0;

        // Username
        JLabel lblUser = new JLabel("Username");
        lblUser.setFont(UITheme.FONT_BODY_BOLD);
        lblUser.setForeground(UITheme.TEXT_PRIMARY);
        formPanel.add(lblUser, gbc);

        gbc.gridy++;
        txtUsername = new JTextField("admin");
        UIHelper.styleTextField(txtUsername);
        txtUsername.setPreferredSize(new Dimension(320, 38));
        txtUsername.addActionListener(e -> performLogin());
        formPanel.add(txtUsername, gbc);

        // Password
        gbc.gridy++;
        gbc.insets = new Insets(10, 0, 5, 0);
        JLabel lblPass = new JLabel("Password");
        lblPass.setFont(UITheme.FONT_BODY_BOLD);
        lblPass.setForeground(UITheme.TEXT_PRIMARY);
        formPanel.add(lblPass, gbc);

        gbc.gridy++;
        gbc.insets = new Insets(5, 0, 5, 0);
        txtPassword = new JPasswordField("admin123");
        txtPassword.setFont(UITheme.FONT_BODY);
        txtPassword.setBorder(UITheme.BORDER_INPUT);
        txtPassword.setPreferredSize(new Dimension(320, 38));
        txtPassword.addActionListener(e -> performLogin());
        formPanel.add(txtPassword, gbc);

        // Status & Progress Indicator
        gbc.gridy++;
        gbc.insets = new Insets(4, 0, 4, 0);
        lblStatus = new JLabel(" ", SwingConstants.CENTER);
        lblStatus.setFont(UITheme.FONT_SMALL);
        lblStatus.setForeground(UITheme.DANGER);
        formPanel.add(lblStatus, gbc);

        gbc.gridy++;
        progressLogin = new JProgressBar();
        progressLogin.setIndeterminate(true);
        progressLogin.setVisible(false);
        progressLogin.setPreferredSize(new Dimension(320, 6));
        formPanel.add(progressLogin, gbc);

        // Login Button
        gbc.gridy++;
        gbc.insets = new Insets(10, 0, 5, 0);
        btnLogin = UIHelper.createPrimaryButton("SIGN IN");
        btnLogin.setPreferredSize(new Dimension(320, 42));
        btnLogin.setFont(UITheme.FONT_SECTION);
        btnLogin.addActionListener(e -> performLogin());
        formPanel.add(btnLogin, gbc);

        card.add(formPanel, BorderLayout.CENTER);

        // 3. Footer with Database Configuration
        JPanel footer = new JPanel(new FlowLayout(FlowLayout.CENTER, 0, 0));
        footer.setOpaque(false);

        JButton btnDbConfig = new JButton("⚙ Configure Database Connection");
        btnDbConfig.setFont(UITheme.FONT_SMALL);
        btnDbConfig.setForeground(UITheme.TEXT_MUTED);
        btnDbConfig.setBorderPainted(false);
        btnDbConfig.setContentAreaFilled(false);
        btnDbConfig.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnDbConfig.addActionListener(e -> promptDatabaseConfig());
        footer.add(btnDbConfig);

        card.add(footer, BorderLayout.SOUTH);

        rootPanel.add(card);
    }

    private void performLogin() {
        String username = txtUsername.getText().trim();
        String password = new String(txtPassword.getPassword()).trim();

        if (username.isEmpty() || password.isEmpty()) {
            lblStatus.setText("Please enter username and password.");
            lblStatus.setForeground(UITheme.DANGER);
            return;
        }

        lblStatus.setText("Authenticating credentials...");
        lblStatus.setForeground(UITheme.PRIMARY);
        btnLogin.setEnabled(false);
        progressLogin.setVisible(true);

        SwingWorker<User, Void> worker = new SwingWorker<>() {
            @Override
            protected User doInBackground() throws Exception {
                return authService.login(username, password);
            }

            @Override
            protected void done() {
                btnLogin.setEnabled(true);
                progressLogin.setVisible(false);

                try {
                    User user = get();
                    dispose();
                    SwingUtilities.invokeLater(() -> {
                        MainFrame mainFrame = new MainFrame();
                        mainFrame.setVisible(true);
                    });
                } catch (Exception ex) {
                    Throwable cause = ex.getCause() != null ? ex.getCause() : ex;
                    // Drill down if it's a DatabaseException wrapping a SQLException
                    if (cause instanceof com.restaurantbilling.exception.DatabaseException && cause.getCause() != null) {
                        cause = cause.getCause();
                    }
                    if (cause instanceof com.restaurantbilling.exception.ValidationException) {
                        lblStatus.setText(cause.getMessage());
                        lblStatus.setForeground(UITheme.DANGER);
                    } else {
                        lblStatus.setText("Database connection error. Check MySQL.");
                        lblStatus.setForeground(UITheme.DANGER);
                        String errorDetails = (cause.getMessage() != null) ? cause.getMessage() : "Connection refused";
                        CustomDialogs.showError(LoginFrame.this,
                            "Unable to connect to the Restaurant Billing System database.\nDetails: " + errorDetails + "\n\nPlease ensure the MySQL server is running and configuration is correct.",
                            "Database Connection Failed");
                    }
                }
            }
        };

        worker.execute();
    }

    private void promptDatabaseConfig() {
        JTextField userField = new JTextField(DatabaseConnection.getUsername() != null ? DatabaseConnection.getUsername() : "root");
        JPasswordField passField = new JPasswordField(DatabaseConnection.getPassword() != null ? DatabaseConnection.getPassword() : "");
        Object[] message = {
            "MySQL Username:", userField,
            "MySQL Password:", passField
        };

        int option = JOptionPane.showConfirmDialog(this, message, "Configure MySQL Credentials", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            String u = userField.getText().trim();
            String p = new String(passField.getPassword());
            DatabaseConnection.setCredentials(u, p);
            if (DatabaseConnection.testConnection()) {
                CustomDialogs.showSuccess(this, "Connected to MySQL successfully!", "Database Connected");
            } else {
                CustomDialogs.showWarning(this, "Could not connect with provided credentials. Please ensure MySQL is running and password is correct.", "Connection Failed");
            }
        }
    }
}
