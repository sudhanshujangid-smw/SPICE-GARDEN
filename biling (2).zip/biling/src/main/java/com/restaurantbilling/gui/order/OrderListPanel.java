package com.restaurantbilling.gui.order;

import com.restaurantbilling.exception.ValidationException;
import com.restaurantbilling.gui.theme.UIHelper;
import com.restaurantbilling.gui.theme.UITheme;
import com.restaurantbilling.gui.util.CustomDialogs;
import com.restaurantbilling.model.Order;
import com.restaurantbilling.service.OrderService;
import com.restaurantbilling.util.FormatUtil;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class OrderListPanel extends JPanel {

    private final OrderService orderService;
    private List<Order> orderList = new ArrayList<>();

    private JTextField txtSearch;
    private JComboBox<String> cmbStatusFilter;
    private JTable orderTable;
    private DefaultTableModel tableModel;
    private JLabel lblStatusInfo;
    private JProgressBar progressBar;

    private JButton btnViewDetails;
    private JButton btnUpdateStatus;
    private JButton btnCancelOrder;
    private JComboBox<String> cmbNewStatus;

    private static final String[] COLUMNS = {
        "Order ID", "Customer", "Phone", "Order Date & Time", "Total Amount", "Status"
    };

    public OrderListPanel(OrderService orderService) {
        this.orderService = orderService;

        setLayout(new BorderLayout(15, 15));
        setBorder(new EmptyBorder(16, 20, 16, 20));
        setBackground(UITheme.APP_BG);

        initComponents();
        setupSelectionListener();
        loadOrdersAsync();
    }

    private void initComponents() {
        // TOP: Header & Search Bar Card
        JPanel topPanel = new JPanel(new BorderLayout(10, 12));
        topPanel.setOpaque(false);

        JPanel titlePanel = new JPanel(new GridLayout(2, 1, 0, 3));
        titlePanel.setOpaque(false);

        JLabel lblTitle = new JLabel("Order History & Active Processing");
        lblTitle.setFont(UITheme.FONT_TITLE_LARGE);
        lblTitle.setForeground(UITheme.TEXT_PRIMARY);
        titlePanel.add(lblTitle);

        JLabel lblSubtitle = new JLabel("Monitor active orders, update preparation status, and review fulfilled orders.");
        lblSubtitle.setFont(UITheme.FONT_BODY_MEDIUM);
        lblSubtitle.setForeground(UITheme.TEXT_SECONDARY);
        titlePanel.add(lblSubtitle);

        topPanel.add(titlePanel, BorderLayout.NORTH);

        JPanel filterBar = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 8));
        filterBar.setBackground(UITheme.CARD_BG);
        filterBar.setBorder(UITheme.BORDER_CARD);

        JLabel lblSearch = new JLabel("Search:");
        lblSearch.setFont(UITheme.FONT_BODY_BOLD);
        filterBar.add(lblSearch);

        txtSearch = new JTextField(15);
        UIHelper.styleTextField(txtSearch);
        txtSearch.setPreferredSize(new Dimension(160, 34));
        txtSearch.putClientProperty("JTextField.placeholderText", "Order ID, Name, Phone...");
        txtSearch.addActionListener(e -> performSearch());
        filterBar.add(txtSearch);

        JButton btnSearch = UIHelper.createSecondaryButton("Search");
        btnSearch.setPreferredSize(new Dimension(85, 34));
        btnSearch.addActionListener(e -> performSearch());
        filterBar.add(btnSearch);

        JLabel lblStatus = new JLabel("Status:");
        lblStatus.setFont(UITheme.FONT_BODY_BOLD);
        filterBar.add(lblStatus);

        cmbStatusFilter = new JComboBox<>(new String[]{"All", "PENDING", "CONFIRMED", "PREPARING", "READY", "COMPLETED", "CANCELLED"});
        UIHelper.styleComboBox(cmbStatusFilter);
        cmbStatusFilter.setPreferredSize(new Dimension(130, 34));
        cmbStatusFilter.addActionListener(e -> performSearch());
        filterBar.add(cmbStatusFilter);

        JButton btnClear = UIHelper.createSecondaryButton("Clear Filters");
        btnClear.setPreferredSize(new Dimension(110, 34));
        btnClear.addActionListener(e -> {
            txtSearch.setText("");
            cmbStatusFilter.setSelectedItem("All");
            loadOrdersAsync();
        });
        filterBar.add(btnClear);

        topPanel.add(filterBar, BorderLayout.SOUTH);
        add(topPanel, BorderLayout.NORTH);

        // CENTER: Orders Table Card
        JPanel centerCard = new JPanel(new BorderLayout());
        centerCard.setBackground(UITheme.CARD_BG);
        centerCard.setBorder(new LineBorder(UITheme.BORDER, 1, true));

        tableModel = new DefaultTableModel(COLUMNS, 0) {
            @Override
            public boolean isCellEditable(int row, int col) {
                return false;
            }
        };

        orderTable = new JTable(tableModel);
        UIHelper.styleTable(orderTable);

        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(SwingConstants.CENTER);

        orderTable.getColumnModel().getColumn(0).setPreferredWidth(60);
        orderTable.getColumnModel().getColumn(0).setCellRenderer(centerRenderer);

        orderTable.getColumnModel().getColumn(1).setPreferredWidth(160);
        orderTable.getColumnModel().getColumn(2).setPreferredWidth(120);

        orderTable.getColumnModel().getColumn(3).setPreferredWidth(150);
        orderTable.getColumnModel().getColumn(3).setCellRenderer(centerRenderer);

        DefaultTableCellRenderer rightRenderer = new DefaultTableCellRenderer();
        rightRenderer.setHorizontalAlignment(SwingConstants.RIGHT);
        orderTable.getColumnModel().getColumn(4).setPreferredWidth(110);
        orderTable.getColumnModel().getColumn(4).setCellRenderer(rightRenderer);

        orderTable.getColumnModel().getColumn(5).setPreferredWidth(120);
        orderTable.getColumnModel().getColumn(5).setCellRenderer(UIHelper.createStatusCellRenderer());

        // Double click to view details
        orderTable.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2 && orderTable.getSelectedRow() != -1) {
                    onViewDetails();
                }
            }
        });

        JScrollPane scrollPane = new JScrollPane(orderTable);
        UIHelper.styleScrollPane(scrollPane);
        centerCard.add(scrollPane, BorderLayout.CENTER);

        add(centerCard, BorderLayout.CENTER);

        // SOUTH: Actions Toolbar & Status Bar
        JPanel southPanel = new JPanel(new BorderLayout(10, 10));
        southPanel.setOpaque(false);

        JPanel actionPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));
        actionPanel.setOpaque(false);

        btnViewDetails = UIHelper.createSecondaryButton("View Order Details");
        btnViewDetails.setEnabled(false);
        btnViewDetails.addActionListener(e -> onViewDetails());
        actionPanel.add(btnViewDetails);

        actionPanel.add(new JLabel("  Change Status:"));
        cmbNewStatus = new JComboBox<>(new String[]{"CONFIRMED", "PREPARING", "READY", "COMPLETED"});
        UIHelper.styleComboBox(cmbNewStatus);
        cmbNewStatus.setPreferredSize(new Dimension(130, 34));
        cmbNewStatus.setEnabled(false);
        actionPanel.add(cmbNewStatus);

        btnUpdateStatus = UIHelper.createPrimaryButton("Update Status");
        btnUpdateStatus.setEnabled(false);
        btnUpdateStatus.addActionListener(e -> onUpdateStatus());
        actionPanel.add(btnUpdateStatus);

        btnCancelOrder = UIHelper.createDangerButton("Cancel Order");
        btnCancelOrder.setEnabled(false);
        btnCancelOrder.addActionListener(e -> onCancelOrder());
        actionPanel.add(btnCancelOrder);

        JButton btnRefresh = UIHelper.createSecondaryButton("Refresh");
        btnRefresh.addActionListener(e -> loadOrdersAsync());
        actionPanel.add(btnRefresh);

        southPanel.add(actionPanel, BorderLayout.NORTH);

        // Status Bar
        JPanel statusBar = new JPanel(new BorderLayout());
        statusBar.setOpaque(false);

        lblStatusInfo = new JLabel("Loading orders...");
        lblStatusInfo.setFont(UITheme.FONT_SMALL);
        lblStatusInfo.setForeground(UITheme.TEXT_SECONDARY);
        statusBar.add(lblStatusInfo, BorderLayout.WEST);

        progressBar = new JProgressBar();
        progressBar.setPreferredSize(new Dimension(140, 12));
        progressBar.setIndeterminate(true);
        progressBar.setVisible(false);
        statusBar.add(progressBar, BorderLayout.EAST);

        southPanel.add(statusBar, BorderLayout.SOUTH);
        add(southPanel, BorderLayout.SOUTH);
    }

    private void setupSelectionListener() {
        orderTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                int selectedRow = orderTable.getSelectedRow();
                boolean selected = (selectedRow >= 0 && selectedRow < orderList.size());
                btnViewDetails.setEnabled(selected);

                if (selected) {
                    Order ord = orderList.get(selectedRow);
                    boolean isCancelable = !"CANCELLED".equalsIgnoreCase(ord.getStatus()) && !"COMPLETED".equalsIgnoreCase(ord.getStatus());
                    btnCancelOrder.setEnabled(isCancelable);
                    btnUpdateStatus.setEnabled(isCancelable);
                    cmbNewStatus.setEnabled(isCancelable);
                } else {
                    btnCancelOrder.setEnabled(false);
                    btnUpdateStatus.setEnabled(false);
                    cmbNewStatus.setEnabled(false);
                }
            }
        });
    }

    public void loadOrdersAsync() {
        progressBar.setVisible(true);
        lblStatusInfo.setText("Loading orders...");

        SwingWorker<List<Order>, Void> worker = new SwingWorker<>() {
            @Override
            protected List<Order> doInBackground() {
                return orderService.getAllOrders();
            }

            @Override
            protected void done() {
                try {
                    orderList = get();
                    renderTable(orderList);
                    lblStatusInfo.setText("Total Orders Recorded: " + orderList.size());
                } catch (Exception ex) {
                    lblStatusInfo.setText("Error loading orders: " + ex.getMessage());
                } finally {
                    progressBar.setVisible(false);
                }
            }
        };
        worker.execute();
    }

    private void performSearch() {
        String keyword = txtSearch.getText().trim();
        String status = (String) cmbStatusFilter.getSelectedItem();

        progressBar.setVisible(true);
        lblStatusInfo.setText("Searching orders...");

        SwingWorker<List<Order>, Void> worker = new SwingWorker<>() {
            @Override
            protected List<Order> doInBackground() {
                return orderService.searchOrders(keyword, status);
            }

            @Override
            protected void done() {
                try {
                    orderList = get();
                    renderTable(orderList);
                    lblStatusInfo.setText("Found " + orderList.size() + " matching order(s).");
                } catch (Exception ex) {
                    lblStatusInfo.setText("Error: " + ex.getMessage());
                } finally {
                    progressBar.setVisible(false);
                }
            }
        };
        worker.execute();
    }

    private void renderTable(List<Order> list) {
        tableModel.setRowCount(0);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");

        for (Order o : list) {
            String cust = (o.getCustomerName() != null) ? o.getCustomerName() : "Walk-in";
            String phone = (o.getCustomerPhone() != null) ? o.getCustomerPhone() : "-";
            String dateStr = (o.getOrderDate() != null) ? sdf.format(o.getOrderDate()) : "-";

            tableModel.addRow(new Object[]{
                "#" + o.getId(),
                cust,
                phone,
                dateStr,
                FormatUtil.formatCurrency(o.getTotal()),
                o.getStatus()
            });
        }
    }

    private Order getSelectedOrder() {
        int row = orderTable.getSelectedRow();
        if (row >= 0 && row < orderList.size()) {
            return orderList.get(row);
        }
        return null;
    }

    private void onViewDetails() {
        Order selected = getSelectedOrder();
        if (selected == null) return;

        Optional<Order> detailedOpt = orderService.getOrderDetails(selected.getId());
        if (detailedOpt.isPresent()) {
            Window parent = SwingUtilities.getWindowAncestor(this);
            OrderDetailsDialog dialog = new OrderDetailsDialog(parent, detailedOpt.get());
            dialog.setVisible(true);
        } else {
            CustomDialogs.showError(this, "Unable to load order details from database.", "Error");
        }
    }

    private void onUpdateStatus() {
        Order selected = getSelectedOrder();
        if (selected == null) return;

        String newStatus = (String) cmbNewStatus.getSelectedItem();
        try {
            orderService.updateOrderStatus(selected.getId(), newStatus);
            CustomDialogs.showSuccess(this, "Order #" + selected.getId() + " status updated to " + newStatus, "Status Updated");
            loadOrdersAsync();
        } catch (ValidationException ex) {
            CustomDialogs.showWarning(this, ex.getMessage(), "Status Error");
        } catch (Exception ex) {
            CustomDialogs.showError(this, "Failed to update status: " + ex.getMessage(), "Database Error");
        }
    }

    private void onCancelOrder() {
        Order selected = getSelectedOrder();
        if (selected == null) return;

        boolean confirm = CustomDialogs.showDangerConfirm(this,
            "Are you sure you want to cancel Order #" + selected.getId() + "?\nThis will mark the order as CANCELLED.",
            "Confirm Cancellation",
            "Cancel Order");

        if (confirm) {
            try {
                orderService.cancelOrder(selected.getId());
                CustomDialogs.showSuccess(this, "Order #" + selected.getId() + " has been cancelled.", "Order Cancelled");
                loadOrdersAsync();
            } catch (ValidationException ex) {
                CustomDialogs.showWarning(this, ex.getMessage(), "Cancel Error");
            } catch (Exception ex) {
                CustomDialogs.showError(this, "Failed to cancel order: " + ex.getMessage(), "Database Error");
            }
        }
    }
}
