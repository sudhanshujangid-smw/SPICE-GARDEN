package com.restaurantbilling.gui.order;

import com.restaurantbilling.gui.theme.UIHelper;
import com.restaurantbilling.gui.theme.UITheme;
import com.restaurantbilling.gui.util.CustomDialogs;
import com.restaurantbilling.model.Customer;
import com.restaurantbilling.model.FoodItem;
import com.restaurantbilling.model.Order;
import com.restaurantbilling.model.OrderItem;
import com.restaurantbilling.service.CustomerService;
import com.restaurantbilling.service.FoodItemService;
import com.restaurantbilling.service.OrderService;
import com.restaurantbilling.service.PexelsImageService;
import com.restaurantbilling.util.FormatUtil;

import javax.swing.*;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class OrderCreationPanel extends JPanel {

    private final OrderService orderService;
    private final FoodItemService foodItemService;
    private final CustomerService customerService;
    private final PexelsImageService imageService;
    private final Runnable onOrderPlacedCallback;

    // Data lists
    private List<Customer> customerList = new ArrayList<>();
    private List<FoodItem> foodItemList = new ArrayList<>();
    private final List<OrderItem> cartItems = new ArrayList<>();

    // Controls - Menu Side
    private JComboBox<CustomerWrapper> cmbCustomer;
    private JTextField txtFoodSearch;
    private JComboBox<String> cmbFoodCategory;
    private JTable foodTable;
    private DefaultTableModel foodTableModel;

    // Controls - Cart Side
    private JTable cartTable;
    private DefaultTableModel cartTableModel;
    private JLabel lblSubtotal;
    private JTextField txtDiscount;
    private JLabel lblTax;
    private JLabel lblGrandTotal;
    private JButton btnPlaceOrder;
    private JButton btnClearOrder;

    private BigDecimal currentSubtotal = BigDecimal.ZERO;
    private BigDecimal currentDiscount = BigDecimal.ZERO;
    private BigDecimal currentTax = BigDecimal.ZERO;
    private BigDecimal currentGrandTotal = BigDecimal.ZERO;

    public OrderCreationPanel(OrderService orderService, Runnable onOrderPlacedCallback) {
        this.orderService = orderService;
        this.foodItemService = new FoodItemService();
        this.customerService = new CustomerService();
        this.imageService = new PexelsImageService();
        this.onOrderPlacedCallback = onOrderPlacedCallback;

        setLayout(new BorderLayout(15, 15));
        setBorder(new EmptyBorder(16, 20, 16, 20));
        setBackground(UITheme.APP_BG);

        initComponents();
        loadCustomers();
        loadFoodItems();
    }

    private void initComponents() {
        // TOP: Customer Selection Bar Card
        JPanel topPanel = new JPanel(new BorderLayout(10, 10));
        topPanel.setBackground(UITheme.CARD_BG);
        topPanel.setBorder(UITheme.BORDER_CARD);

        JPanel custPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 0));
        custPanel.setOpaque(false);
        JLabel lblCust = new JLabel("Customer Profile:");
        lblCust.setFont(UITheme.FONT_BODY_BOLD);
        lblCust.setForeground(UITheme.TEXT_PRIMARY);
        custPanel.add(lblCust);

        cmbCustomer = new JComboBox<>();
        UIHelper.styleComboBox(cmbCustomer);
        cmbCustomer.setPreferredSize(new Dimension(320, 34));
        custPanel.add(cmbCustomer);

        JButton btnRefreshCust = UIHelper.createSecondaryButton("Refresh Customers");
        btnRefreshCust.addActionListener(e -> loadCustomers());
        custPanel.add(btnRefreshCust);

        topPanel.add(custPanel, BorderLayout.CENTER);
        add(topPanel, BorderLayout.NORTH);

        // CENTER: 2-Column Split (Left: Menu, Right: Cart)
        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
        splitPane.setResizeWeight(0.55);
        splitPane.setDividerSize(8);
        splitPane.setBorder(null);
        splitPane.setOpaque(false);

        // LEFT: Menu Panel
        JPanel leftMenuPanel = createMenuPanel();
        splitPane.setLeftComponent(leftMenuPanel);

        // RIGHT: Cart Panel
        JPanel rightCartPanel = createCartPanel();
        splitPane.setRightComponent(rightCartPanel);

        add(splitPane, BorderLayout.CENTER);
    }

    private JPanel createMenuPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBackground(UITheme.CARD_BG);
        panel.setBorder(UITheme.BORDER_CARD);

        // Header & Search
        JPanel headerPanel = new JPanel(new BorderLayout(5, 8));
        headerPanel.setOpaque(false);

        JLabel lblMenuTitle = new JLabel("🍽️ Food Menu Selection");
        lblMenuTitle.setFont(UITheme.FONT_SECTION);
        lblMenuTitle.setForeground(UITheme.TEXT_PRIMARY);
        headerPanel.add(lblMenuTitle, BorderLayout.NORTH);

        JPanel searchBar = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        searchBar.setOpaque(false);

        txtFoodSearch = new JTextField(12);
        UIHelper.styleTextField(txtFoodSearch);
        txtFoodSearch.setPreferredSize(new Dimension(140, 32));
        txtFoodSearch.putClientProperty("JTextField.placeholderText", "Search food...");
        txtFoodSearch.addActionListener(e -> filterFoodItems());
        searchBar.add(txtFoodSearch);

        cmbFoodCategory = new JComboBox<>(new String[]{"All", "Starter", "Main Course", "Breads", "Beverages", "Dessert", "Fast Food"});
        UIHelper.styleComboBox(cmbFoodCategory);
        cmbFoodCategory.setPreferredSize(new Dimension(110, 32));
        cmbFoodCategory.addActionListener(e -> filterFoodItems());
        searchBar.add(cmbFoodCategory);

        JButton btnSearch = UIHelper.createSecondaryButton("Filter");
        btnSearch.setPreferredSize(new Dimension(75, 32));
        btnSearch.addActionListener(e -> filterFoodItems());
        searchBar.add(btnSearch);

        headerPanel.add(searchBar, BorderLayout.SOUTH);
        panel.add(headerPanel, BorderLayout.NORTH);

        // Table
        String[] columns = {"ID", "Image", "Item Name", "Category", "Price", "Available"};
        foodTableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int col) {
                return false;
            }
            @Override
            public Class<?> getColumnClass(int columnIndex) {
                if (columnIndex == 1) return ImageIcon.class;
                return super.getColumnClass(columnIndex);
            }
        };

        foodTable = new JTable(foodTableModel);
        UIHelper.styleTable(foodTable);
        foodTable.setRowHeight(50);

        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(SwingConstants.CENTER);
        foodTable.getColumnModel().getColumn(0).setPreferredWidth(40);
        foodTable.getColumnModel().getColumn(0).setCellRenderer(centerRenderer);

        foodTable.getColumnModel().getColumn(1).setPreferredWidth(70);
        foodTable.getColumnModel().getColumn(2).setPreferredWidth(140);
        foodTable.getColumnModel().getColumn(3).setPreferredWidth(100);

        DefaultTableCellRenderer rightRenderer = new DefaultTableCellRenderer();
        rightRenderer.setHorizontalAlignment(SwingConstants.RIGHT);
        foodTable.getColumnModel().getColumn(4).setPreferredWidth(80);
        foodTable.getColumnModel().getColumn(4).setCellRenderer(rightRenderer);

        foodTable.getColumnModel().getColumn(5).setPreferredWidth(90);
        foodTable.getColumnModel().getColumn(5).setCellRenderer(UIHelper.createStatusCellRenderer());

        // Double-click to add to cart
        foodTable.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2 && foodTable.getSelectedRow() != -1) {
                    onAddToCart();
                }
            }
        });

        JScrollPane scrollPane = new JScrollPane(foodTable);
        UIHelper.styleScrollPane(scrollPane);
        panel.add(scrollPane, BorderLayout.CENTER);

        // Add to Order Button
        JPanel actionPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 0));
        actionPanel.setOpaque(false);
        JButton btnAddToCart = UIHelper.createPrimaryButton("+ Add Selected Item to Order");
        btnAddToCart.addActionListener(e -> onAddToCart());
        actionPanel.add(btnAddToCart);
        panel.add(actionPanel, BorderLayout.SOUTH);

        return panel;
    }

    private JPanel createCartPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBackground(UITheme.CARD_BG);
        panel.setBorder(UITheme.BORDER_CARD);

        // Header
        JLabel lblCartTitle = new JLabel("🛒 Current Order Cart");
        lblCartTitle.setFont(UITheme.FONT_SECTION);
        lblCartTitle.setForeground(UITheme.TEXT_PRIMARY);
        panel.add(lblCartTitle, BorderLayout.NORTH);

        // Cart Table
        String[] columns = {"Item", "Price", "Qty", "Amount"};
        cartTableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int col) {
                return false;
            }
        };

        cartTable = new JTable(cartTableModel);
        UIHelper.styleTable(cartTable);

        DefaultTableCellRenderer rightRenderer = new DefaultTableCellRenderer();
        rightRenderer.setHorizontalAlignment(SwingConstants.RIGHT);
        cartTable.getColumnModel().getColumn(0).setPreferredWidth(160);
        cartTable.getColumnModel().getColumn(1).setPreferredWidth(80);
        cartTable.getColumnModel().getColumn(1).setCellRenderer(rightRenderer);
        cartTable.getColumnModel().getColumn(2).setPreferredWidth(50);
        cartTable.getColumnModel().getColumn(2).setCellRenderer(rightRenderer);
        cartTable.getColumnModel().getColumn(3).setPreferredWidth(90);
        cartTable.getColumnModel().getColumn(3).setCellRenderer(rightRenderer);

        JScrollPane scrollPane = new JScrollPane(cartTable);
        UIHelper.styleScrollPane(scrollPane);
        panel.add(scrollPane, BorderLayout.CENTER);

        // Bottom Cart Area (Controls + Summary + Place Order)
        JPanel bottomCartArea = new JPanel(new BorderLayout(10, 10));
        bottomCartArea.setOpaque(false);

        // Quantity Modifier Buttons
        JPanel qtyControlPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 4));
        qtyControlPanel.setOpaque(false);

        JButton btnInc = UIHelper.createSecondaryButton("➕ Increase (+1)");
        btnInc.addActionListener(e -> modifyQuantity(1));
        qtyControlPanel.add(btnInc);

        JButton btnDec = UIHelper.createSecondaryButton("➖ Decrease (-1)");
        btnDec.addActionListener(e -> modifyQuantity(-1));
        qtyControlPanel.add(btnDec);

        JButton btnRemove = UIHelper.createDangerButton("Remove Item");
        btnRemove.addActionListener(e -> removeItem());
        qtyControlPanel.add(btnRemove);

        bottomCartArea.add(qtyControlPanel, BorderLayout.NORTH);

        // Summary Calculations Box Card
        JPanel summaryBox = new JPanel(new GridLayout(4, 2, 8, 4));
        summaryBox.setBackground(UITheme.CARD_BG_ALT);
        summaryBox.setBorder(new CompoundBorder(
            new LineBorder(UITheme.BORDER, 1, true),
            new EmptyBorder(10, 14, 10, 14)
        ));

        summaryBox.add(new JLabel("Subtotal:"));
        lblSubtotal = new JLabel("₹0.00", SwingConstants.RIGHT);
        lblSubtotal.setFont(UITheme.FONT_BODY_BOLD);
        lblSubtotal.setForeground(UITheme.TEXT_PRIMARY);
        summaryBox.add(lblSubtotal);

        summaryBox.add(new JLabel("Discount (₹):"));
        txtDiscount = new JTextField("0.00");
        UIHelper.styleTextField(txtDiscount);
        txtDiscount.setHorizontalAlignment(SwingConstants.RIGHT);
        txtDiscount.addActionListener(e -> recalculateTotals());
        summaryBox.add(txtDiscount);

        summaryBox.add(new JLabel("Tax / GST:"));
        lblTax = new JLabel("₹0.00", SwingConstants.RIGHT);
        lblTax.setFont(UITheme.FONT_BODY_BOLD);
        lblTax.setForeground(UITheme.TEXT_PRIMARY);
        summaryBox.add(lblTax);

        JLabel lblTotalText = new JLabel("TOTAL AMOUNT:");
        lblTotalText.setFont(UITheme.FONT_SECTION);
        lblTotalText.setForeground(UITheme.TEXT_PRIMARY);
        summaryBox.add(lblTotalText);

        lblGrandTotal = new JLabel("₹0.00", SwingConstants.RIGHT);
        lblGrandTotal.setFont(UITheme.FONT_TITLE_LARGE);
        lblGrandTotal.setForeground(UITheme.PRIMARY);
        summaryBox.add(lblGrandTotal);

        bottomCartArea.add(summaryBox, BorderLayout.CENTER);

        // Action Buttons
        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 6));
        btnPanel.setOpaque(false);

        btnClearOrder = UIHelper.createSecondaryButton("Clear Cart");
        btnClearOrder.addActionListener(e -> onClearOrder());
        btnPanel.add(btnClearOrder);

        btnPlaceOrder = UIHelper.createSuccessButton("PLACE ORDER ➔");
        btnPlaceOrder.setPreferredSize(new Dimension(160, 38));
        btnPlaceOrder.setFont(UITheme.FONT_SECTION);
        btnPlaceOrder.addActionListener(e -> onPlaceOrder());
        btnPanel.add(btnPlaceOrder);

        bottomCartArea.add(btnPanel, BorderLayout.SOUTH);
        panel.add(bottomCartArea, BorderLayout.SOUTH);

        return panel;
    }

    public void loadCustomers() {
        SwingWorker<List<Customer>, Void> worker = new SwingWorker<>() {
            @Override
            protected List<Customer> doInBackground() {
                return customerService.getAllCustomers();
            }

            @Override
            protected void done() {
                try {
                    customerList = get();
                    cmbCustomer.removeAllItems();
                    cmbCustomer.addItem(new CustomerWrapper(null, "Walk-in Customer"));
                    for (Customer c : customerList) {
                        if ("Active".equalsIgnoreCase(c.getStatus())) {
                            cmbCustomer.addItem(new CustomerWrapper(c.getId(), c.getName() + " (" + c.getPhone() + ")"));
                        }
                    }
                } catch (Exception ignored) {}
            }
        };
        worker.execute();
    }

    public void loadFoodItems() {
        SwingWorker<List<FoodItem>, Void> worker = new SwingWorker<>() {
            @Override
            protected List<FoodItem> doInBackground() {
                return foodItemService.getAllFoodItems();
            }

            @Override
            protected void done() {
                try {
                    foodItemList = get();
                    renderFoodTable(foodItemList);
                } catch (Exception ignored) {}
            }
        };
        worker.execute();
    }

    private void filterFoodItems() {
        String keyword = txtFoodSearch.getText().trim();
        String cat = (String) cmbFoodCategory.getSelectedItem();

        SwingWorker<List<FoodItem>, Void> worker = new SwingWorker<>() {
            @Override
            protected List<FoodItem> doInBackground() {
                return foodItemService.searchFoodItems(keyword, cat);
            }

            @Override
            protected void done() {
                try {
                    foodItemList = get();
                    renderFoodTable(foodItemList);
                } catch (Exception ignored) {}
            }
        };
        worker.execute();
    }

    private void renderFoodTable(List<FoodItem> list) {
        foodTableModel.setRowCount(0);
        for (FoodItem item : list) {
            ImageIcon placeholder = null;
            
            foodTableModel.addRow(new Object[]{
                item.getId(),
                placeholder,
                item.getName(),
                item.getCategory(),
                FormatUtil.formatCurrency(item.getPrice()),
                item.isAvailable() ? "Available" : "Out of Stock"
            });
            
            final int rowIdx = foodTableModel.getRowCount() - 1;
            
            if (item.getPexelsPhotoId() != null && item.getImageUrl() != null) {
                SwingWorker<ImageIcon, Void> worker = new SwingWorker<>() {
                    @Override
                    protected ImageIcon doInBackground() throws Exception {
                        Image img = imageService.getCachedOrDownloadImage(item.getPexelsPhotoId(), item.getImageUrl());
                        if (img != null) {
                            return new ImageIcon(img.getScaledInstance(60, 50, Image.SCALE_SMOOTH));
                        }
                        return null;
                    }
                    @Override
                    protected void done() {
                        try {
                            ImageIcon loaded = get();
                            if (loaded != null) {
                                // Double check if row hasn't changed due to sorting/filtering
                                if (rowIdx < foodTableModel.getRowCount() && foodTableModel.getValueAt(rowIdx, 0).equals(item.getId())) {
                                    foodTableModel.setValueAt(loaded, rowIdx, 1);
                                }
                            }
                        } catch (Exception ignored) {}
                    }
                };
                worker.execute();
            }
        }
    }

    private void onAddToCart() {
        int selectedRow = foodTable.getSelectedRow();
        if (selectedRow < 0 || selectedRow >= foodItemList.size()) {
            CustomDialogs.showWarning(this, "Please select an item from the menu table.", "Selection Required");
            return;
        }

        FoodItem selected = foodItemList.get(selectedRow);

        if (!selected.isAvailable()) {
            CustomDialogs.showWarning(this,
                "'" + selected.getName() + "' is currently out of stock and cannot be added.",
                "Item Unavailable");
            return;
        }

        for (OrderItem item : cartItems) {
            if (item.getFoodItemId() == selected.getId()) {
                item.setQuantity(item.getQuantity() + 1);
                refreshCartTable();
                return;
            }
        }

        OrderItem newItem = new OrderItem(selected.getId(), selected.getName(), 1, selected.getPrice());
        cartItems.add(newItem);
        refreshCartTable();
    }

    private void modifyQuantity(int delta) {
        int selectedRow = cartTable.getSelectedRow();
        if (selectedRow < 0 || selectedRow >= cartItems.size()) {
            return;
        }

        OrderItem item = cartItems.get(selectedRow);
        int newQty = item.getQuantity() + delta;

        if (newQty <= 0) {
            boolean confirm = CustomDialogs.showConfirm(this,
                "Remove '" + item.getFoodItemName() + "' from cart?",
                "Confirm Removal",
                "Remove",
                "Keep");
            if (confirm) {
                cartItems.remove(selectedRow);
            }
        } else {
            item.setQuantity(newQty);
        }
        refreshCartTable();
    }

    private void removeItem() {
        int selectedRow = cartTable.getSelectedRow();
        if (selectedRow < 0 || selectedRow >= cartItems.size()) {
            CustomDialogs.showWarning(this, "Please select an item in the cart to remove.", "Selection Required");
            return;
        }
        cartItems.remove(selectedRow);
        refreshCartTable();
    }

    private void refreshCartTable() {
        cartTableModel.setRowCount(0);
        currentSubtotal = BigDecimal.ZERO;

        for (OrderItem item : cartItems) {
            currentSubtotal = currentSubtotal.add(item.getSubtotal());
            cartTableModel.addRow(new Object[]{
                item.getFoodItemName(),
                FormatUtil.formatCurrency(item.getUnitPrice()),
                item.getQuantity(),
                FormatUtil.formatCurrency(item.getSubtotal())
            });
        }

        recalculateTotals();
    }

    private void recalculateTotals() {
        lblSubtotal.setText(FormatUtil.formatCurrency(currentSubtotal));

        try {
            String discStr = txtDiscount.getText().trim();
            currentDiscount = discStr.isEmpty() ? BigDecimal.ZERO : new BigDecimal(discStr);
            if (currentDiscount.compareTo(BigDecimal.ZERO) < 0) {
                currentDiscount = BigDecimal.ZERO;
            }
            if (currentDiscount.compareTo(currentSubtotal) > 0) {
                currentDiscount = currentSubtotal;
            }
        } catch (Exception e) {
            currentDiscount = BigDecimal.ZERO;
        }

        currentTax = BigDecimal.ZERO;
        currentGrandTotal = currentSubtotal.subtract(currentDiscount).add(currentTax);

        lblTax.setText(FormatUtil.formatCurrency(currentTax));
        lblGrandTotal.setText(FormatUtil.formatCurrency(currentGrandTotal));
    }

    private void onClearOrder() {
        if (cartItems.isEmpty()) return;

        boolean confirm = CustomDialogs.showConfirm(this,
            "Are you sure you want to clear all items from the current order?",
            "Clear Current Order",
            "Clear Cart",
            "Keep Cart");

        if (confirm) {
            cartItems.clear();
            txtDiscount.setText("0.00");
            refreshCartTable();
        }
    }

    private void onPlaceOrder() {
        if (cartItems.isEmpty()) {
            CustomDialogs.showWarning(this, "Cart is empty. Please add menu items before placing an order.", "Empty Order");
            return;
        }

        recalculateTotals();

        CustomerWrapper selectedCust = (CustomerWrapper) cmbCustomer.getSelectedItem();
        Integer customerId = (selectedCust != null) ? selectedCust.id : null;

        Order newOrder = new Order(
            customerId,
            currentSubtotal,
            currentDiscount,
            currentTax,
            currentGrandTotal,
            "PENDING"
        );

        boolean confirm = CustomDialogs.showConfirm(this,
            "Place Order for " + selectedCust + " with " + cartItems.size() + " item(s)?\nGrand Total: " + FormatUtil.formatCurrency(currentGrandTotal),
            "Confirm Order Placement",
            "Place Order",
            "Cancel");

        if (!confirm) {
            return;
        }

        btnPlaceOrder.setEnabled(false);

        SwingWorker<Order, Void> worker = new SwingWorker<>() {
            @Override
            protected Order doInBackground() throws Exception {
                return orderService.createOrder(newOrder, new ArrayList<>(cartItems));
            }

            @Override
            protected void done() {
                btnPlaceOrder.setEnabled(true);
                try {
                    Order created = get();
                    CustomDialogs.showSuccess(OrderCreationPanel.this,
                        "Order #" + created.getId() + " placed successfully!\nStatus: PENDING",
                        "Order Placed");

                    cartItems.clear();
                    txtDiscount.setText("0.00");
                    refreshCartTable();

                    if (onOrderPlacedCallback != null) {
                        onOrderPlacedCallback.run();
                    }
                } catch (Exception ex) {
                    Throwable cause = ex.getCause() != null ? ex.getCause() : ex;
                    CustomDialogs.showError(OrderCreationPanel.this,
                        cause.getMessage(),
                        "Order Creation Failed");
                }
            }
        };
        worker.execute();
    }

    private static class CustomerWrapper {
        final Integer id;
        final String displayName;

        CustomerWrapper(Integer id, String displayName) {
            this.id = id;
            this.displayName = displayName;
        }

        @Override
        public String toString() {
            return displayName;
        }
    }
}
