package com.restaurantbilling.gui.util;

import com.restaurantbilling.gui.theme.UIHelper;
import com.restaurantbilling.gui.theme.UITheme;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

/**
 * Modern, styled modal dialogs replacing raw JOptionPane boxes with unified branding.
 */
public final class CustomDialogs {

    private CustomDialogs() {
    }

    public static void showSuccess(Component parent, String message, String title) {
        showThemedDialog(parent, title != null ? title : "Success", message, "✓", UITheme.SUCCESS, false, null, "OK");
    }

    public static void showError(Component parent, String message, String title) {
        showThemedDialog(parent, title != null ? title : "Error", message, "✕", UITheme.DANGER, false, null, "OK");
    }

    public static void showWarning(Component parent, String message, String title) {
        showThemedDialog(parent, title != null ? title : "Warning", message, "⚠", UITheme.WARNING, false, null, "OK");
    }

    public static void showInfo(Component parent, String message, String title) {
        showThemedDialog(parent, title != null ? title : "Information", message, "ℹ", UITheme.PRIMARY, false, null, "OK");
    }

    public static boolean showConfirm(Component parent, String message, String title, String confirmText, String cancelText) {
        return showThemedDialog(parent, title != null ? title : "Confirm Action", message, "?", UITheme.PRIMARY, true, confirmText != null ? confirmText : "Confirm", cancelText != null ? cancelText : "Cancel");
    }

    public static boolean showDangerConfirm(Component parent, String message, String title, String dangerBtnText) {
        return showThemedDialog(parent, title != null ? title : "Confirm Delete", message, "🗑", UITheme.DANGER, true, dangerBtnText != null ? dangerBtnText : "Delete", "Cancel");
    }

    private static boolean showThemedDialog(Component parent, String title, String message, String iconText, Color accentColor, boolean isConfirm, String confirmText, String cancelOrOkText) {
        Window owner = (parent instanceof Window w) ? w : SwingUtilities.getWindowAncestor(parent);
        JDialog dialog = new JDialog(owner, title, Dialog.ModalityType.APPLICATION_MODAL);
        dialog.setResizable(false);

        JPanel content = new JPanel(new BorderLayout(15, 15));
        content.setBackground(UITheme.CARD_BG);
        content.setBorder(new EmptyBorder(20, 24, 20, 24));

        // Header with colored icon and title
        JPanel top = new JPanel(new BorderLayout(12, 0));
        top.setOpaque(false);

        JLabel lblIcon = new JLabel(iconText, SwingConstants.CENTER);
        lblIcon.setFont(new Font("Segoe UI", Font.BOLD, 22));
        lblIcon.setForeground(Color.WHITE);
        lblIcon.setOpaque(true);
        lblIcon.setBackground(accentColor);
        lblIcon.setPreferredSize(new Dimension(42, 42));
        lblIcon.setBorder(new EmptyBorder(4, 4, 4, 4));

        JPanel textPanel = new JPanel(new GridLayout(2, 1, 0, 4));
        textPanel.setOpaque(false);

        JLabel lblTitle = new JLabel(title);
        lblTitle.setFont(UITheme.FONT_TITLE_MEDIUM);
        lblTitle.setForeground(UITheme.TEXT_PRIMARY);

        JLabel lblMsg = new JLabel("<html><body style='width: 320px; font-family: Segoe UI; font-size: 11px;'>" + message.replace("\n", "<br>") + "</body></html>");
        lblMsg.setForeground(UITheme.TEXT_SECONDARY);

        textPanel.add(lblTitle);
        textPanel.add(lblMsg);

        top.add(lblIcon, BorderLayout.WEST);
        top.add(textPanel, BorderLayout.CENTER);
        content.add(top, BorderLayout.CENTER);

        // Buttons
        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        btnPanel.setOpaque(false);
        btnPanel.setBorder(new EmptyBorder(10, 0, 0, 0));

        final boolean[] result = {false};

        if (isConfirm) {
            JButton btnCancel = UIHelper.createSecondaryButton(cancelOrOkText);
            btnCancel.addActionListener(e -> {
                result[0] = false;
                dialog.dispose();
            });
            btnPanel.add(btnCancel);

            JButton btnConfirm = accentColor.equals(UITheme.DANGER)
                ? UIHelper.createDangerButton(confirmText)
                : UIHelper.createPrimaryButton(confirmText);

            btnConfirm.addActionListener(e -> {
                result[0] = true;
                dialog.dispose();
            });
            btnPanel.add(btnConfirm);
        } else {
            JButton btnOk = UIHelper.createPrimaryButton(cancelOrOkText);
            btnOk.setPreferredSize(new Dimension(90, 34));
            btnOk.addActionListener(e -> dialog.dispose());
            btnPanel.add(btnOk);
        }

        content.add(btnPanel, BorderLayout.SOUTH);
        dialog.setContentPane(content);
        dialog.pack();
        dialog.setLocationRelativeTo(owner);
        dialog.setVisible(true);

        return result[0];
    }
}
