package com.restaurantbilling.gui.audit;

import com.restaurantbilling.gui.theme.UIHelper;
import com.restaurantbilling.gui.theme.UITheme;
import com.restaurantbilling.model.audit.AuditLog;
import com.restaurantbilling.service.AuditService;
import com.restaurantbilling.util.FormatUtil;
import com.restaurantbilling.util.UserSession;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class AuditLogPanel extends JPanel {

    private final AuditService auditService;

    // Filter controls
    private JTextField txtSearch;
    private JComboBox<String> cmbModule;
    private JComboBox<String> cmbAction;
    private JComboBox<String> cmbStatus;
    private JTextField txtUser;
    private JTextField txtFromDate;
    private JTextField txtToDate;
    private JButton btnSearch;
    private JButton btnClear;

    // Table
    private JTable tblAudit;
    private DefaultTableModel tableModel;

    // Pagination controls
    private int currentPage = 1;
    private int pageSize = 25;
    private int totalRecords = 0;
    private JLabel lblPaginationInfo;
    private JLabel lblPageNumber;
    private JButton btnPrev;
    private JButton btnNext;
    private JComboBox<Integer> cmbPageSize;

    private JLabel lblRoleNotice;

    public AuditLogPanel() {
        this.auditService = new AuditService();

        setLayout(new BorderLayout(15, 15));
        setBorder(new EmptyBorder(16, 20, 16, 20));
        setBackground(UITheme.APP_BG);

        initComponents();
        loadAuditLogsAsync();
    }

    private void initComponents() {
        // TOP: Header
        JPanel topPanel = new JPanel(new BorderLayout(10, 5));
        topPanel.setOpaque(false);

        JPanel titlePanel = new JPanel(new GridLayout(2, 1, 0, 3));
        titlePanel.setOpaque(false);

        JLabel lblTitle = new JLabel("Security Audit Logs & Access Tracking");
        lblTitle.setFont(UITheme.FONT_TITLE_LARGE);
        lblTitle.setForeground(UITheme.TEXT_PRIMARY);
        titlePanel.add(lblTitle);

        JLabel lblSub = new JLabel("Immutable security event trail, authentication logs, and data operation tracking.");
        lblSub.setFont(UITheme.FONT_BODY_MEDIUM);
        lblSub.setForeground(UITheme.TEXT_SECONDARY);
        titlePanel.add(lblSub);

        topPanel.add(titlePanel, BorderLayout.WEST);

        boolean isAdmin = UserSession.isAdmin();
        lblRoleNotice = UIHelper.createStatusBadge(
            isAdmin ? "ADMIN: Full Audit Trail" : "STAFF: Restricted / Read-Only",
            isAdmin ? UITheme.SUCCESS_BG : UITheme.DANGER_BG,
            isAdmin ? UITheme.SUCCESS_DARK : UITheme.DANGER_DARK
        );
        topPanel.add(lblRoleNotice, BorderLayout.EAST);

        add(topPanel, BorderLayout.NORTH);

        // CENTER: Container with Filter Toolbar and Table
        JPanel centerContainer = new JPanel(new BorderLayout(12, 12));
        centerContainer.setOpaque(false);

        // Filter Card
        centerContainer.add(createFilterCard(), BorderLayout.NORTH);

        // Table Card
        centerContainer.add(createTableCard(), BorderLayout.CENTER);

        add(centerContainer, BorderLayout.CENTER);

        // SOUTH: Pagination Toolbar
        add(createPaginationToolbar(), BorderLayout.SOUTH);
    }

    private JPanel createFilterCard() {
        JPanel card = new JPanel(new GridBagLayout());
        card.setBackground(UITheme.CARD_BG);
        card.setBorder(UITheme.BORDER_CARD);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Row 1: Search keyword, Module, Action, Status
        gbc.gridx = 0; gbc.gridy = 0; gbc.weightx = 0.3;
        txtSearch = new JTextField(15);
        UIHelper.styleTextField(txtSearch);
        txtSearch.putClientProperty("JTextField.placeholderText", "Search description, user, action...");
        card.add(createLabeledComponent("Keyword Search:", txtSearch), gbc);

        gbc.gridx = 1; gbc.gridy = 0; gbc.weightx = 0.2;
        cmbModule = new JComboBox<>(new String[]{"ALL", "AUTH", "MENU", "CUSTOMER", "ORDER", "BILLING", "SETTINGS", "MAINTENANCE", "SECURITY"});
        UIHelper.styleComboBox(cmbModule);
        card.add(createLabeledComponent("Module:", cmbModule), gbc);

        gbc.gridx = 2; gbc.gridy = 0; gbc.weightx = 0.25;
        cmbAction = new JComboBox<>(new String[]{
            "ALL", "LOGIN_SUCCESS", "LOGIN_FAILED", "LOGOUT", "MENU_CREATED", "MENU_UPDATED",
            "MENU_DELETED", "CUSTOMER_CREATED", "CUSTOMER_UPDATED", "CUSTOMER_DELETED",
            "ORDER_CREATED", "ORDER_UPDATED", "ORDER_CANCELLED", "BILL_GENERATED",
            "SETTINGS_UPDATED", "BACKUP_CREATED", "RESTORE_STARTED", "RESTORE_COMPLETED", "ACCESS_DENIED", "PASSWORD_CHANGED"
        });
        UIHelper.styleComboBox(cmbAction);
        card.add(createLabeledComponent("Action:", cmbAction), gbc);

        gbc.gridx = 3; gbc.gridy = 0; gbc.weightx = 0.15;
        cmbStatus = new JComboBox<>(new String[]{"ALL", "SUCCESS", "FAILED", "DENIED", "WARNING"});
        UIHelper.styleComboBox(cmbStatus);
        card.add(createLabeledComponent("Status:", cmbStatus), gbc);

        // Row 2: User, From Date, To Date, Buttons
        gbc.gridx = 0; gbc.gridy = 1; gbc.weightx = 0.3;
        txtUser = new JTextField(10);
        UIHelper.styleTextField(txtUser);
        card.add(createLabeledComponent("Username:", txtUser), gbc);

        gbc.gridx = 1; gbc.gridy = 1; gbc.weightx = 0.2;
        txtFromDate = new JTextField(10);
        UIHelper.styleTextField(txtFromDate);
        txtFromDate.putClientProperty("JTextField.placeholderText", "YYYY-MM-DD");
        card.add(createLabeledComponent("From Date:", txtFromDate), gbc);

        gbc.gridx = 2; gbc.gridy = 1; gbc.weightx = 0.25;
        txtToDate = new JTextField(10);
        UIHelper.styleTextField(txtToDate);
        txtToDate.putClientProperty("JTextField.placeholderText", "YYYY-MM-DD");
        card.add(createLabeledComponent("To Date:", txtToDate), gbc);

        gbc.gridx = 3; gbc.gridy = 1; gbc.weightx = 0.15;
        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 5, 0));
        btnPanel.setOpaque(false);

        btnSearch = UIHelper.createPrimaryButton("Search");
        btnSearch.setPreferredSize(new Dimension(80, 34));
        btnSearch.addActionListener(e -> {
            currentPage = 1;
            loadAuditLogsAsync();
        });

        btnClear = UIHelper.createSecondaryButton("Clear");
        btnClear.setPreferredSize(new Dimension(75, 34));
        btnClear.addActionListener(e -> onClearFilters());

        btnPanel.add(btnClear);
        btnPanel.add(btnSearch);
        card.add(btnPanel, gbc);

        return card;
    }

    private JPanel createLabeledComponent(String labelText, JComponent comp) {
        JPanel p = new JPanel(new BorderLayout(2, 4));
        p.setOpaque(false);
        JLabel l = new JLabel(labelText);
        l.setFont(UITheme.FONT_BODY_BOLD);
        l.setForeground(UITheme.TEXT_SECONDARY);
        p.add(l, BorderLayout.NORTH);
        p.add(comp, BorderLayout.CENTER);
        return p;
    }

    private JPanel createTableCard() {
        JPanel card = new JPanel(new BorderLayout());
        card.setBackground(UITheme.CARD_BG);
        card.setBorder(new LineBorder(UITheme.BORDER, 1, true));

        String[] columns = {"ID", "Date & Time", "User", "Module", "Action", "Status", "Description"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Immutability
            }
        };

        tblAudit = new JTable(tableModel);
        UIHelper.styleTable(tblAudit);

        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(SwingConstants.CENTER);

        tblAudit.getColumnModel().getColumn(0).setPreferredWidth(50);
        tblAudit.getColumnModel().getColumn(0).setCellRenderer(centerRenderer);
        tblAudit.getColumnModel().getColumn(1).setPreferredWidth(140);
        tblAudit.getColumnModel().getColumn(2).setPreferredWidth(90);
        tblAudit.getColumnModel().getColumn(3).setPreferredWidth(90);
        tblAudit.getColumnModel().getColumn(3).setCellRenderer(centerRenderer);
        tblAudit.getColumnModel().getColumn(4).setPreferredWidth(140);
        tblAudit.getColumnModel().getColumn(5).setPreferredWidth(90);
        tblAudit.getColumnModel().getColumn(5).setCellRenderer(UIHelper.createStatusCellRenderer());
        tblAudit.getColumnModel().getColumn(6).setPreferredWidth(360);

        JScrollPane scrollPane = new JScrollPane(tblAudit);
        UIHelper.styleScrollPane(scrollPane);
        card.add(scrollPane, BorderLayout.CENTER);

        return card;
    }

    private JPanel createPaginationToolbar() {
        JPanel bar = new JPanel(new BorderLayout(10, 10));
        bar.setOpaque(false);

        lblPaginationInfo = new JLabel("Showing 0-0 of 0 records");
        lblPaginationInfo.setFont(UITheme.FONT_SMALL);
        lblPaginationInfo.setForeground(UITheme.TEXT_SECONDARY);
        bar.add(lblPaginationInfo, BorderLayout.WEST);

        JPanel centerPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 8, 0));
        centerPanel.setOpaque(false);

        btnPrev = UIHelper.createSecondaryButton("◀ Previous");
        btnPrev.addActionListener(e -> {
            if (currentPage > 1) {
                currentPage--;
                loadAuditLogsAsync();
            }
        });

        lblPageNumber = new JLabel("Page 1 of 1");
        lblPageNumber.setFont(UITheme.FONT_BODY_BOLD);
        lblPageNumber.setForeground(UITheme.TEXT_PRIMARY);

        btnNext = UIHelper.createSecondaryButton("Next ▶");
        btnNext.addActionListener(e -> {
            int maxPages = (int) Math.ceil((double) totalRecords / pageSize);
            if (currentPage < maxPages) {
                currentPage++;
                loadAuditLogsAsync();
            }
        });

        centerPanel.add(btnPrev);
        centerPanel.add(lblPageNumber);
        centerPanel.add(btnNext);
        bar.add(centerPanel, BorderLayout.CENTER);

        JPanel rightPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 5, 0));
        rightPanel.setOpaque(false);
        JLabel lblPageSize = new JLabel("Page Size:");
        lblPageSize.setFont(UITheme.FONT_BODY_BOLD);
        rightPanel.add(lblPageSize);
        cmbPageSize = new JComboBox<>(new Integer[]{25, 50, 100});
        UIHelper.styleComboBox(cmbPageSize);
        cmbPageSize.setPreferredSize(new Dimension(75, 32));
        cmbPageSize.addActionListener(e -> {
            pageSize = (Integer) cmbPageSize.getSelectedItem();
            currentPage = 1;
            loadAuditLogsAsync();
        });
        rightPanel.add(cmbPageSize);
        bar.add(rightPanel, BorderLayout.EAST);

        return bar;
    }

    private void onClearFilters() {
        txtSearch.setText("");
        cmbModule.setSelectedIndex(0);
        cmbAction.setSelectedIndex(0);
        cmbStatus.setSelectedIndex(0);
        txtUser.setText("");
        txtFromDate.setText("");
        txtToDate.setText("");
        currentPage = 1;
        loadAuditLogsAsync();
    }

    public void loadAuditLogsAsync() {
        boolean isAdmin = UserSession.isAdmin();
        lblRoleNotice.setText(isAdmin ? "ADMIN: Full Audit Trail" : "STAFF: Restricted / Read-Only");

        if (!isAdmin) {
            tableModel.setRowCount(0);
            lblPaginationInfo.setText("Access Denied: Only administrators can view security audit logs.");
            btnPrev.setEnabled(false);
            btnNext.setEnabled(false);
            return;
        }

        String keyword = txtSearch.getText().trim();
        String module = (String) cmbModule.getSelectedItem();
        String action = (String) cmbAction.getSelectedItem();
        String status = (String) cmbStatus.getSelectedItem();
        String username = txtUser.getText().trim();

        LocalDate from = parseDate(txtFromDate.getText().trim());
        LocalDate to = parseDate(txtToDate.getText().trim());

        btnSearch.setEnabled(false);

        SwingWorker<List<AuditLog>, Void> worker = new SwingWorker<>() {
            private int count = 0;

            @Override
            protected List<AuditLog> doInBackground() throws Exception {
                count = auditService.getTotalLogCount(keyword, username, module, action, status, from, to);
                return auditService.getAuditLogs(keyword, username, module, action, status, from, to, currentPage, pageSize);
            }

            @Override
            protected void done() {
                btnSearch.setEnabled(true);
                try {
                    List<AuditLog> logs = get();
                    totalRecords = count;
                    tableModel.setRowCount(0);

                    for (AuditLog log : logs) {
                        tableModel.addRow(new Object[]{
                            log.getId(),
                            FormatUtil.formatDateTime(log.getTimestamp()),
                            log.getUsername(),
                            log.getModule(),
                            log.getAction(),
                            log.getStatus(),
                            log.getDescription()
                        });
                    }

                    int totalPages = Math.max(1, (int) Math.ceil((double) totalRecords / pageSize));
                    int startRecord = totalRecords == 0 ? 0 : (currentPage - 1) * pageSize + 1;
                    int endRecord = Math.min(currentPage * pageSize, totalRecords);

                    lblPaginationInfo.setText("Showing " + startRecord + "–" + endRecord + " of " + totalRecords + " records");
                    lblPageNumber.setText("Page " + currentPage + " of " + totalPages);

                    btnPrev.setEnabled(currentPage > 1);
                    btnNext.setEnabled(currentPage < totalPages);

                } catch (Exception ex) {
                    tableModel.setRowCount(0);
                    lblPaginationInfo.setText("Error loading audit logs: " + ex.getMessage());
                }
            }
        };
        worker.execute();
    }

    private LocalDate parseDate(String text) {
        if (text == null || text.trim().isEmpty()) return null;
        try {
            return LocalDate.parse(text.trim(), DateTimeFormatter.ofPattern("yyyy-MM-dd"));
        } catch (Exception e) {
            return null;
        }
    }
}
