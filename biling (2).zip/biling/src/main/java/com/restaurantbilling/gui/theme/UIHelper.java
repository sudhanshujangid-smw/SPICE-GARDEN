package com.restaurantbilling.gui.theme;

import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableCellRenderer;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.RoundRectangle2D;

/**
 * UI Component Factory & Styling Helper for Spice Garden Restaurant Billing System.
 * Green + White premium design system.
 */
public final class UIHelper {

    private UIHelper() {
        // Prevent instantiation
    }

    // =========================================================================
    // BUTTON FACTORIES
    // =========================================================================

    public static JButton createPrimaryButton(String text) {
        return createStyledButton(text, UITheme.PRIMARY, Color.WHITE, UITheme.PRIMARY_HOVER, true);
    }

    public static JButton createPrimaryButton(String text, int width, int height) {
        JButton btn = createPrimaryButton(text);
        btn.setPreferredSize(new Dimension(width, height));
        return btn;
    }

    public static JButton createSecondaryButton(String text) {
        return createStyledButton(text, UITheme.CARD_BG_ALT, UITheme.TEXT_PRIMARY, UITheme.BORDER, false);
    }

    public static JButton createSecondaryButton(String text, int width, int height) {
        JButton btn = createSecondaryButton(text);
        btn.setPreferredSize(new Dimension(width, height));
        return btn;
    }

    public static JButton createSuccessButton(String text) {
        return createStyledButton(text, UITheme.SUCCESS, Color.WHITE, UITheme.SUCCESS_DARK, true);
    }

    public static JButton createSuccessButton(String text, int width, int height) {
        JButton btn = createSuccessButton(text);
        btn.setPreferredSize(new Dimension(width, height));
        return btn;
    }

    public static JButton createDangerButton(String text) {
        return createStyledButton(text, UITheme.DANGER, Color.WHITE, UITheme.DANGER_DARK, true);
    }

    public static JButton createDangerButton(String text, int width, int height) {
        JButton btn = createDangerButton(text);
        btn.setPreferredSize(new Dimension(width, height));
        return btn;
    }

    /**
     * Creates a Quick Action style button: white background, green border, green text.
     */
    public static JButton createGreenOutlineButton(String text) {
        JButton btn = new JButton(text) {
            private boolean hovered = false;
            {
                addMouseListener(new MouseAdapter() {
                    @Override public void mouseEntered(MouseEvent e) { hovered = true; repaint(); }
                    @Override public void mouseExited(MouseEvent e)  { hovered = false; repaint(); }
                });
            }
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                Color bg = hovered ? UITheme.PRIMARY_LIGHT : Color.WHITE;
                g2.setColor(bg);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 10, 10);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        btn.setFont(UITheme.FONT_BODY_BOLD);
        btn.setForeground(UITheme.PRIMARY);
        btn.setFocusPainted(false);
        btn.setContentAreaFilled(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setBorder(new CompoundBorder(
            new LineBorder(UITheme.PRIMARY, 1, true),
            new EmptyBorder(10, 14, 10, 14)
        ));
        return btn;
    }

    public static JButton createGhostButton(String text) {
        JButton btn = new JButton(text);
        btn.setFont(UITheme.FONT_BODY_BOLD);
        btn.setForeground(UITheme.PRIMARY);
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setContentAreaFilled(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.addMouseListener(new MouseAdapter() {
            @Override public void mouseEntered(MouseEvent e) { btn.setForeground(UITheme.PRIMARY_HOVER); }
            @Override public void mouseExited(MouseEvent e)  { btn.setForeground(UITheme.PRIMARY); }
        });
        return btn;
    }

    private static JButton createStyledButton(String text, Color bg, Color fg, Color hoverBg, boolean isSolid) {
        JButton btn = new JButton(text);
        btn.setFont(UITheme.FONT_BODY_BOLD);
        btn.setBackground(bg);
        btn.setForeground(fg);
        btn.setFocusPainted(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setBorder(new CompoundBorder(
            new LineBorder(isSolid ? bg : UITheme.BORDER, 1, true),
            new EmptyBorder(8, 16, 8, 16)
        ));

        btn.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                if (btn.isEnabled()) {
                    btn.setBackground(hoverBg);
                    if (isSolid) {
                        btn.setBorder(new CompoundBorder(
                            new LineBorder(hoverBg, 1, true),
                            new EmptyBorder(8, 16, 8, 16)
                        ));
                    }
                }
            }
            @Override
            public void mouseExited(MouseEvent e) {
                if (btn.isEnabled()) {
                    btn.setBackground(bg);
                    if (isSolid) {
                        btn.setBorder(new CompoundBorder(
                            new LineBorder(bg, 1, true),
                            new EmptyBorder(8, 16, 8, 16)
                        ));
                    }
                }
            }
        });

        return btn;
    }

    // =========================================================================
    // CARD & CONTAINER BUILDERS
    // =========================================================================

    public static JPanel createCardPanel() {
        JPanel panel = new JPanel();
        panel.setBackground(UITheme.CARD_BG);
        panel.setBorder(UITheme.BORDER_CARD);
        return panel;
    }

    public static JPanel createCardPanel(LayoutManager layout) {
        JPanel panel = new JPanel(layout);
        panel.setBackground(UITheme.CARD_BG);
        panel.setBorder(UITheme.BORDER_CARD);
        return panel;
    }

    /**
     * Creates a rounded card panel with custom Swing painting for rounded corners + subtle shadow.
     */
    public static JPanel createRoundedCard(int arcRadius) {
        return new JPanel() {
            {
                setOpaque(false);
            }
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                // Subtle shadow
                g2.setColor(new Color(0, 0, 0, 12));
                g2.fillRoundRect(2, 3, getWidth() - 4, getHeight() - 4, arcRadius + 2, arcRadius + 2);
                // Card background
                g2.setColor(Color.WHITE);
                g2.fillRoundRect(0, 0, getWidth() - 2, getHeight() - 2, arcRadius, arcRadius);
                // Border
                g2.setColor(UITheme.BORDER);
                g2.setStroke(new BasicStroke(1f));
                g2.drawRoundRect(0, 0, getWidth() - 2, getHeight() - 2, arcRadius, arcRadius);
                g2.dispose();
                super.paintComponent(g);
            }
        };
    }

    public static JPanel createElevatedCard(Color accentLeftBorder) {
        JPanel card = new JPanel(new BorderLayout());
        card.setBackground(UITheme.CARD_BG);
        Border leftMatte = BorderFactory.createMatteBorder(0, 4, 0, 0, accentLeftBorder);
        Border outline = BorderFactory.createLineBorder(UITheme.BORDER, 1, true);
        Border pad = new EmptyBorder(12, 16, 12, 16);
        card.setBorder(new CompoundBorder(leftMatte, new CompoundBorder(outline, pad)));
        return card;
    }

    public static JPanel createHeaderBanner(String title, String subtitle, JComponent rightComponent) {
        JPanel banner = new JPanel(new BorderLayout(15, 5));
        banner.setBackground(UITheme.PRIMARY);
        banner.setBorder(new EmptyBorder(16, 20, 16, 20));

        JPanel left = new JPanel(new GridLayout(2, 1, 0, 4));
        left.setOpaque(false);

        JLabel lblTitle = new JLabel(title);
        lblTitle.setFont(UITheme.FONT_TITLE_LARGE);
        lblTitle.setForeground(Color.WHITE);
        left.add(lblTitle);

        if (subtitle != null && !subtitle.isEmpty()) {
            JLabel lblSub = new JLabel(subtitle);
            lblSub.setFont(UITheme.FONT_BODY_MEDIUM);
            lblSub.setForeground(UITheme.TEXT_ON_DARK_MUTED);
            left.add(lblSub);
        }

        banner.add(left, BorderLayout.WEST);

        if (rightComponent != null) {
            banner.add(rightComponent, BorderLayout.EAST);
        }

        return banner;
    }

    // =========================================================================
    // TABLE STYLING
    // =========================================================================

    public static void styleTable(JTable table) {
        table.setRowHeight(36);
        table.setFont(UITheme.FONT_BODY);
        table.setSelectionBackground(UITheme.TABLE_SELECTION_BG);
        table.setSelectionForeground(UITheme.TEXT_PRIMARY);
        table.setGridColor(UITheme.TABLE_GRID);
        table.setShowVerticalLines(false);
        table.setShowHorizontalLines(true);
        table.setIntercellSpacing(new Dimension(0, 1));
        table.setFillsViewportHeight(true);

        // Header Styling
        JTableHeader header = table.getTableHeader();
        header.setFont(UITheme.FONT_BODY_BOLD);
        header.setBackground(UITheme.TABLE_HEADER_BG);
        header.setForeground(UITheme.TEXT_SECONDARY);
        header.setPreferredSize(new Dimension(header.getPreferredSize().width, 38));
        header.setReorderingAllowed(false);

        // Header renderer with padding
        TableCellRenderer headerRenderer = header.getDefaultRenderer();
        header.setDefaultRenderer((tbl, value, isSelected, hasFocus, row, col) -> {
            Component c = headerRenderer.getTableCellRendererComponent(tbl, value, isSelected, hasFocus, row, col);
            if (c instanceof JLabel label) {
                label.setBorder(new EmptyBorder(4, 12, 4, 12));
                label.setHorizontalAlignment(SwingConstants.LEFT);
            }
            return c;
        });

        // Alternating row renderer
        table.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable tbl, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
                Component comp = super.getTableCellRendererComponent(tbl, value, isSelected, hasFocus, row, column);
                if (comp instanceof JLabel label) {
                    label.setBorder(new EmptyBorder(0, 12, 0, 12));
                    if (!isSelected) {
                        label.setBackground(row % 2 == 0 ? UITheme.CARD_BG : UITheme.TABLE_ROW_ALT);
                        label.setForeground(UITheme.TEXT_PRIMARY);
                    }
                }
                return comp;
            }
        });

        // Hover effect
        table.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            @Override
            public void mouseMoved(java.awt.event.MouseEvent e) {
                int row = table.rowAtPoint(e.getPoint());
                if (row >= 0) {
                    table.setSelectionBackground(UITheme.TABLE_SELECTION_BG);
                }
            }
        });
    }

    // =========================================================================
    // INPUT COMPONENT STYLING
    // =========================================================================

    public static void styleTextField(JTextField field) {
        field.setFont(UITheme.FONT_BODY);
        field.setBorder(UITheme.BORDER_INPUT);
        field.setPreferredSize(new Dimension(field.getPreferredSize().width, 34));
    }

    public static void styleComboBox(JComboBox<?> box) {
        box.setFont(UITheme.FONT_BODY);
        box.setBackground(Color.WHITE);
        box.setPreferredSize(new Dimension(box.getPreferredSize().width, 34));
    }

    public static void styleScrollPane(JScrollPane scrollPane) {
        scrollPane.setBorder(new LineBorder(UITheme.BORDER, 1, true));
        scrollPane.getViewport().setBackground(Color.WHITE);
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);
    }

    // =========================================================================
    // BADGES & STATUS PILLS
    // =========================================================================

    /**
     * Creates a rounded pill-style status badge with custom painting.
     */
    public static JLabel createStatusBadge(String text, Color bgColor, Color fgColor) {
        JLabel badge = new JLabel(text, SwingConstants.CENTER) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(bgColor);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 20, 20);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        badge.setFont(UITheme.FONT_SMALL_BOLD);
        badge.setForeground(fgColor);
        badge.setOpaque(false);
        badge.setBorder(new EmptyBorder(3, 10, 3, 10));
        return badge;
    }

    /**
     * Creates a green "Completed" pill badge.
     */
    public static JLabel createGreenStatusBadge(String text) {
        return createStatusBadge(text, UITheme.PRIMARY_LIGHT, UITheme.PRIMARY_DARK);
    }

    public static DefaultTableCellRenderer createStatusCellRenderer() {
        return new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
                JLabel l = (JLabel) super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                l.setHorizontalAlignment(SwingConstants.CENTER);
                String val = (value != null) ? value.toString().trim() : "";

                if (!isSelected) {
                    l.setBackground(row % 2 == 0 ? UITheme.CARD_BG : UITheme.TABLE_ROW_ALT);
                    if ("Active".equalsIgnoreCase(val) || "Available".equalsIgnoreCase(val)
                            || "COMPLETED".equalsIgnoreCase(val) || "SUCCESS".equalsIgnoreCase(val)
                            || "Yes (Billed)".equalsIgnoreCase(val) || "HEALTHY".equalsIgnoreCase(val)
                            || "PASS".equalsIgnoreCase(val)) {
                        l.setForeground(UITheme.SUCCESS_DARK);
                        l.setFont(UITheme.FONT_BODY_BOLD);
                    } else if ("Inactive".equalsIgnoreCase(val) || "Out of Stock".equalsIgnoreCase(val)
                            || "CANCELLED".equalsIgnoreCase(val) || "FAILED".equalsIgnoreCase(val)
                            || "DENIED".equalsIgnoreCase(val) || "ERROR".equalsIgnoreCase(val)
                            || "FAIL".equalsIgnoreCase(val)) {
                        l.setForeground(UITheme.DANGER_DARK);
                        l.setFont(UITheme.FONT_BODY_BOLD);
                    } else if ("PENDING".equalsIgnoreCase(val) || "WARNING".equalsIgnoreCase(val)
                            || "Unbilled".equalsIgnoreCase(val)) {
                        l.setForeground(UITheme.WARNING_DARK);
                        l.setFont(UITheme.FONT_BODY_BOLD);
                    } else if ("CONFIRMED".equalsIgnoreCase(val) || "PREPARING".equalsIgnoreCase(val)
                            || "READY".equalsIgnoreCase(val)) {
                        l.setForeground(UITheme.PRIMARY);
                        l.setFont(UITheme.FONT_BODY_BOLD);
                    } else {
                        l.setForeground(UITheme.TEXT_SECONDARY);
                    }
                }
                return l;
            }
        };
    }

    /**
     * Creates a status cell renderer specifically for the Recent Orders table
     * that renders pill-style green badges for Completed status.
     */
    public static DefaultTableCellRenderer createOrderStatusCellRenderer() {
        return new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
                String val = (value != null) ? value.toString().trim() : "";
                Color rowBg = isSelected ? UITheme.TABLE_SELECTION_BG : (row % 2 == 0 ? UITheme.CARD_BG : UITheme.TABLE_ROW_ALT);

                JPanel wrapper = new JPanel(new FlowLayout(FlowLayout.CENTER, 0, 4));
                wrapper.setBackground(rowBg);

                Color pillBg, pillFg;
                if ("COMPLETED".equalsIgnoreCase(val) || "Completed".equalsIgnoreCase(val)) {
                    pillBg = UITheme.PRIMARY_LIGHT;
                    pillFg = UITheme.PRIMARY_DARK;
                } else if ("CANCELLED".equalsIgnoreCase(val) || "Cancelled".equalsIgnoreCase(val)) {
                    pillBg = UITheme.DANGER_BG;
                    pillFg = UITheme.DANGER_DARK;
                } else if ("PENDING".equalsIgnoreCase(val)) {
                    pillBg = UITheme.WARNING_BG;
                    pillFg = UITheme.WARNING_DARK;
                } else if ("CONFIRMED".equalsIgnoreCase(val) || "PREPARING".equalsIgnoreCase(val) || "READY".equalsIgnoreCase(val)) {
                    pillBg = new Color(0xE0, 0xF0, 0xFF);
                    pillFg = new Color(0x1E, 0x60, 0xAF);
                } else {
                    pillBg = UITheme.CARD_BG_ALT;
                    pillFg = UITheme.TEXT_SECONDARY;
                }

                JLabel pill = new JLabel(val, SwingConstants.CENTER) {
                    @Override
                    protected void paintComponent(Graphics g) {
                        Graphics2D g2 = (Graphics2D) g.create();
                        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                        g2.setColor(pillBg);
                        g2.fillRoundRect(0, 0, getWidth(), getHeight(), 20, 20);
                        g2.dispose();
                        super.paintComponent(g);
                    }
                };
                pill.setFont(UITheme.FONT_SMALL_BOLD);
                pill.setForeground(pillFg);
                pill.setOpaque(false);
                pill.setBorder(new EmptyBorder(2, 10, 2, 10));

                wrapper.add(pill);
                return wrapper;
            }
        };
    }
}
