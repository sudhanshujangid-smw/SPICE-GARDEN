package com.restaurantbilling.gui.customer;

import com.restaurantbilling.exception.ValidationException;
import com.restaurantbilling.gui.theme.UIHelper;
import com.restaurantbilling.gui.theme.UITheme;
import com.restaurantbilling.gui.util.CustomDialogs;
import com.restaurantbilling.model.Customer;
import com.restaurantbilling.service.CustomerService;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

public class CustomerDialog extends JDialog {

    public enum Mode {
        ADD, EDIT, VIEW
    }

    private final Mode mode;
    private final CustomerService customerService;
    private Customer customer;
    private boolean saved = false;

    private JTextField txtName;
    private JTextField txtPhone;
    private JTextField txtEmail;
    private JTextArea txtAddress;
    private JComboBox<String> cmbStatus;
    private JButton btnSave;
    private JButton btnCancel;
    private JButton btnClear;

    public CustomerDialog(Window owner, CustomerService customerService, Customer customer, Mode mode) {
        super(owner, getTitleForMode(mode), ModalityType.APPLICATION_MODAL);
        this.customerService = customerService;
        this.customer = (customer != null) ? customer : new Customer();
        this.mode = mode;

        initComponents();
        populateFields();
        applyModePermissions();

        setSize(480, 520);
        setLocationRelativeTo(owner);
        setResizable(false);
    }

    private static String getTitleForMode(Mode mode) {
        return switch (mode) {
            case ADD -> "Register New Customer";
            case EDIT -> "Edit Customer Profile";
            case VIEW -> "Customer Details";
        };
    }

    private void initComponents() {
        JPanel contentPane = new JPanel(new BorderLayout(15, 15));
        contentPane.setBorder(new EmptyBorder(24, 28, 20, 28));
        contentPane.setBackground(UITheme.CARD_BG);
        setContentPane(contentPane);

        // Header Title
        JLabel lblHeader = new JLabel(getTitleForMode(mode));
        lblHeader.setFont(UITheme.FONT_TITLE_MEDIUM);
        lblHeader.setForeground(UITheme.TEXT_PRIMARY);
        contentPane.add(lblHeader, BorderLayout.NORTH);

        // Form Panel
        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setOpaque(false);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 0, 5, 0);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1.0;
        gbc.gridx = 0;
        gbc.gridy = 0;

        // Name
        formPanel.add(createFieldLabel("Customer Name *"), gbc);
        gbc.gridy++;
        txtName = new JTextField();
        UIHelper.styleTextField(txtName);
        formPanel.add(txtName, gbc);

        // Phone
        gbc.gridy++;
        formPanel.add(createFieldLabel("Phone Number * (10 Digits)"), gbc);
        gbc.gridy++;
        txtPhone = new JTextField();
        UIHelper.styleTextField(txtPhone);
        formPanel.add(txtPhone, gbc);

        // Email
        gbc.gridy++;
        formPanel.add(createFieldLabel("Email Address (Optional)"), gbc);
        gbc.gridy++;
        txtEmail = new JTextField();
        UIHelper.styleTextField(txtEmail);
        formPanel.add(txtEmail, gbc);

        // Status
        gbc.gridy++;
        formPanel.add(createFieldLabel("Account Status"), gbc);
        gbc.gridy++;
        cmbStatus = new JComboBox<>(new String[]{"Active", "Inactive"});
        UIHelper.styleComboBox(cmbStatus);
        formPanel.add(cmbStatus, gbc);

        // Address
        gbc.gridy++;
        formPanel.add(createFieldLabel("Address (Optional)"), gbc);
        gbc.gridy++;
        txtAddress = new JTextArea(3, 20);
        txtAddress.setFont(UITheme.FONT_BODY);
        txtAddress.setLineWrap(true);
        txtAddress.setWrapStyleWord(true);
        txtAddress.setBorder(new EmptyBorder(6, 8, 6, 8));
        JScrollPane scrollAddress = new JScrollPane(txtAddress);
        UIHelper.styleScrollPane(scrollAddress);
        scrollAddress.setPreferredSize(new Dimension(380, 70));
        formPanel.add(scrollAddress, gbc);

        contentPane.add(formPanel, BorderLayout.CENTER);

        // Buttons Panel
        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        btnPanel.setOpaque(false);

        if (mode == Mode.ADD) {
            btnClear = UIHelper.createSecondaryButton("Clear");
            btnClear.setPreferredSize(new Dimension(85, 34));
            btnClear.addActionListener(e -> clearForm());
            btnPanel.add(btnClear);
        }

        btnCancel = UIHelper.createSecondaryButton(mode == Mode.VIEW ? "Close" : "Cancel");
        btnCancel.setPreferredSize(new Dimension(85, 34));
        btnCancel.addActionListener(e -> dispose());
        btnPanel.add(btnCancel);

        if (mode != Mode.VIEW) {
            btnSave = UIHelper.createPrimaryButton("Save Customer");
            btnSave.setPreferredSize(new Dimension(140, 34));
            btnSave.addActionListener(e -> onSave());
            btnPanel.add(btnSave);
        }

        contentPane.add(btnPanel, BorderLayout.SOUTH);
    }

    private JLabel createFieldLabel(String text) {
        JLabel label = new JLabel(text);
        label.setFont(UITheme.FONT_BODY_BOLD);
        label.setForeground(UITheme.TEXT_SECONDARY);
        return label;
    }

    private void populateFields() {
        if (customer != null && mode != Mode.ADD) {
            txtName.setText(customer.getName() != null ? customer.getName() : "");
            txtPhone.setText(customer.getPhone() != null ? customer.getPhone() : "");
            txtEmail.setText(customer.getEmail() != null ? customer.getEmail() : "");
            txtAddress.setText(customer.getAddress() != null ? customer.getAddress() : "");
            cmbStatus.setSelectedItem(customer.getStatus() != null ? customer.getStatus() : "Active");
        }
    }

    private void applyModePermissions() {
        if (mode == Mode.VIEW) {
            txtName.setEditable(false);
            txtPhone.setEditable(false);
            txtEmail.setEditable(false);
            txtAddress.setEditable(false);
            cmbStatus.setEnabled(false);
        }
    }

    private void clearForm() {
        txtName.setText("");
        txtPhone.setText("");
        txtEmail.setText("");
        txtAddress.setText("");
        cmbStatus.setSelectedItem("Active");
        txtName.requestFocus();
    }

    private void onSave() {
        String name = txtName.getText().trim();
        String phone = txtPhone.getText().trim();
        String email = txtEmail.getText().trim();
        String address = txtAddress.getText().trim();
        String status = (String) cmbStatus.getSelectedItem();

        customer.setName(name);
        customer.setPhone(phone);
        customer.setEmail(email.isEmpty() ? null : email);
        customer.setAddress(address.isEmpty() ? null : address);
        customer.setStatus(status);

        try {
            if (mode == Mode.ADD) {
                customerService.addCustomer(customer);
                CustomDialogs.showSuccess(this, "Customer added successfully.", "Customer Registered");
            } else if (mode == Mode.EDIT) {
                customerService.updateCustomer(customer);
                CustomDialogs.showSuccess(this, "Customer profile updated successfully.", "Profile Updated");
            }
            saved = true;
            dispose();
        } catch (ValidationException ex) {
            CustomDialogs.showWarning(this, ex.getMessage(), "Validation Error");
        } catch (Exception ex) {
            CustomDialogs.showError(this, "Failed to save customer: " + ex.getMessage(), "Database Error");
        }
    }

    public boolean isSaved() {
        return saved;
    }

    public Customer getCustomer() {
        return customer;
    }
}
