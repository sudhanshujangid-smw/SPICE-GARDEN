package com.restaurantbilling.gui.billing;

import com.restaurantbilling.gui.theme.UIHelper;
import com.restaurantbilling.gui.theme.UITheme;
import com.restaurantbilling.gui.util.CustomDialogs;
import com.restaurantbilling.invoice.InvoiceGenerator;
import com.restaurantbilling.model.Bill;
import com.restaurantbilling.service.BillingService;
import com.restaurantbilling.util.FormatUtil;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class BillHistoryPanel extends JPanel {

    private final BillingService billingService;
    private List<Bill> billList = new ArrayList<>();

    private JTextField txtSearch;
    private JTable billTable;
    private DefaultTableModel tableModel;
    private JLabel lblStatusInfo;
    private JProgressBar progressBar;

    private JButton btnViewDetails;
    private JButton btnPrintBill;
    private JButton btnExportInvoice;

    private static final String[] COLUMNS = {
        "Bill Number", "Order #", "Customer", "Bill Date & Time", "Subtotal", "Discount", "Tax", "Grand Total", "Status"
    };

    public BillHistoryPanel(BillingService billingService) {
        this.billingService = billingService;

        setLayout(new BorderLayout(15, 15));
        setBorder(new EmptyBorder(16, 20, 16, 20));
        setBackground(UITheme.APP_BG);

        initComponents();
        setupSelectionListener();
        loadBillsAsync();
    }

    private void initComponents() {
        // TOP: Header & Search Bar Card
        JPanel topPanel = new JPanel(new BorderLayout(10, 12));
        topPanel.setOpaque(false);

        JPanel titlePanel = new JPanel(new GridLayout(2, 1, 0, 3));
        titlePanel.setOpaque(false);

        JLabel lblTitle = new JLabel("Bill Archive & Invoice Management");
        lblTitle.setFont(UITheme.FONT_TITLE_LARGE);
        lblTitle.setForeground(UITheme.TEXT_PRIMARY);
        titlePanel.add(lblTitle);

        JLabel lblSubtitle = new JLabel("Search, view, print, and export official finalized bills and invoices.");
        lblSubtitle.setFont(UITheme.FONT_BODY_MEDIUM);
        lblSubtitle.setForeground(UITheme.TEXT_SECONDARY);
        titlePanel.add(lblSubtitle);

        topPanel.add(titlePanel, BorderLayout.NORTH);

        JPanel searchBar = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 8));
        searchBar.setBackground(UITheme.CARD_BG);
        searchBar.setBorder(UITheme.BORDER_CARD);

        JLabel lblSearch = new JLabel("Search Bill:");
        lblSearch.setFont(UITheme.FONT_BODY_BOLD);
        searchBar.add(lblSearch);

        txtSearch = new JTextField(18);
        UIHelper.styleTextField(txtSearch);
        txtSearch.setPreferredSize(new Dimension(220, 34));
        txtSearch.putClientProperty("JTextField.placeholderText", "Bill No, Order #, Customer...");
        txtSearch.addActionListener(e -> performSearch());
        searchBar.add(txtSearch);

        JButton btnSearch = UIHelper.createSecondaryButton("Search");
        btnSearch.setPreferredSize(new Dimension(85, 34));
        btnSearch.addActionListener(e -> performSearch());
        searchBar.add(btnSearch);

        JButton btnClear = UIHelper.createSecondaryButton("Clear");
        btnClear.setPreferredSize(new Dimension(80, 34));
        btnClear.addActionListener(e -> {
            txtSearch.setText("");
            loadBillsAsync();
        });
        searchBar.add(btnClear);

        topPanel.add(searchBar, BorderLayout.SOUTH);
        add(topPanel, BorderLayout.NORTH);

        // CENTER: Table Card
        JPanel centerCard = new JPanel(new BorderLayout());
        centerCard.setBackground(UITheme.CARD_BG);
        centerCard.setBorder(new LineBorder(UITheme.BORDER, 1, true));

        tableModel = new DefaultTableModel(COLUMNS, 0) {
            @Override
            public boolean isCellEditable(int row, int col) {
                return false;
            }
        };

        billTable = new JTable(tableModel);
        UIHelper.styleTable(billTable);

        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(SwingConstants.CENTER);

        billTable.getColumnModel().getColumn(0).setPreferredWidth(120);
        billTable.getColumnModel().getColumn(0).setCellRenderer(centerRenderer);

        billTable.getColumnModel().getColumn(1).setPreferredWidth(70);
        billTable.getColumnModel().getColumn(1).setCellRenderer(centerRenderer);

        billTable.getColumnModel().getColumn(2).setPreferredWidth(160);

        billTable.getColumnModel().getColumn(3).setPreferredWidth(140);
        billTable.getColumnModel().getColumn(3).setCellRenderer(centerRenderer);

        DefaultTableCellRenderer rightRenderer = new DefaultTableCellRenderer();
        rightRenderer.setHorizontalAlignment(SwingConstants.RIGHT);
        billTable.getColumnModel().getColumn(4).setPreferredWidth(85);
        billTable.getColumnModel().getColumn(4).setCellRenderer(rightRenderer);
        billTable.getColumnModel().getColumn(5).setPreferredWidth(75);
        billTable.getColumnModel().getColumn(5).setCellRenderer(rightRenderer);
        billTable.getColumnModel().getColumn(6).setPreferredWidth(75);
        billTable.getColumnModel().getColumn(6).setCellRenderer(rightRenderer);
        billTable.getColumnModel().getColumn(7).setPreferredWidth(95);
        billTable.getColumnModel().getColumn(7).setCellRenderer(rightRenderer);

        billTable.getColumnModel().getColumn(8).setPreferredWidth(100);
        billTable.getColumnModel().getColumn(8).setCellRenderer(UIHelper.createStatusCellRenderer());

        billTable.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2 && billTable.getSelectedRow() != -1) {
                    onViewDetails();
                }
            }
        });

        JScrollPane scrollPane = new JScrollPane(billTable);
        UIHelper.styleScrollPane(scrollPane);
        centerCard.add(scrollPane, BorderLayout.CENTER);
        add(centerCard, BorderLayout.CENTER);

        // SOUTH: Actions & Status Bar
        JPanel southPanel = new JPanel(new BorderLayout(10, 10));
        southPanel.setOpaque(false);

        JPanel actionPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));
        actionPanel.setOpaque(false);

        btnViewDetails = UIHelper.createPrimaryButton("View Invoice");
        btnViewDetails.setEnabled(false);
        btnViewDetails.addActionListener(e -> onViewDetails());
        actionPanel.add(btnViewDetails);

        btnPrintBill = UIHelper.createSecondaryButton("Print Bill");
        btnPrintBill.setEnabled(false);
        btnPrintBill.addActionListener(e -> onPrintBill());
        actionPanel.add(btnPrintBill);

        btnExportInvoice = UIHelper.createSecondaryButton("Save / Export Invoice");
        btnExportInvoice.setEnabled(false);
        btnExportInvoice.addActionListener(e -> onExportInvoice());
        actionPanel.add(btnExportInvoice);

        JButton btnRefresh = UIHelper.createSecondaryButton("Refresh");
        btnRefresh.addActionListener(e -> loadBillsAsync());
        actionPanel.add(btnRefresh);

        southPanel.add(actionPanel, BorderLayout.NORTH);

        // Status Bar
        JPanel statusBar = new JPanel(new BorderLayout());
        statusBar.setOpaque(false);

        lblStatusInfo = new JLabel("Loading bill history...");
        lblStatusInfo.setFont(UITheme.FONT_SMALL);
        lblStatusInfo.setForeground(UITheme.TEXT_SECONDARY);
        statusBar.add(lblStatusInfo, BorderLayout.WEST);

        progressBar = new JProgressBar();
        progressBar.setPreferredSize(new Dimension(140, 12));
        progressBar.setIndeterminate(true);
        progressBar.setVisible(false);
        statusBar.add(progressBar, BorderLayout.EAST);

        southPanel.add(statusBar, BorderLayout.SOUTH);
        add(southPanel, BorderLayout.SOUTH);
    }

    private void setupSelectionListener() {
        billTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                int row = billTable.getSelectedRow();
                boolean selected = (row >= 0 && row < billList.size());
                btnViewDetails.setEnabled(selected);
                btnPrintBill.setEnabled(selected);
                btnExportInvoice.setEnabled(selected);
            }
        });
    }

    public void loadBillsAsync() {
        progressBar.setVisible(true);
        lblStatusInfo.setText("Loading bills...");

        SwingWorker<List<Bill>, Void> worker = new SwingWorker<>() {
            @Override
            protected List<Bill> doInBackground() {
                return billingService.getAllBills();
            }

            @Override
            protected void done() {
                try {
                    billList = get();
                    renderTable(billList);
                    lblStatusInfo.setText("Total Finalized Bills: " + billList.size());
                } catch (Exception ex) {
                    lblStatusInfo.setText("Error loading bills: " + ex.getMessage());
                } finally {
                    progressBar.setVisible(false);
                }
            }
        };
        worker.execute();
    }

    private void performSearch() {
        String keyword = txtSearch.getText().trim();
        progressBar.setVisible(true);
        lblStatusInfo.setText("Searching bills...");

        SwingWorker<List<Bill>, Void> worker = new SwingWorker<>() {
            @Override
            protected List<Bill> doInBackground() {
                return billingService.searchBills(keyword);
            }

            @Override
            protected void done() {
                try {
                    billList = get();
                    renderTable(billList);
                    lblStatusInfo.setText("Bills Found: " + billList.size());
                } catch (Exception ex) {
                    lblStatusInfo.setText("Search error: " + ex.getMessage());
                } finally {
                    progressBar.setVisible(false);
                }
            }
        };
        worker.execute();
    }

    private void renderTable(List<Bill> list) {
        tableModel.setRowCount(0);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");

        for (Bill b : list) {
            String dateStr = (b.getBillDate() != null) ? sdf.format(b.getBillDate()) : "-";
            String cust = (b.getCustomerName() != null) ? b.getCustomerName() : "Walk-in";

            tableModel.addRow(new Object[]{
                b.getBillNumber(),
                "#" + b.getOrderId(),
                cust,
                dateStr,
                FormatUtil.formatCurrency(b.getSubtotal()),
                FormatUtil.formatCurrency(b.getDiscount()),
                FormatUtil.formatCurrency(b.getTax()),
                FormatUtil.formatCurrency(b.getFinalAmount()),
                b.getStatus()
            });
        }
    }

    private Bill getSelectedBill() {
        int row = billTable.getSelectedRow();
        if (row >= 0 && row < billList.size()) {
            return billList.get(row);
        }
        return null;
    }

    private void onViewDetails() {
        Bill selected = getSelectedBill();
        if (selected == null) return;

        Optional<Bill> detailedOpt = billingService.getBillDetails(selected.getId());
        if (detailedOpt.isPresent()) {
            Window parent = SwingUtilities.getWindowAncestor(this);
            BillDetailsDialog dialog = new BillDetailsDialog(parent, detailedOpt.get(), false);
            dialog.setVisible(true);
        }
    }

    private void onPrintBill() {
        Bill selected = getSelectedBill();
        if (selected == null) return;

        Optional<Bill> detailedOpt = billingService.getBillDetails(selected.getId());
        detailedOpt.ifPresent(b -> {
            InvoiceGenerator gen = new InvoiceGenerator(b);
            gen.printInvoice();
        });
    }

    private void onExportInvoice() {
        Bill selected = getSelectedBill();
        if (selected == null) return;

        Optional<Bill> detailedOpt = billingService.getBillDetails(selected.getId());
        detailedOpt.ifPresent(b -> {
            try {
                InvoiceGenerator gen = new InvoiceGenerator(b);
                File file = gen.saveInvoiceFile();
                CustomDialogs.showSuccess(this, "Invoice exported to:\n" + file.getAbsolutePath(), "Invoice Exported");
            } catch (Exception ex) {
                CustomDialogs.showError(this, "Export failed: " + ex.getMessage(), "Export Error");
            }
        });
    }
}
