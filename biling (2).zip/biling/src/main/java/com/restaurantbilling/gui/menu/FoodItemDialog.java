package com.restaurantbilling.gui.menu;

import com.restaurantbilling.exception.ValidationException;
import com.restaurantbilling.gui.theme.UIHelper;
import com.restaurantbilling.gui.theme.UITheme;
import com.restaurantbilling.gui.util.CustomDialogs;
import com.restaurantbilling.model.FoodItem;
import com.restaurantbilling.service.FoodItemService;

import com.restaurantbilling.api.pexels.PexelsPhoto;
import com.restaurantbilling.service.PexelsImageService;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.math.BigDecimal;

public class FoodItemDialog extends JDialog {

    private final FoodItemService foodItemService;
    private FoodItem item;
    private final boolean isEdit;
    private boolean saved = false;

    private JTextField txtName;
    private JComboBox<String> cmbCategory;
    private JTextField txtPrice;
    private JCheckBox chkAvailable;
    
    private JLabel lblImagePreview;
    private final PexelsImageService imageService = new PexelsImageService();

    public FoodItemDialog(Window owner, FoodItemService service, FoodItem item, boolean isEdit) {
        super(owner, isEdit ? "Edit Menu Item" : "Add New Menu Item", ModalityType.APPLICATION_MODAL);
        this.foodItemService = service;
        this.item = (item != null) ? item : new FoodItem();
        this.isEdit = isEdit;

        initComponents();
        populateFields();

        setSize(600, 480);
        setLocationRelativeTo(owner);
        setResizable(false);
    }

    private void initComponents() {
        JPanel contentPane = new JPanel(new BorderLayout(15, 15));
        contentPane.setBorder(new EmptyBorder(24, 28, 20, 28));
        contentPane.setBackground(UITheme.CARD_BG);
        setContentPane(contentPane);

        // Header Title
        JLabel lblTitle = new JLabel(isEdit ? "Edit Menu Item Details" : "Add New Food Item");
        lblTitle.setFont(UITheme.FONT_TITLE_MEDIUM);
        lblTitle.setForeground(UITheme.TEXT_PRIMARY);
        contentPane.add(lblTitle, BorderLayout.NORTH);

        // Form Panel
        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setOpaque(false);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(6, 0, 6, 0);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1.0;
        gbc.gridx = 0;
        gbc.gridy = 0;

        // Item Name
        formPanel.add(createFieldLabel("Item Name *"), gbc);
        gbc.gridy++;
        txtName = new JTextField();
        UIHelper.styleTextField(txtName);
        formPanel.add(txtName, gbc);

        // Category
        gbc.gridy++;
        formPanel.add(createFieldLabel("Category *"), gbc);
        gbc.gridy++;
        cmbCategory = new JComboBox<>(new String[]{"Starter", "Main Course", "Breads", "Beverages", "Dessert", "Fast Food", "Others"});
        cmbCategory.setEditable(true);
        UIHelper.styleComboBox(cmbCategory);
        formPanel.add(cmbCategory, gbc);

        // Price
        gbc.gridy++;
        formPanel.add(createFieldLabel("Unit Price (₹) *"), gbc);
        gbc.gridy++;
        txtPrice = new JTextField();
        UIHelper.styleTextField(txtPrice);
        formPanel.add(txtPrice, gbc);

        // Available Checkbox
        gbc.gridy++;
        chkAvailable = new JCheckBox("Item is In Stock & Available for Orders", true);
        chkAvailable.setFont(UITheme.FONT_BODY_BOLD);
        chkAvailable.setForeground(UITheme.TEXT_PRIMARY);
        chkAvailable.setBackground(UITheme.CARD_BG);
        chkAvailable.setBorder(new EmptyBorder(6, 0, 4, 0));
        formPanel.add(chkAvailable, gbc);

        // Image Selection Area
        gbc.gridy++;
        formPanel.add(createFieldLabel("Food Image (Optional)"), gbc);
        gbc.gridy++;
        
        JPanel imagePanel = new JPanel(new BorderLayout(10, 0));
        imagePanel.setOpaque(false);
        
        lblImagePreview = new JLabel("[ No Image ]", SwingConstants.CENTER);
        lblImagePreview.setPreferredSize(new Dimension(150, 100));
        lblImagePreview.setBorder(BorderFactory.createLineBorder(UITheme.BORDER));
        imagePanel.add(lblImagePreview, BorderLayout.WEST);
        
        JPanel imgActionPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
        imgActionPanel.setOpaque(false);
        JButton btnSearchImage = UIHelper.createSecondaryButton("Search Food Image");
        btnSearchImage.addActionListener(e -> onSearchImage());
        imgActionPanel.add(btnSearchImage);
        
        JButton btnRemoveImage = UIHelper.createSecondaryButton("Remove Image");
        btnRemoveImage.addActionListener(e -> onRemoveImage());
        imgActionPanel.add(btnRemoveImage);
        
        imagePanel.add(imgActionPanel, BorderLayout.CENTER);
        
        formPanel.add(imagePanel, gbc);

        contentPane.add(formPanel, BorderLayout.CENTER);

        // Buttons
        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        btnPanel.setOpaque(false);

        JButton btnCancel = UIHelper.createSecondaryButton("Cancel");
        btnCancel.addActionListener(e -> dispose());
        btnPanel.add(btnCancel);

        JButton btnSave = UIHelper.createPrimaryButton(isEdit ? "Update Item" : "Save Item");
        btnSave.addActionListener(e -> onSave());
        btnPanel.add(btnSave);

        contentPane.add(btnPanel, BorderLayout.SOUTH);
    }

    private JLabel createFieldLabel(String text) {
        JLabel label = new JLabel(text);
        label.setFont(UITheme.FONT_BODY_BOLD);
        label.setForeground(UITheme.TEXT_SECONDARY);
        return label;
    }

    private void populateFields() {
        if (isEdit && item != null) {
            txtName.setText(item.getName() != null ? item.getName() : "");
            cmbCategory.setSelectedItem(item.getCategory());
            txtPrice.setText(item.getPrice() != null ? item.getPrice().toString() : "");
            chkAvailable.setSelected(item.isAvailable());
            
            if (item.getPexelsPhotoId() != null && item.getImageUrl() != null) {
                loadImageAsync(item.getPexelsPhotoId(), item.getImageUrl());
            }
        }
    }

    private void onSearchImage() {
        String query = txtName.getText().trim();
        if (query.isEmpty()) {
            CustomDialogs.showWarning(this, "Please enter an Item Name first to search for images.", "Name Required");
            return;
        }

        PexelsImageSearchDialog dialog = new PexelsImageSearchDialog(this, query);
        dialog.setVisible(true);

        PexelsPhoto selected = dialog.getSelectedPhoto();
        if (selected != null) {
            item.setImageSource("Pexels");
            item.setPexelsPhotoId(selected.getId());
            item.setImageUrl(selected.getSrc().getMedium());
            item.setPhotographerName(selected.getPhotographer());
            item.setPhotographerUrl(selected.getPhotographerUrl());
            loadImageAsync(selected.getId(), selected.getSrc().getMedium());
        }
    }

    private void onRemoveImage() {
        item.setImageSource(null);
        item.setPexelsPhotoId(null);
        item.setImageUrl(null);
        item.setPhotographerName(null);
        item.setPhotographerUrl(null);
        lblImagePreview.setIcon(null);
        lblImagePreview.setText("[ No Image ]");
    }

    private void loadImageAsync(long photoId, String url) {
        lblImagePreview.setText("Loading...");
        lblImagePreview.setIcon(null);
        
        SwingWorker<ImageIcon, Void> worker = new SwingWorker<>() {
            @Override
            protected ImageIcon doInBackground() throws Exception {
                Image img = imageService.getCachedOrDownloadImage(photoId, url);
                if (img != null) {
                    Image scaled = img.getScaledInstance(150, 100, Image.SCALE_SMOOTH);
                    return new ImageIcon(scaled);
                }
                return null;
            }

            @Override
            protected void done() {
                try {
                    ImageIcon icon = get();
                    if (icon != null) {
                        lblImagePreview.setIcon(icon);
                        lblImagePreview.setText("");
                    } else {
                        lblImagePreview.setText("[ No Image ]");
                    }
                } catch (Exception e) {
                    lblImagePreview.setText("[ Load Failed ]");
                }
            }
        };
        worker.execute();
    }

    private void onSave() {
        try {
            String name = txtName.getText().trim();
            String category = (String) cmbCategory.getSelectedItem();
            String priceStr = txtPrice.getText().trim();

            if (priceStr.isEmpty()) {
                throw new ValidationException("Price cannot be empty.");
            }

            BigDecimal price;
            try {
                price = new BigDecimal(priceStr);
                if (price.compareTo(BigDecimal.ZERO) < 0) {
                    throw new ValidationException("Price cannot be negative.");
                }
            } catch (NumberFormatException nfe) {
                throw new ValidationException("Invalid price format. Please enter a valid number (e.g. 150.00).");
            }

            item.setName(name);
            item.setCategory(category != null ? category.trim() : "General");
            item.setPrice(price);
            item.setAvailable(chkAvailable.isSelected());

            if (isEdit) {
                foodItemService.updateFoodItem(item);
                CustomDialogs.showSuccess(this, "Menu item updated successfully.", "Item Updated");
            } else {
                foodItemService.addFoodItem(item);
                CustomDialogs.showSuccess(this, "New menu item added successfully.", "Item Added");
            }
            saved = true;
            dispose();
        } catch (ValidationException ex) {
            CustomDialogs.showWarning(this, ex.getMessage(), "Validation Error");
        } catch (Exception ex) {
            CustomDialogs.showError(this, "Database error: " + ex.getMessage(), "Error Saving Item");
        }
    }

    public boolean isSaved() {
        return saved;
    }
}
