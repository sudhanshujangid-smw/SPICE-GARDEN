package com.restaurantbilling.gui.calendar;

import com.restaurantbilling.gui.theme.UITheme;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.time.LocalDate;
import java.time.YearMonth;
import java.time.format.TextStyle;
import java.util.Locale;

/**
 * Spice Garden Calendar Panel.
 * Lightweight monthly calendar — pure Swing, no external dependencies.
 * Displays current month with green highlighting for today's date.
 */
public class CalendarPanel extends JPanel {

    private YearMonth displayMonth;
    private LocalDate today;

    // Day cells grid
    private JPanel calendarGrid;
    private JLabel lblMonthYear;

    public CalendarPanel() {
        this.today = LocalDate.now();
        this.displayMonth = YearMonth.of(today.getYear(), today.getMonth());

        setLayout(new BorderLayout(0, 0));
        setBackground(UITheme.APP_BG);
        setBorder(new EmptyBorder(16, 20, 16, 20));

        initComponents();
    }

    private void initComponents() {
        // ── Header ──
        JPanel headerBar = new JPanel(new BorderLayout());
        headerBar.setOpaque(false);
        headerBar.setBorder(new EmptyBorder(0, 0, 16, 0));

        JLabel lblTitle = new JLabel("📅  Calendar");
        lblTitle.setFont(UITheme.FONT_TITLE_LARGE);
        lblTitle.setForeground(UITheme.TEXT_PRIMARY);
        headerBar.add(lblTitle, BorderLayout.WEST);

        add(headerBar, BorderLayout.NORTH);

        // ── Calendar Card ──
        JPanel card = new JPanel(new BorderLayout(0, 12));
        card.setBackground(Color.WHITE);
        card.setBorder(new EmptyBorder(16, 16, 16, 16));
        card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(UITheme.BORDER, 1, true),
            new EmptyBorder(16, 16, 16, 16)
        ));

        // Month navigation bar
        JPanel navBar = new JPanel(new BorderLayout());
        navBar.setOpaque(false);

        JButton btnPrev = new JButton("‹");
        styleNavBtn(btnPrev);
        btnPrev.addActionListener(e -> { displayMonth = displayMonth.minusMonths(1); refresh(); });

        JButton btnNext = new JButton("›");
        styleNavBtn(btnNext);
        btnNext.addActionListener(e -> { displayMonth = displayMonth.plusMonths(1); refresh(); });

        lblMonthYear = new JLabel("", SwingConstants.CENTER);
        lblMonthYear.setFont(UITheme.FONT_SECTION);
        lblMonthYear.setForeground(UITheme.TEXT_PRIMARY);

        navBar.add(btnPrev, BorderLayout.WEST);
        navBar.add(lblMonthYear, BorderLayout.CENTER);
        navBar.add(btnNext, BorderLayout.EAST);
        card.add(navBar, BorderLayout.NORTH);

        // Day-of-week headers
        String[] days = {"Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"};
        JPanel dayHeaders = new JPanel(new GridLayout(1, 7, 4, 0));
        dayHeaders.setOpaque(false);
        for (String d : days) {
            JLabel lbl = new JLabel(d, SwingConstants.CENTER);
            lbl.setFont(UITheme.FONT_SMALL_BOLD);
            lbl.setForeground(UITheme.TEXT_MUTED);
            lbl.setBorder(new EmptyBorder(0, 0, 6, 0));
            dayHeaders.add(lbl);
        }
        card.add(dayHeaders, BorderLayout.CENTER);

        // Calendar grid
        calendarGrid = new JPanel(new GridLayout(6, 7, 4, 4));
        calendarGrid.setOpaque(false);
        card.add(calendarGrid, BorderLayout.SOUTH);

        add(card, BorderLayout.CENTER);
        refresh();
    }

    private void refresh() {
        // Update month/year label
        String monthName = displayMonth.getMonth().getDisplayName(TextStyle.FULL, Locale.ENGLISH);
        lblMonthYear.setText(monthName + "  " + displayMonth.getYear());

        calendarGrid.removeAll();

        // First day of month, adjust for Mon-start week
        LocalDate firstDay = displayMonth.atDay(1);
        int firstDayOfWeek = firstDay.getDayOfWeek().getValue(); // 1=Mon, 7=Sun

        // Fill leading blanks
        for (int i = 1; i < firstDayOfWeek; i++) {
            calendarGrid.add(new JLabel(""));
        }

        // Fill days
        int daysInMonth = displayMonth.lengthOfMonth();
        for (int d = 1; d <= daysInMonth; d++) {
            LocalDate date = displayMonth.atDay(d);
            boolean isToday = date.equals(today);
            calendarGrid.add(createDayCell(d, isToday));
        }

        // Fill trailing blanks (up to 42 cells = 6 rows × 7)
        int totalCells = firstDayOfWeek - 1 + daysInMonth;
        int trailing = (totalCells % 7 == 0) ? 0 : (7 - totalCells % 7);
        for (int i = 0; i < trailing; i++) {
            calendarGrid.add(new JLabel(""));
        }

        calendarGrid.revalidate();
        calendarGrid.repaint();
    }

    private JPanel createDayCell(int day, boolean isToday) {
        JPanel cell = new JPanel(new GridBagLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                if (isToday) {
                    g2.setColor(UITheme.PRIMARY);
                    g2.fillOval(0, 0, getWidth(), getHeight());
                }
                g2.dispose();
                super.paintComponent(g);
            }
        };
        cell.setOpaque(false);
        cell.setPreferredSize(new Dimension(32, 32));

        JLabel lbl = new JLabel(String.valueOf(day), SwingConstants.CENTER);
        lbl.setFont(isToday ? UITheme.FONT_BODY_BOLD : UITheme.FONT_BODY);
        lbl.setForeground(isToday ? Color.WHITE : UITheme.TEXT_PRIMARY);
        cell.add(lbl);

        // Hover effect for non-today cells
        if (!isToday) {
            cell.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseEntered(MouseEvent e) {
                    cell.setBackground(UITheme.PRIMARY_LIGHT);
                    cell.setOpaque(true);
                }
                @Override
                public void mouseExited(MouseEvent e) {
                    cell.setOpaque(false);
                    cell.repaint();
                }
            });
        }
        return cell;
    }

    private void styleNavBtn(JButton btn) {
        btn.setFont(new Font(UITheme.FONT_FAMILY, Font.BOLD, 18));
        btn.setForeground(UITheme.PRIMARY);
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setContentAreaFilled(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.addMouseListener(new MouseAdapter() {
            @Override public void mouseEntered(MouseEvent e) { btn.setForeground(UITheme.PRIMARY_DARK); }
            @Override public void mouseExited(MouseEvent e)  { btn.setForeground(UITheme.PRIMARY); }
        });
    }
}
