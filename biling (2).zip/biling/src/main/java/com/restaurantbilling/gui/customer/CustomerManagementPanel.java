package com.restaurantbilling.gui.customer;

import com.restaurantbilling.exception.ValidationException;
import com.restaurantbilling.gui.theme.UIHelper;
import com.restaurantbilling.gui.theme.UITheme;
import com.restaurantbilling.gui.util.CustomDialogs;
import com.restaurantbilling.model.Customer;
import com.restaurantbilling.service.CustomerService;
import com.restaurantbilling.util.UserSession;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

public class CustomerManagementPanel extends JPanel {

    private final CustomerService customerService;
    private List<Customer> customerList = new ArrayList<>();

    // Controls
    private JTextField txtSearch;
    private JComboBox<String> cmbStatusFilter;
    private JButton btnSearch;
    private JButton btnClearFilters;

    private JButton btnAddCustomer;
    private JButton btnEditCustomer;
    private JButton btnViewCustomer;
    private JButton btnToggleStatus;
    private JButton btnDeleteCustomer;
    private JButton btnRefresh;

    private JTable customerTable;
    private DefaultTableModel tableModel;
    private JLabel lblStatusInfo;
    private JProgressBar progressBar;

    private static final String[] COLUMN_NAMES = {
        "ID", "Customer Name", "Phone", "Email", "Status", "Registered Date"
    };

    public CustomerManagementPanel() {
        this(new CustomerService());
    }

    public CustomerManagementPanel(CustomerService customerService) {
        this.customerService = customerService;
        setLayout(new BorderLayout(15, 15));
        setBorder(new EmptyBorder(16, 20, 16, 20));
        setBackground(UITheme.APP_BG);

        initComponents();
        setupTableSelectionListener();
        applyRolePermissions();
        loadCustomersAsync();
    }

    private void initComponents() {
        // TOP: Header + Search/Filter Toolbar
        JPanel topPanel = new JPanel(new BorderLayout(10, 12));
        topPanel.setOpaque(false);

        JPanel titlePanel = new JPanel(new GridLayout(2, 1, 0, 3));
        titlePanel.setOpaque(false);

        JLabel lblTitle = new JLabel("Customer Management");
        lblTitle.setFont(UITheme.FONT_TITLE_LARGE);
        lblTitle.setForeground(UITheme.TEXT_PRIMARY);
        titlePanel.add(lblTitle);

        JLabel lblSubtitle = new JLabel("Search, view, register, and maintain restaurant customer profiles.");
        lblSubtitle.setFont(UITheme.FONT_BODY_MEDIUM);
        lblSubtitle.setForeground(UITheme.TEXT_SECONDARY);
        titlePanel.add(lblSubtitle);

        topPanel.add(titlePanel, BorderLayout.NORTH);

        // Filter Bar Card
        JPanel filterPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 8));
        filterPanel.setBackground(UITheme.CARD_BG);
        filterPanel.setBorder(UITheme.BORDER_CARD);

        JLabel lblSearch = new JLabel("Search:");
        lblSearch.setFont(UITheme.FONT_BODY_BOLD);
        filterPanel.add(lblSearch);

        txtSearch = new JTextField(18);
        UIHelper.styleTextField(txtSearch);
        txtSearch.setPreferredSize(new Dimension(200, 34));
        txtSearch.putClientProperty("JTextField.placeholderText", "Name, Phone or Email...");
        txtSearch.addActionListener(e -> performSearch());
        filterPanel.add(txtSearch);

        btnSearch = UIHelper.createSecondaryButton("Search");
        btnSearch.setPreferredSize(new Dimension(90, 34));
        btnSearch.addActionListener(e -> performSearch());
        filterPanel.add(btnSearch);

        JLabel lblStatus = new JLabel("Status:");
        lblStatus.setFont(UITheme.FONT_BODY_BOLD);
        filterPanel.add(lblStatus);

        cmbStatusFilter = new JComboBox<>(new String[]{"All", "Active", "Inactive"});
        UIHelper.styleComboBox(cmbStatusFilter);
        cmbStatusFilter.setPreferredSize(new Dimension(110, 34));
        cmbStatusFilter.addActionListener(e -> performSearch());
        filterPanel.add(cmbStatusFilter);

        btnClearFilters = UIHelper.createSecondaryButton("Clear Filters");
        btnClearFilters.setPreferredSize(new Dimension(110, 34));
        btnClearFilters.addActionListener(e -> clearFilters());
        filterPanel.add(btnClearFilters);

        topPanel.add(filterPanel, BorderLayout.SOUTH);
        add(topPanel, BorderLayout.NORTH);

        // CENTER: Customer Table Card
        JPanel centerCard = new JPanel(new BorderLayout());
        centerCard.setBackground(UITheme.CARD_BG);
        centerCard.setBorder(new LineBorder(UITheme.BORDER, 1, true));

        tableModel = new DefaultTableModel(COLUMN_NAMES, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        customerTable = new JTable(tableModel);
        UIHelper.styleTable(customerTable);

        // Column widths & Alignments
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(SwingConstants.CENTER);

        customerTable.getColumnModel().getColumn(0).setPreferredWidth(50);
        customerTable.getColumnModel().getColumn(0).setCellRenderer(centerRenderer);

        customerTable.getColumnModel().getColumn(1).setPreferredWidth(180);
        customerTable.getColumnModel().getColumn(2).setPreferredWidth(130);
        customerTable.getColumnModel().getColumn(3).setPreferredWidth(180);

        customerTable.getColumnModel().getColumn(4).setPreferredWidth(90);
        customerTable.getColumnModel().getColumn(4).setCellRenderer(UIHelper.createStatusCellRenderer());

        customerTable.getColumnModel().getColumn(5).setPreferredWidth(140);
        customerTable.getColumnModel().getColumn(5).setCellRenderer(centerRenderer);

        // Double click to view details
        customerTable.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2 && customerTable.getSelectedRow() != -1) {
                    onViewCustomer();
                }
            }
        });

        JScrollPane scrollPane = new JScrollPane(customerTable);
        UIHelper.styleScrollPane(scrollPane);
        centerCard.add(scrollPane, BorderLayout.CENTER);

        add(centerCard, BorderLayout.CENTER);

        // SOUTH: Action Buttons + Status Bar
        JPanel southPanel = new JPanel(new BorderLayout(10, 10));
        southPanel.setOpaque(false);

        JPanel actionPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));
        actionPanel.setOpaque(false);

        btnAddCustomer = UIHelper.createPrimaryButton("+ Add Customer");
        btnAddCustomer.addActionListener(e -> onAddCustomer());
        actionPanel.add(btnAddCustomer);

        btnEditCustomer = UIHelper.createSecondaryButton("Edit Customer");
        btnEditCustomer.setEnabled(false);
        btnEditCustomer.addActionListener(e -> onEditCustomer());
        actionPanel.add(btnEditCustomer);

        btnViewCustomer = UIHelper.createSecondaryButton("View Profile");
        btnViewCustomer.setEnabled(false);
        btnViewCustomer.addActionListener(e -> onViewCustomer());
        actionPanel.add(btnViewCustomer);

        btnToggleStatus = UIHelper.createSecondaryButton("Deactivate");
        btnToggleStatus.setEnabled(false);
        btnToggleStatus.addActionListener(e -> onToggleStatus());
        actionPanel.add(btnToggleStatus);

        btnDeleteCustomer = UIHelper.createDangerButton("Delete");
        btnDeleteCustomer.setEnabled(false);
        btnDeleteCustomer.addActionListener(e -> onDeleteCustomer());
        actionPanel.add(btnDeleteCustomer);

        btnRefresh = UIHelper.createSecondaryButton("Refresh");
        btnRefresh.addActionListener(e -> loadCustomersAsync());
        actionPanel.add(btnRefresh);

        southPanel.add(actionPanel, BorderLayout.NORTH);

        // Bottom Status Bar
        JPanel statusBar = new JPanel(new BorderLayout());
        statusBar.setOpaque(false);

        lblStatusInfo = new JLabel("Loading customer records...");
        lblStatusInfo.setFont(UITheme.FONT_SMALL);
        lblStatusInfo.setForeground(UITheme.TEXT_SECONDARY);
        statusBar.add(lblStatusInfo, BorderLayout.WEST);

        progressBar = new JProgressBar();
        progressBar.setPreferredSize(new Dimension(150, 12));
        progressBar.setIndeterminate(true);
        progressBar.setVisible(false);
        statusBar.add(progressBar, BorderLayout.EAST);

        southPanel.add(statusBar, BorderLayout.SOUTH);
        add(southPanel, BorderLayout.SOUTH);
    }

    private void setupTableSelectionListener() {
        customerTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                int selectedRow = customerTable.getSelectedRow();
                boolean rowSelected = selectedRow != -1;
                btnViewCustomer.setEnabled(rowSelected);

                if (rowSelected && selectedRow < customerList.size()) {
                    Customer selectedCustomer = customerList.get(selectedRow);
                    boolean isAdmin = UserSession.isAdmin();
                    btnEditCustomer.setEnabled(isAdmin);
                    btnDeleteCustomer.setEnabled(isAdmin);

                    if (isAdmin) {
                        btnToggleStatus.setEnabled(true);
                        if ("Active".equalsIgnoreCase(selectedCustomer.getStatus())) {
                            btnToggleStatus.setText("Deactivate");
                        } else {
                            btnToggleStatus.setText("Activate");
                        }
                    } else {
                        btnToggleStatus.setEnabled(false);
                    }
                } else {
                    btnEditCustomer.setEnabled(false);
                    btnDeleteCustomer.setEnabled(false);
                    btnToggleStatus.setEnabled(false);
                }
            }
        });
    }

    private void applyRolePermissions() {
        boolean isAdmin = UserSession.isAdmin();
        btnEditCustomer.setVisible(isAdmin);
        btnToggleStatus.setVisible(isAdmin);
        btnDeleteCustomer.setVisible(isAdmin);
    }

    public void loadCustomersAsync() {
        progressBar.setVisible(true);
        lblStatusInfo.setText("Loading customer records...");

        SwingWorker<List<Customer>, Void> worker = new SwingWorker<>() {
            @Override
            protected List<Customer> doInBackground() {
                return customerService.getAllCustomers();
            }

            @Override
            protected void done() {
                try {
                    customerList = get();
                    updateTableData(customerList);
                    int total = customerList.size();
                    int active = customerService.getActiveCustomerCount();
                    lblStatusInfo.setText("Total Customers: " + total + "  |  Active Profiles: " + active);
                } catch (Exception ex) {
                    Throwable cause = ex.getCause() != null ? ex.getCause() : ex;
                    System.err.println("[CustomerManagementPanel] Load customers failed: " + cause.getMessage());
                    lblStatusInfo.setText("Error: " + cause.getMessage());
                    // Determine whether this is a connection failure or a SQL/data error
                    String causeMsg = cause.getMessage() != null ? cause.getMessage().toLowerCase() : "";
                    boolean isConnectionFailure = causeMsg.contains("communications link failure")
                        || causeMsg.contains("connection refused")
                        || causeMsg.contains("unable to connect")
                        || causeMsg.contains("access denied")
                        || causeMsg.contains("driver not found");
                    if (isConnectionFailure) {
                        CustomDialogs.showError(CustomerManagementPanel.this,
                            "Unable to connect to the database.\nPlease ensure MySQL is running and the connection settings are correct.",
                            "Database Connection Error");
                    } else {
                        CustomDialogs.showError(CustomerManagementPanel.this,
                            "Unable to load customer data.\nDetails: " + cause.getMessage(),
                            "Database Error");
                    }
                } finally {
                    progressBar.setVisible(false);
                }
            }
        };
        worker.execute();
    }

    private void performSearch() {
        String keyword = txtSearch.getText().trim();
        String status = (String) cmbStatusFilter.getSelectedItem();

        progressBar.setVisible(true);
        lblStatusInfo.setText("Searching customers...");

        SwingWorker<List<Customer>, Void> worker = new SwingWorker<>() {
            @Override
            protected List<Customer> doInBackground() {
                return customerService.searchCustomers(keyword, status);
            }

            @Override
            protected void done() {
                try {
                    customerList = get();
                    updateTableData(customerList);
                    if (customerList.isEmpty()) {
                        lblStatusInfo.setText("No customers match the search criteria.");
                    } else {
                        lblStatusInfo.setText("Found " + customerList.size() + " matching customer(s).");
                    }
                } catch (Exception ex) {
                    lblStatusInfo.setText("Search error: " + ex.getMessage());
                } finally {
                    progressBar.setVisible(false);
                }
            }
        };
        worker.execute();
    }

    private void clearFilters() {
        txtSearch.setText("");
        cmbStatusFilter.setSelectedItem("All");
        loadCustomersAsync();
    }

    private void updateTableData(List<Customer> list) {
        tableModel.setRowCount(0);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");

        for (Customer c : list) {
            String formattedDate = (c.getCreatedAt() != null) ? sdf.format(c.getCreatedAt()) : "-";
            tableModel.addRow(new Object[]{
                c.getId(),
                c.getName(),
                c.getPhone(),
                (c.getEmail() != null) ? c.getEmail() : "-",
                c.getStatus(),
                formattedDate
            });
        }
    }

    private Customer getSelectedCustomer() {
        int selectedRow = customerTable.getSelectedRow();
        if (selectedRow >= 0 && selectedRow < customerList.size()) {
            return customerList.get(selectedRow);
        }
        return null;
    }

    private void onAddCustomer() {
        Window parentWindow = SwingUtilities.getWindowAncestor(this);
        CustomerDialog dialog = new CustomerDialog(parentWindow, customerService, null, CustomerDialog.Mode.ADD);
        dialog.setVisible(true);

        if (dialog.isSaved()) {
            loadCustomersAsync();
        }
    }

    private void onEditCustomer() {
        Customer selected = getSelectedCustomer();
        if (selected == null) {
            CustomDialogs.showWarning(this, "Please select a customer from the table to edit.", "Selection Required");
            return;
        }

        Window parentWindow = SwingUtilities.getWindowAncestor(this);
        CustomerDialog dialog = new CustomerDialog(parentWindow, customerService, selected, CustomerDialog.Mode.EDIT);
        dialog.setVisible(true);

        if (dialog.isSaved()) {
            loadCustomersAsync();
        }
    }

    private void onViewCustomer() {
        Customer selected = getSelectedCustomer();
        if (selected == null) {
            CustomDialogs.showWarning(this, "Please select a customer from the table to view.", "Selection Required");
            return;
        }

        Window parentWindow = SwingUtilities.getWindowAncestor(this);
        CustomerDialog dialog = new CustomerDialog(parentWindow, customerService, selected, CustomerDialog.Mode.VIEW);
        dialog.setVisible(true);
    }

    private void onToggleStatus() {
        Customer selected = getSelectedCustomer();
        if (selected == null) return;

        String currentStatus = selected.getStatus();
        String newStatus = "Active".equalsIgnoreCase(currentStatus) ? "Inactive" : "Active";

        boolean confirmed = CustomDialogs.showConfirm(this,
            "Are you sure you want to change status of '" + selected.getName() + "' to " + newStatus + "?",
            "Confirm Status Change",
            "Update Status",
            "Cancel");

        if (confirmed) {
            try {
                customerService.setCustomerStatus(selected.getId(), newStatus);
                CustomDialogs.showSuccess(this, "Customer status updated to " + newStatus + ".", "Status Updated");
                loadCustomersAsync();
            } catch (ValidationException ex) {
                CustomDialogs.showWarning(this, ex.getMessage(), "Error");
            } catch (Exception ex) {
                CustomDialogs.showError(this, "Failed to update status: " + ex.getMessage(), "Database Error");
            }
        }
    }

    private void onDeleteCustomer() {
        Customer selected = getSelectedCustomer();
        if (selected == null) return;

        boolean confirmed = CustomDialogs.showDangerConfirm(this,
            "Are you sure you want to permanently delete customer '" + selected.getName() + "'?\nIf past orders exist, consider deactivating instead.",
            "Confirm Customer Deletion",
            "Delete Customer");

        if (confirmed) {
            try {
                customerService.deleteCustomer(selected.getId());
                CustomDialogs.showSuccess(this, "Customer profile deleted successfully.", "Customer Deleted");
                loadCustomersAsync();
            } catch (ValidationException ex) {
                CustomDialogs.showWarning(this, ex.getMessage(), "Permission Denied");
            } catch (Exception ex) {
                CustomDialogs.showWarning(this, ex.getMessage(), "Deletion Notice");
            }
        }
    }

    public Customer getSelectedCustomerForOrder() {
        return getSelectedCustomer();
    }
}
