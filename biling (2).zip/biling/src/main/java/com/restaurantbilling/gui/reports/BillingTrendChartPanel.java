package com.restaurantbilling.gui.reports;

import com.restaurantbilling.gui.theme.UITheme;
import com.restaurantbilling.model.report.BillingTrendDTO;
import com.restaurantbilling.util.FormatUtil;

import javax.swing.*;
import java.awt.*;
import java.awt.geom.GeneralPath;
import java.awt.geom.Path2D;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * Daily Revenue Overview — Smooth Line Chart with green gradient fill.
 * Spice Garden premium chart component.
 */
public class BillingTrendChartPanel extends JPanel {

    private List<BillingTrendDTO> data = new ArrayList<>();
    private String chartTitle = "Daily Revenue Overview";

    // Green palette
    private static final Color LINE_COLOR     = UITheme.PRIMARY;          // #238B2A
    private static final Color POINT_COLOR    = UITheme.PRIMARY;
    private static final Color POINT_FILL     = Color.WHITE;
    private static final Color FILL_TOP       = new Color(0x23, 0x8B, 0x2A, 60);  // transparent green
    private static final Color FILL_BOTTOM    = new Color(0x23, 0x8B, 0x2A, 0);   // fully transparent
    private static final Color GRID_COLOR     = new Color(0xE8, 0xF0, 0xE8);
    private static final Color AXIS_COLOR     = new Color(0xCC, 0xD4, 0xCC);
    private static final Color LABEL_COLOR    = UITheme.TEXT_SECONDARY;

    public BillingTrendChartPanel() {
        setBackground(UITheme.CARD_BG);
        setPreferredSize(new Dimension(500, 260));
        setMinimumSize(new Dimension(300, 200));
    }

    public void setData(List<BillingTrendDTO> data, String title) {
        this.data = (data != null) ? data : new ArrayList<>();
        this.chartTitle = (title != null) ? title : "Daily Revenue Overview";
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        g2.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);

        int w = getWidth();
        int h = getHeight();

        // ── Title ──
        g2.setFont(UITheme.FONT_SECTION);
        g2.setColor(UITheme.TEXT_PRIMARY);
        g2.drawString(chartTitle, 16, 26);

        if (data == null || data.isEmpty()) {
            g2.setFont(UITheme.FONT_BODY);
            g2.setColor(UITheme.TEXT_MUTED);
            String msg = "No revenue data available for the selected period";
            FontMetrics fm = g2.getFontMetrics();
            g2.drawString(msg, (w - fm.stringWidth(msg)) / 2, h / 2);
            g2.dispose();
            return;
        }

        // ── Layout bounds ──
        int leftMargin   = 72;
        int rightMargin  = 20;
        int topMargin    = 44;
        int bottomMargin = 42;

        int plotW = w - leftMargin - rightMargin;
        int plotH = h - topMargin - bottomMargin;
        if (plotW <= 0 || plotH <= 0) { g2.dispose(); return; }

        // ── Find max value ──
        BigDecimal maxVal = BigDecimal.ZERO;
        for (BillingTrendDTO d : data) {
            if (d.getTotalAmount() != null && d.getTotalAmount().compareTo(maxVal) > 0) {
                maxVal = d.getTotalAmount();
            }
        }
        if (maxVal.compareTo(BigDecimal.ZERO) == 0) maxVal = new BigDecimal("1000");
        // Add 10% headroom
        maxVal = maxVal.multiply(new BigDecimal("1.10")).setScale(0, java.math.RoundingMode.CEILING);

        // ── Grid lines & Y-axis labels ──
        int gridSteps = 5;
        g2.setFont(new Font(UITheme.FONT_FAMILY, Font.PLAIN, 10));
        for (int i = 0; i <= gridSteps; i++) {
            int y = topMargin + (plotH * (gridSteps - i)) / gridSteps;
            BigDecimal labelVal = maxVal.multiply(BigDecimal.valueOf(i))
                                       .divide(BigDecimal.valueOf(gridSteps), 2, java.math.RoundingMode.HALF_UP);

            // Grid line
            g2.setColor(GRID_COLOR);
            g2.setStroke(new BasicStroke(1f));
            g2.drawLine(leftMargin, y, leftMargin + plotW, y);

            // Y label
            g2.setColor(LABEL_COLOR);
            String yStr = formatShortCurrency(labelVal);
            FontMetrics fm = g2.getFontMetrics();
            g2.drawString(yStr, leftMargin - fm.stringWidth(yStr) - 6, y + 4);
        }

        // ── Compute data point coordinates ──
        int n = data.size();
        int[] xs = new int[n];
        int[] ys = new int[n];
        int slotW = n > 1 ? plotW / (n - 1) : plotW;

        for (int i = 0; i < n; i++) {
            xs[i] = leftMargin + (n > 1 ? i * plotW / (n - 1) : plotW / 2);
            double ratio = data.get(i).getTotalAmount().doubleValue() / maxVal.doubleValue();
            ys[i] = topMargin + plotH - (int) (plotH * Math.min(ratio, 1.0));
        }

        // ── Fill area below line (gradient) ──
        Path2D fillPath = new Path2D.Float();
        fillPath.moveTo(xs[0], topMargin + plotH);
        fillPath.lineTo(xs[0], ys[0]);
        for (int i = 1; i < n; i++) {
            // Smooth bezier curves
            double cx = (xs[i - 1] + xs[i]) / 2.0;
            fillPath.curveTo(cx, ys[i - 1], cx, ys[i], xs[i], ys[i]);
        }
        fillPath.lineTo(xs[n - 1], topMargin + plotH);
        fillPath.closePath();

        GradientPaint grad = new GradientPaint(
            leftMargin, topMargin,    FILL_TOP,
            leftMargin, topMargin + plotH, FILL_BOTTOM
        );
        g2.setPaint(grad);
        g2.fill(fillPath);

        // ── Draw smooth line ──
        GeneralPath linePath = new GeneralPath();
        linePath.moveTo(xs[0], ys[0]);
        for (int i = 1; i < n; i++) {
            double cx = (xs[i - 1] + xs[i]) / 2.0;
            linePath.curveTo(cx, ys[i - 1], cx, ys[i], xs[i], ys[i]);
        }
        g2.setColor(LINE_COLOR);
        g2.setStroke(new BasicStroke(2.5f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        g2.draw(linePath);

        // ── Data points (circles) ──
        int dotR = 5;
        for (int i = 0; i < n; i++) {
            // White fill
            g2.setColor(POINT_FILL);
            g2.fillOval(xs[i] - dotR, ys[i] - dotR, dotR * 2, dotR * 2);
            // Green ring
            g2.setColor(POINT_COLOR);
            g2.setStroke(new BasicStroke(2f));
            g2.drawOval(xs[i] - dotR, ys[i] - dotR, dotR * 2, dotR * 2);
        }

        // ── X-axis labels ──
        g2.setFont(new Font(UITheme.FONT_FAMILY, Font.PLAIN, 10));
        g2.setColor(LABEL_COLOR);
        FontMetrics fm = g2.getFontMetrics();

        // Baseline
        g2.setColor(AXIS_COLOR);
        g2.setStroke(new BasicStroke(1f));
        g2.drawLine(leftMargin, topMargin + plotH, leftMargin + plotW, topMargin + plotH);

        g2.setColor(LABEL_COLOR);
        for (int i = 0; i < n; i++) {
            BillingTrendDTO d = data.get(i);
            String label = d.getPeriodLabel();
            if (label != null && label.length() > 10) label = label.substring(5); // MM-DD
            if (label != null && label.length() > 6) label = label.substring(0, 6);
            if (label == null) label = "";
            g2.drawString(label, xs[i] - fm.stringWidth(label) / 2, topMargin + plotH + 16);
        }

        // ── Value tooltips above each point ──
        g2.setFont(new Font(UITheme.FONT_FAMILY, Font.BOLD, 10));
        for (int i = 0; i < n; i++) {
            String val = formatShortCurrency(data.get(i).getTotalAmount());
            FontMetrics vfm = g2.getFontMetrics();
            int vx = xs[i] - vfm.stringWidth(val) / 2;
            int vy = ys[i] - 9;
            // Mini label above point
            g2.setColor(UITheme.TEXT_SECONDARY);
            g2.drawString(val, vx, vy);
        }

        g2.dispose();
    }

    /**
     * Formats large currency values as compact strings (e.g., ₹1.2K, ₹45K).
     */
    private String formatShortCurrency(BigDecimal val) {
        if (val == null) return "₹0";
        double v = val.doubleValue();
        if (v >= 100_000) return String.format("₹%.1fL", v / 100_000);
        if (v >= 1_000)   return String.format("₹%.0fK", v / 1_000);
        return "₹" + (int) v;
    }
}
