package com.restaurantbilling.gui.reports;

import com.restaurantbilling.exception.ValidationException;
import com.restaurantbilling.gui.theme.UIHelper;
import com.restaurantbilling.gui.theme.UITheme;
import com.restaurantbilling.gui.util.CustomDialogs;
import com.restaurantbilling.model.report.*;
import com.restaurantbilling.report.CsvExporter;
import com.restaurantbilling.report.PdfDocumentGenerator;
import com.restaurantbilling.report.ReportGenerator;
import com.restaurantbilling.service.AuditService;
import com.restaurantbilling.service.ReportService;
import com.restaurantbilling.util.FormatUtil;

import javax.swing.*;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.border.MatteBorder;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class ReportsDashboardPanel extends JPanel {

    private final ReportService reportService;
    private final AuditService auditService;

    // Report Type
    private JComboBox<String> cmbReportType;

    // Filters
    private JTextField txtFromDate;
    private JTextField txtToDate;
    private JButton btnGenerate;
    private JButton btnResetFilter;

    // Secondary Dynamic Filters
    private JPanel secondaryFilterPanel;
    private JComboBox<String> cmbLimit;
    private JComboBox<String> cmbOrderStatus;
    private JTextField txtCustomerSearch;
    private JComboBox<String> cmbMenuCategory;

    // KPI Card Labels
    private JLabel lblTotalBills;
    private JLabel lblTotalBilling;
    private JLabel lblTotalOrders;
    private JLabel lblTotalCustomers;
    private JLabel lblAvgBill;

    // Results Table & Model
    private JTable reportTable;
    private DefaultTableModel tableModel;
    private JLabel lblStatusMessage;

    // Action Buttons
    private JButton btnPrintPreview;
    private JButton btnPrint;
    private JButton btnExportPdf;
    private JButton btnExportCsv;
    private JButton btnSaveTxt;

    // Current State Cache for Export/Print
    private String currentReportTitle = "Billing Summary";
    private String currentDateRangeLabel = "This Month";
    private String[] currentHeaders = new String[0];
    private List<String[]> currentRows = new ArrayList<>();
    private String currentSummaryText = "";

    public ReportsDashboardPanel() {
        this.reportService = new ReportService();
        this.auditService = new AuditService();

        setLayout(new BorderLayout(12, 12));
        setBorder(new EmptyBorder(16, 20, 16, 20));
        setBackground(UITheme.APP_BG);

        initComponents();
        setQuickFilterThisMonth();
        generateReportAsync();
    }

    private void initComponents() {
        // TOP: Title + Controls + KPI Cards
        JPanel topContainer = new JPanel();
        topContainer.setLayout(new BoxLayout(topContainer, BoxLayout.Y_AXIS));
        topContainer.setOpaque(false);

        // Header Title
        JPanel titlePanel = new JPanel(new GridLayout(2, 1, 0, 3));
        titlePanel.setOpaque(false);

        JLabel lblTitle = new JLabel("Report Center & Business Analytics");
        lblTitle.setFont(UITheme.FONT_TITLE_LARGE);
        lblTitle.setForeground(UITheme.TEXT_PRIMARY);
        titlePanel.add(lblTitle);

        JLabel lblSub = new JLabel("Generate, visualize, print and export comprehensive analytical restaurant reports.");
        lblSub.setFont(UITheme.FONT_BODY_MEDIUM);
        lblSub.setForeground(UITheme.TEXT_SECONDARY);
        titlePanel.add(lblSub);

        topContainer.add(titlePanel);
        topContainer.add(Box.createVerticalStrut(12));

        // KPI Cards Row
        JPanel kpiPanel = new JPanel(new GridLayout(1, 5, 10, 0));
        kpiPanel.setOpaque(false);

        lblTotalBills = new JLabel("0", SwingConstants.LEFT);
        kpiPanel.add(createKpiCard("TOTAL BILLS", lblTotalBills, UITheme.PRIMARY));

        lblTotalBilling = new JLabel("₹0.00", SwingConstants.LEFT);
        kpiPanel.add(createKpiCard("TOTAL BILLED", lblTotalBilling, UITheme.SUCCESS));

        lblTotalOrders = new JLabel("0", SwingConstants.LEFT);
        kpiPanel.add(createKpiCard("TOTAL ORDERS", lblTotalOrders, UITheme.WARNING));

        lblTotalCustomers = new JLabel("0", SwingConstants.LEFT);
        kpiPanel.add(createKpiCard("CUSTOMERS", lblTotalCustomers, UITheme.INFO));

        lblAvgBill = new JLabel("₹0.00", SwingConstants.LEFT);
        kpiPanel.add(createKpiCard("AVG BILL VALUE", lblAvgBill, UITheme.SECONDARY));

        topContainer.add(kpiPanel);
        topContainer.add(Box.createVerticalStrut(12));

        // Filter Bar Card
        JPanel filterCard = new JPanel(new BorderLayout(8, 8));
        filterCard.setBackground(UITheme.CARD_BG);
        filterCard.setBorder(UITheme.BORDER_CARD);

        // Primary Row: Report Type + Dates + Quick Buttons + Generate
        JPanel primaryFilterRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));
        primaryFilterRow.setOpaque(false);

        JLabel lblRep = new JLabel("Report Type:");
        lblRep.setFont(UITheme.FONT_BODY_BOLD);
        primaryFilterRow.add(lblRep);

        cmbReportType = new JComboBox<>(new String[]{
            "Billing Summary",
            "Daily Billing Report",
            "Monthly Billing Report",
            "Order Report",
            "Customer Report",
            "Menu Item Report",
            "Top-Selling Items"
        });
        UIHelper.styleComboBox(cmbReportType);
        cmbReportType.setFont(UITheme.FONT_BODY_BOLD);
        cmbReportType.setPreferredSize(new Dimension(190, 34));
        cmbReportType.addActionListener(e -> onReportTypeChanged());
        primaryFilterRow.add(cmbReportType);

        primaryFilterRow.add(new JSeparator(SwingConstants.VERTICAL));

        JLabel lblFrom = new JLabel("From:");
        lblFrom.setFont(UITheme.FONT_BODY_MEDIUM);
        primaryFilterRow.add(lblFrom);

        txtFromDate = new JTextField(9);
        UIHelper.styleTextField(txtFromDate);
        txtFromDate.setPreferredSize(new Dimension(95, 32));
        primaryFilterRow.add(txtFromDate);

        JLabel lblTo = new JLabel("To:");
        lblTo.setFont(UITheme.FONT_BODY_MEDIUM);
        primaryFilterRow.add(lblTo);

        txtToDate = new JTextField(9);
        UIHelper.styleTextField(txtToDate);
        txtToDate.setPreferredSize(new Dimension(95, 32));
        primaryFilterRow.add(txtToDate);

        btnGenerate = UIHelper.createPrimaryButton("Generate Report");
        btnGenerate.addActionListener(e -> generateReportAsync());
        primaryFilterRow.add(btnGenerate);

        btnResetFilter = UIHelper.createSecondaryButton("Reset");
        btnResetFilter.addActionListener(e -> {
            txtFromDate.setText("");
            txtToDate.setText("");
            generateReportAsync();
        });
        primaryFilterRow.add(btnResetFilter);

        primaryFilterRow.add(new JSeparator(SwingConstants.VERTICAL));
        primaryFilterRow.add(createQuickDateBtn("Today", this::setQuickFilterToday));
        primaryFilterRow.add(createQuickDateBtn("This Week", this::setQuickFilterThisWeek));
        primaryFilterRow.add(createQuickDateBtn("This Month", this::setQuickFilterThisMonth));
        primaryFilterRow.add(createQuickDateBtn("This Year", this::setQuickFilterThisYear));

        filterCard.add(primaryFilterRow, BorderLayout.NORTH);

        // Secondary Filter Row
        secondaryFilterPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));
        secondaryFilterPanel.setOpaque(false);
        setupSecondaryFilters();
        filterCard.add(secondaryFilterPanel, BorderLayout.SOUTH);

        topContainer.add(filterCard);
        add(topContainer, BorderLayout.NORTH);

        // CENTER: Table Results Card
        JPanel centerPanel = new JPanel(new BorderLayout(8, 8));
        centerPanel.setBackground(UITheme.CARD_BG);
        centerPanel.setBorder(new LineBorder(UITheme.BORDER, 1, true));

        tableModel = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        reportTable = new JTable(tableModel);
        UIHelper.styleTable(reportTable);

        JScrollPane scrollPane = new JScrollPane(reportTable);
        UIHelper.styleScrollPane(scrollPane);
        centerPanel.add(scrollPane, BorderLayout.CENTER);

        lblStatusMessage = new JLabel("Ready. Click Generate Report to load data.", SwingConstants.LEFT);
        lblStatusMessage.setFont(UITheme.FONT_SMALL);
        lblStatusMessage.setForeground(UITheme.TEXT_SECONDARY);
        lblStatusMessage.setBorder(new EmptyBorder(4, 10, 6, 10));
        centerPanel.add(lblStatusMessage, BorderLayout.SOUTH);

        add(centerPanel, BorderLayout.CENTER);

        // BOTTOM: Action Bar (Print, PDF, CSV, TXT)
        JPanel bottomBar = new JPanel(new BorderLayout());
        bottomBar.setOpaque(false);

        JPanel actionBtnGroup = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 5));
        actionBtnGroup.setOpaque(false);

        btnPrintPreview = UIHelper.createSecondaryButton("Print Preview");
        btnPrintPreview.addActionListener(e -> onPrintPreview());
        actionBtnGroup.add(btnPrintPreview);

        btnPrint = UIHelper.createPrimaryButton("🖨️ Print Report");
        btnPrint.addActionListener(e -> onPrintReport());
        actionBtnGroup.add(btnPrint);

        btnExportPdf = UIHelper.createDangerButton("Export PDF");
        btnExportPdf.addActionListener(e -> onExportPdf());
        actionBtnGroup.add(btnExportPdf);

        btnExportCsv = UIHelper.createSuccessButton("Export CSV");
        btnExportCsv.addActionListener(e -> onExportCsv());
        actionBtnGroup.add(btnExportCsv);

        btnSaveTxt = UIHelper.createSecondaryButton("Save TXT");
        btnSaveTxt.addActionListener(e -> onSaveTxt());
        actionBtnGroup.add(btnSaveTxt);

        bottomBar.add(actionBtnGroup, BorderLayout.EAST);
        add(bottomBar, BorderLayout.SOUTH);
    }

    private void setupSecondaryFilters() {
        secondaryFilterPanel.removeAll();

        String selected = (String) cmbReportType.getSelectedItem();
        if ("Top-Selling Items".equals(selected)) {
            secondaryFilterPanel.add(new JLabel("Limit Results:"));
            cmbLimit = new JComboBox<>(new String[]{"Top 5", "Top 10", "Top 25", "Top 50", "All (100)"});
            UIHelper.styleComboBox(cmbLimit);
            cmbLimit.setSelectedIndex(1);
            cmbLimit.addActionListener(e -> generateReportAsync());
            secondaryFilterPanel.add(cmbLimit);
        } else if ("Order Report".equals(selected)) {
            secondaryFilterPanel.add(new JLabel("Status Filter:"));
            cmbOrderStatus = new JComboBox<>(new String[]{"ALL", "PENDING", "CONFIRMED", "PREPARING", "READY", "COMPLETED", "CANCELLED"});
            UIHelper.styleComboBox(cmbOrderStatus);
            cmbOrderStatus.addActionListener(e -> generateReportAsync());
            secondaryFilterPanel.add(cmbOrderStatus);
        } else if ("Customer Report".equals(selected)) {
            secondaryFilterPanel.add(new JLabel("Search Customer (Name/Phone):"));
            txtCustomerSearch = new JTextField(15);
            UIHelper.styleTextField(txtCustomerSearch);
            txtCustomerSearch.setPreferredSize(new Dimension(140, 30));
            txtCustomerSearch.addActionListener(e -> generateReportAsync());
            secondaryFilterPanel.add(txtCustomerSearch);

            JButton btnSearch = UIHelper.createSecondaryButton("Search");
            btnSearch.addActionListener(e -> generateReportAsync());
            secondaryFilterPanel.add(btnSearch);
        } else if ("Menu Item Report".equals(selected)) {
            secondaryFilterPanel.add(new JLabel("Category:"));
            cmbMenuCategory = new JComboBox<>(new String[]{"ALL", "Starter", "Main Course", "Dessert", "Beverage", "Snacks"});
            UIHelper.styleComboBox(cmbMenuCategory);
            cmbMenuCategory.addActionListener(e -> generateReportAsync());
            secondaryFilterPanel.add(cmbMenuCategory);
        }

        secondaryFilterPanel.revalidate();
        secondaryFilterPanel.repaint();
    }

    private void onReportTypeChanged() {
        setupSecondaryFilters();
        generateReportAsync();
    }

    public void loadAllReportsAsync() {
        generateReportAsync();
    }

    public void generateReportAsync() {
        String fromDate = txtFromDate.getText().trim();
        String toDate = txtToDate.getText().trim();
        String reportType = (String) cmbReportType.getSelectedItem();

        try {
            reportService.validateDateRange(fromDate, toDate);
        } catch (ValidationException ve) {
            CustomDialogs.showWarning(this, ve.getMessage(), "Validation Error");
            return;
        }

        btnGenerate.setEnabled(false);
        lblStatusMessage.setText("Loading " + reportType + " data from database...");

        SwingWorker<Void, Void> worker = new SwingWorker<>() {
            private BillSummaryDTO billSummary;
            private OrderSummaryDTO orderSummary;
            private CustomerSummaryDTO customerSummary;
            private String[] headers;
            private List<String[]> rows;
            private String summaryText;
            private Exception error;

            @Override
            protected Void doInBackground() {
                try {
                    billSummary = reportService.getBillSummary(fromDate, toDate);
                    orderSummary = reportService.getOrderSummary(fromDate, toDate);
                    customerSummary = reportService.getCustomerSummary();

                    currentReportTitle = reportType;
                    currentDateRangeLabel = (fromDate.isEmpty() && toDate.isEmpty()) ? "All Time" : (fromDate + " to " + toDate);

                    if ("Billing Summary".equals(reportType)) {
                        headers = new String[]{"Summary Metric", "Calculated Value", "Remarks"};
                        rows = new ArrayList<>();
                        rows.add(new String[]{"Total Bills Generated", String.valueOf(billSummary.getTotalBills()), "Unique finalized bills"});
                        rows.add(new String[]{"Total Billed Amount", FormatUtil.formatCurrency(billSummary.getTotalBillingAmount()), "Sum of all bill totals"});
                        rows.add(new String[]{"Average Bill Amount", FormatUtil.formatCurrency(billSummary.getAverageBillAmount()), "Average ticket size"});
                        rows.add(new String[]{"Highest Bill Amount", FormatUtil.formatCurrency(billSummary.getHighestBillAmount()), "Maximum bill generated"});
                        rows.add(new String[]{"Lowest Bill Amount", FormatUtil.formatCurrency(billSummary.getLowestBillAmount()), "Minimum bill generated"});
                        rows.add(new String[]{"Total Orders Placed", String.valueOf(orderSummary.getTotalOrders()), "All customer orders"});
                        rows.add(new String[]{"Completed Orders", String.valueOf(orderSummary.getCompletedOrders()), "Fulfilled orders"});
                        rows.add(new String[]{"Cancelled Orders", String.valueOf(orderSummary.getCancelledOrders()), "Voided/cancelled orders"});
                        summaryText = String.format("Total Bills: %d | Total Billed: %s | Avg Bill: %s",
                            billSummary.getTotalBills(), FormatUtil.formatCurrency(billSummary.getTotalBillingAmount()), FormatUtil.formatCurrency(billSummary.getAverageBillAmount()));
                    } else if ("Daily Billing Report".equals(reportType)) {
                        headers = new String[]{"Date", "Bills Count", "Orders Count", "Total Billed Amount"};
                        rows = new ArrayList<>();
                        List<BillingTrendDTO> list = reportService.getDailyBillingTrend(fromDate, toDate);
                        for (BillingTrendDTO d : list) {
                            rows.add(new String[]{
                                d.getPeriodLabel(),
                                String.valueOf(d.getBillCount()),
                                String.valueOf(d.getOrderCount()),
                                FormatUtil.formatCurrency(d.getTotalAmount())
                            });
                        }
                        summaryText = "Daily Breakdown: " + rows.size() + " active days recorded.";
                    } else if ("Monthly Billing Report".equals(reportType)) {
                        headers = new String[]{"Month / Year", "Bills Count", "Orders Count", "Total Billed Amount"};
                        rows = new ArrayList<>();
                        List<BillingTrendDTO> list = reportService.getMonthlyBillingReport(fromDate, toDate);
                        for (BillingTrendDTO m : list) {
                            rows.add(new String[]{
                                m.getPeriodLabel(),
                                String.valueOf(m.getBillCount()),
                                String.valueOf(m.getOrderCount()),
                                FormatUtil.formatCurrency(m.getTotalAmount())
                            });
                        }
                        summaryText = "Monthly Breakdown: " + rows.size() + " months recorded.";
                    } else if ("Order Report".equals(reportType)) {
                        headers = new String[]{"Order ID", "Date", "Customer Name", "Items", "Status", "Bill Ref", "Total Amount"};
                        rows = new ArrayList<>();
                        String status = cmbOrderStatus != null ? (String) cmbOrderStatus.getSelectedItem() : "ALL";
                        List<OrderReportDTO> list = reportService.getOrderReport(fromDate, toDate, status, 1, 200);
                        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");
                        for (OrderReportDTO o : list) {
                            rows.add(new String[]{
                                "#" + o.getOrderId(),
                                o.getOrderDate() != null ? sdf.format(o.getOrderDate()) : "-",
                                o.getCustomerName(),
                                String.valueOf(o.getItemCount()),
                                o.getStatus(),
                                o.getBillNumber(),
                                FormatUtil.formatCurrency(o.getTotalAmount())
                            });
                        }
                        summaryText = "Showing " + rows.size() + " orders for the period.";
                    } else if ("Customer Report".equals(reportType)) {
                        headers = new String[]{"Customer ID", "Customer Name", "Phone", "Total Orders", "Total Billed Amount", "Last Order Date"};
                        rows = new ArrayList<>();
                        String kw = txtCustomerSearch != null ? txtCustomerSearch.getText().trim() : "";
                        List<CustomerReportDTO> list = reportService.getCustomerReport(kw, 1, 200);
                        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                        for (CustomerReportDTO c : list) {
                            rows.add(new String[]{
                                "#" + c.getCustomerId(),
                                c.getCustomerName(),
                                c.getCustomerPhone(),
                                String.valueOf(c.getTotalOrders()),
                                FormatUtil.formatCurrency(c.getTotalBilledAmount()),
                                c.getLastOrderDate() != null ? sdf.format(c.getLastOrderDate()) : "-"
                            });
                        }
                        summaryText = "Showing " + rows.size() + " customer profiles.";
                    } else if ("Menu Item Report".equals(reportType)) {
                        headers = new String[]{"Item ID", "Item Name", "Category", "Unit Price", "Qty Ordered", "Total Billing"};
                        rows = new ArrayList<>();
                        String cat = cmbMenuCategory != null ? (String) cmbMenuCategory.getSelectedItem() : "ALL";
                        List<MenuReportDTO> list = reportService.getMenuReport(fromDate, toDate, cat);
                        for (MenuReportDTO m : list) {
                            rows.add(new String[]{
                                "#" + m.getFoodItemId(),
                                m.getFoodName(),
                                m.getCategory(),
                                FormatUtil.formatCurrency(m.getPrice()),
                                String.valueOf(m.getQuantityOrdered()),
                                FormatUtil.formatCurrency(m.getTotalBilling())
                            });
                        }
                        summaryText = "Showing " + rows.size() + " menu item metrics.";
                    } else if ("Top-Selling Items".equals(reportType)) {
                        headers = new String[]{"Rank", "Food Item Name", "Category", "Quantity Sold", "Total Revenue Contribution"};
                        rows = new ArrayList<>();
                        int limit = 10;
                        if (cmbLimit != null) {
                            String sel = (String) cmbLimit.getSelectedItem();
                            if (sel.contains("5")) limit = 5;
                            else if (sel.contains("10")) limit = 10;
                            else if (sel.contains("25")) limit = 25;
                            else if (sel.contains("50")) limit = 50;
                            else if (sel.contains("100")) limit = 100;
                        }
                        List<ItemSalesDTO> list = reportService.getItemSalesReport(fromDate, toDate, limit);
                        int rank = 1;
                        for (ItemSalesDTO it : list) {
                            rows.add(new String[]{
                                "#" + (rank++),
                                it.getItemName(),
                                it.getCategory(),
                                String.valueOf(it.getQuantitySold()),
                                FormatUtil.formatCurrency(it.getRevenue())
                            });
                        }
                        summaryText = "Top " + rows.size() + " performing items.";
                    }
                } catch (Exception ex) {
                    error = ex;
                }
                return null;
            }

            @Override
            protected void done() {
                btnGenerate.setEnabled(true);
                if (error != null) {
                    lblStatusMessage.setText("Error loading report data: " + error.getMessage());
                    CustomDialogs.showError(ReportsDashboardPanel.this, "Unable to generate report: " + error.getMessage(), "Report Error");
                    return;
                }

                // Update KPI Cards
                lblTotalBills.setText(String.valueOf(billSummary.getTotalBills()));
                lblTotalBilling.setText(FormatUtil.formatCurrency(billSummary.getTotalBillingAmount()));
                lblTotalOrders.setText(String.valueOf(orderSummary.getTotalOrders()));
                lblTotalCustomers.setText(String.valueOf(customerSummary.getTotalCustomers()));
                lblAvgBill.setText(FormatUtil.formatCurrency(billSummary.getAverageBillAmount()));

                // Cache current state
                currentHeaders = headers;
                currentRows = rows;
                currentSummaryText = summaryText;

                // Populate Table
                tableModel.setDataVector(rows != null ? rows.toArray(new String[0][0]) : new String[0][0], headers);
                alignTableCells();

                lblStatusMessage.setText("Report '" + reportType + "' generated successfully (" + (rows != null ? rows.size() : 0) + " records).");

                auditService.log("REPORT", "REPORT_GENERATED", "Generated " + reportType + " for period: " + currentDateRangeLabel, "SUCCESS");
            }
        };

        worker.execute();
    }

    private void alignTableCells() {
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(SwingConstants.CENTER);

        DefaultTableCellRenderer rightRenderer = new DefaultTableCellRenderer();
        rightRenderer.setHorizontalAlignment(SwingConstants.RIGHT);

        for (int i = 0; i < reportTable.getColumnCount(); i++) {
            String col = reportTable.getColumnName(i).toLowerCase();
            if (col.contains("amount") || col.contains("billing") || col.contains("revenue") || col.contains("price") || col.contains("value") || col.contains("qty") || col.contains("count") || col.contains("items")) {
                reportTable.getColumnModel().getColumn(i).setCellRenderer(rightRenderer);
            } else if (col.contains("id") || col.contains("date") || col.contains("status") || col.contains("rank") || col.contains("ref")) {
                reportTable.getColumnModel().getColumn(i).setCellRenderer(centerRenderer);
            }
        }
    }

    private void onPrintPreview() {
        ReportGenerator generator = new ReportGenerator(currentReportTitle, currentDateRangeLabel, currentHeaders, currentRows);
        PrintPreviewDialog dialog = new PrintPreviewDialog(SwingUtilities.getWindowAncestor(this), currentReportTitle, generator.generateTextReport(), generator);
        dialog.setVisible(true);
    }

    private void onPrintReport() {
        ReportGenerator generator = new ReportGenerator(currentReportTitle, currentDateRangeLabel, currentHeaders, currentRows);
        boolean ok = generator.printReport();
        if (ok) {
            auditService.log("REPORT", "REPORT_PRINTED", "Printed report: " + currentReportTitle, "SUCCESS");
            CustomDialogs.showSuccess(this, "Report successfully sent to printer.", "Print Successful");
        }
    }

    private void onExportPdf() {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Export Report to PDF");
        String safeName = currentReportTitle.toLowerCase().replace(" ", "_") + "_" + new SimpleDateFormat("yyyyMMdd").format(new Date()) + ".pdf";
        fileChooser.setSelectedFile(new File(safeName));
        fileChooser.setFileFilter(new FileNameExtensionFilter("PDF Documents (*.pdf)", "pdf"));

        if (fileChooser.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
            File file = fileChooser.getSelectedFile();
            if (!file.getName().toLowerCase().endsWith(".pdf")) {
                file = new File(file.getParentFile(), file.getName() + ".pdf");
            }

            try {
                PdfDocumentGenerator.exportReportToPdf(currentReportTitle, currentDateRangeLabel, currentHeaders, currentRows, currentSummaryText, file);
                auditService.log("REPORT", "REPORT_EXPORTED", "Exported PDF for report: " + currentReportTitle, "SUCCESS");
                CustomDialogs.showSuccess(this, "PDF Report exported successfully:\n" + file.getAbsolutePath(), "Export Successful");
            } catch (Exception ex) {
                CustomDialogs.showError(this, "Unable to export PDF: " + ex.getMessage(), "Export Error");
            }
        }
    }

    private void onExportCsv() {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Export Report to CSV");
        String safeName = currentReportTitle.toLowerCase().replace(" ", "_") + "_" + new SimpleDateFormat("yyyyMMdd").format(new Date()) + ".csv";
        fileChooser.setSelectedFile(new File(safeName));
        fileChooser.setFileFilter(new FileNameExtensionFilter("CSV Spreadsheets (*.csv)", "csv"));

        if (fileChooser.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
            File file = fileChooser.getSelectedFile();
            if (!file.getName().toLowerCase().endsWith(".csv")) {
                file = new File(file.getParentFile(), file.getName() + ".csv");
            }

            try {
                CsvExporter.exportDataToCsv(currentHeaders, currentRows, file);
                auditService.log("REPORT", "REPORT_EXPORTED", "Exported CSV for report: " + currentReportTitle, "SUCCESS");
                CustomDialogs.showSuccess(this, "CSV Report exported successfully:\n" + file.getAbsolutePath(), "Export Successful");
            } catch (Exception ex) {
                CustomDialogs.showError(this, "Unable to export CSV: " + ex.getMessage(), "Export Error");
            }
        }
    }

    private void onSaveTxt() {
        try {
            ReportGenerator generator = new ReportGenerator(currentReportTitle, currentDateRangeLabel, currentHeaders, currentRows);
            File saved = generator.saveReportFile();
            auditService.log("REPORT", "REPORT_SAVED", "Saved text report: " + currentReportTitle, "SUCCESS");
            CustomDialogs.showSuccess(this, "Text report saved successfully in:\n" + saved.getAbsolutePath(), "Report Saved");
        } catch (Exception ex) {
            CustomDialogs.showError(this, "Unable to save text report: " + ex.getMessage(), "File Save Error");
        }
    }

    // Quick Date Helpers
    private void setQuickFilterToday() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String today = sdf.format(new Date());
        txtFromDate.setText(today);
        txtToDate.setText(today);
    }

    private void setQuickFilterThisWeek() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.DAY_OF_WEEK, cal.getFirstDayOfWeek());
        txtFromDate.setText(sdf.format(cal.getTime()));
        txtToDate.setText(sdf.format(new Date()));
    }

    private void setQuickFilterThisMonth() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.DAY_OF_MONTH, 1);
        txtFromDate.setText(sdf.format(cal.getTime()));
        txtToDate.setText(sdf.format(new Date()));
    }

    private void setQuickFilterThisYear() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.DAY_OF_YEAR, 1);
        txtFromDate.setText(sdf.format(cal.getTime()));
        txtToDate.setText(sdf.format(new Date()));
    }

    private JButton createQuickDateBtn(String label, Runnable action) {
        JButton btn = new JButton(label);
        btn.setFont(UITheme.FONT_SMALL);
        btn.setBackground(UITheme.CARD_BG_ALT);
        btn.setForeground(UITheme.TEXT_SECONDARY);
        btn.setFocusPainted(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setBorder(new CompoundBorder(
            new LineBorder(UITheme.BORDER, 1, true),
            new EmptyBorder(4, 8, 4, 8)
        ));
        btn.addActionListener(e -> {
            action.run();
            generateReportAsync();
        });
        return btn;
    }

    private JPanel createKpiCard(String title, JLabel valueLabel, Color accentColor) {
        JPanel card = new JPanel(new BorderLayout(4, 4));
        card.setBackground(UITheme.CARD_BG);
        card.setBorder(new CompoundBorder(
            new MatteBorder(0, 4, 0, 0, accentColor),
            new CompoundBorder(
                new LineBorder(UITheme.BORDER, 1, true),
                new EmptyBorder(10, 12, 10, 12)
            )
        ));

        JLabel lblCardTitle = new JLabel(title);
        lblCardTitle.setFont(UITheme.FONT_SMALL_BOLD);
        lblCardTitle.setForeground(UITheme.TEXT_SECONDARY);
        card.add(lblCardTitle, BorderLayout.NORTH);

        valueLabel.setFont(UITheme.FONT_TITLE_LARGE);
        valueLabel.setForeground(UITheme.TEXT_PRIMARY);
        card.add(valueLabel, BorderLayout.CENTER);

        return card;
    }
}
