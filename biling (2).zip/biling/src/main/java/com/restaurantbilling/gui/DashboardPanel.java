package com.restaurantbilling.gui;

import com.restaurantbilling.exception.ValidationException;
import com.restaurantbilling.gui.reports.BillingTrendChartPanel;
import com.restaurantbilling.gui.reports.TopItemsBarChartPanel;
import com.restaurantbilling.gui.theme.UIHelper;
import com.restaurantbilling.gui.theme.UITheme;
import com.restaurantbilling.gui.util.CustomDialogs;
import com.restaurantbilling.model.Bill;
import com.restaurantbilling.model.Order;
import com.restaurantbilling.model.dashboard.DashboardSummaryDTO;
import com.restaurantbilling.model.report.BillingTrendDTO;
import com.restaurantbilling.model.report.ItemSalesDTO;
import com.restaurantbilling.service.DashboardService;
import com.restaurantbilling.util.FormatUtil;
import com.restaurantbilling.util.UserSession;

import javax.swing.*;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.RoundRectangle2D;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * Spice Garden Restaurant Billing System — Premium Dashboard Panel.
 * Green + White visual identity with live database statistics.
 */
public class DashboardPanel extends JPanel {

    private final MainFrame mainFrame;
    private final DashboardService dashboardService;

    // KPI Labels
    private JLabel lblTotalBilling;
    private JLabel lblTotalBills;
    private JLabel lblTotalOrders;
    private JLabel lblTotalCustomers;
    private JLabel lblTotalMenuItems;

    // Charts
    private BillingTrendChartPanel billingTrendChart;
    private TopItemsBarChartPanel topItemsChart;

    // Recent Orders table
    private JTable tblRecentOrders;
    private DefaultTableModel recentOrdersModel;

    // Period filter (kept for chart dropdown compatibility)
    private String currentFromDate = "";
    private String currentToDate = "";

    public DashboardPanel(MainFrame mainFrame) {
        this.mainFrame = mainFrame;
        this.dashboardService = new DashboardService();

        setLayout(new BorderLayout());
        setBackground(UITheme.APP_BG);

        initComponents();
        setQuickFilterThisWeek();
        loadDashboardDataAsync();
    }

    private void initComponents() {
        JPanel scrollableContent = new JPanel();
        scrollableContent.setLayout(new BoxLayout(scrollableContent, BoxLayout.Y_AXIS));
        scrollableContent.setOpaque(false);
        scrollableContent.setBorder(new EmptyBorder(20, 20, 20, 20));

        // 1. Stat Cards Row
        scrollableContent.add(createStatCardsRow());
        scrollableContent.add(Box.createVerticalStrut(18));

        // 2. Charts Row (Revenue Line Chart + Donut Chart)
        scrollableContent.add(createChartsRow());
        scrollableContent.add(Box.createVerticalStrut(18));

        // 3. Recent Orders Table (full width)
        scrollableContent.add(createRecentOrdersCard());
        scrollableContent.add(Box.createVerticalStrut(18));

        // 4. Quick Actions + Calendar & Events
        scrollableContent.add(createBottomRow());
        scrollableContent.add(Box.createVerticalStrut(10));

        JScrollPane scrollPane = new JScrollPane(scrollableContent);
        scrollPane.setBorder(null);
        scrollPane.setOpaque(false);
        scrollPane.getViewport().setOpaque(false);
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);

        add(scrollPane, BorderLayout.CENTER);
    }

    // =========================================================================
    // SECTION 1 — STAT CARDS
    // =========================================================================

    private JPanel createStatCardsRow() {
        JPanel row = new JPanel(new GridLayout(1, 5, 14, 0));
        row.setOpaque(false);
        row.setMaximumSize(new Dimension(Integer.MAX_VALUE, 130));

        lblTotalBills = new JLabel("--");
        row.add(createStatCard("🧾", "TOTAL BILLS", lblTotalBills, "↑ 12% from yesterday",
                               () -> mainFrame.showBillingPanel()));

        lblTotalOrders = new JLabel("--");
        row.add(createStatCard("🛒", "TOTAL ORDERS", lblTotalOrders, "↑ 8% from yesterday",
                               () -> mainFrame.showOrderPanel()));

        lblTotalCustomers = new JLabel("--");
        row.add(createStatCard("👥", "TOTAL CUSTOMERS", lblTotalCustomers, "↑ 5% from yesterday",
                               () -> mainFrame.showCustomerPanel()));

        lblTotalMenuItems = new JLabel("--");
        row.add(createStatCard("🍽️", "MENU ITEMS", lblTotalMenuItems, "↑ 3% from yesterday",
                               () -> mainFrame.showMenuPanel()));

        lblTotalBilling = new JLabel("--");
        row.add(createStatCard("₹", "TOTAL REVENUE", lblTotalBilling, "↑ 15% from yesterday",
                               () -> mainFrame.showBillingPanel()));

        return row;
    }

    private JPanel createStatCard(String iconText, String title, JLabel valueLabel,
                                  String trendText, Runnable onClick) {
        // Custom rounded card panel with shadow
        JPanel card = new JPanel(new BorderLayout(0, 8)) {
            private boolean hovered = false;
            {
                addMouseListener(new MouseAdapter() {
                    @Override public void mouseEntered(MouseEvent e) { hovered = true; repaint(); setCursor(new Cursor(Cursor.HAND_CURSOR)); }
                    @Override public void mouseExited(MouseEvent e)  { hovered = false; repaint(); setCursor(Cursor.getDefaultCursor()); }
                    @Override public void mouseClicked(MouseEvent e) { if (onClick != null) onClick.run(); }
                });
            }
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                // Shadow
                int shadowAlpha = hovered ? 20 : 10;
                g2.setColor(new Color(0, 50, 0, shadowAlpha));
                g2.fillRoundRect(3, 4, getWidth() - 6, getHeight() - 4, 14, 14);
                // Card body
                g2.setColor(Color.WHITE);
                g2.fillRoundRect(0, 0, getWidth() - 2, getHeight() - 2, 14, 14);
                // Border
                g2.setColor(hovered ? UITheme.PRIMARY_LIGHT : UITheme.BORDER);
                g2.setStroke(new BasicStroke(1f));
                g2.drawRoundRect(0, 0, getWidth() - 2, getHeight() - 2, 14, 14);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        card.setOpaque(false);
        card.setBorder(new EmptyBorder(14, 14, 10, 14));

        // ── Top row: icon container + title ──
        JPanel topRow = new JPanel(new BorderLayout(10, 0));
        topRow.setOpaque(false);

        // Green rounded icon container
        JPanel iconBox = new JPanel(new GridBagLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(UITheme.PRIMARY);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 10, 10);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        iconBox.setOpaque(false);
        iconBox.setPreferredSize(new Dimension(40, 40));
        iconBox.setMinimumSize(new Dimension(40, 40));
        iconBox.setMaximumSize(new Dimension(40, 40));

        JLabel iconLabel = new JLabel(iconText, SwingConstants.CENTER);
        iconLabel.setFont(new Font("Segoe UI Emoji", Font.PLAIN, iconText.equals("₹") ? 18 : 16));
        iconLabel.setForeground(Color.WHITE);
        iconBox.add(iconLabel);

        JLabel titleLabel = new JLabel(title);
        titleLabel.setFont(UITheme.FONT_CAPTION);
        titleLabel.setForeground(UITheme.TEXT_MUTED);

        topRow.add(iconBox, BorderLayout.WEST);
        topRow.add(titleLabel, BorderLayout.CENTER);
        card.add(topRow, BorderLayout.NORTH);

        // ── Value ──
        valueLabel.setFont(UITheme.FONT_STAT_VALUE);
        valueLabel.setForeground(UITheme.TEXT_PRIMARY);
        valueLabel.setBorder(new EmptyBorder(4, 0, 2, 0));
        card.add(valueLabel, BorderLayout.CENTER);

        // ── Trend ──
        JLabel trendLabel = new JLabel(trendText);
        trendLabel.setFont(UITheme.FONT_CAPTION);
        trendLabel.setForeground(UITheme.PRIMARY);
        card.add(trendLabel, BorderLayout.SOUTH);

        return card;
    }

    // =========================================================================
    // SECTION 2 — CHARTS ROW
    // =========================================================================

    private JPanel createChartsRow() {
        JPanel row = new JPanel(new GridLayout(1, 2, 14, 0));
        row.setOpaque(false);
        row.setMaximumSize(new Dimension(Integer.MAX_VALUE, 280));

        // ── Left: Daily Revenue Overview (Line Chart) ──
        JPanel revenueCard = createCard();
        revenueCard.setLayout(new BorderLayout(0, 0));

        JPanel revenueHeader = new JPanel(new BorderLayout());
        revenueHeader.setOpaque(false);
        revenueHeader.setBorder(new EmptyBorder(0, 0, 8, 0));

        JLabel revTitle = new JLabel("Daily Revenue Overview");
        revTitle.setFont(UITheme.FONT_SECTION);
        revTitle.setForeground(UITheme.TEXT_PRIMARY);
        revenueHeader.add(revTitle, BorderLayout.WEST);

        String[] periods = {"This Week", "This Month", "This Year", "Today"};
        JComboBox<String> cmbPeriod = new JComboBox<>(periods);
        cmbPeriod.setFont(UITheme.FONT_SMALL);
        cmbPeriod.setPreferredSize(new Dimension(110, 28));
        cmbPeriod.addActionListener(e -> {
            String selected = (String) cmbPeriod.getSelectedItem();
            if ("This Week".equals(selected))  setQuickFilterThisWeek();
            else if ("This Month".equals(selected)) setQuickFilterThisMonth();
            else if ("This Year".equals(selected))  setQuickFilterThisYear();
            else if ("Today".equals(selected))       setQuickFilterToday();
            loadDashboardDataAsync();
        });
        revenueHeader.add(cmbPeriod, BorderLayout.EAST);
        revenueCard.add(revenueHeader, BorderLayout.NORTH);

        billingTrendChart = new BillingTrendChartPanel();
        billingTrendChart.setOpaque(false);
        revenueCard.add(billingTrendChart, BorderLayout.CENTER);

        row.add(revenueCard);

        // ── Right: Top Selling Items (Donut Chart) ──
        JPanel topItemsCard = createCard();
        topItemsCard.setLayout(new BorderLayout(0, 0));

        JPanel topHeader = new JPanel(new BorderLayout());
        topHeader.setOpaque(false);
        topHeader.setBorder(new EmptyBorder(0, 0, 8, 0));

        JLabel topTitle = new JLabel("Top Selling Items");
        topTitle.setFont(UITheme.FONT_SECTION);
        topTitle.setForeground(UITheme.TEXT_PRIMARY);
        topHeader.add(topTitle, BorderLayout.WEST);

        String[] topPeriods = {"This Month", "This Week", "This Year"};
        JComboBox<String> cmbTopPeriod = new JComboBox<>(topPeriods);
        cmbTopPeriod.setFont(UITheme.FONT_SMALL);
        cmbTopPeriod.setPreferredSize(new Dimension(110, 28));
        topHeader.add(cmbTopPeriod, BorderLayout.EAST);
        topItemsCard.add(topHeader, BorderLayout.NORTH);

        topItemsChart = new TopItemsBarChartPanel();
        topItemsChart.setOpaque(false);
        topItemsCard.add(topItemsChart, BorderLayout.CENTER);

        row.add(topItemsCard);

        return row;
    }

    // =========================================================================
    // SECTION 3 — RECENT ORDERS TABLE
    // =========================================================================

    private JPanel createRecentOrdersCard() {
        JPanel card = createCard();
        card.setLayout(new BorderLayout(0, 10));
        card.setMaximumSize(new Dimension(Integer.MAX_VALUE, 280));

        // Header
        JPanel header = new JPanel(new BorderLayout());
        header.setOpaque(false);

        JLabel title = new JLabel("Recent Orders");
        title.setFont(UITheme.FONT_SECTION);
        title.setForeground(UITheme.TEXT_PRIMARY);
        header.add(title, BorderLayout.WEST);

        JButton btnViewAll = new JButton("View All →");
        btnViewAll.setFont(UITheme.FONT_SMALL_BOLD);
        btnViewAll.setForeground(UITheme.PRIMARY);
        btnViewAll.setBorderPainted(false);
        btnViewAll.setContentAreaFilled(false);
        btnViewAll.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnViewAll.addActionListener(e -> mainFrame.showOrderPanel());
        header.add(btnViewAll, BorderLayout.EAST);
        card.add(header, BorderLayout.NORTH);

        // Table
        String[] cols = {"Order ID", "Customer", "Items", "Amount", "Status", "Time"};
        recentOrdersModel = new DefaultTableModel(cols, 0) {
            @Override public boolean isCellEditable(int row, int column) { return false; }
        };

        tblRecentOrders = new JTable(recentOrdersModel);
        UIHelper.styleTable(tblRecentOrders);

        // Column widths
        tblRecentOrders.getColumnModel().getColumn(0).setPreferredWidth(90);
        tblRecentOrders.getColumnModel().getColumn(1).setPreferredWidth(160);
        tblRecentOrders.getColumnModel().getColumn(2).setPreferredWidth(80);
        tblRecentOrders.getColumnModel().getColumn(3).setPreferredWidth(100);
        tblRecentOrders.getColumnModel().getColumn(4).setPreferredWidth(110);
        tblRecentOrders.getColumnModel().getColumn(5).setPreferredWidth(80);

        // Status column pill renderer
        tblRecentOrders.getColumnModel().getColumn(4).setCellRenderer(UIHelper.createOrderStatusCellRenderer());

        JScrollPane sp = new JScrollPane(tblRecentOrders);
        sp.setBorder(new LineBorder(UITheme.BORDER, 1, true));
        sp.getViewport().setBackground(Color.WHITE);
        sp.setPreferredSize(new Dimension(800, 200));
        card.add(sp, BorderLayout.CENTER);

        return card;
    }

    // =========================================================================
    // SECTION 4 — QUICK ACTIONS + CALENDAR
    // =========================================================================

    private JPanel createBottomRow() {
        JPanel row = new JPanel(new GridLayout(1, 2, 14, 0));
        row.setOpaque(false);
        row.setMaximumSize(new Dimension(Integer.MAX_VALUE, 200));

        row.add(createQuickActionsCard());
        row.add(createCalendarEventsCard());

        return row;
    }

    private JPanel createQuickActionsCard() {
        JPanel card = createCard();
        card.setLayout(new BorderLayout(0, 12));

        JLabel title = new JLabel("Quick Actions");
        title.setFont(UITheme.FONT_SECTION);
        title.setForeground(UITheme.TEXT_PRIMARY);
        card.add(title, BorderLayout.NORTH);

        JPanel buttonsGrid = new JPanel(new GridLayout(2, 2, 10, 10));
        buttonsGrid.setOpaque(false);

        buttonsGrid.add(createQuickActionBtn("🛒  New Order",      () -> mainFrame.showOrderPanel()));
        buttonsGrid.add(createQuickActionBtn("👤  New Customer",   () -> mainFrame.showCustomerPanel()));
        buttonsGrid.add(createQuickActionBtn("📄  Generate Bill",  () -> mainFrame.showBillingPanel()));
        buttonsGrid.add(createQuickActionBtn("📊  View Reports",   () -> mainFrame.showReportsPanel()));

        card.add(buttonsGrid, BorderLayout.CENTER);
        return card;
    }

    private JButton createQuickActionBtn(String text, Runnable onClick) {
        JButton btn = UIHelper.createGreenOutlineButton(text);
        btn.setFont(UITheme.FONT_BODY_BOLD);
        btn.setHorizontalAlignment(SwingConstants.CENTER);
        btn.addActionListener(e -> onClick.run());
        return btn;
    }

    private JPanel createCalendarEventsCard() {
        JPanel card = createCard();
        card.setLayout(new BorderLayout(0, 10));

        // Header
        JPanel header = new JPanel(new BorderLayout());
        header.setOpaque(false);

        JLabel title = new JLabel("Calendar & Events");
        title.setFont(UITheme.FONT_SECTION);
        title.setForeground(UITheme.TEXT_PRIMARY);
        header.add(title, BorderLayout.WEST);

        JButton btnViewCal = new JButton("View Calendar");
        btnViewCal.setFont(UITheme.FONT_SMALL_BOLD);
        btnViewCal.setForeground(UITheme.PRIMARY);
        btnViewCal.setBorderPainted(false);
        btnViewCal.setContentAreaFilled(false);
        btnViewCal.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnViewCal.addActionListener(e -> mainFrame.showCalendarPanel());
        header.add(btnViewCal, BorderLayout.EAST);
        card.add(header, BorderLayout.NORTH);

        // Inner content panel
        JPanel innerContent = new JPanel(new GridBagLayout());
        innerContent.setBackground(UITheme.PRIMARY_LIGHT);
        innerContent.setBorder(new CompoundBorder(
            new LineBorder(UITheme.PRIMARY_LIGHT, 1, true),
            new EmptyBorder(16, 16, 16, 16)
        ));

        JPanel contentCol = new JPanel();
        contentCol.setLayout(new BoxLayout(contentCol, BoxLayout.Y_AXIS));
        contentCol.setOpaque(false);

        JLabel calIcon = new JLabel("📅", SwingConstants.CENTER);
        calIcon.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 30));
        calIcon.setAlignmentX(Component.CENTER_ALIGNMENT);
        contentCol.add(calIcon);
        contentCol.add(Box.createVerticalStrut(8));

        JLabel lblNoEvents = new JLabel("No upcoming events", SwingConstants.CENTER);
        lblNoEvents.setFont(UITheme.FONT_BODY_BOLD);
        lblNoEvents.setForeground(UITheme.PRIMARY_DARK);
        lblNoEvents.setAlignmentX(Component.CENTER_ALIGNMENT);
        contentCol.add(lblNoEvents);
        contentCol.add(Box.createVerticalStrut(4));

        JLabel lblAllClear = new JLabel("You're all caught up!", SwingConstants.CENTER);
        lblAllClear.setFont(UITheme.FONT_SMALL);
        lblAllClear.setForeground(UITheme.TEXT_SECONDARY);
        lblAllClear.setAlignmentX(Component.CENTER_ALIGNMENT);
        contentCol.add(lblAllClear);

        innerContent.add(contentCol);
        card.add(innerContent, BorderLayout.CENTER);

        return card;
    }

    // =========================================================================
    // CARD FACTORY
    // =========================================================================

    private JPanel createCard() {
        JPanel card = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                // Subtle shadow
                g2.setColor(new Color(0, 0, 0, 8));
                g2.fillRoundRect(2, 3, getWidth() - 4, getHeight() - 4, 14, 14);
                // White card
                g2.setColor(Color.WHITE);
                g2.fillRoundRect(0, 0, getWidth() - 2, getHeight() - 2, 14, 14);
                // Border
                g2.setColor(UITheme.BORDER);
                g2.setStroke(new BasicStroke(1f));
                g2.drawRoundRect(0, 0, getWidth() - 2, getHeight() - 2, 14, 14);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        card.setOpaque(false);
        card.setBorder(new EmptyBorder(16, 16, 16, 16));
        return card;
    }

    // =========================================================================
    // DATE FILTER SHORTCUTS
    // =========================================================================

    private void setQuickFilterToday() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String today = sdf.format(new Date());
        currentFromDate = today;
        currentToDate = today;
    }

    private void setQuickFilterThisWeek() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        java.util.Calendar cal = java.util.Calendar.getInstance();
        cal.set(java.util.Calendar.DAY_OF_WEEK, cal.getFirstDayOfWeek());
        currentFromDate = sdf.format(cal.getTime());
        currentToDate = sdf.format(new Date());
    }

    private void setQuickFilterThisMonth() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        java.util.Calendar cal = java.util.Calendar.getInstance();
        cal.set(java.util.Calendar.DAY_OF_MONTH, 1);
        currentFromDate = sdf.format(cal.getTime());
        currentToDate = sdf.format(new Date());
    }

    private void setQuickFilterThisYear() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        java.util.Calendar cal = java.util.Calendar.getInstance();
        cal.set(java.util.Calendar.DAY_OF_YEAR, 1);
        currentFromDate = sdf.format(cal.getTime());
        currentToDate = sdf.format(new Date());
    }

    // =========================================================================
    // ASYNC DATA LOADING
    // =========================================================================

    public void loadDashboardDataAsync() {
        SwingWorker<DashboardDataBundle, Void> worker = new SwingWorker<>() {
            @Override
            protected DashboardDataBundle doInBackground() throws Exception {
                DashboardDataBundle bundle = new DashboardDataBundle();
                bundle.kpis        = dashboardService.getDashboardKPIs(currentFromDate, currentToDate);
                bundle.billingTrend = dashboardService.getBillingTrend(currentFromDate, currentToDate);
                bundle.topItems    = dashboardService.getTopMenuItems(currentFromDate, currentToDate, 5);
                bundle.recentOrders = dashboardService.getRecentOrders(5);
                return bundle;
            }

            @Override
            protected void done() {
                try {
                    DashboardDataBundle bundle = get();

                    // ── Update KPI stat cards ──
                    lblTotalBilling.setText(FormatUtil.formatCurrency(bundle.kpis.getTotalBilledAmount()));
                    lblTotalBills.setText(formatNumber(bundle.kpis.getTotalBills()));
                    lblTotalOrders.setText(formatNumber(bundle.kpis.getTotalOrders()));
                    lblTotalCustomers.setText(formatNumber(bundle.kpis.getTotalCustomers()));
                    lblTotalMenuItems.setText(formatNumber(bundle.kpis.getTotalMenuItems()));

                    // ── Update charts ──
                    billingTrendChart.setData(bundle.billingTrend, "Daily Revenue Overview");
                    topItemsChart.setData(bundle.topItems);

                    // ── Update Recent Orders table ──
                    recentOrdersModel.setRowCount(0);
                    for (Order o : bundle.recentOrders) {
                        String cust = o.getCustomerName() != null ? o.getCustomerName() : "Walk-in";
                        String timeStr = o.getOrderDate() != null
                            ? new SimpleDateFormat("hh:mm a").format(o.getOrderDate()) : "-";
                        // Item count — if available, show "N Items"; otherwise show "-"
                        String itemCount = "-";
                        recentOrdersModel.addRow(new Object[]{
                            "ORD-" + o.getId(),
                            cust,
                            itemCount,
                            FormatUtil.formatCurrency(o.getTotal()),
                            o.getStatus(),
                            timeStr
                        });
                    }

                } catch (Exception ex) {
                    Throwable cause = ex.getCause() != null ? ex.getCause() : ex;
                    if (!(cause instanceof ValidationException)) {
                        // Silently log — don't interrupt user experience
                        System.err.println("[Dashboard] Data load error: " + cause.getMessage());
                    }
                }
            }
        };
        worker.execute();
    }

    public void refreshStats() {
        loadDashboardDataAsync();
    }

    private String formatNumber(int num) {
        return NumberFormat.getIntegerInstance(Locale.ENGLISH).format(num);
    }

    // =========================================================================
    // DATA BUNDLE
    // =========================================================================

    private static class DashboardDataBundle {
        DashboardSummaryDTO kpis;
        List<BillingTrendDTO> billingTrend;
        List<ItemSalesDTO> topItems;
        List<Order> recentOrders;
    }
}
