package com.restaurantbilling.gui.order;

import com.restaurantbilling.gui.theme.UIHelper;
import com.restaurantbilling.gui.theme.UITheme;
import com.restaurantbilling.model.Order;
import com.restaurantbilling.model.OrderItem;
import com.restaurantbilling.util.FormatUtil;

import javax.swing.*;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.text.SimpleDateFormat;

public class OrderDetailsDialog extends JDialog {

    public OrderDetailsDialog(Window owner, Order order) {
        super(owner, "Order Details — #" + order.getId(), ModalityType.APPLICATION_MODAL);
        initComponents(order);
        setSize(560, 620);
        setLocationRelativeTo(owner);
        setResizable(false);
    }

    private void initComponents(Order order) {
        JPanel contentPane = new JPanel(new BorderLayout(15, 15));
        contentPane.setBackground(UITheme.CARD_BG);
        contentPane.setBorder(new EmptyBorder(22, 26, 20, 26));
        setContentPane(contentPane);

        // Header with Order ID & Status Badge
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setOpaque(false);

        JLabel lblTitle = new JLabel("Order #" + order.getId());
        lblTitle.setFont(UITheme.FONT_TITLE_LARGE);
        lblTitle.setForeground(UITheme.TEXT_PRIMARY);

        JLabel lblStatus = UIHelper.createStatusBadge(
            order.getStatus(),
            getStatusBg(order.getStatus()),
            getStatusFg(order.getStatus())
        );

        headerPanel.add(lblTitle, BorderLayout.WEST);
        headerPanel.add(lblStatus, BorderLayout.EAST);
        contentPane.add(headerPanel, BorderLayout.NORTH);

        // Center Details Panel
        JPanel centerPanel = new JPanel(new BorderLayout(10, 12));
        centerPanel.setOpaque(false);

        // Customer & Meta Info Card
        JPanel metaPanel = new JPanel(new GridLayout(2, 2, 10, 8));
        metaPanel.setBackground(UITheme.CARD_BG_ALT);
        metaPanel.setBorder(new CompoundBorder(
            new LineBorder(UITheme.BORDER, 1, true),
            new EmptyBorder(12, 16, 12, 16)
        ));

        String cust = (order.getCustomerName() != null && !order.getCustomerName().isEmpty())
            ? order.getCustomerName() : "Walk-in Customer";
        String phone = (order.getCustomerPhone() != null) ? order.getCustomerPhone() : "-";
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String dateStr = (order.getOrderDate() != null) ? sdf.format(order.getOrderDate()) : "-";

        metaPanel.add(createMetaLabel("👤 Customer:", cust));
        metaPanel.add(createMetaLabel("📞 Phone:", phone));
        metaPanel.add(createMetaLabel("📅 Placed Date:", dateStr));
        metaPanel.add(createMetaLabel("🍽️ Item Count:", (order.getItems() != null ? order.getItems().size() : 0) + " items"));

        centerPanel.add(metaPanel, BorderLayout.NORTH);

        // Order Items Table
        String[] columns = {"Food Item Name", "Unit Price", "Qty", "Line Total"};
        DefaultTableModel tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int col) {
                return false;
            }
        };

        if (order.getItems() != null) {
            for (OrderItem item : order.getItems()) {
                tableModel.addRow(new Object[]{
                    (item.getFoodItemName() != null) ? item.getFoodItemName() : "Item #" + item.getFoodItemId(),
                    FormatUtil.formatCurrency(item.getUnitPrice()),
                    item.getQuantity(),
                    FormatUtil.formatCurrency(item.getSubtotal())
                });
            }
        }

        JTable table = new JTable(tableModel);
        UIHelper.styleTable(table);

        DefaultTableCellRenderer rightRenderer = new DefaultTableCellRenderer();
        rightRenderer.setHorizontalAlignment(SwingConstants.RIGHT);
        table.getColumnModel().getColumn(0).setPreferredWidth(200);
        table.getColumnModel().getColumn(1).setPreferredWidth(90);
        table.getColumnModel().getColumn(1).setCellRenderer(rightRenderer);
        table.getColumnModel().getColumn(2).setPreferredWidth(60);
        table.getColumnModel().getColumn(2).setCellRenderer(rightRenderer);
        table.getColumnModel().getColumn(3).setPreferredWidth(100);
        table.getColumnModel().getColumn(3).setCellRenderer(rightRenderer);

        JScrollPane scrollTable = new JScrollPane(table);
        UIHelper.styleScrollPane(scrollTable);
        scrollTable.setPreferredSize(new Dimension(480, 180));
        centerPanel.add(scrollTable, BorderLayout.CENTER);

        // Totals Summary Card
        JPanel totalsPanel = new JPanel(new GridLayout(4, 2, 10, 4));
        totalsPanel.setBackground(UITheme.CARD_BG_ALT);
        totalsPanel.setBorder(new CompoundBorder(
            new LineBorder(UITheme.BORDER, 1, true),
            new EmptyBorder(10, 16, 10, 16)
        ));

        totalsPanel.add(new JLabel("Subtotal:"));
        JLabel lblSub = new JLabel(FormatUtil.formatCurrency(order.getSubtotal()), SwingConstants.RIGHT);
        lblSub.setFont(UITheme.FONT_BODY_BOLD);
        totalsPanel.add(lblSub);

        totalsPanel.add(new JLabel("Discount:"));
        JLabel lblDisc = new JLabel(FormatUtil.formatCurrency(order.getDiscount()), SwingConstants.RIGHT);
        lblDisc.setFont(UITheme.FONT_BODY_BOLD);
        totalsPanel.add(lblDisc);

        totalsPanel.add(new JLabel("Tax (GST):"));
        JLabel lblTax = new JLabel(FormatUtil.formatCurrency(order.getTax()), SwingConstants.RIGHT);
        lblTax.setFont(UITheme.FONT_BODY_BOLD);
        totalsPanel.add(lblTax);

        JLabel lblGrandText = new JLabel("GRAND TOTAL:");
        lblGrandText.setFont(UITheme.FONT_SECTION);
        lblGrandText.setForeground(UITheme.TEXT_PRIMARY);
        totalsPanel.add(lblGrandText);

        JLabel lblGrand = new JLabel(FormatUtil.formatCurrency(order.getTotal()), SwingConstants.RIGHT);
        lblGrand.setFont(UITheme.FONT_TITLE_LARGE);
        lblGrand.setForeground(UITheme.PRIMARY);
        totalsPanel.add(lblGrand);

        centerPanel.add(totalsPanel, BorderLayout.SOUTH);
        contentPane.add(centerPanel, BorderLayout.CENTER);

        // Close Button
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 0));
        bottomPanel.setOpaque(false);
        JButton btnClose = UIHelper.createSecondaryButton("Close");
        btnClose.setPreferredSize(new Dimension(90, 34));
        btnClose.addActionListener(e -> dispose());
        bottomPanel.add(btnClose);
        contentPane.add(bottomPanel, BorderLayout.SOUTH);
    }

    private JLabel createMetaLabel(String prefix, String val) {
        JLabel l = new JLabel(prefix + " " + val);
        l.setFont(UITheme.FONT_BODY);
        l.setForeground(UITheme.TEXT_PRIMARY);
        return l;
    }

    private Color getStatusBg(String status) {
        if (status == null) return UITheme.CARD_BG_ALT;
        return switch (status.toUpperCase()) {
            case "COMPLETED" -> UITheme.SUCCESS_BG;
            case "CONFIRMED", "PREPARING", "READY" -> UITheme.PRIMARY_LIGHT;
            case "CANCELLED" -> UITheme.DANGER_BG;
            default -> UITheme.WARNING_BG;
        };
    }

    private Color getStatusFg(String status) {
        if (status == null) return UITheme.TEXT_SECONDARY;
        return switch (status.toUpperCase()) {
            case "COMPLETED" -> UITheme.SUCCESS_DARK;
            case "CONFIRMED", "PREPARING", "READY" -> UITheme.PRIMARY;
            case "CANCELLED" -> UITheme.DANGER_DARK;
            default -> UITheme.WARNING_DARK;
        };
    }
}
