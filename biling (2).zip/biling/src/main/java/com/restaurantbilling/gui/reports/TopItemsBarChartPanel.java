package com.restaurantbilling.gui.reports;

import com.restaurantbilling.gui.theme.UITheme;
import com.restaurantbilling.model.report.ItemSalesDTO;

import javax.swing.*;
import java.awt.*;
import java.awt.geom.Arc2D;
import java.awt.geom.Ellipse2D;
import java.util.ArrayList;
import java.util.List;

/**
 * Top Selling Items — Donut Chart.
 * Green shades palette for Spice Garden branding.
 */
public class TopItemsBarChartPanel extends JPanel {

    private List<ItemSalesDTO> items = new ArrayList<>();

    // 5 green shades for the donut slices
    private static final Color[] DONUT_COLORS = {
        UITheme.GREEN_1,  // #238B2A — darkest
        UITheme.GREEN_2,  // #2EA836
        UITheme.GREEN_3,  // #45C45D
        UITheme.GREEN_4,  // #6DD97A
        UITheme.GREEN_5   // #A5EBB0 — lightest
    };

    public TopItemsBarChartPanel() {
        setBackground(UITheme.CARD_BG);
        setPreferredSize(new Dimension(480, 260));
        setMinimumSize(new Dimension(300, 200));
    }

    public void setData(List<ItemSalesDTO> items) {
        this.items = (items != null) ? items : new ArrayList<>();
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        g2.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);

        int w = getWidth();
        int h = getHeight();

        // ── Title ──
        g2.setFont(UITheme.FONT_SECTION);
        g2.setColor(UITheme.TEXT_PRIMARY);
        g2.drawString("Top Selling Items", 16, 26);

        if (items == null || items.isEmpty()) {
            g2.setFont(UITheme.FONT_BODY);
            g2.setColor(UITheme.TEXT_MUTED);
            String msg = "No item sales data for the selected period";
            FontMetrics fm = g2.getFontMetrics();
            g2.drawString(msg, (w - fm.stringWidth(msg)) / 2, h / 2);
            g2.dispose();
            return;
        }

        int maxDisplay = Math.min(5, items.size());

        // ── Compute total quantity ──
        int total = 0;
        for (int i = 0; i < maxDisplay; i++) {
            total += items.get(i).getQuantitySold();
        }
        if (total == 0) total = 1;

        // ── Donut geometry ──
        int donutDiameter = Math.min(w / 2, h - 50);
        donutDiameter = Math.max(donutDiameter, 120);
        int donutX = 16;
        int donutY = (h - donutDiameter) / 2 + 10;
        int innerDiameter = (int) (donutDiameter * 0.55);
        int innerX = donutX + (donutDiameter - innerDiameter) / 2;
        int innerY = donutY + (donutDiameter - innerDiameter) / 2;

        // ── Draw donut slices ──
        float startAngle = 90f; // start from top
        for (int i = 0; i < maxDisplay; i++) {
            float sweepAngle = 360f * items.get(i).getQuantitySold() / total;

            // Outer arc
            g2.setColor(DONUT_COLORS[i % DONUT_COLORS.length]);
            Arc2D.Float arc = new Arc2D.Float(donutX, donutY, donutDiameter, donutDiameter,
                startAngle, sweepAngle, Arc2D.PIE);
            g2.fill(arc);

            // Small gap between slices
            g2.setColor(UITheme.CARD_BG);
            g2.setStroke(new BasicStroke(2f));
            g2.draw(arc);

            startAngle += sweepAngle;
        }

        // ── Punch out center hole (white) ──
        g2.setColor(UITheme.CARD_BG);
        g2.fillOval(innerX, innerY, innerDiameter, innerDiameter);

        // ── Center text: total ──
        g2.setFont(new Font(UITheme.FONT_FAMILY, Font.BOLD, 18));
        g2.setColor(UITheme.TEXT_PRIMARY);
        String totalStr = String.valueOf(total);
        FontMetrics bigFm = g2.getFontMetrics();
        int cx = donutX + donutDiameter / 2;
        int cy = donutY + donutDiameter / 2;
        g2.drawString(totalStr, cx - bigFm.stringWidth(totalStr) / 2, cy + 4);

        g2.setFont(new Font(UITheme.FONT_FAMILY, Font.PLAIN, 9));
        g2.setColor(UITheme.TEXT_MUTED);
        String soldStr = "sold";
        FontMetrics smFm = g2.getFontMetrics();
        g2.drawString(soldStr, cx - smFm.stringWidth(soldStr) / 2, cy + 16);

        // ── Legend (right side) ──
        int legendX = donutX + donutDiameter + 20;
        int legendY = donutY + 20;
        int legendRowH = (h - 70) / Math.max(maxDisplay, 1);
        legendRowH = Math.min(legendRowH, 38);
        legendRowH = Math.max(legendRowH, 26);

        for (int i = 0; i < maxDisplay; i++) {
            ItemSalesDTO item = items.get(i);
            int rowY = legendY + i * legendRowH;

            // Color swatch (rounded)
            g2.setColor(DONUT_COLORS[i % DONUT_COLORS.length]);
            g2.fillRoundRect(legendX, rowY + 2, 12, 12, 4, 4);

            // Item name
            g2.setFont(new Font(UITheme.FONT_FAMILY, Font.BOLD, 11));
            g2.setColor(UITheme.TEXT_PRIMARY);
            String name = item.getItemName();
            if (name != null && name.length() > 16) name = name.substring(0, 15) + "…";
            g2.drawString(name != null ? name : "", legendX + 18, rowY + 13);

            // Quantity & percentage
            g2.setFont(new Font(UITheme.FONT_FAMILY, Font.PLAIN, 10));
            g2.setColor(UITheme.TEXT_SECONDARY);
            int pct = (int) Math.round(100.0 * item.getQuantitySold() / total);
            String detail = item.getQuantitySold() + " sold  (" + pct + "%)";
            g2.drawString(detail, legendX + 18, rowY + 24);
        }

        g2.dispose();
    }
}
