package com.restaurantbilling.gui.theme;

import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import java.awt.*;

/**
 * Centralized Design Tokens & Color Palette for Spice Garden Restaurant Billing System.
 * Green + White visual identity — modern, premium, restaurant-oriented.
 */
public final class UITheme {

    private UITheme() {
        // Prevent instantiation
    }

    // =========================================================================
    // BRAND COLOR SYSTEM — Spice Garden Green
    // =========================================================================

    // Primary Green — Spice Garden Brand
    public static final Color PRIMARY         = new Color(0x23, 0x8B, 0x2A); // #238B2A — rich restaurant green
    public static final Color PRIMARY_DARK    = new Color(0x17, 0x6B, 0x20); // #176B20 — dark green
    public static final Color PRIMARY_LIGHT   = new Color(0xEA, 0xF6, 0xEA); // #EAF6EA — light green tint
    public static final Color PRIMARY_HOVER   = new Color(0x1E, 0x7A, 0x25); // #1E7A25 — hover green
    public static final Color PRIMARY_MEDIUM  = new Color(0x2E, 0xA8, 0x36); // #2EA836 — medium green

    // Green Accent Shades (for donut chart, badges, etc.)
    public static final Color GREEN_1 = new Color(0x23, 0x8B, 0x2A); // #238B2A
    public static final Color GREEN_2 = new Color(0x2E, 0xA8, 0x36); // #2EA836
    public static final Color GREEN_3 = new Color(0x45, 0xC4, 0x5D); // #45C45D
    public static final Color GREEN_4 = new Color(0x6D, 0xD9, 0x7A); // #6DD97A
    public static final Color GREEN_5 = new Color(0xA5, 0xEB, 0xB0); // #A5EBB0

    // Secondary (neutral)
    public static final Color SECONDARY       = new Color(100, 116, 139);     // Slate Secondary
    public static final Color SECONDARY_HOVER = new Color(71, 85, 105);       // Darker slate

    // Status Colors
    public static final Color SUCCESS         = new Color(0x23, 0x8B, 0x2A); // Green (aligns with brand)
    public static final Color SUCCESS_DARK    = new Color(0x17, 0x6B, 0x20); // Dark green
    public static final Color SUCCESS_BG      = new Color(0xEA, 0xF6, 0xEA); // Light green

    public static final Color WARNING         = new Color(245, 158, 11);      // Amber
    public static final Color WARNING_DARK    = new Color(217, 119, 6);       // Darker amber
    public static final Color WARNING_BG      = new Color(254, 252, 232);     // Light amber

    public static final Color DANGER          = new Color(239, 68, 68);       // Red
    public static final Color DANGER_DARK     = new Color(220, 38, 38);       // Darker red
    public static final Color DANGER_BG       = new Color(254, 242, 242);     // Light red

    public static final Color INFO            = new Color(6, 182, 212);       // Cyan
    public static final Color INFO_DARK       = new Color(8, 145, 178);       // Darker cyan
    public static final Color INFO_BG         = new Color(236, 254, 255);     // Light cyan

    // =========================================================================
    // SURFACES & BACKGROUNDS
    // =========================================================================

    public static final Color APP_BG          = new Color(0xF7, 0xF9, 0xF7); // #F7F9F7 — very light greenish-white
    public static final Color CARD_BG         = Color.WHITE;                  // #FFFFFF
    public static final Color CARD_BG_ALT     = new Color(0xF0, 0xF7, 0xF0); // #F0F7F0 — very light green tint

    // =========================================================================
    // SIDEBAR & HEADER
    // =========================================================================

    public static final Color HEADER_BG       = new Color(0x23, 0x8B, 0x2A); // #238B2A — green header
    public static final Color HEADER_WHITE_BG = Color.WHITE;                  // White header for main content

    public static final Color SIDEBAR_BG           = new Color(0x1E, 0x7A, 0x25); // #1E7A25 — dark green sidebar
    public static final Color SIDEBAR_HEADER_BG    = new Color(0x17, 0x6B, 0x20); // #176B20 — darker for header section
    public static final Color SIDEBAR_ITEM_BG      = new Color(0x17, 0x6B, 0x20); // active item bg
    public static final Color SIDEBAR_HOVER        = new Color(0x2E, 0xA8, 0x36); // hover green
    public static final Color SIDEBAR_ACTIVE       = new Color(0x23, 0x8B, 0x2A); // active green
    public static final Color SIDEBAR_BORDER       = new Color(0x17, 0x6B, 0x20); // dark green border
    public static final Color SIDEBAR_ACTIVE_CARD  = Color.WHITE;                  // white card for active item

    // =========================================================================
    // STATUS BAR
    // =========================================================================

    public static final Color STATUS_BAR_BG   = new Color(0xF0, 0xF7, 0xF0); // #F0F7F0
    public static final Color STATUS_BAR_BORDER = new Color(0xD4, 0xE8, 0xD4); // slightly darker green-gray

    // =========================================================================
    // TYPOGRAPHY COLORS
    // =========================================================================

    public static final Color TEXT_PRIMARY     = new Color(0x1A, 0x1A, 0x1A); // #1A1A1A — near-black
    public static final Color TEXT_SECONDARY   = new Color(0x66, 0x66, 0x66); // #666666 — medium gray
    public static final Color TEXT_MUTED       = new Color(0x99, 0x99, 0x99); // #999999 — light gray
    public static final Color TEXT_ON_DARK     = Color.WHITE;
    public static final Color TEXT_ON_DARK_MUTED = new Color(0xCC, 0xFF, 0xCC); // light green-white

    // =========================================================================
    // BORDERS & DIVIDERS
    // =========================================================================

    public static final Color BORDER          = new Color(0xE4, 0xE8, 0xE4); // #E4E8E4 — greenish border
    public static final Color BORDER_FOCUS    = new Color(0x23, 0x8B, 0x2A); // #238B2A
    public static final Color TABLE_GRID      = new Color(0xF0, 0xF4, 0xF0); // very light
    public static final Color TABLE_HEADER_BG = new Color(0xF0, 0xF7, 0xF0); // light green header
    public static final Color TABLE_SELECTION_BG = new Color(0xD5, 0xF0, 0xD5); // light green selection
    public static final Color TABLE_ROW_ALT   = new Color(0xFA, 0xFD, 0xFA); // very subtle green-white

    // =========================================================================
    // TYPOGRAPHY SYSTEM
    // =========================================================================

    public static final String FONT_FAMILY = "Segoe UI";

    public static final Font FONT_STAT_VALUE   = new Font(FONT_FAMILY, Font.BOLD, 30);     // Dashboard stat numbers
    public static final Font FONT_TITLE_XL     = new Font(FONT_FAMILY, Font.BOLD, 24);
    public static final Font FONT_TITLE_LARGE  = new Font(FONT_FAMILY, Font.BOLD, 20);
    public static final Font FONT_TITLE_MEDIUM = new Font(FONT_FAMILY, Font.BOLD, 16);
    public static final Font FONT_SECTION      = new Font(FONT_FAMILY, Font.BOLD, 14);

    public static final Font FONT_BODY         = new Font(FONT_FAMILY, Font.PLAIN, 13);
    public static final Font FONT_BODY_BOLD    = new Font(FONT_FAMILY, Font.BOLD, 13);
    public static final Font FONT_BODY_MEDIUM  = new Font(FONT_FAMILY, Font.PLAIN, 12);

    public static final Font FONT_SMALL        = new Font(FONT_FAMILY, Font.PLAIN, 11);
    public static final Font FONT_SMALL_BOLD   = new Font(FONT_FAMILY, Font.BOLD, 11);
    public static final Font FONT_CAPTION      = new Font(FONT_FAMILY, Font.PLAIN, 10);

    public static final Font FONT_SIDEBAR_BRAND    = new Font(FONT_FAMILY, Font.BOLD, 15);
    public static final Font FONT_SIDEBAR_SUBTITLE = new Font(FONT_FAMILY, Font.PLAIN, 9);
    public static final Font FONT_STATUS_BAR       = new Font(FONT_FAMILY, Font.PLAIN, 11);

    public static final Font FONT_MONO        = new Font("Consolas", Font.PLAIN, 12);
    public static final Font FONT_MONO_BOLD   = new Font("Consolas", Font.BOLD, 12);

    // =========================================================================
    // REUSABLE BORDERS
    // =========================================================================

    public static final Border BORDER_CARD = new CompoundBorder(
        new LineBorder(BORDER, 1, true),
        new EmptyBorder(14, 16, 14, 16)
    );

    public static final Border BORDER_CARD_TIGHT = new CompoundBorder(
        new LineBorder(BORDER, 1, true),
        new EmptyBorder(10, 12, 10, 12)
    );

    public static final Border BORDER_INPUT = new CompoundBorder(
        new LineBorder(BORDER, 1, true),
        new EmptyBorder(6, 10, 6, 10)
    );

    public static final Border BORDER_INPUT_FOCUS = new CompoundBorder(
        new LineBorder(BORDER_FOCUS, 1, true),
        new EmptyBorder(6, 10, 6, 10)
    );
}
