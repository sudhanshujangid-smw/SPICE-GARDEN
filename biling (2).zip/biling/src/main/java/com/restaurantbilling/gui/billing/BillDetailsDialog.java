package com.restaurantbilling.gui.billing;

import com.restaurantbilling.gui.reports.PrintPreviewDialog;
import com.restaurantbilling.gui.theme.UIHelper;
import com.restaurantbilling.gui.theme.UITheme;
import com.restaurantbilling.gui.util.CustomDialogs;
import com.restaurantbilling.invoice.InvoiceGenerator;
import com.restaurantbilling.model.Bill;
import com.restaurantbilling.service.AuditService;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.*;
import java.io.File;

public class BillDetailsDialog extends JDialog {

    private final Bill bill;
    private final InvoiceGenerator invoiceGenerator;
    private final boolean justGenerated;
    private final AuditService auditService;

    public BillDetailsDialog(Window owner, Bill bill, boolean justGenerated) {
        super(owner, "Invoice — " + bill.getBillNumber(), ModalityType.APPLICATION_MODAL);
        this.bill = bill;
        this.justGenerated = justGenerated;
        this.invoiceGenerator = new InvoiceGenerator(bill);
        this.auditService = new AuditService();

        initComponents();
        setSize(620, 680);
        setLocationRelativeTo(owner);
        setResizable(false);
    }

    private void initComponents() {
        JPanel contentPane = new JPanel(new BorderLayout(12, 12));
        contentPane.setBackground(UITheme.CARD_BG);
        contentPane.setBorder(new EmptyBorder(18, 22, 18, 22));
        setContentPane(contentPane);

        // Header / Status Banner
        JPanel headerPanel = new JPanel(new BorderLayout(0, 8));
        headerPanel.setOpaque(false);

        if (justGenerated) {
            JLabel lblSuccess = new JLabel("✓ BILL GENERATED SUCCESSFULLY", SwingConstants.CENTER);
            lblSuccess.setOpaque(true);
            lblSuccess.setBackground(UITheme.SUCCESS_BG);
            lblSuccess.setForeground(UITheme.SUCCESS_DARK);
            lblSuccess.setFont(UITheme.FONT_SECTION);
            lblSuccess.setBorder(new EmptyBorder(10, 14, 10, 14));
            headerPanel.add(lblSuccess, BorderLayout.NORTH);
        }

        JLabel lblTitle = new JLabel("Official Bill: " + bill.getBillNumber());
        lblTitle.setFont(UITheme.FONT_TITLE_MEDIUM);
        lblTitle.setForeground(UITheme.TEXT_PRIMARY);
        headerPanel.add(lblTitle, BorderLayout.SOUTH);

        contentPane.add(headerPanel, BorderLayout.NORTH);

        // Center: Formatted Monospaced Invoice Preview
        JTextArea txtReceipt = new JTextArea();
        txtReceipt.setFont(UITheme.FONT_MONO);
        txtReceipt.setEditable(false);
        txtReceipt.setText(invoiceGenerator.generateTextReceipt());
        txtReceipt.setCaretPosition(0);
        txtReceipt.setBackground(new Color(252, 252, 252));
        txtReceipt.setBorder(new EmptyBorder(12, 16, 12, 16));

        JScrollPane scrollPane = new JScrollPane(txtReceipt);
        scrollPane.setBorder(new LineBorder(UITheme.BORDER, 1, true));
        contentPane.add(scrollPane, BorderLayout.CENTER);

        // Footer Actions
        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 5));
        btnPanel.setOpaque(false);

        JButton btnPrintPreview = UIHelper.createSecondaryButton("Print Preview");
        btnPrintPreview.addActionListener(e -> onPrintPreview());
        btnPanel.add(btnPrintPreview);

        JButton btnPrint = UIHelper.createPrimaryButton("🖨️ Print Bill");
        btnPrint.setPreferredSize(new Dimension(115, 34));
        btnPrint.addActionListener(e -> onPrint());
        btnPanel.add(btnPrint);

        JButton btnExportPdf = UIHelper.createDangerButton("Export PDF");
        btnExportPdf.setPreferredSize(new Dimension(110, 34));
        btnExportPdf.addActionListener(e -> onExportPdf());
        btnPanel.add(btnExportPdf);

        JButton btnSaveFile = UIHelper.createSecondaryButton("Save TXT/HTML");
        btnSaveFile.addActionListener(e -> onSaveFile());
        btnPanel.add(btnSaveFile);

        JButton btnClose = UIHelper.createSecondaryButton("Close");
        btnClose.setPreferredSize(new Dimension(80, 34));
        btnClose.addActionListener(e -> dispose());
        btnPanel.add(btnClose);

        contentPane.add(btnPanel, BorderLayout.SOUTH);
    }

    private void onPrintPreview() {
        PrintPreviewDialog dialog = new PrintPreviewDialog(this, "Bill #" + bill.getBillNumber(), invoiceGenerator.generateTextReceipt(), invoiceGenerator);
        dialog.setVisible(true);
    }

    private void onPrint() {
        boolean printed = invoiceGenerator.printInvoice();
        if (printed) {
            auditService.log("BILLING", "BILL_PRINTED", "Printed bill #" + bill.getBillNumber(), "SUCCESS");
            CustomDialogs.showSuccess(this, "Bill sent to system printer successfully.", "Print Successful");
        }
    }

    private void onExportPdf() {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Save Bill PDF");
        fileChooser.setSelectedFile(new File("bill_" + bill.getBillNumber() + ".pdf"));
        fileChooser.setFileFilter(new FileNameExtensionFilter("PDF Documents (*.pdf)", "pdf"));

        if (fileChooser.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
            File selectedFile = fileChooser.getSelectedFile();
            if (!selectedFile.getName().toLowerCase().endsWith(".pdf")) {
                selectedFile = new File(selectedFile.getParentFile(), selectedFile.getName() + ".pdf");
            }

            try {
                invoiceGenerator.exportPdfInvoice(selectedFile);
                auditService.log("BILLING", "INVOICE_EXPORTED", "Exported PDF for bill #" + bill.getBillNumber(), "SUCCESS");
                CustomDialogs.showSuccess(this, "PDF Invoice saved successfully:\n" + selectedFile.getAbsolutePath(), "Export Successful");
            } catch (Exception ex) {
                CustomDialogs.showError(this, "Unable to export PDF: " + ex.getMessage(), "Export Error");
            }
        }
    }

    private void onSaveFile() {
        try {
            File savedFile = invoiceGenerator.saveInvoiceFile();
            auditService.log("BILLING", "INVOICE_SAVED", "Saved local invoice files for bill #" + bill.getBillNumber(), "SUCCESS");
            CustomDialogs.showSuccess(this, "Invoice saved successfully in:\n" + savedFile.getAbsolutePath(), "Invoice Saved");
        } catch (Exception ex) {
            CustomDialogs.showError(this, "Failed to save invoice: " + ex.getMessage(), "Error Saving File");
        }
    }
}
