package com.restaurantbilling.gui.reports;

import com.restaurantbilling.gui.theme.UIHelper;
import com.restaurantbilling.gui.theme.UITheme;
import com.restaurantbilling.gui.util.CustomDialogs;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.awt.print.Printable;
import java.awt.print.PrinterJob;

public class PrintPreviewDialog extends JDialog {

    private final Printable printable;
    private final String previewText;
    private final String documentTitle;

    public PrintPreviewDialog(Window owner, String documentTitle, String previewText, Printable printable) {
        super(owner, "Print Preview — " + documentTitle, ModalityType.APPLICATION_MODAL);
        this.documentTitle = documentTitle;
        this.previewText = previewText;
        this.printable = printable;

        initComponents(); 
        setSize(680, 720);
        setLocationRelativeTo(owner);
    }

    private void initComponents() {
        JPanel contentPane = new JPanel(new BorderLayout(12, 12));
        contentPane.setBackground(UITheme.CARD_BG);
        contentPane.setBorder(new EmptyBorder(18, 22, 18, 22));
        setContentPane(contentPane);

        // Header
        JPanel headerPanel = new JPanel(new GridLayout(2, 1, 0, 3));
        headerPanel.setOpaque(false);

        JLabel lblTitle = new JLabel("Print Preview: " + documentTitle);
        lblTitle.setFont(UITheme.FONT_TITLE_MEDIUM);
        lblTitle.setForeground(UITheme.TEXT_PRIMARY);
        headerPanel.add(lblTitle);

        JLabel lblSub = new JLabel("Inspect the formatted document layout before sending to printer.");
        lblSub.setFont(UITheme.FONT_BODY_MEDIUM);
        lblSub.setForeground(UITheme.TEXT_SECONDARY);
        headerPanel.add(lblSub);

        contentPane.add(headerPanel, BorderLayout.NORTH);

        // Center: Preview TextArea resembling paper sheet
        JTextArea txtPreview = new JTextArea();
        txtPreview.setFont(UITheme.FONT_MONO);
        txtPreview.setEditable(false);
        txtPreview.setText(previewText != null ? previewText : "");
        txtPreview.setCaretPosition(0);
        txtPreview.setBackground(new Color(252, 252, 252));
        txtPreview.setBorder(new EmptyBorder(16, 20, 16, 20));

        JScrollPane scrollPane = new JScrollPane(txtPreview);
        scrollPane.setBorder(new LineBorder(UITheme.BORDER, 1, true));
        contentPane.add(scrollPane, BorderLayout.CENTER);

        // Footer Actions
        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 5));
        btnPanel.setOpaque(false);

        JButton btnPrint = UIHelper.createPrimaryButton("🖨️ Print Document");
        btnPrint.setPreferredSize(new Dimension(150, 34));
        btnPrint.addActionListener(e -> onPrint());
        btnPanel.add(btnPrint);

        JButton btnClose = UIHelper.createSecondaryButton("Close");
        btnClose.setPreferredSize(new Dimension(80, 34));
        btnClose.addActionListener(e -> dispose());
        btnPanel.add(btnClose);

        contentPane.add(btnPanel, BorderLayout.SOUTH);
    }

    private void onPrint() {
        if (printable == null) {
            CustomDialogs.showError(this, "No printable document attached.", "Print Error");
            return;
        }

        PrinterJob job = PrinterJob.getPrinterJob();
        job.setPrintable(printable);
        if (job.printDialog()) {
            try {
                job.print();
                CustomDialogs.showSuccess(this, "Document successfully sent to printer.", "Print Successful");
                dispose();
            } catch (Exception ex) {
                CustomDialogs.showError(this, "Printing failed: " + ex.getMessage(), "Print Error");
            }
        }
    }
}
