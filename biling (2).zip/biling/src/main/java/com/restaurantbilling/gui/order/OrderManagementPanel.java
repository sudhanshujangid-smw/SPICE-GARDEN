package com.restaurantbilling.gui.order;

import com.restaurantbilling.gui.theme.UITheme;
import com.restaurantbilling.service.OrderService;

import javax.swing.*;
import java.awt.*;

public class OrderManagementPanel extends JPanel {

    private final OrderService orderService;
    private final JTabbedPane tabbedPane;
    private final OrderCreationPanel orderCreationPanel;
    private final OrderListPanel orderListPanel;

    public OrderManagementPanel() {
        this.orderService = new OrderService();

        setLayout(new BorderLayout());
        setBackground(UITheme.APP_BG);

        tabbedPane = new JTabbedPane();
        tabbedPane.setFont(UITheme.FONT_SECTION);

        orderListPanel = new OrderListPanel(orderService);

        orderCreationPanel = new OrderCreationPanel(orderService, () -> {
            orderListPanel.loadOrdersAsync();
            tabbedPane.setSelectedIndex(1); // Switch to order list tab
        });

        tabbedPane.addTab("  🛒 + Create New Order  ", orderCreationPanel);
        tabbedPane.addTab("  📋 Order History & Status  ", orderListPanel);

        add(tabbedPane, BorderLayout.CENTER);
    }

    public void refreshData() {
        orderCreationPanel.loadCustomers();
        orderCreationPanel.loadFoodItems();
        orderListPanel.loadOrdersAsync();
    }
}
