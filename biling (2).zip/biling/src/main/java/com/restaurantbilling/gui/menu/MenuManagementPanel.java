package com.restaurantbilling.gui.menu;

import com.restaurantbilling.gui.theme.UIHelper;
import com.restaurantbilling.gui.theme.UITheme;
import com.restaurantbilling.gui.util.CustomDialogs;
import com.restaurantbilling.model.FoodItem;
import com.restaurantbilling.service.FoodItemService;
import com.restaurantbilling.service.PexelsImageService;
import com.restaurantbilling.util.FormatUtil;
import com.restaurantbilling.util.UserSession;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;

public class MenuManagementPanel extends JPanel {

    private final FoodItemService foodItemService;
    private final PexelsImageService imageService;
    private List<FoodItem> itemList = new ArrayList<>();

    private JTextField txtSearch;
    private JComboBox<String> cmbCategoryFilter;
    private JTable itemTable;
    private DefaultTableModel tableModel;
    private JLabel lblStatus;

    private JButton btnAddItem;
    private JButton btnEditItem;
    private JButton btnDeleteItem;

    private static final String[] COLUMNS = {"ID", "Image", "Item Name", "Category", "Price", "Availability Status"};

    public MenuManagementPanel() {
        this.foodItemService = new FoodItemService();
        this.imageService = new PexelsImageService();
        setLayout(new BorderLayout(15, 15));
        setBorder(new EmptyBorder(16, 20, 16, 20));
        setBackground(UITheme.APP_BG);

        initComponents();
        loadItems();
    }

    private void initComponents() {
        // TOP: Header + Search/Filter Toolbar
        JPanel topPanel = new JPanel(new BorderLayout(10, 12));
        topPanel.setOpaque(false);

        // Header Title
        JPanel titlePanel = new JPanel(new GridLayout(2, 1, 0, 3));
        titlePanel.setOpaque(false);

        JLabel lblTitle = new JLabel("Menu Management");
        lblTitle.setFont(UITheme.FONT_TITLE_LARGE);
        lblTitle.setForeground(UITheme.TEXT_PRIMARY);
        titlePanel.add(lblTitle);

        JLabel lblSubtitle = new JLabel("Manage restaurant dishes, pricing, categories, and inventory availability.");
        lblSubtitle.setFont(UITheme.FONT_BODY_MEDIUM);
        lblSubtitle.setForeground(UITheme.TEXT_SECONDARY);
        titlePanel.add(lblSubtitle);

        topPanel.add(titlePanel, BorderLayout.NORTH);

        // Filter / Search Bar Card
        JPanel filterPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 8));
        filterPanel.setBackground(UITheme.CARD_BG);
        filterPanel.setBorder(UITheme.BORDER_CARD);

        JLabel lblSearch = new JLabel("Search Item:");
        lblSearch.setFont(UITheme.FONT_BODY_BOLD);
        filterPanel.add(lblSearch);

        txtSearch = new JTextField(15);
        UIHelper.styleTextField(txtSearch);
        txtSearch.setPreferredSize(new Dimension(180, 34));
        txtSearch.putClientProperty("JTextField.placeholderText", "Name or keyword...");
        txtSearch.addActionListener(e -> searchItems());
        filterPanel.add(txtSearch);

        JButton btnSearch = UIHelper.createSecondaryButton("Search");
        btnSearch.setPreferredSize(new Dimension(90, 34));
        btnSearch.addActionListener(e -> searchItems());
        filterPanel.add(btnSearch);

        JLabel lblCategory = new JLabel("Category:");
        lblCategory.setFont(UITheme.FONT_BODY_BOLD);
        filterPanel.add(lblCategory);

        cmbCategoryFilter = new JComboBox<>(new String[]{"All", "Starter", "Main Course", "Breads", "Beverages", "Dessert", "Fast Food"});
        UIHelper.styleComboBox(cmbCategoryFilter);
        cmbCategoryFilter.setPreferredSize(new Dimension(130, 34));
        cmbCategoryFilter.addActionListener(e -> searchItems());
        filterPanel.add(cmbCategoryFilter);

        JButton btnClear = UIHelper.createSecondaryButton("Clear");
        btnClear.setPreferredSize(new Dimension(80, 34));
        btnClear.addActionListener(e -> {
            txtSearch.setText("");
            cmbCategoryFilter.setSelectedItem("All");
            loadItems();
        });
        filterPanel.add(btnClear);

        topPanel.add(filterPanel, BorderLayout.SOUTH);
        add(topPanel, BorderLayout.NORTH);

        // CENTER: Table Card
        JPanel centerCard = new JPanel(new BorderLayout());
        centerCard.setBackground(UITheme.CARD_BG);
        centerCard.setBorder(new LineBorder(UITheme.BORDER, 1, true));

        tableModel = new DefaultTableModel(COLUMNS, 0) {
            @Override
            public boolean isCellEditable(int row, int col) {
                return false;
            }
            @Override
            public Class<?> getColumnClass(int columnIndex) {
                if (columnIndex == 1) return ImageIcon.class;
                return super.getColumnClass(columnIndex);
            }
        };

        itemTable = new JTable(tableModel);
        UIHelper.styleTable(itemTable);

        // Alignments & Renderers
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(SwingConstants.CENTER);
        itemTable.getColumnModel().getColumn(0).setPreferredWidth(40);
        itemTable.getColumnModel().getColumn(0).setCellRenderer(centerRenderer);

        itemTable.getColumnModel().getColumn(1).setPreferredWidth(70);
        itemTable.getColumnModel().getColumn(2).setPreferredWidth(200);
        itemTable.getColumnModel().getColumn(3).setPreferredWidth(120);

        DefaultTableCellRenderer rightRenderer = new DefaultTableCellRenderer();
        rightRenderer.setHorizontalAlignment(SwingConstants.RIGHT);
        itemTable.getColumnModel().getColumn(4).setPreferredWidth(100);
        itemTable.getColumnModel().getColumn(4).setCellRenderer(rightRenderer);

        itemTable.getColumnModel().getColumn(5).setPreferredWidth(120);
        itemTable.getColumnModel().getColumn(5).setCellRenderer(UIHelper.createStatusCellRenderer());

        itemTable.setRowHeight(50);

        // Double-click to edit
        itemTable.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2 && itemTable.getSelectedRow() != -1 && UserSession.isAdmin()) {
                    onEditItem();
                }
            }
        });

        JScrollPane scrollPane = new JScrollPane(itemTable);
        UIHelper.styleScrollPane(scrollPane);
        centerCard.add(scrollPane, BorderLayout.CENTER);

        add(centerCard, BorderLayout.CENTER);

        // SOUTH: Action Toolbar & Status Bar
        JPanel southPanel = new JPanel(new BorderLayout(10, 10));
        southPanel.setOpaque(false);

        JPanel actionPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));
        actionPanel.setOpaque(false);

        btnAddItem = UIHelper.createPrimaryButton("+ Add Food Item");
        btnAddItem.addActionListener(e -> onAddItem());
        actionPanel.add(btnAddItem);

        btnEditItem = UIHelper.createSecondaryButton("Edit Item");
        btnEditItem.addActionListener(e -> onEditItem());
        actionPanel.add(btnEditItem);

        btnDeleteItem = UIHelper.createDangerButton("Delete Item");
        btnDeleteItem.addActionListener(e -> onDeleteItem());
        actionPanel.add(btnDeleteItem);

        JButton btnRefresh = UIHelper.createSecondaryButton("Refresh");
        btnRefresh.addActionListener(e -> loadItems());
        actionPanel.add(btnRefresh);

        southPanel.add(actionPanel, BorderLayout.NORTH);

        lblStatus = new JLabel("Loading items...");
        lblStatus.setFont(UITheme.FONT_SMALL);
        lblStatus.setForeground(UITheme.TEXT_SECONDARY);
        southPanel.add(lblStatus, BorderLayout.SOUTH);

        add(southPanel, BorderLayout.SOUTH);

        // Role-based visibility
        boolean isAdmin = UserSession.isAdmin();
        btnAddItem.setVisible(isAdmin);
        btnEditItem.setVisible(isAdmin);
        btnDeleteItem.setVisible(isAdmin);
    }

    public void loadItems() {
        try {
            itemList = foodItemService.getAllFoodItems();
            renderTable(itemList);
            lblStatus.setText("Total Menu Items: " + itemList.size());
        } catch (Exception ex) {
            lblStatus.setText("Error loading menu items: " + ex.getMessage());
        }
    }

    private void searchItems() {
        String keyword = txtSearch.getText().trim();
        String category = (String) cmbCategoryFilter.getSelectedItem();
        try {
            itemList = foodItemService.searchFoodItems(keyword, category);
            renderTable(itemList);
            lblStatus.setText("Found " + itemList.size() + " matching item(s).");
        } catch (Exception ex) {
            lblStatus.setText("Search error: " + ex.getMessage());
        }
    }

    private void renderTable(List<FoodItem> list) {
        tableModel.setRowCount(0);
        for (FoodItem item : list) {
            ImageIcon placeholder = null;
            tableModel.addRow(new Object[]{
                item.getId(),
                placeholder,
                item.getName(),
                item.getCategory(),
                FormatUtil.formatCurrency(item.getPrice()),
                item.isAvailable() ? "Available" : "Out of Stock"
            });
            
            final int rowIdx = tableModel.getRowCount() - 1;
            
            if (item.getPexelsPhotoId() != null && item.getImageUrl() != null) {
                SwingWorker<ImageIcon, Void> worker = new SwingWorker<>() {
                    @Override
                    protected ImageIcon doInBackground() throws Exception {
                        Image img = imageService.getCachedOrDownloadImage(item.getPexelsPhotoId(), item.getImageUrl());
                        if (img != null) {
                            return new ImageIcon(img.getScaledInstance(60, 50, Image.SCALE_SMOOTH));
                        }
                        return null;
                    }
                    @Override
                    protected void done() {
                        try {
                            ImageIcon loaded = get();
                            if (loaded != null) {
                                if (rowIdx < tableModel.getRowCount() && tableModel.getValueAt(rowIdx, 0).equals(item.getId())) {
                                    tableModel.setValueAt(loaded, rowIdx, 1);
                                }
                            }
                        } catch (Exception ignored) {}
                    }
                };
                worker.execute();
            }
        }
    }

    private void onAddItem() {
        Window parent = SwingUtilities.getWindowAncestor(this);
        FoodItemDialog dialog = new FoodItemDialog(parent, foodItemService, null, false);
        dialog.setVisible(true);
        if (dialog.isSaved()) {
            loadItems();
        }
    }

    private void onEditItem() {
        int row = itemTable.getSelectedRow();
        if (row < 0 || row >= itemList.size()) {
            CustomDialogs.showWarning(this, "Please select an item from the table to edit.", "Selection Required");
            return;
        }
        FoodItem selected = itemList.get(row);
        Window parent = SwingUtilities.getWindowAncestor(this);
        FoodItemDialog dialog = new FoodItemDialog(parent, foodItemService, selected, true);
        dialog.setVisible(true);
        if (dialog.isSaved()) {
            loadItems();
        }
    }

    private void onDeleteItem() {
        int row = itemTable.getSelectedRow();
        if (row < 0 || row >= itemList.size()) {
            CustomDialogs.showWarning(this, "Please select an item from the table to delete.", "Selection Required");
            return;
        }
        FoodItem selected = itemList.get(row);

        boolean confirmed = CustomDialogs.showDangerConfirm(this,
            "Are you sure you want to permanently delete '" + selected.getName() + "'?\nThis action cannot be undone.",
            "Confirm Item Deletion",
            "Delete Item");

        if (confirmed) {
            try {
                foodItemService.deleteFoodItem(selected.getId());
                CustomDialogs.showSuccess(this, "Menu item '" + selected.getName() + "' deleted successfully.", "Item Deleted");
                loadItems();
            } catch (Exception ex) {
                CustomDialogs.showError(this, "Failed to delete item: " + ex.getMessage(), "Deletion Error");
            }
        }
    }
}
