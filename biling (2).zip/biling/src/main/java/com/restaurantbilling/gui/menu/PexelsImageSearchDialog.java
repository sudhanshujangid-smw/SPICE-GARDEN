package com.restaurantbilling.gui.menu;

import com.restaurantbilling.api.pexels.PexelsPhoto;
import com.restaurantbilling.gui.theme.UIHelper;
import com.restaurantbilling.gui.theme.UITheme;
import com.restaurantbilling.service.PexelsImageService;
import com.restaurantbilling.gui.util.CustomDialogs;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.net.URL;
import java.util.List;

public class PexelsImageSearchDialog extends JDialog {

    private final PexelsImageService imageService;
    private final String query;
    private PexelsPhoto selectedPhoto;

    private JPanel resultsPanel;
    private JLabel statusLabel;

    public PexelsImageSearchDialog(Window owner, String query) {
        super(owner, "Pexels Food Image Search", ModalityType.APPLICATION_MODAL);
        this.imageService = new PexelsImageService();
        this.query = query;

        initComponents();
        setSize(800, 600);
        setLocationRelativeTo(owner);

        performSearch();
    }

    private void initComponents() {
        JPanel contentPane = new JPanel(new BorderLayout(10, 10));
        contentPane.setBorder(new EmptyBorder(15, 15, 15, 15));
        contentPane.setBackground(UITheme.APP_BG);

        // Header
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setOpaque(false);
        JLabel titleLabel = new JLabel("Searching food images for: " + query);
        titleLabel.setFont(UITheme.FONT_TITLE_MEDIUM);
        headerPanel.add(titleLabel, BorderLayout.CENTER);
        
        JLabel attributionLabel = new JLabel("Photos provided by Pexels");
        attributionLabel.setFont(UITheme.FONT_SMALL);
        attributionLabel.setForeground(UITheme.TEXT_SECONDARY);
        headerPanel.add(attributionLabel, BorderLayout.EAST);
        
        contentPane.add(headerPanel, BorderLayout.NORTH);

        // Results Area
        resultsPanel = new JPanel(new GridLayout(0, 3, 15, 15));
        resultsPanel.setBackground(UITheme.APP_BG);
        JScrollPane scrollPane = new JScrollPane(resultsPanel);
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);
        contentPane.add(scrollPane, BorderLayout.CENTER);

        // Footer
        JPanel footerPanel = new JPanel(new BorderLayout());
        footerPanel.setOpaque(false);
        statusLabel = new JLabel("Searching...");
        footerPanel.add(statusLabel, BorderLayout.WEST);

        JButton cancelButton = UIHelper.createSecondaryButton("Cancel");
        cancelButton.addActionListener(e -> dispose());
        footerPanel.add(cancelButton, BorderLayout.EAST);

        contentPane.add(footerPanel, BorderLayout.SOUTH);

        setContentPane(contentPane);
    }

    private void performSearch() {
        resultsPanel.removeAll();
        statusLabel.setText("Searching for '" + query + "'...");

        SwingWorker<List<PexelsPhoto>, Void> worker = new SwingWorker<>() {
            @Override
            protected List<PexelsPhoto> doInBackground() throws Exception {
                return imageService.searchFoodImages(query);
            }

            @Override
            protected void done() {
                try {
                    List<PexelsPhoto> photos = get();
                    statusLabel.setText("Found " + photos.size() + " results.");
                    displayResults(photos);
                } catch (Exception ex) {
                    statusLabel.setText("Error: " + ex.getMessage());
                    CustomDialogs.showError(PexelsImageSearchDialog.this, ex.getMessage(), "Search Failed");
                }
            }
        };
        worker.execute();
    }

    private void displayResults(List<PexelsPhoto> photos) {
        for (PexelsPhoto photo : photos) {
            JPanel card = new JPanel(new BorderLayout(5, 5));
            card.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(UITheme.BORDER),
                    new EmptyBorder(10, 10, 10, 10)
            ));
            card.setBackground(UITheme.CARD_BG);

            JLabel imageLabel = new JLabel("Loading...");
            imageLabel.setHorizontalAlignment(SwingConstants.CENTER);
            imageLabel.setPreferredSize(new Dimension(200, 150));
            card.add(imageLabel, BorderLayout.CENTER);

            JPanel infoPanel = new JPanel(new BorderLayout());
            infoPanel.setOpaque(false);
            JLabel photographerLabel = new JLabel(photo.getPhotographer());
            photographerLabel.setFont(UITheme.FONT_BODY_MEDIUM);
            infoPanel.add(photographerLabel, BorderLayout.CENTER);

            JButton selectBtn = UIHelper.createPrimaryButton("Select");
            selectBtn.addActionListener(e -> {
                selectedPhoto = photo;
                dispose();
            });
            infoPanel.add(selectBtn, BorderLayout.SOUTH);
            card.add(infoPanel, BorderLayout.SOUTH);

            resultsPanel.add(card);

            // Load image asynchronously
            SwingWorker<ImageIcon, Void> imgLoader = new SwingWorker<>() {
                @Override
                protected ImageIcon doInBackground() throws Exception {
                    Image img = imageService.getCachedOrDownloadImage(photo.getId(), photo.getSrc().getMedium());
                    Image scaled = img.getScaledInstance(200, 150, Image.SCALE_SMOOTH);
                    return new ImageIcon(scaled);
                }

                @Override
                protected void done() {
                    try {
                        imageLabel.setIcon(get());
                        imageLabel.setText("");
                    } catch (Exception ignored) {
                        imageLabel.setText("[ Image Load Failed ]");
                    }
                }
            };
            imgLoader.execute();
        }
        resultsPanel.revalidate();
        resultsPanel.repaint();
    }

    public PexelsPhoto getSelectedPhoto() {
        return selectedPhoto;
    }
}
