package com.restaurantbilling.gui;

import com.restaurantbilling.database.DatabaseConnection;
import com.restaurantbilling.gui.audit.AuditLogPanel;
import com.restaurantbilling.gui.billing.BillingManagementPanel;
import com.restaurantbilling.gui.calendar.CalendarPanel;
import com.restaurantbilling.gui.customer.CustomerManagementPanel;
import com.restaurantbilling.gui.maintenance.MaintenancePanel;
import com.restaurantbilling.gui.menu.MenuManagementPanel;
import com.restaurantbilling.gui.order.OrderManagementPanel;
import com.restaurantbilling.gui.reports.ReportsDashboardPanel;
import com.restaurantbilling.gui.settings.SettingsPanel;
import com.restaurantbilling.gui.theme.UITheme;
import com.restaurantbilling.gui.util.CustomDialogs;
import com.restaurantbilling.util.UserSession;

import javax.swing.*;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.MatteBorder;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Spice Garden Restaurant Billing System — Main Application Frame.
 * Premium green + white design with collapsible sidebar and live status bar.
 */
public class MainFrame extends JFrame {

    // ── Panels ──
    private CardLayout cardLayout;
    private JPanel mainContentPanel;
    private JPanel sidebarPanel;

    // ── Module panels ──
    private DashboardPanel dashboardPanel;
    private MenuManagementPanel menuPanel;
    private CustomerManagementPanel customerPanel;
    private OrderManagementPanel orderPanel;
    private BillingManagementPanel billingPanel;
    private ReportsDashboardPanel reportsPanel;
    private SettingsPanel settingsPanel;
    private MaintenancePanel maintenancePanel;
    private AuditLogPanel auditPanel;
    private CalendarPanel calendarPanel;

    // ── Navigation state ──
    private final List<NavItem> navItems = new ArrayList<>();
    private NavItem activeNavItem = null;
    private boolean sidebarCollapsed = false;

    // ── Header components (live-updated) ──
    private JLabel lblHeaderWelcome;
    private JLabel lblHeaderDate;
    private JLabel lblHeaderClock;

    // ── Status bar ──
    private JLabel lblDbStatus;
    private JLabel lblStatusUser;

    // Sidebar width constants
    private static final int SIDEBAR_EXPANDED  = 260;
    private static final int SIDEBAR_COLLAPSED = 60;

    public MainFrame() {
        setTitle("Spice Garden — Restaurant Billing System");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1366, 800);
        setMinimumSize(new Dimension(1050, 680));
        setLocationRelativeTo(null);

        initComponents();
        startClockTimer();
        checkDbStatusAsync();
    }

    // =========================================================================
    // INIT
    // =========================================================================

    private void initComponents() {
        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(UITheme.APP_BG);
        setContentPane(root);

        // 1. Top white header
        root.add(createHeaderPanel(), BorderLayout.NORTH);

        // 2. Left green sidebar
        sidebarPanel = createSidebarPanel();
        root.add(sidebarPanel, BorderLayout.WEST);

        // 3. Center content (CardLayout)
        cardLayout = new CardLayout();
        mainContentPanel = new JPanel(cardLayout);
        mainContentPanel.setBackground(UITheme.APP_BG);

        dashboardPanel    = new DashboardPanel(this);
        menuPanel         = new MenuManagementPanel();
        customerPanel     = new CustomerManagementPanel();
        orderPanel        = new OrderManagementPanel();
        billingPanel      = new BillingManagementPanel();
        reportsPanel      = new ReportsDashboardPanel();
        settingsPanel     = new SettingsPanel();
        maintenancePanel  = new MaintenancePanel();
        auditPanel        = new AuditLogPanel();
        calendarPanel     = new CalendarPanel();

        mainContentPanel.add(dashboardPanel,   "DASHBOARD");
        mainContentPanel.add(menuPanel,        "MENU");
        mainContentPanel.add(customerPanel,    "CUSTOMERS");
        mainContentPanel.add(orderPanel,       "ORDERS");
        mainContentPanel.add(billingPanel,     "BILLING");
        mainContentPanel.add(reportsPanel,     "REPORTS");
        mainContentPanel.add(settingsPanel,    "SETTINGS");
        mainContentPanel.add(maintenancePanel, "MAINTENANCE");
        mainContentPanel.add(auditPanel,       "AUDIT");
        mainContentPanel.add(calendarPanel,    "CALENDAR");

        root.add(mainContentPanel, BorderLayout.CENTER);

        // 4. Bottom status bar
        root.add(createStatusBar(), BorderLayout.SOUTH);

        // Activate Dashboard
        if (!navItems.isEmpty()) {
            setActiveNavItem(navItems.get(0));
        }
    }

    // =========================================================================
    // TOP HEADER (white, 80px)
    // =========================================================================

    private JPanel createHeaderPanel() {
        JPanel header = new JPanel(new BorderLayout(12, 0));
        header.setBackground(Color.WHITE);
        header.setPreferredSize(new Dimension(getWidth(), 80));
        header.setBorder(new CompoundBorder(
            new MatteBorder(0, 0, 1, 0, UITheme.BORDER),
            new EmptyBorder(12, 20, 12, 20)
        ));

        // ── LEFT: hamburger + welcome text ──
        JPanel leftGroup = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        leftGroup.setOpaque(false);

        // Hamburger
        JButton btnHamburger = new JButton("☰");
        btnHamburger.setFont(new Font("Segoe UI", Font.PLAIN, 20));
        btnHamburger.setForeground(UITheme.TEXT_SECONDARY);
        btnHamburger.setFocusPainted(false);
        btnHamburger.setBorderPainted(false);
        btnHamburger.setContentAreaFilled(false);
        btnHamburger.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnHamburger.addActionListener(e -> toggleSidebar());
        btnHamburger.addMouseListener(new MouseAdapter() {
            @Override public void mouseEntered(MouseEvent e) { btnHamburger.setForeground(UITheme.PRIMARY); }
            @Override public void mouseExited(MouseEvent e)  { btnHamburger.setForeground(UITheme.TEXT_SECONDARY); }
        });
        leftGroup.add(btnHamburger);

        // Welcome text column
        JPanel welcomeCol = new JPanel();
        welcomeCol.setLayout(new BoxLayout(welcomeCol, BoxLayout.Y_AXIS));
        welcomeCol.setOpaque(false);

        String username = UserSession.getUsername() != null ? UserSession.getUsername() : "Admin";
        lblHeaderWelcome = new JLabel("Welcome back, " + username + "! 👋");
        lblHeaderWelcome.setFont(UITheme.FONT_TITLE_MEDIUM);
        lblHeaderWelcome.setForeground(UITheme.TEXT_PRIMARY);
        welcomeCol.add(lblHeaderWelcome);

        JLabel lblSubtitle = new JLabel("Here's what's happening with your restaurant today.");
        lblSubtitle.setFont(UITheme.FONT_BODY_MEDIUM);
        lblSubtitle.setForeground(UITheme.TEXT_MUTED);
        welcomeCol.add(lblSubtitle);

        leftGroup.add(welcomeCol);
        header.add(leftGroup, BorderLayout.WEST);

        // ── RIGHT: date/clock + user chip ──
        JPanel rightGroup = new JPanel(new FlowLayout(FlowLayout.RIGHT, 16, 0));
        rightGroup.setOpaque(false);

        // Date display
        JPanel dateTimePanel = new JPanel();
        dateTimePanel.setLayout(new BoxLayout(dateTimePanel, BoxLayout.Y_AXIS));
        dateTimePanel.setOpaque(false);

        lblHeaderDate = new JLabel("📅  " + formatDate());
        lblHeaderDate.setFont(UITheme.FONT_BODY_BOLD);
        lblHeaderDate.setForeground(UITheme.TEXT_PRIMARY);
        dateTimePanel.add(lblHeaderDate);

        lblHeaderClock = new JLabel("🕐  --:--:-- --");
        lblHeaderClock.setFont(UITheme.FONT_BODY_MEDIUM);
        lblHeaderClock.setForeground(UITheme.TEXT_SECONDARY);
        dateTimePanel.add(lblHeaderClock);

        rightGroup.add(dateTimePanel);

        // Separator
        JSeparator sep = new JSeparator(SwingConstants.VERTICAL);
        sep.setPreferredSize(new Dimension(1, 40));
        sep.setForeground(UITheme.BORDER);
        rightGroup.add(sep);

        // User chip with dropdown
        rightGroup.add(createUserChip());
        header.add(rightGroup, BorderLayout.EAST);

        return header;
    }

    private JButton createUserChip() {
        String username = UserSession.getUsername() != null ? UserSession.getUsername() : "Admin";
        String role     = UserSession.getRole()     != null ? UserSession.getRole()     : "Administrator";

        JButton chip = new JButton() {
            @Override
            protected void paintComponent(Graphics g) {
                // Don't paint default button bg
                super.paintComponent(g);
            }
        };
        chip.setLayout(new FlowLayout(FlowLayout.LEFT, 8, 0));
        chip.setOpaque(false);
        chip.setContentAreaFilled(false);
        chip.setBorderPainted(false);
        chip.setFocusPainted(false);
        chip.setCursor(new Cursor(Cursor.HAND_CURSOR));

        // Green avatar circle
        JLabel avatar = new JLabel() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(UITheme.PRIMARY);
                g2.fillOval(0, 0, getWidth(), getHeight());
                g2.setColor(Color.WHITE);
                g2.setFont(new Font("Segoe UI", Font.BOLD, 14));
                String init = username.substring(0, 1).toUpperCase();
                FontMetrics fm = g2.getFontMetrics();
                g2.drawString(init, (getWidth() - fm.stringWidth(init)) / 2, (getHeight() + fm.getAscent() - fm.getDescent()) / 2);
                g2.dispose();
            }
        };
        avatar.setPreferredSize(new Dimension(36, 36));
        avatar.setOpaque(false);
        chip.add(avatar);

        // Name + role column
        JPanel userInfo = new JPanel();
        userInfo.setLayout(new BoxLayout(userInfo, BoxLayout.Y_AXIS));
        userInfo.setOpaque(false);

        JLabel lblName = new JLabel(username);
        lblName.setFont(UITheme.FONT_BODY_BOLD);
        lblName.setForeground(UITheme.TEXT_PRIMARY);
        userInfo.add(lblName);

        JLabel lblRole = new JLabel(role);
        lblRole.setFont(UITheme.FONT_CAPTION);
        lblRole.setForeground(UITheme.TEXT_MUTED);
        userInfo.add(lblRole);

        chip.add(userInfo);

        // Dropdown arrow
        JLabel arrow = new JLabel("▾");
        arrow.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        arrow.setForeground(UITheme.TEXT_MUTED);
        chip.add(arrow);

        // Dropdown popup on click
        JPopupMenu popup = new JPopupMenu();
        popup.setBorder(new CompoundBorder(
            BorderFactory.createLineBorder(UITheme.BORDER, 1, true),
            new EmptyBorder(4, 0, 4, 0)
        ));

        JMenuItem miProfile = new JMenuItem("👤  Profile");
        miProfile.setFont(UITheme.FONT_BODY);
        miProfile.addActionListener(e -> JOptionPane.showMessageDialog(this,
            "Username: " + username + "\nRole: " + role, "Profile", JOptionPane.INFORMATION_MESSAGE));
        popup.add(miProfile);
        popup.addSeparator();

        JMenuItem miLogout = new JMenuItem("⎋  Sign Out");
        miLogout.setFont(UITheme.FONT_BODY);
        miLogout.setForeground(UITheme.DANGER);
        miLogout.addActionListener(e -> onLogout());
        popup.add(miLogout);

        chip.addActionListener(e -> popup.show(chip, 0, chip.getHeight()));

        return chip;
    }

    private String formatDate() {
        SimpleDateFormat sdf = new SimpleDateFormat("dd MMM yyyy, EEEE");
        return sdf.format(new Date());
    }

    // =========================================================================
    // GREEN SIDEBAR
    // =========================================================================

    private JPanel createSidebarPanel() {
        JPanel sidebar = new JPanel();
        sidebar.setLayout(new BoxLayout(sidebar, BoxLayout.Y_AXIS));
        sidebar.setBackground(UITheme.SIDEBAR_BG);
        sidebar.setPreferredSize(new Dimension(SIDEBAR_EXPANDED, getHeight()));

        // ── Brand Header ──
        sidebar.add(createSidebarBrand());
        sidebar.add(Box.createVerticalStrut(8));

        // ── Navigation Divider ──
        sidebar.add(createSidebarDivider("NAVIGATION"));

        // ── Main nav items ──
        addNavItem(sidebar, "⊞",  "Dashboard",           () -> showDashboardPanel());
        addNavItem(sidebar, "🍽",  "Menu Management",     () -> showMenuPanel());
        addNavItem(sidebar, "👤",  "Customer Management", () -> showCustomerPanel());
        addNavItem(sidebar, "🛒",  "Order Management",    () -> showOrderPanel());
        addNavItem(sidebar, "🧾",  "Billing & Invoice",   () -> showBillingPanel());
        addNavItem(sidebar, "📈",  "Reports & Analytics", () -> showReportsPanel());

        sidebar.add(Box.createVerticalStrut(6));
        sidebar.add(createSidebarDivider("ADMINISTRATION"));

        addNavItem(sidebar, "⚙",   "Settings",            () -> showSettingsPanel());
        addNavItem(sidebar, "🗄",   "Maintenance",         () -> showMaintenancePanel());
        addNavItem(sidebar, "🛡",   "Audit Logs",          () -> showAuditLogPanel());
        addNavItem(sidebar, "👥",   "User Management",     () -> showUserManagementPlaceholder());
        addNavItem(sidebar, "📅",   "Calendar",            () -> showCalendarPanel());

        sidebar.add(Box.createVerticalGlue());

        // ── Collapse button ──
        sidebar.add(createCollapseButton());

        return sidebar;
    }

    private JPanel createSidebarBrand() {
        JPanel brandPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(UITheme.SIDEBAR_HEADER_BG);
                g2.fillRect(0, 0, getWidth(), getHeight());
                g2.dispose();
                super.paintComponent(g);
            }
        };
        brandPanel.setLayout(new BorderLayout(10, 0));
        brandPanel.setOpaque(false);
        brandPanel.setBorder(new EmptyBorder(18, 14, 16, 14));
        brandPanel.setMaximumSize(new Dimension(SIDEBAR_EXPANDED, 90));

        // Logo icon
        JLabel logo = new JLabel("🍽") {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(255, 255, 255, 30));
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 10, 10);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        logo.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 26));
        logo.setHorizontalAlignment(SwingConstants.CENTER);
        logo.setPreferredSize(new Dimension(42, 42));
        logo.setOpaque(false);
        brandPanel.add(logo, BorderLayout.WEST);

        // Brand text column
        JPanel brandText = new JPanel();
        brandText.setLayout(new BoxLayout(brandText, BoxLayout.Y_AXIS));
        brandText.setOpaque(false);

        JLabel lblName = new JLabel("SPICE GARDEN");
        lblName.setFont(UITheme.FONT_SIDEBAR_BRAND);
        lblName.setForeground(Color.WHITE);
        brandText.add(lblName);

        JLabel lblSub = new JLabel("RESTAURANT BILLING SYSTEM");
        lblSub.setFont(UITheme.FONT_SIDEBAR_SUBTITLE);
        lblSub.setForeground(new Color(200, 240, 200));
        brandText.add(lblSub);

        brandPanel.add(brandText, BorderLayout.CENTER);

        return brandPanel;
    }

    private JLabel createSidebarDivider(String text) {
        JLabel lbl = new JLabel(text) {
            @Override
            public Dimension getMaximumSize() {
                return new Dimension(SIDEBAR_EXPANDED, super.getPreferredSize().height);
            }
        };
        lbl.setFont(new Font(UITheme.FONT_FAMILY, Font.BOLD, 9));
        lbl.setForeground(new Color(180, 230, 180));
        lbl.setBorder(new EmptyBorder(8, 16, 4, 16));
        lbl.setAlignmentX(Component.LEFT_ALIGNMENT);
        lbl.putClientProperty("isDivider", true);
        return lbl;
    }

    private static class NavItem {
        JPanel panel;
        JLabel iconLabel;
        JLabel textLabel;
        String icon;
        String text;
        Runnable action;

        NavItem(JPanel panel, JLabel iconLabel, JLabel textLabel, String icon, String text, Runnable action) {
            this.panel = panel;
            this.iconLabel = iconLabel;
            this.textLabel = textLabel;
            this.icon = icon;
            this.text = text;
            this.action = action;
        }
    }

    private void addNavItem(JPanel sidebar, String icon, String text, Runnable action) {
        // Container panel
        JPanel itemPanel = new JPanel(new BorderLayout(10, 0)) {
            boolean hovered = false;

            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                NavItem me = navItems.stream()
                    .filter(ni -> ni.panel == this).findFirst().orElse(null);
                boolean isActive = (me != null && me == activeNavItem);

                if (isActive) {
                    // White rounded card for active item
                    g2.setColor(Color.WHITE);
                    g2.fillRoundRect(6, 2, getWidth() - 12, getHeight() - 4, 10, 10);
                } else if (hovered) {
                    g2.setColor(new Color(255, 255, 255, 25));
                    g2.fillRoundRect(6, 2, getWidth() - 12, getHeight() - 4, 10, 10);
                }
                g2.dispose();
                super.paintComponent(g);
            }
        };
        itemPanel.setOpaque(false);
        itemPanel.setMaximumSize(new Dimension(SIDEBAR_EXPANDED, 42));
        itemPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
        itemPanel.setBorder(new EmptyBorder(4, 14, 4, 14));

        JLabel iconLabel = new JLabel(icon);
        iconLabel.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 16));
        iconLabel.setForeground(Color.WHITE);
        iconLabel.setPreferredSize(new Dimension(22, 22));
        iconLabel.setHorizontalAlignment(SwingConstants.CENTER);
        itemPanel.add(iconLabel, BorderLayout.WEST);

        JLabel textLabel = new JLabel(text);
        textLabel.setFont(UITheme.FONT_BODY);
        textLabel.setForeground(new Color(220, 250, 220));
        textLabel.setBorder(new EmptyBorder(0, 6, 0, 0));
        itemPanel.add(textLabel, BorderLayout.CENTER);

        NavItem navItem = new NavItem(itemPanel, iconLabel, textLabel, icon, text, action);
        navItems.add(navItem);

        // Hover & click
        itemPanel.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                ((JPanel)e.getSource()).putClientProperty("hovered", true);
                itemPanel.repaint();
            }
            @Override
            public void mouseExited(MouseEvent e) {
                itemPanel.putClientProperty("hovered", false);
                itemPanel.repaint();
            }
            @Override
            public void mouseClicked(MouseEvent e) {
                setActiveNavItem(navItem);
                action.run();
            }
        });
        // Also make child labels clickable
        for (Component c : itemPanel.getComponents()) {
            c.addMouseListener(new MouseAdapter() {
                @Override public void mouseClicked(MouseEvent e) {
                    setActiveNavItem(navItem);
                    action.run();
                }
            });
        }

        sidebar.add(itemPanel);
        sidebar.add(Box.createVerticalStrut(2));
    }

    private void setActiveNavItem(NavItem target) {
        this.activeNavItem = target;
        for (NavItem ni : navItems) {
            boolean isActive = (ni == target);
            // Icon color
            ni.iconLabel.setForeground(isActive ? UITheme.PRIMARY : Color.WHITE);
            // Text color & font
            ni.textLabel.setForeground(isActive ? UITheme.TEXT_PRIMARY : new Color(220, 250, 220));
            ni.textLabel.setFont(isActive ? UITheme.FONT_BODY_BOLD : UITheme.FONT_BODY);
            ni.panel.repaint();
        }
    }

    private JButton createCollapseButton() {
        JButton btn = new JButton("‹‹  Collapse") {
            @Override
            public Dimension getMaximumSize() {
                return new Dimension(SIDEBAR_EXPANDED, 44);
            }
        };
        btn.setFont(UITheme.FONT_SMALL_BOLD);
        btn.setForeground(new Color(200, 240, 200));
        btn.setFocusPainted(false);
        btn.setContentAreaFilled(false);
        btn.setBorderPainted(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setHorizontalAlignment(SwingConstants.CENTER);
        btn.setBorder(new CompoundBorder(
            new MatteBorder(1, 0, 0, 0, UITheme.SIDEBAR_BORDER),
            new EmptyBorder(10, 16, 10, 16)
        ));
        btn.setAlignmentX(Component.LEFT_ALIGNMENT);
        btn.addMouseListener(new MouseAdapter() {
            @Override public void mouseEntered(MouseEvent e) { btn.setForeground(Color.WHITE); }
            @Override public void mouseExited(MouseEvent e)  { btn.setForeground(new Color(200, 240, 200)); }
        });
        btn.addActionListener(e -> toggleSidebar());
        return btn;
    }

    private void toggleSidebar() {
        sidebarCollapsed = !sidebarCollapsed;
        int targetWidth = sidebarCollapsed ? SIDEBAR_COLLAPSED : SIDEBAR_EXPANDED;

        // Animate sidebar width
        int currentWidth = sidebarPanel.getPreferredSize().width;
        int steps = 8;
        int delta = (targetWidth - currentWidth) / steps;

        Timer anim = new Timer(16, null);
        int[] step = {0};
        anim.addActionListener(e -> {
            step[0]++;
            int newW = currentWidth + delta * step[0];
            if (step[0] >= steps) {
                newW = targetWidth;
                anim.stop();
            }
            sidebarPanel.setPreferredSize(new Dimension(newW, sidebarPanel.getHeight()));
            // Show/hide text labels and dividers
            boolean show = !sidebarCollapsed;
            for (NavItem ni : navItems) {
                ni.textLabel.setVisible(show);
            }
            // Hide divider labels
            for (Component c : sidebarPanel.getComponents()) {
                if (c instanceof JLabel lbl && Boolean.TRUE.equals(lbl.getClientProperty("isDivider"))) {
                    lbl.setVisible(show);
                }
            }
            sidebarPanel.revalidate();
            sidebarPanel.repaint();
        });
        anim.start();
    }

    // =========================================================================
    // STATUS BAR (bottom)
    // =========================================================================

    private JPanel createStatusBar() {
        JPanel bar = new JPanel(new BorderLayout());
        bar.setBackground(UITheme.STATUS_BAR_BG);
        bar.setPreferredSize(new Dimension(getWidth(), 28));
        bar.setBorder(new CompoundBorder(
            new MatteBorder(1, 0, 0, 0, UITheme.STATUS_BAR_BORDER),
            new EmptyBorder(4, 16, 4, 16)
        ));

        // Left: DB connection indicator
        lblDbStatus = new JLabel("● Database: Checking...");
        lblDbStatus.setFont(UITheme.FONT_STATUS_BAR);
        lblDbStatus.setForeground(UITheme.TEXT_MUTED);
        bar.add(lblDbStatus, BorderLayout.WEST);

        // Center: App name
        JLabel lblCenter = new JLabel("SPICE GARDEN  RESTAURANT BILLING SYSTEM", SwingConstants.CENTER);
        lblCenter.setFont(UITheme.FONT_STATUS_BAR);
        lblCenter.setForeground(UITheme.TEXT_SECONDARY);
        bar.add(lblCenter, BorderLayout.CENTER);

        // Right: user / role / version
        String username = UserSession.getUsername() != null ? UserSession.getUsername() : "Admin";
        String role     = UserSession.getRole()     != null ? UserSession.getRole()     : "Administrator";
        lblStatusUser = new JLabel("User: " + username + "   Role: " + role + "   Version: 2.0.0");
        lblStatusUser.setFont(UITheme.FONT_STATUS_BAR);
        lblStatusUser.setForeground(UITheme.TEXT_SECONDARY);
        bar.add(lblStatusUser, BorderLayout.EAST);

        return bar;
    }

    private void checkDbStatusAsync() {
        SwingWorker<Boolean, Void> worker = new SwingWorker<>() {
            @Override protected Boolean doInBackground() { return DatabaseConnection.testConnection(); }
            @Override protected void done() {
                try {
                    boolean connected = get();
                    if (connected) {
                        lblDbStatus.setText("● Database: Connected");
                        lblDbStatus.setForeground(UITheme.PRIMARY);
                    } else {
                        lblDbStatus.setText("● Database: Disconnected");
                        lblDbStatus.setForeground(UITheme.DANGER);
                    }
                } catch (Exception e) {
                    lblDbStatus.setText("● Database: Error");
                    lblDbStatus.setForeground(UITheme.DANGER);
                }
            }
        };
        worker.execute();

        // Re-check every 30 seconds
        new Timer(30_000, e -> {
            SwingWorker<Boolean, Void> w = new SwingWorker<>() {
                @Override protected Boolean doInBackground() { return DatabaseConnection.testConnection(); }
                @Override protected void done() {
                    try {
                        boolean c = get();
                        lblDbStatus.setText(c ? "● Database: Connected" : "● Database: Disconnected");
                        lblDbStatus.setForeground(c ? UITheme.PRIMARY : UITheme.DANGER);
                    } catch (Exception ignored) {}
                }
            };
            w.execute();
        }).start();
    }

    // =========================================================================
    // CLOCK TIMER
    // =========================================================================

    private void startClockTimer() {
        SimpleDateFormat timeFmt = new SimpleDateFormat("hh:mm:ss a");
        Timer timer = new Timer(1000, e -> {
            lblHeaderClock.setText("🕐  " + timeFmt.format(new Date()));
        });
        timer.setInitialDelay(0);
        timer.start();
    }

    // =========================================================================
    // NAVIGATION METHODS
    // =========================================================================

    public void showDashboardPanel() {
        setActiveNavByIndex(0);
        dashboardPanel.refreshStats();
        cardLayout.show(mainContentPanel, "DASHBOARD");
    }

    public void showMenuPanel() {
        setActiveNavByIndex(1);
        menuPanel.loadItems();
        cardLayout.show(mainContentPanel, "MENU");
    }

    public void showCustomerPanel() {
        setActiveNavByIndex(2);
        customerPanel.loadCustomersAsync();
        cardLayout.show(mainContentPanel, "CUSTOMERS");
    }

    public void showOrderPanel() {
        setActiveNavByIndex(3);
        orderPanel.refreshData();
        cardLayout.show(mainContentPanel, "ORDERS");
    }

    public void showBillingPanel() {
        setActiveNavByIndex(4);
        billingPanel.refreshData();
        cardLayout.show(mainContentPanel, "BILLING");
    }

    public void showReportsPanel() {
        setActiveNavByIndex(5);
        reportsPanel.loadAllReportsAsync();
        cardLayout.show(mainContentPanel, "REPORTS");
    }

    public void showSettingsPanel() {
        setActiveNavByIndex(6);
        settingsPanel.loadSettingsToForm();
        cardLayout.show(mainContentPanel, "SETTINGS");
    }

    public void showMaintenancePanel() {
        setActiveNavByIndex(7);
        maintenancePanel.refreshAllDataAsync();
        cardLayout.show(mainContentPanel, "MAINTENANCE");
    }

    public void showAuditLogPanel() {
        setActiveNavByIndex(8);
        auditPanel.loadAuditLogsAsync();
        cardLayout.show(mainContentPanel, "AUDIT");
    }

    public void showCalendarPanel() {
        setActiveNavByIndex(10);
        cardLayout.show(mainContentPanel, "CALENDAR");
    }

    private void showUserManagementPlaceholder() {
        setActiveNavByIndex(9);
        JOptionPane.showMessageDialog(this,
            "User Management module is coming soon.\n\nUse Settings → User Administration for now.",
            "User Management",
            JOptionPane.INFORMATION_MESSAGE);
        // Revert to dashboard
        showDashboardPanel();
    }

    private void setActiveNavByIndex(int index) {
        if (index >= 0 && index < navItems.size()) {
            setActiveNavItem(navItems.get(index));
        }
    }

    // =========================================================================
    // LOGOUT
    // =========================================================================

    private void onLogout() {
        boolean confirmed = CustomDialogs.showConfirm(this,
            "Are you sure you want to sign out from the system?",
            "Confirm Sign Out",
            "Sign Out",
            "Stay Signed In");

        if (confirmed) {
            UserSession.logout();
            dispose();
            SwingUtilities.invokeLater(() -> new LoginFrame().setVisible(true));
        }
    }
}
