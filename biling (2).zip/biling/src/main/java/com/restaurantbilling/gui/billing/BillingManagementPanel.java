package com.restaurantbilling.gui.billing;

import com.restaurantbilling.exception.ValidationException;
import com.restaurantbilling.gui.theme.UIHelper;
import com.restaurantbilling.gui.theme.UITheme;
import com.restaurantbilling.gui.util.CustomDialogs;
import com.restaurantbilling.model.Bill;
import com.restaurantbilling.model.Order;
import com.restaurantbilling.service.BillingService;
import com.restaurantbilling.service.OrderService;
import com.restaurantbilling.util.FormatUtil;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class BillingManagementPanel extends JPanel {

    private final BillingService billingService;
    private final OrderService orderService;

    private final JTabbedPane tabbedPane;
    private final BillHistoryPanel billHistoryPanel;

    // Order selection for billing
    private List<Order> unbilledOrders = new ArrayList<>();
    private JTable ordersTable;
    private DefaultTableModel ordersTableModel;
    private JButton btnGenerateBill;
    private JButton btnViewExistingBill;
    private JLabel lblOrderStatus;

    private static final String[] ORDER_COLS = {
        "Order ID", "Customer", "Date & Time", "Subtotal", "Discount", "Tax", "Total Amount", "Order Status", "Billing Status"
    };

    public BillingManagementPanel() {
        this.billingService = new BillingService();
        this.orderService = new OrderService();

        setLayout(new BorderLayout());
        setBackground(UITheme.APP_BG);

        tabbedPane = new JTabbedPane();
        tabbedPane.setFont(UITheme.FONT_SECTION);

        JPanel generateBillTab = createGenerateBillTab();
        billHistoryPanel = new BillHistoryPanel(billingService);

        tabbedPane.addTab("  🧾 Generate Bill / Invoice  ", generateBillTab);
        tabbedPane.addTab("  📋 Bill History & Archive  ", billHistoryPanel);

        add(tabbedPane, BorderLayout.CENTER);
        loadOrdersForBilling();
    }

    private JPanel createGenerateBillTab() {
        JPanel panel = new JPanel(new BorderLayout(15, 15));
        panel.setBorder(new EmptyBorder(16, 20, 16, 20));
        panel.setBackground(UITheme.APP_BG);

        // Header & Instructions Card
        JPanel topPanel = new JPanel(new BorderLayout(10, 8));
        topPanel.setOpaque(false);

        JPanel titlePanel = new JPanel(new GridLayout(2, 1, 0, 3));
        titlePanel.setOpaque(false);

        JLabel lblTitle = new JLabel("Generate Customer Bill / Invoice");
        lblTitle.setFont(UITheme.FONT_TITLE_LARGE);
        lblTitle.setForeground(UITheme.TEXT_PRIMARY);
        titlePanel.add(lblTitle);

        JLabel lblHelp = new JLabel("Select an order from the list below to generate, finalize, and print its customer bill.");
        lblHelp.setFont(UITheme.FONT_BODY_MEDIUM);
        lblHelp.setForeground(UITheme.TEXT_SECONDARY);
        titlePanel.add(lblHelp);

        topPanel.add(titlePanel, BorderLayout.NORTH);
        panel.add(topPanel, BorderLayout.NORTH);

        // Center Table Card
        JPanel centerCard = new JPanel(new BorderLayout());
        centerCard.setBackground(UITheme.CARD_BG);
        centerCard.setBorder(new LineBorder(UITheme.BORDER, 1, true));

        ordersTableModel = new DefaultTableModel(ORDER_COLS, 0) {
            @Override
            public boolean isCellEditable(int row, int col) {
                return false;
            }
        };

        ordersTable = new JTable(ordersTableModel);
        UIHelper.styleTable(ordersTable);

        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(SwingConstants.CENTER);
        ordersTable.getColumnModel().getColumn(0).setPreferredWidth(60);
        ordersTable.getColumnModel().getColumn(0).setCellRenderer(centerRenderer);

        ordersTable.getColumnModel().getColumn(1).setPreferredWidth(160);
        ordersTable.getColumnModel().getColumn(2).setPreferredWidth(140);
        ordersTable.getColumnModel().getColumn(2).setCellRenderer(centerRenderer);

        DefaultTableCellRenderer rightRenderer = new DefaultTableCellRenderer();
        rightRenderer.setHorizontalAlignment(SwingConstants.RIGHT);
        ordersTable.getColumnModel().getColumn(3).setPreferredWidth(90);
        ordersTable.getColumnModel().getColumn(3).setCellRenderer(rightRenderer);
        ordersTable.getColumnModel().getColumn(4).setPreferredWidth(80);
        ordersTable.getColumnModel().getColumn(4).setCellRenderer(rightRenderer);
        ordersTable.getColumnModel().getColumn(5).setPreferredWidth(80);
        ordersTable.getColumnModel().getColumn(5).setCellRenderer(rightRenderer);
        ordersTable.getColumnModel().getColumn(6).setPreferredWidth(100);
        ordersTable.getColumnModel().getColumn(6).setCellRenderer(rightRenderer);

        ordersTable.getColumnModel().getColumn(7).setPreferredWidth(110);
        ordersTable.getColumnModel().getColumn(7).setCellRenderer(UIHelper.createStatusCellRenderer());

        ordersTable.getColumnModel().getColumn(8).setPreferredWidth(110);
        ordersTable.getColumnModel().getColumn(8).setCellRenderer(UIHelper.createStatusCellRenderer());

        ordersTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                int row = ordersTable.getSelectedRow();
                boolean selected = (row >= 0 && row < unbilledOrders.size());
                if (selected) {
                    Order ord = unbilledOrders.get(row);
                    boolean isBilled = billingService.isOrderAlreadyBilled(ord.getId());
                    btnGenerateBill.setEnabled(!isBilled && !"CANCELLED".equalsIgnoreCase(ord.getStatus()));
                    btnViewExistingBill.setEnabled(isBilled);
                } else {
                    btnGenerateBill.setEnabled(false);
                    btnViewExistingBill.setEnabled(false);
                }
            }
        });

        JScrollPane scrollPane = new JScrollPane(ordersTable);
        UIHelper.styleScrollPane(scrollPane);
        centerCard.add(scrollPane, BorderLayout.CENTER);
        panel.add(centerCard, BorderLayout.CENTER);

        // South Actions Toolbar
        JPanel southPanel = new JPanel(new BorderLayout(10, 10));
        southPanel.setOpaque(false);

        JPanel actionPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));
        actionPanel.setOpaque(false);

        btnGenerateBill = UIHelper.createSuccessButton("🧾 GENERATE BILL ➔");
        btnGenerateBill.setPreferredSize(new Dimension(170, 36));
        btnGenerateBill.setEnabled(false);
        btnGenerateBill.addActionListener(e -> onGenerateBill());
        actionPanel.add(btnGenerateBill);

        btnViewExistingBill = UIHelper.createSecondaryButton("View Existing Bill");
        btnViewExistingBill.setPreferredSize(new Dimension(150, 36));
        btnViewExistingBill.setEnabled(false);
        btnViewExistingBill.addActionListener(e -> onViewExistingBill());
        actionPanel.add(btnViewExistingBill);

        JButton btnRefresh = UIHelper.createSecondaryButton("Refresh Orders");
        btnRefresh.setPreferredSize(new Dimension(130, 36));
        btnRefresh.addActionListener(e -> loadOrdersForBilling());
        actionPanel.add(btnRefresh);

        southPanel.add(actionPanel, BorderLayout.NORTH);

        lblOrderStatus = new JLabel("Loading orders...");
        lblOrderStatus.setFont(UITheme.FONT_SMALL);
        lblOrderStatus.setForeground(UITheme.TEXT_SECONDARY);
        southPanel.add(lblOrderStatus, BorderLayout.SOUTH);

        panel.add(southPanel, BorderLayout.SOUTH);

        return panel;
    }

    public void loadOrdersForBilling() {
        lblOrderStatus.setText("Fetching orders...");
        SwingWorker<List<Order>, Void> worker = new SwingWorker<>() {
            @Override
            protected List<Order> doInBackground() {
                return orderService.getAllOrders();
            }

            @Override
            protected void done() {
                try {
                    unbilledOrders = get();
                    renderOrdersTable(unbilledOrders);
                    lblOrderStatus.setText("Total Orders Available for Billing: " + unbilledOrders.size());
                } catch (Exception ex) {
                    lblOrderStatus.setText("Error loading orders: " + ex.getMessage());
                }
            }
        };
        worker.execute();
    }

    private void renderOrdersTable(List<Order> list) {
        ordersTableModel.setRowCount(0);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");

        for (Order o : list) {
            boolean isBilled = billingService.isOrderAlreadyBilled(o.getId());
            String dateStr = (o.getOrderDate() != null) ? sdf.format(o.getOrderDate()) : "-";
            String cust = (o.getCustomerName() != null) ? o.getCustomerName() : "Walk-in";

            ordersTableModel.addRow(new Object[]{
                "#" + o.getId(),
                cust,
                dateStr,
                FormatUtil.formatCurrency(o.getSubtotal()),
                FormatUtil.formatCurrency(o.getDiscount()),
                FormatUtil.formatCurrency(o.getTax()),
                FormatUtil.formatCurrency(o.getTotal()),
                o.getStatus(),
                isBilled ? "Yes (Billed)" : "Unbilled"
            });
        }
    }

    private Order getSelectedOrder() {
        int row = ordersTable.getSelectedRow();
        if (row >= 0 && row < unbilledOrders.size()) {
            return unbilledOrders.get(row);
        }
        return null;
    }

    private void onGenerateBill() {
        Order selected = getSelectedOrder();
        if (selected == null) return;

        if (billingService.isOrderAlreadyBilled(selected.getId())) {
            CustomDialogs.showWarning(this,
                "This order has already been billed. Please click 'View Existing Bill'.",
                "Duplicate Bill Prevention");
            return;
        }

        boolean confirm = CustomDialogs.showConfirm(this,
            "Generate finalized bill for Order #" + selected.getId() + " (" + FormatUtil.formatCurrency(selected.getTotal()) + ")?",
            "Confirm Bill Generation",
            "Generate Bill",
            "Cancel");

        if (confirm) {
            try {
                Bill bill = billingService.generateBillForOrder(selected.getId());
                loadOrdersForBilling();
                billHistoryPanel.loadBillsAsync();

                Window parent = SwingUtilities.getWindowAncestor(this);
                BillDetailsDialog dialog = new BillDetailsDialog(parent, bill, true);
                dialog.setVisible(true);
            } catch (ValidationException ex) {
                CustomDialogs.showWarning(this, ex.getMessage(), "Billing Notice");
            } catch (Exception ex) {
                CustomDialogs.showError(this, "Failed to generate bill: " + ex.getMessage(), "Billing Error");
            }
        }
    }

    private void onViewExistingBill() {
        Order selected = getSelectedOrder();
        if (selected == null) return;

        Optional<Bill> billOpt = billingService.getBillByOrderId(selected.getId());
        if (billOpt.isPresent()) {
            Window parent = SwingUtilities.getWindowAncestor(this);
            BillDetailsDialog dialog = new BillDetailsDialog(parent, billOpt.get(), false);
            dialog.setVisible(true);
        } else {
            CustomDialogs.showInfo(this, "No finalized bill found for this order.", "Notice");
        }
    }

    public void refreshData() {
        loadOrdersForBilling();
        billHistoryPanel.loadBillsAsync();
    }
}
