package com.restaurantbilling.gui.settings;

import com.restaurantbilling.exception.ValidationException;
import com.restaurantbilling.gui.theme.UIHelper;
import com.restaurantbilling.gui.theme.UITheme;
import com.restaurantbilling.gui.util.CustomDialogs;
import com.restaurantbilling.model.RestaurantSettings;
import com.restaurantbilling.service.SettingsService;
import com.restaurantbilling.util.UserSession;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.*;
import java.io.File;

public class SettingsPanel extends JPanel {

    private final SettingsService settingsService;

    // Form inputs - General
    private JTextField txtRestaurantName;
    private JTextField txtAddress;
    private JTextField txtCity;
    private JTextField txtState;
    private JTextField txtPincode;
    private JTextField txtPhone;
    private JTextField txtEmail;
    private JTextField txtWebsite;

    // Form inputs - Branding
    private JTextField txtInvoiceHeader;
    private JTextField txtInvoiceFooter;
    private String currentLogoPath = "";
    private JLabel lblLogoPreview;
    private JButton btnChooseLogo;
    private JButton btnRemoveLogo;

    // Form inputs - Billing Config
    private JTextField txtCurrencySymbol;
    private JTextField txtTaxRate;

    // Action buttons
    private JButton btnSave;
    private JButton btnReset;
    private JLabel lblRoleNotice;

    public SettingsPanel() {
        this.settingsService = new SettingsService();

        setLayout(new BorderLayout(15, 15));
        setBorder(new EmptyBorder(16, 20, 16, 20));
        setBackground(UITheme.APP_BG);

        initComponents();
        loadSettingsToForm();
    }

    private void initComponents() {
        // TOP: Header & Access status
        JPanel topPanel = new JPanel(new BorderLayout(10, 5));
        topPanel.setOpaque(false);

        JPanel titlePanel = new JPanel(new GridLayout(2, 1, 0, 3));
        titlePanel.setOpaque(false);

        JLabel lblTitle = new JLabel("System Settings & Restaurant Configuration");
        lblTitle.setFont(UITheme.FONT_TITLE_LARGE);
        lblTitle.setForeground(UITheme.TEXT_PRIMARY);
        titlePanel.add(lblTitle);

        JLabel lblSub = new JLabel("Configure restaurant business details, receipt formatting, and security parameters.");
        lblSub.setFont(UITheme.FONT_BODY_MEDIUM);
        lblSub.setForeground(UITheme.TEXT_SECONDARY);
        titlePanel.add(lblSub);

        topPanel.add(titlePanel, BorderLayout.WEST);

        boolean isAdmin = UserSession.isAdmin();
        lblRoleNotice = UIHelper.createStatusBadge(
            isAdmin ? "ADMIN: Full Edit Access" : "STAFF: Read-Only Mode",
            isAdmin ? UITheme.SUCCESS_BG : UITheme.WARNING_BG,
            isAdmin ? UITheme.SUCCESS_DARK : UITheme.WARNING_DARK
        );
        topPanel.add(lblRoleNotice, BorderLayout.EAST);

        add(topPanel, BorderLayout.NORTH);

        // CENTER: Tabbed Settings Form
        JTabbedPane tabbedPane = new JTabbedPane();
        tabbedPane.setFont(UITheme.FONT_SECTION);

        tabbedPane.addTab("  🏢 General Profile  ", createGeneralTab());
        tabbedPane.addTab("  🎨 Branding & Logo  ", createBrandingTab());
        tabbedPane.addTab("  🧾 Billing Config  ", createBillingConfigTab());
        tabbedPane.addTab("  🔒 Security & Account  ", createSecurityTab());
        tabbedPane.addTab("  ℹ️ System Information  ", createSystemInfoTab());

        add(tabbedPane, BorderLayout.CENTER);

        // SOUTH: Action Buttons
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 12, 10));
        bottomPanel.setOpaque(false);

        btnReset = UIHelper.createSecondaryButton("Reset to Saved");
        btnReset.addActionListener(e -> loadSettingsToForm());
        bottomPanel.add(btnReset);

        btnSave = UIHelper.createPrimaryButton("Save Configuration");
        btnSave.setPreferredSize(new Dimension(160, 36));
        btnSave.setEnabled(isAdmin);
        btnSave.addActionListener(e -> onSaveSettings());
        bottomPanel.add(btnSave);

        add(bottomPanel, BorderLayout.SOUTH);
    }

    private JPanel createSecurityTab() {
        JPanel panel = new JPanel(new BorderLayout(15, 15));
        panel.setBackground(UITheme.CARD_BG);
        panel.setBorder(UITheme.BORDER_CARD);

        JPanel infoGrid = new JPanel(new GridLayout(4, 2, 10, 15));
        infoGrid.setOpaque(false);

        addInfoRow(infoGrid, "Active User Account:", UserSession.getUsername());
        addInfoRow(infoGrid, "Assigned Role:", UserSession.getRole());
        addInfoRow(infoGrid, "Login Timestamp:", UserSession.getFormattedLoginTime());
        addInfoRow(infoGrid, "Password Security:", "SHA-256 Cryptographic Hash");

        panel.add(infoGrid, BorderLayout.NORTH);

        JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 15));
        btnRow.setOpaque(false);

        JButton btnChangePassword = UIHelper.createPrimaryButton("🔑 Change Account Password");
        btnChangePassword.addActionListener(e -> {
            Frame owner = (Frame) SwingUtilities.getWindowAncestor(this);
            new ChangePasswordDialog(owner).setVisible(true);
        });
        btnRow.add(btnChangePassword);

        panel.add(btnRow, BorderLayout.CENTER);

        return panel;
    }

    private JPanel createGeneralTab() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(UITheme.CARD_BG);
        panel.setBorder(UITheme.BORDER_CARD);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(8, 8, 8, 8);

        txtRestaurantName = new JTextField(25);
        UIHelper.styleTextField(txtRestaurantName);
        txtAddress = new JTextField(25);
        UIHelper.styleTextField(txtAddress);
        txtCity = new JTextField(25);
        UIHelper.styleTextField(txtCity);
        txtState = new JTextField(25);
        UIHelper.styleTextField(txtState);
        txtPincode = new JTextField(25);
        UIHelper.styleTextField(txtPincode);
        txtPhone = new JTextField(25);
        UIHelper.styleTextField(txtPhone);
        txtEmail = new JTextField(25);
        UIHelper.styleTextField(txtEmail);
        txtWebsite = new JTextField(25);
        UIHelper.styleTextField(txtWebsite);

        int row = 0;
        addFormRow(panel, gbc, row++, "Restaurant Name *:", txtRestaurantName);
        addFormRow(panel, gbc, row++, "Street Address:", txtAddress);
        addFormRow(panel, gbc, row++, "City:", txtCity);
        addFormRow(panel, gbc, row++, "State / Province:", txtState);
        addFormRow(panel, gbc, row++, "Postal PIN Code:", txtPincode);
        addFormRow(panel, gbc, row++, "Contact Phone:", txtPhone);
        addFormRow(panel, gbc, row++, "Email Address:", txtEmail);
        addFormRow(panel, gbc, row++, "Official Website:", txtWebsite);

        // Fill remaining space
        gbc.gridx = 0;
        gbc.gridy = row;
        gbc.weighty = 1.0;
        panel.add(Box.createGlue(), gbc);

        return panel;
    }

    private JPanel createBrandingTab() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(UITheme.CARD_BG);
        panel.setBorder(UITheme.BORDER_CARD);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(8, 8, 8, 8);

        txtInvoiceHeader = new JTextField(25);
        UIHelper.styleTextField(txtInvoiceHeader);
        txtInvoiceFooter = new JTextField(25);
        UIHelper.styleTextField(txtInvoiceFooter);

        int row = 0;
        addFormRow(panel, gbc, row++, "Invoice Title / Header:", txtInvoiceHeader);
        addFormRow(panel, gbc, row++, "Invoice Footer / Note:", txtInvoiceFooter);

        // Logo section
        gbc.gridx = 0;
        gbc.gridy = row++;
        gbc.weightx = 0.3;
        JLabel lblLogo = new JLabel("Restaurant Logo:");
        lblLogo.setFont(UITheme.FONT_BODY_BOLD);
        lblLogo.setForeground(UITheme.TEXT_PRIMARY);
        panel.add(lblLogo, gbc);

        gbc.gridx = 1;
        gbc.weightx = 0.7;
        JPanel logoPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        logoPanel.setOpaque(false);

        lblLogoPreview = new JLabel("No Logo");
        lblLogoPreview.setHorizontalAlignment(SwingConstants.CENTER);
        lblLogoPreview.setPreferredSize(new Dimension(100, 100));
        lblLogoPreview.setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY));
        logoPanel.add(lblLogoPreview);

        JPanel btnPanel = new JPanel(new GridLayout(2, 1, 0, 5));
        btnPanel.setOpaque(false);

        btnChooseLogo = UIHelper.createSecondaryButton("Choose Logo...");
        btnChooseLogo.addActionListener(e -> chooseLogo());
        btnPanel.add(btnChooseLogo);

        btnRemoveLogo = UIHelper.createSecondaryButton("Remove Logo");
        btnRemoveLogo.addActionListener(e -> removeLogo());
        btnPanel.add(btnRemoveLogo);

        logoPanel.add(btnPanel);
        panel.add(logoPanel, gbc);

        gbc.gridx = 0;
        gbc.gridy = row;
        gbc.weighty = 1.0;
        panel.add(Box.createGlue(), gbc);

        return panel;
    }

    private JPanel createBillingConfigTab() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(UITheme.CARD_BG);
        panel.setBorder(UITheme.BORDER_CARD);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(8, 8, 8, 8);

        txtCurrencySymbol = new JTextField(10);
        UIHelper.styleTextField(txtCurrencySymbol);
        txtTaxRate = new JTextField(10);
        UIHelper.styleTextField(txtTaxRate);

        int row = 0;
        addFormRow(panel, gbc, row++, "Display Currency Symbol:", txtCurrencySymbol);
        addFormRow(panel, gbc, row++, "Default Tax Rate (%):", txtTaxRate);

        gbc.gridx = 0;
        gbc.gridy = row;
        gbc.weighty = 1.0;
        panel.add(Box.createGlue(), gbc);

        return panel;
    }

    private JPanel createSystemInfoTab() {
        JPanel panel = new JPanel(new GridLayout(6, 2, 10, 15));
        panel.setBackground(UITheme.CARD_BG);
        panel.setBorder(UITheme.BORDER_CARD);

        addInfoRow(panel, "Application Suite:", "Restaurant Billing & POS System (Phase 17)");
        addInfoRow(panel, "Architecture:", "Java 21 Swing (MVC + DAO) + MySQL 8.x");
        addInfoRow(panel, "Active Database:", "restaurant_billing (JDBC Connection Pool)");
        addInfoRow(panel, "Date/Time Format:", "YYYY-MM-DD HH:mm:ss (ISO Standard)");
        addInfoRow(panel, "Payment Module Status:", "DISABLED (Strict Billing & Invoice only)");
        addInfoRow(panel, "Configuration Cache:", "In-Memory Dynamic Singleton (ApplicationSettings)");

        return panel;
    }

    private void addFormRow(JPanel panel, GridBagConstraints gbc, int row, String labelText, JTextField textField) {
        gbc.gridx = 0;
        gbc.gridy = row;
        gbc.weightx = 0.3;
        JLabel lbl = new JLabel(labelText);
        lbl.setFont(UITheme.FONT_BODY_BOLD);
        lbl.setForeground(UITheme.TEXT_PRIMARY);
        panel.add(lbl, gbc);

        gbc.gridx = 1;
        gbc.weightx = 0.7;
        panel.add(textField, gbc);
    }

    private void addInfoRow(JPanel panel, String label, String value) {
        JLabel l = new JLabel(label);
        l.setFont(UITheme.FONT_BODY_BOLD);
        l.setForeground(UITheme.TEXT_SECONDARY);
        panel.add(l);

        JLabel v = new JLabel(value);
        v.setFont(UITheme.FONT_BODY);
        v.setForeground(UITheme.TEXT_PRIMARY);
        panel.add(v);
    }

    private void chooseLogo() {
        JFileChooser chooser = new JFileChooser();
        chooser.setDialogTitle("Select Restaurant Logo");
        chooser.setFileFilter(new FileNameExtensionFilter("Image Files", "jpg", "png", "jpeg"));
        chooser.setAcceptAllFileFilterUsed(false);

        if (chooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
            File selectedFile = chooser.getSelectedFile();
            if (selectedFile.length() > 5 * 1024 * 1024) { // 5MB limit
                CustomDialogs.showWarning(this, "The selected image is too large. Please select an image under 5MB.", "File Too Large");
                return;
            }
            currentLogoPath = selectedFile.getAbsolutePath();
            updateLogoPreview();
        }
    }

    private void removeLogo() {
        currentLogoPath = "";
        updateLogoPreview();
    }

    private void updateLogoPreview() {
        if (currentLogoPath != null && !currentLogoPath.isEmpty()) {
            File f = new File(currentLogoPath);
            if (f.exists() && f.isFile()) {
                ImageIcon icon = new ImageIcon(currentLogoPath);
                Image img = icon.getImage();
                if (img != null) {
                    // Scale down to fit 100x100
                    int width = icon.getIconWidth();
                    int height = icon.getIconHeight();
                    if (width > height) {
                        height = (height * 100) / width;
                        width = 100;
                    } else {
                        width = (width * 100) / height;
                        height = 100;
                    }
                    if (width <= 0) width = 100;
                    if (height <= 0) height = 100;
                    
                    Image scaledImg = img.getScaledInstance(width, height, Image.SCALE_SMOOTH);
                    lblLogoPreview.setIcon(new ImageIcon(scaledImg));
                    lblLogoPreview.setText("");
                    return;
                }
            }
        }
        
        lblLogoPreview.setIcon(null);
        lblLogoPreview.setText("No Logo");
    }

    public void loadSettingsToForm() {
        RestaurantSettings s = settingsService.getSettings();

        txtRestaurantName.setText(s.getRestaurantName());
        txtAddress.setText(s.getAddress());
        txtCity.setText(s.getCity());
        txtState.setText(s.getState());
        txtPincode.setText(s.getPincode());
        txtPhone.setText(s.getPhone());
        txtEmail.setText(s.getEmail());
        txtWebsite.setText(s.getWebsite());

        txtInvoiceHeader.setText(s.getInvoiceHeader());
        txtInvoiceFooter.setText(s.getInvoiceFooter());
        currentLogoPath = s.getLogoPath() != null ? s.getLogoPath() : "";
        updateLogoPreview();
        
        txtCurrencySymbol.setText(s.getCurrencySymbol());
        txtTaxRate.setText(String.valueOf(s.getTaxRate()));

        boolean isAdmin = UserSession.isAdmin();
        btnSave.setEnabled(isAdmin);
        btnChooseLogo.setEnabled(isAdmin);
        btnRemoveLogo.setEnabled(isAdmin);
        txtRestaurantName.setEditable(isAdmin);
        txtAddress.setEditable(isAdmin);
        txtCity.setEditable(isAdmin);
        txtState.setEditable(isAdmin);
        txtPincode.setEditable(isAdmin);
        txtPhone.setEditable(isAdmin);
        txtEmail.setEditable(isAdmin);
        txtWebsite.setEditable(isAdmin);
        txtInvoiceHeader.setEditable(isAdmin);
        txtInvoiceFooter.setEditable(isAdmin);
        txtCurrencySymbol.setEditable(isAdmin);
        txtTaxRate.setEditable(isAdmin);
    }

    private void onSaveSettings() {
        if (!UserSession.isAdmin()) {
            CustomDialogs.showError(this, "Access Denied: Only ADMIN can configure system settings.", "Permission Denied");
            return;
        }

        try {
            RestaurantSettings s = new RestaurantSettings();
            s.setRestaurantName(txtRestaurantName.getText().trim());
            s.setAddress(txtAddress.getText().trim());
            s.setCity(txtCity.getText().trim());
            s.setState(txtState.getText().trim());
            s.setPincode(txtPincode.getText().trim());
            s.setPhone(txtPhone.getText().trim());
            s.setEmail(txtEmail.getText().trim());
            s.setWebsite(txtWebsite.getText().trim());

            s.setInvoiceHeader(txtInvoiceHeader.getText().trim());
            s.setInvoiceFooter(txtInvoiceFooter.getText().trim());
            s.setLogoPath(currentLogoPath);
            s.setCurrencySymbol(txtCurrencySymbol.getText().trim().isEmpty() ? "₹" : txtCurrencySymbol.getText().trim());

            try {
                s.setTaxRate(Double.parseDouble(txtTaxRate.getText().trim()));
            } catch (NumberFormatException e) {
                throw new ValidationException("Invalid Tax Rate. Please enter a valid decimal number (e.g., 5.0).");
            }

            settingsService.saveSettings(s);
            CustomDialogs.showSuccess(this, "System Settings and Restaurant profile saved successfully.", "Settings Saved");

        } catch (ValidationException ex) {
            CustomDialogs.showWarning(this, ex.getMessage(), "Validation Error");
        } catch (Exception ex) {
            CustomDialogs.showError(this, "Unable to save settings: " + ex.getMessage(), "Save Error");
        }
    }
}
