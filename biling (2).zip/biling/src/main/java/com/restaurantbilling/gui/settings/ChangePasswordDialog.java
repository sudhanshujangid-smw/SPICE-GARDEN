package com.restaurantbilling.gui.settings;

import com.restaurantbilling.exception.ValidationException;
import com.restaurantbilling.gui.theme.UIHelper;
import com.restaurantbilling.gui.theme.UITheme;
import com.restaurantbilling.gui.util.CustomDialogs;
import com.restaurantbilling.service.AuthenticationService;
import com.restaurantbilling.util.UserSession;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

public class ChangePasswordDialog extends JDialog {

    private final AuthenticationService authService;
    private JPasswordField txtCurrentPassword;
    private JPasswordField txtNewPassword;
    private JPasswordField txtConfirmPassword;

    public ChangePasswordDialog(Frame owner) {
        super(owner, "Change Account Password", true);
        this.authService = new AuthenticationService();

        setSize(440, 340);
        setLocationRelativeTo(owner);
        setResizable(false);

        initComponents();
    }

    private void initComponents() {
        JPanel content = new JPanel(new BorderLayout(15, 15));
        content.setBorder(new EmptyBorder(22, 26, 20, 26));
        content.setBackground(UITheme.CARD_BG);
        setContentPane(content);

        // Header
        JPanel header = new JPanel(new GridLayout(2, 1, 0, 3));
        header.setOpaque(false);

        JLabel lblHeader = new JLabel("Update Account Password");
        lblHeader.setFont(UITheme.FONT_TITLE_MEDIUM);
        lblHeader.setForeground(UITheme.TEXT_PRIMARY);
        header.add(lblHeader);

        JLabel lblSub = new JLabel("Ensure passwords are at least 6 characters long.");
        lblSub.setFont(UITheme.FONT_BODY_MEDIUM);
        lblSub.setForeground(UITheme.TEXT_SECONDARY);
        header.add(lblSub);

        content.add(header, BorderLayout.NORTH);

        // Form
        JPanel form = new JPanel(new GridBagLayout());
        form.setOpaque(false);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(6, 6, 6, 6);

        txtCurrentPassword = new JPasswordField(15);
        txtCurrentPassword.setFont(UITheme.FONT_BODY);
        txtCurrentPassword.setBorder(UITheme.BORDER_INPUT);

        txtNewPassword = new JPasswordField(15);
        txtNewPassword.setFont(UITheme.FONT_BODY);
        txtNewPassword.setBorder(UITheme.BORDER_INPUT);

        txtConfirmPassword = new JPasswordField(15);
        txtConfirmPassword.setFont(UITheme.FONT_BODY);
        txtConfirmPassword.setBorder(UITheme.BORDER_INPUT);

        int row = 0;
        addFormRow(form, gbc, row++, "Current Password *:", txtCurrentPassword);
        addFormRow(form, gbc, row++, "New Password *:", txtNewPassword);
        addFormRow(form, gbc, row++, "Confirm Password *:", txtConfirmPassword);

        content.add(form, BorderLayout.CENTER);

        // Buttons
        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        btnPanel.setOpaque(false);

        JButton btnCancel = UIHelper.createSecondaryButton("Cancel");
        btnCancel.addActionListener(e -> dispose());

        JButton btnSave = UIHelper.createPrimaryButton("Update Password");
        btnSave.addActionListener(e -> onSavePassword());

        btnPanel.add(btnCancel);
        btnPanel.add(btnSave);
        content.add(btnPanel, BorderLayout.SOUTH);
    }

    private void addFormRow(JPanel panel, GridBagConstraints gbc, int row, String label, JComponent comp) {
        gbc.gridx = 0; gbc.gridy = row; gbc.weightx = 0.38;
        JLabel l = new JLabel(label);
        l.setFont(UITheme.FONT_BODY_BOLD);
        l.setForeground(UITheme.TEXT_PRIMARY);
        panel.add(l, gbc);

        gbc.gridx = 1; gbc.weightx = 0.62;
        comp.setFont(UITheme.FONT_BODY);
        panel.add(comp, gbc);
    }

    private void onSavePassword() {
        String current = new String(txtCurrentPassword.getPassword());
        String newPass = new String(txtNewPassword.getPassword());
        String confirm = new String(txtConfirmPassword.getPassword());

        Integer userId = UserSession.getUserId();
        if (userId == null || userId <= 0) {
            CustomDialogs.showError(this, "No active user session found.", "Session Error");
            return;
        }

        try {
            boolean success = authService.changePassword(userId, current, newPass, confirm);
            if (success) {
                CustomDialogs.showSuccess(this, "Password updated successfully!", "Success");
                dispose();
            }
        } catch (ValidationException ex) {
            CustomDialogs.showWarning(this, ex.getMessage(), "Validation Error");
        } catch (Exception ex) {
            CustomDialogs.showError(this, "Failed to update password: " + ex.getMessage(), "Error");
        }
    }
}
