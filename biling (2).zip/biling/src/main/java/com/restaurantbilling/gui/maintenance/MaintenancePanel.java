package com.restaurantbilling.gui.maintenance;

import com.restaurantbilling.gui.theme.UIHelper;
import com.restaurantbilling.gui.theme.UITheme;
import com.restaurantbilling.gui.util.CustomDialogs;
import com.restaurantbilling.model.maintenance.BackupRecord;
import com.restaurantbilling.model.maintenance.DatabaseHealth;
import com.restaurantbilling.service.MaintenanceService;
import com.restaurantbilling.util.FormatUtil;
import com.restaurantbilling.util.UserSession;

import javax.swing.*;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.File;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;

public class MaintenancePanel extends JPanel {

    private final MaintenanceService maintenanceService;

    // UI - Status Card
    private JLabel lblConnectionStatus;
    private JLabel lblDbName;
    private JLabel lblDbHost;
    private JLabel lblDbVersion;

    // UI - Data Summary Card
    private JLabel lblCountMenuItems;
    private JLabel lblCountCustomers;
    private JLabel lblCountOrders;
    private JLabel lblCountBills;
    private JLabel lblCountSettings;

    // UI - Backup Card
    private JLabel lblLastBackupInfo;
    private JButton btnCreateBackup;
    private JProgressBar progressBackup;

    // UI - Restore Card
    private JLabel lblSelectedRestoreFile;
    private File selectedRestoreFile;
    private JButton btnSelectBackup;
    private JButton btnRestoreDatabase;
    private JProgressBar progressRestore;

    // UI - Health Diagnostics
    private JLabel lblHealthOverall;
    private JLabel lblHealthConnection;
    private JLabel lblHealthTables;
    private JLabel lblHealthConsistency;
    private JTextArea txtHealthDetails;
    private JButton btnRunHealthCheck;

    // UI - Backup History
    private JTable tblHistory;
    private DefaultTableModel historyTableModel;
    private JButton btnRefreshHistory;

    private JLabel lblRoleNotice;

    public MaintenancePanel() {
        this.maintenanceService = new MaintenanceService();

        setLayout(new BorderLayout(15, 15));
        setBorder(new EmptyBorder(16, 20, 16, 20));
        setBackground(UITheme.APP_BG);

        initComponents();
        refreshAllDataAsync();
    }

    private void initComponents() {
        // TOP: Header
        JPanel topPanel = new JPanel(new BorderLayout(10, 5));
        topPanel.setOpaque(false);

        JPanel titlePanel = new JPanel(new GridLayout(2, 1, 0, 3));
        titlePanel.setOpaque(false);

        JLabel lblTitle = new JLabel("System Maintenance & Data Management");
        lblTitle.setFont(UITheme.FONT_TITLE_LARGE);
        lblTitle.setForeground(UITheme.TEXT_PRIMARY);
        titlePanel.add(lblTitle);

        JLabel lblSub = new JLabel("Database backups, integrity verification, data restoration, and schema health diagnostics.");
        lblSub.setFont(UITheme.FONT_BODY_MEDIUM);
        lblSub.setForeground(UITheme.TEXT_SECONDARY);
        titlePanel.add(lblSub);

        topPanel.add(titlePanel, BorderLayout.WEST);

        boolean isAdmin = UserSession.isAdmin();
        lblRoleNotice = UIHelper.createStatusBadge(
            isAdmin ? "ADMIN: Maintenance Access" : "STAFF: Restricted / Read-Only",
            isAdmin ? UITheme.SUCCESS_BG : UITheme.DANGER_BG,
            isAdmin ? UITheme.SUCCESS_DARK : UITheme.DANGER_DARK
        );
        topPanel.add(lblRoleNotice, BorderLayout.EAST);

        add(topPanel, BorderLayout.NORTH);

        // CENTER: Main Container with ScrollPane
        JPanel contentGrid = new JPanel();
        contentGrid.setLayout(new BoxLayout(contentGrid, BoxLayout.Y_AXIS));
        contentGrid.setOpaque(false);

        // Section 1: Overview (Database Info & Summary)
        JPanel overviewRow = new JPanel(new GridLayout(1, 2, 15, 15));
        overviewRow.setOpaque(false);
        overviewRow.setMaximumSize(new Dimension(Integer.MAX_VALUE, 200));
        overviewRow.add(createDatabaseStatusCard());
        overviewRow.add(createDataSummaryCard());
        contentGrid.add(overviewRow);

        contentGrid.add(Box.createVerticalStrut(15));

        // Section 2: Backup & Restore Actions
        JPanel actionRow = new JPanel(new GridLayout(1, 2, 15, 15));
        actionRow.setOpaque(false);
        actionRow.setMaximumSize(new Dimension(Integer.MAX_VALUE, 220));
        actionRow.add(createBackupCard());
        actionRow.add(createRestoreCard());
        contentGrid.add(actionRow);

        contentGrid.add(Box.createVerticalStrut(15));

        // Section 3: Diagnostic & History Tabs
        JTabbedPane tabbedPane = new JTabbedPane();
        tabbedPane.setFont(UITheme.FONT_SECTION);
        tabbedPane.addTab("  🩺 Database Health & Diagnostics  ", createHealthDiagnosticsTab());
        tabbedPane.addTab("  🗃️ Backup History & Audit Archive  ", createBackupHistoryTab());
        contentGrid.add(tabbedPane);

        JScrollPane scrollPane = new JScrollPane(contentGrid);
        scrollPane.setBorder(null);
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);
        scrollPane.setOpaque(false);
        scrollPane.getViewport().setOpaque(false);
        add(scrollPane, BorderLayout.CENTER);
    }

    private JPanel createDatabaseStatusCard() {
        JPanel card = createBaseCard("Database Status & Information");
        card.setLayout(new GridBagLayout());

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(6, 6, 6, 6);

        lblConnectionStatus = new JLabel("● Checking...", SwingConstants.LEFT);
        lblConnectionStatus.setFont(UITheme.FONT_BODY_BOLD);
        lblConnectionStatus.setForeground(UITheme.TEXT_MUTED);

        lblDbName = new JLabel("-");
        lblDbHost = new JLabel("-");
        lblDbVersion = new JLabel("-");

        int row = 0;
        addCardInfoRow(card, gbc, row++, "Connection Status:", lblConnectionStatus);
        addCardInfoRow(card, gbc, row++, "Active Database:", lblDbName);
        addCardInfoRow(card, gbc, row++, "Server Host & Port:", lblDbHost);
        addCardInfoRow(card, gbc, row++, "Database Engine:", lblDbVersion);

        return card;
    }

    private JPanel createDataSummaryCard() {
        JPanel card = createBaseCard("Live Table Counters Summary");
        card.setLayout(new GridLayout(5, 2, 8, 8));

        lblCountMenuItems = new JLabel("0", SwingConstants.RIGHT);
        lblCountCustomers = new JLabel("0", SwingConstants.RIGHT);
        lblCountOrders = new JLabel("0", SwingConstants.RIGHT);
        lblCountBills = new JLabel("0", SwingConstants.RIGHT);
        lblCountSettings = new JLabel("0", SwingConstants.RIGHT);

        addDataSummaryRow(card, "Menu Food Items:", lblCountMenuItems);
        addDataSummaryRow(card, "Registered Customers:", lblCountCustomers);
        addDataSummaryRow(card, "Orders Processed:", lblCountOrders);
        addDataSummaryRow(card, "Bills & Invoices:", lblCountBills);
        addDataSummaryRow(card, "Configured Settings:", lblCountSettings);

        return card;
    }

    private JPanel createBackupCard() {
        JPanel card = createBaseCard("Database Backup Operations");
        card.setLayout(new BorderLayout(10, 10));

        JPanel infoPanel = new JPanel();
        infoPanel.setLayout(new BoxLayout(infoPanel, BoxLayout.Y_AXIS));
        infoPanel.setOpaque(false);

        JLabel lblDesc = new JLabel("<html>Create a complete and validated SQL dump backup of the entire restaurant database schema and data.</html>");
        lblDesc.setFont(UITheme.FONT_BODY_MEDIUM);
        lblDesc.setForeground(UITheme.TEXT_SECONDARY);
        infoPanel.add(lblDesc);
        infoPanel.add(Box.createVerticalStrut(10));

        lblLastBackupInfo = new JLabel("Last Backup: Unknown");
        lblLastBackupInfo.setFont(UITheme.FONT_SMALL);
        lblLastBackupInfo.setForeground(UITheme.TEXT_MUTED);
        infoPanel.add(lblLastBackupInfo);

        card.add(infoPanel, BorderLayout.NORTH);

        progressBackup = new JProgressBar();
        progressBackup.setIndeterminate(true);
        progressBackup.setVisible(false);
        progressBackup.setPreferredSize(new Dimension(200, 8));
        card.add(progressBackup, BorderLayout.CENTER);

        boolean isAdmin = UserSession.isAdmin();
        btnCreateBackup = UIHelper.createPrimaryButton("💾 Create SQL Backup");
        btnCreateBackup.setEnabled(isAdmin);
        btnCreateBackup.addActionListener(e -> onCreateBackupAction());

        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 0));
        btnPanel.setOpaque(false);
        btnPanel.add(btnCreateBackup);
        card.add(btnPanel, BorderLayout.SOUTH);

        return card;
    }

    private JPanel createRestoreCard() {
        JPanel card = createBaseCard("Database Restore Operations");
        card.setLayout(new BorderLayout(10, 10));

        JPanel infoPanel = new JPanel();
        infoPanel.setLayout(new BoxLayout(infoPanel, BoxLayout.Y_AXIS));
        infoPanel.setOpaque(false);

        JLabel lblDesc = new JLabel("<html>Restore database from an existing .sql backup. <b style='color:#dc2626;'>An automatic pre-restore safety backup is created first.</b></html>");
        lblDesc.setFont(UITheme.FONT_BODY_MEDIUM);
        lblDesc.setForeground(UITheme.TEXT_SECONDARY);
        infoPanel.add(lblDesc);
        infoPanel.add(Box.createVerticalStrut(10));

        lblSelectedRestoreFile = new JLabel("Selected File: None");
        lblSelectedRestoreFile.setFont(UITheme.FONT_SMALL);
        lblSelectedRestoreFile.setForeground(UITheme.TEXT_MUTED);
        infoPanel.add(lblSelectedRestoreFile);

        card.add(infoPanel, BorderLayout.NORTH);

        progressRestore = new JProgressBar();
        progressRestore.setIndeterminate(true);
        progressRestore.setVisible(false);
        progressRestore.setPreferredSize(new Dimension(200, 8));
        card.add(progressRestore, BorderLayout.CENTER);

        boolean isAdmin = UserSession.isAdmin();
        btnSelectBackup = UIHelper.createSecondaryButton("Select Backup File");
        btnSelectBackup.setEnabled(isAdmin);
        btnSelectBackup.addActionListener(e -> onSelectRestoreFileAction());

        btnRestoreDatabase = UIHelper.createDangerButton("⚠️ Restore Database");
        btnRestoreDatabase.setEnabled(isAdmin && selectedRestoreFile != null);
        btnRestoreDatabase.addActionListener(e -> onRestoreDatabaseAction());

        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        btnPanel.setOpaque(false);
        btnPanel.add(btnSelectBackup);
        btnPanel.add(btnRestoreDatabase);
        card.add(btnPanel, BorderLayout.SOUTH);

        return card;
    }

    private JPanel createHealthDiagnosticsTab() {
        JPanel panel = new JPanel(new BorderLayout(15, 15));
        panel.setBackground(UITheme.CARD_BG);
        panel.setBorder(UITheme.BORDER_CARD);

        JPanel statusGrid = new JPanel(new GridLayout(2, 2, 15, 15));
        statusGrid.setOpaque(false);

        lblHealthOverall = createBadgeLabel("OVERALL: UNKNOWN", UITheme.SECONDARY);
        lblHealthConnection = createBadgeLabel("Connection: Unknown", UITheme.SECONDARY);
        lblHealthTables = createBadgeLabel("Required Tables: Unknown", UITheme.SECONDARY);
        lblHealthConsistency = createBadgeLabel("Data Consistency: Unknown", UITheme.SECONDARY);

        statusGrid.add(lblHealthOverall);
        statusGrid.add(lblHealthConnection);
        statusGrid.add(lblHealthTables);
        statusGrid.add(lblHealthConsistency);

        panel.add(statusGrid, BorderLayout.NORTH);

        txtHealthDetails = new JTextArea();
        txtHealthDetails.setEditable(false);
        txtHealthDetails.setFont(UITheme.FONT_MONO);
        txtHealthDetails.setText("Click 'Run Health Diagnostics' to inspect database schema, tables, and data consistency.\n");
        txtHealthDetails.setBackground(new Color(252, 252, 252));
        txtHealthDetails.setBorder(new EmptyBorder(10, 14, 10, 14));

        JScrollPane scrollDetails = new JScrollPane(txtHealthDetails);
        UIHelper.styleScrollPane(scrollDetails);
        scrollDetails.setBorder(BorderFactory.createTitledBorder("Diagnostic Log & Details"));
        panel.add(scrollDetails, BorderLayout.CENTER);

        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 0));
        bottomPanel.setOpaque(false);

        btnRunHealthCheck = UIHelper.createSuccessButton("🩺 Run Health Diagnostics");
        btnRunHealthCheck.addActionListener(e -> onRunHealthCheckAction());
        bottomPanel.add(btnRunHealthCheck);

        panel.add(bottomPanel, BorderLayout.SOUTH);

        return panel;
    }

    private JPanel createBackupHistoryTab() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBackground(UITheme.CARD_BG);
        panel.setBorder(UITheme.BORDER_CARD);

        String[] columns = {"ID", "Backup Name", "Type", "File Size", "Date & Time", "Created By", "Status"};
        historyTableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        tblHistory = new JTable(historyTableModel);
        UIHelper.styleTable(tblHistory);

        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(SwingConstants.CENTER);
        tblHistory.getColumnModel().getColumn(0).setPreferredWidth(50);
        tblHistory.getColumnModel().getColumn(0).setCellRenderer(centerRenderer);
        tblHistory.getColumnModel().getColumn(2).setPreferredWidth(130);
        tblHistory.getColumnModel().getColumn(3).setPreferredWidth(90);
        tblHistory.getColumnModel().getColumn(4).setPreferredWidth(160);
        tblHistory.getColumnModel().getColumn(5).setPreferredWidth(100);
        tblHistory.getColumnModel().getColumn(6).setPreferredWidth(90);
        tblHistory.getColumnModel().getColumn(6).setCellRenderer(UIHelper.createStatusCellRenderer());

        JScrollPane scroll = new JScrollPane(tblHistory);
        UIHelper.styleScrollPane(scroll);
        panel.add(scroll, BorderLayout.CENTER);

        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 0));
        bottomPanel.setOpaque(false);

        btnRefreshHistory = UIHelper.createSecondaryButton("Refresh History");
        btnRefreshHistory.addActionListener(e -> loadBackupHistoryAsync());
        bottomPanel.add(btnRefreshHistory);

        panel.add(bottomPanel, BorderLayout.SOUTH);

        return panel;
    }

    private JPanel createBaseCard(String title) {
        JPanel card = new JPanel();
        card.setBackground(UITheme.CARD_BG);
        card.setBorder(new CompoundBorder(
            new LineBorder(UITheme.BORDER, 1, true),
            new CompoundBorder(
                BorderFactory.createTitledBorder(
                    BorderFactory.createEmptyBorder(),
                    title,
                    TitledBorder.LEFT,
                    TitledBorder.TOP,
                    UITheme.FONT_SECTION,
                    UITheme.TEXT_PRIMARY
                ),
                new EmptyBorder(8, 14, 10, 14)
            )
        ));
        return card;
    }

    private void addCardInfoRow(JPanel panel, GridBagConstraints gbc, int row, String label, JLabel valueLabel) {
        gbc.gridx = 0;
        gbc.gridy = row;
        gbc.weightx = 0.4;
        JLabel lbl = new JLabel(label);
        lbl.setFont(UITheme.FONT_BODY_BOLD);
        lbl.setForeground(UITheme.TEXT_SECONDARY);
        panel.add(lbl, gbc);

        gbc.gridx = 1;
        gbc.weightx = 0.6;
        valueLabel.setFont(UITheme.FONT_BODY);
        panel.add(valueLabel, gbc);
    }

    private void addDataSummaryRow(JPanel panel, String label, JLabel valueLabel) {
        JLabel lbl = new JLabel(label);
        lbl.setFont(UITheme.FONT_BODY);
        lbl.setForeground(UITheme.TEXT_SECONDARY);
        panel.add(lbl);

        valueLabel.setFont(UITheme.FONT_BODY_BOLD);
        valueLabel.setForeground(UITheme.PRIMARY);
        panel.add(valueLabel);
    }

    private JLabel createBadgeLabel(String text, Color bgColor) {
        JLabel label = new JLabel(text, SwingConstants.CENTER);
        label.setOpaque(true);
        label.setBackground(bgColor);
        label.setForeground(Color.WHITE);
        label.setFont(UITheme.FONT_BODY_BOLD);
        label.setPreferredSize(new Dimension(200, 36));
        label.setBorder(new EmptyBorder(6, 12, 6, 12));
        return label;
    }

    public void refreshAllDataAsync() {
        boolean isAdmin = UserSession.isAdmin();
        lblRoleNotice.setText(isAdmin ? "ADMIN: Maintenance Access" : "STAFF: Restricted / Read-Only");

        btnCreateBackup.setEnabled(isAdmin);
        btnSelectBackup.setEnabled(isAdmin);
        btnRestoreDatabase.setEnabled(isAdmin && selectedRestoreFile != null);

        loadDatabaseStatusAsync();
        loadDataSummaryAsync();
        loadBackupHistoryAsync();
    }

    private void loadDatabaseStatusAsync() {
        SwingWorker<DatabaseHealth, Void> worker = new SwingWorker<>() {
            @Override
            protected DatabaseHealth doInBackground() {
                return maintenanceService.getHealthStatus();
            }

            @Override
            protected void done() {
                try {
                    DatabaseHealth health = get();
                    if (health.isConnected()) {
                        lblConnectionStatus.setText("● Connected");
                        lblConnectionStatus.setForeground(UITheme.SUCCESS_DARK);
                        lblDbName.setText(health.getDatabaseName() != null ? health.getDatabaseName() : "restaurant_billing");
                        lblDbHost.setText(health.getServerHost() != null ? health.getServerHost() : "localhost:3306");
                        lblDbVersion.setText(health.getDatabaseVersion() != null ? health.getDatabaseVersion() : "MySQL 8.x");
                    } else {
                        lblConnectionStatus.setText("● Disconnected");
                        lblConnectionStatus.setForeground(UITheme.DANGER);
                        lblDbName.setText("-");
                        lblDbHost.setText("-");
                        lblDbVersion.setText("-");
                    }
                } catch (Exception e) {
                    lblConnectionStatus.setText("● Unavailable");
                    lblConnectionStatus.setForeground(UITheme.DANGER);
                }
            }
        };
        worker.execute();
    }

    private void loadDataSummaryAsync() {
        SwingWorker<Map<String, Long>, Void> worker = new SwingWorker<>() {
            @Override
            protected Map<String, Long> doInBackground() {
                return maintenanceService.getDataSummary();
            }

            @Override
            protected void done() {
                try {
                    Map<String, Long> counts = get();
                    lblCountMenuItems.setText(String.valueOf(counts.getOrDefault("food_items", 0L)));
                    lblCountCustomers.setText(String.valueOf(counts.getOrDefault("customers", 0L)));
                    lblCountOrders.setText(String.valueOf(counts.getOrDefault("orders", 0L)));
                    lblCountBills.setText(String.valueOf(counts.getOrDefault("bills", 0L)));
                    lblCountSettings.setText(String.valueOf(counts.getOrDefault("system_settings", 0L)));
                } catch (Exception e) {
                    lblCountMenuItems.setText("-");
                    lblCountCustomers.setText("-");
                    lblCountOrders.setText("-");
                    lblCountBills.setText("-");
                    lblCountSettings.setText("-");
                }
            }
        };
        worker.execute();
    }

    private void loadBackupHistoryAsync() {
        SwingWorker<List<BackupRecord>, Void> worker = new SwingWorker<>() {
            @Override
            protected List<BackupRecord> doInBackground() {
                return maintenanceService.getBackupHistory();
            }

            @Override
            protected void done() {
                try {
                    List<BackupRecord> records = get();
                    historyTableModel.setRowCount(0);

                    if (!records.isEmpty()) {
                        BackupRecord last = records.get(0);
                        lblLastBackupInfo.setText("Last Backup: " + last.getBackupName() + " (" + FormatUtil.formatDateTime(last.getCreatedAt()) + ")");
                    } else {
                        lblLastBackupInfo.setText("Last Backup: None");
                    }

                    for (BackupRecord r : records) {
                        String sizeStr = formatFileSize(r.getFileSizeBytes());
                        String dateStr = FormatUtil.formatDateTime(r.getCreatedAt());
                        historyTableModel.addRow(new Object[]{
                            r.getId(),
                            r.getBackupName(),
                            r.getBackupType(),
                            sizeStr,
                            dateStr,
                            r.getCreatedBy(),
                            r.getStatus()
                        });
                    }
                } catch (Exception ignored) {
                }
            }
        };
        worker.execute();
    }

    private void onCreateBackupAction() {
        if (!UserSession.isAdmin()) {
            CustomDialogs.showError(this, "Access Denied: Only administrators can create backups.", "Permission Denied");
            return;
        }

        String defaultName = "restaurant_backup_" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd_HH-mm-ss")) + ".sql";
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Save Database Backup As");
        fileChooser.setSelectedFile(new File(defaultName));
        fileChooser.setFileFilter(new FileNameExtensionFilter("SQL Backup Files (*.sql)", "sql"));

        int result = fileChooser.showSaveDialog(this);
        if (result == JFileChooser.APPROVE_OPTION) {
            File targetFile = fileChooser.getSelectedFile();
            if (!targetFile.getName().toLowerCase().endsWith(".sql")) {
                targetFile = new File(targetFile.getParentFile(), targetFile.getName() + ".sql");
            }

            btnCreateBackup.setEnabled(false);
            progressBackup.setVisible(true);

            final File finalTarget = targetFile;
            SwingWorker<BackupRecord, Void> worker = new SwingWorker<>() {
                @Override
                protected BackupRecord doInBackground() throws Exception {
                    return maintenanceService.createBackup(finalTarget, "MANUAL");
                }

                @Override
                protected void done() {
                    btnCreateBackup.setEnabled(true);
                    progressBackup.setVisible(false);
                    try {
                        BackupRecord record = get();
                        CustomDialogs.showSuccess(MaintenancePanel.this,
                            "Database backup created successfully!\n\nLocation: " + record.getBackupPath() + "\nSize: " + formatFileSize(record.getFileSizeBytes()),
                            "Backup Created");
                        loadBackupHistoryAsync();
                    } catch (Exception ex) {
                        String msg = ex.getCause() != null ? ex.getCause().getMessage() : ex.getMessage();
                        CustomDialogs.showError(MaintenancePanel.this, "Database backup failed: " + msg, "Backup Error");
                    }
                }
            };
            worker.execute();
        }
    }

    private void onSelectRestoreFileAction() {
        if (!UserSession.isAdmin()) {
            CustomDialogs.showError(this, "Access Denied: Only administrators can select and restore backups.", "Permission Denied");
            return;
        }

        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Select SQL Backup to Restore");
        fileChooser.setFileFilter(new FileNameExtensionFilter("SQL Backup Files (*.sql)", "sql"));

        int result = fileChooser.showOpenDialog(this);
        if (result == JFileChooser.APPROVE_OPTION) {
            selectedRestoreFile = fileChooser.getSelectedFile();
            lblSelectedRestoreFile.setText("Selected: " + selectedRestoreFile.getName() + " (" + formatFileSize(selectedRestoreFile.length()) + ")");
            btnRestoreDatabase.setEnabled(true);
        }
    }

    private void onRestoreDatabaseAction() {
        if (!UserSession.isAdmin()) {
            CustomDialogs.showError(this, "Access Denied: Only administrators can restore the database.", "Permission Denied");
            return;
        }

        if (selectedRestoreFile == null || !selectedRestoreFile.exists()) {
            CustomDialogs.showWarning(this, "Please select a valid .sql backup file first.", "Invalid File");
            return;
        }

        boolean confirm = CustomDialogs.showDangerConfirm(this,
            "WARNING: Database Restoration\n\n" +
            "Restoring this backup will replace existing data with contents from:\n" + selectedRestoreFile.getName() + "\n\n" +
            "An automatic safety pre-restore backup will be created first.\nAre you sure you want to proceed?",
            "Confirm Database Restore",
            "Proceed with Restore");

        if (!confirm) {
            return;
        }

        btnSelectBackup.setEnabled(false);
        btnRestoreDatabase.setEnabled(false);
        progressRestore.setVisible(true);

        SwingWorker<Boolean, Void> worker = new SwingWorker<>() {
            @Override
            protected Boolean doInBackground() throws Exception {
                return maintenanceService.restoreDatabase(selectedRestoreFile);
            }

            @Override
            protected void done() {
                btnSelectBackup.setEnabled(true);
                btnRestoreDatabase.setEnabled(true);
                progressRestore.setVisible(false);

                try {
                    boolean success = get();
                    if (success) {
                        CustomDialogs.showSuccess(MaintenancePanel.this,
                            "Database restored successfully!\nApplication settings and caches have been refreshed.",
                            "Restore Completed");
                        refreshAllDataAsync();
                    }
                } catch (Exception ex) {
                    String msg = ex.getCause() != null ? ex.getCause().getMessage() : ex.getMessage();
                    CustomDialogs.showError(MaintenancePanel.this, "Database restore failed: " + msg, "Restore Error");
                }
            }
        };
        worker.execute();
    }

    private void onRunHealthCheckAction() {
        btnRunHealthCheck.setEnabled(false);
        txtHealthDetails.setText("Running comprehensive database health diagnostics...\n");

        SwingWorker<DatabaseHealth, Void> worker = new SwingWorker<>() {
            @Override
            protected DatabaseHealth doInBackground() {
                return maintenanceService.getHealthStatus();
            }

            @Override
            protected void done() {
                btnRunHealthCheck.setEnabled(true);
                try {
                    DatabaseHealth health = get();
                    updateHealthUI(health);
                } catch (Exception ex) {
                    txtHealthDetails.append("Error executing diagnostics: " + ex.getMessage() + "\n");
                }
            }
        };
        worker.execute();
    }

    private void updateHealthUI(DatabaseHealth health) {
        StringBuilder log = new StringBuilder();
        log.append("============================================================\n");
        log.append("DATABASE DIAGNOSTIC REPORT\n");
        log.append("Checked At: ").append(FormatUtil.formatDateTime(health.getCheckedAt())).append("\n");
        log.append("============================================================\n\n");

        // 1. Connection
        if (health.isConnected()) {
            lblHealthConnection.setText("Connection: PASS");
            lblHealthConnection.setBackground(UITheme.SUCCESS_DARK);
            log.append("[PASS] Database Connection: Established (").append(health.getDatabaseName()).append(")\n");
            log.append("       Server: ").append(health.getServerHost()).append("\n");
            log.append("       Engine: ").append(health.getDatabaseVersion()).append("\n\n");
        } else {
            lblHealthConnection.setText("Connection: FAIL");
            lblHealthConnection.setBackground(UITheme.DANGER_DARK);
            log.append("[FAIL] Database Connection: Unreachable\n\n");
        }

        // 2. Required Tables
        if (health.getMissingTables().isEmpty()) {
            lblHealthTables.setText("Required Tables: PASS");
            lblHealthTables.setBackground(UITheme.SUCCESS_DARK);
            log.append("[PASS] Required Tables: All 7 required schema tables exist.\n");
            for (Map.Entry<String, Long> entry : health.getTableCounts().entrySet()) {
                log.append("       - ").append(entry.getKey()).append(": ").append(entry.getValue()).append(" records\n");
            }
            log.append("\n");
        } else {
            lblHealthTables.setText("Required Tables: FAIL");
            lblHealthTables.setBackground(UITheme.DANGER_DARK);
            log.append("[FAIL] Required Tables Missing: ").append(health.getMissingTables()).append("\n\n");
        }

        // 3. Consistency
        if (health.getConsistencyIssues().isEmpty()) {
            lblHealthConsistency.setText("Consistency: PASS");
            lblHealthConsistency.setBackground(UITheme.SUCCESS_DARK);
            log.append("[PASS] Data Consistency: No orphan records or integrity violations detected.\n\n");
        } else {
            lblHealthConsistency.setText("Consistency: WARNING");
            lblHealthConsistency.setBackground(UITheme.WARNING_DARK);
            log.append("[WARN] Data Consistency Issues Found:\n");
            for (String issue : health.getConsistencyIssues()) {
                log.append("       - ").append(issue).append("\n");
            }
            log.append("\n");
        }

        // Overall
        if (health.getStatus() == DatabaseHealth.HealthStatus.HEALTHY) {
            lblHealthOverall.setText("OVERALL: HEALTHY");
            lblHealthOverall.setBackground(UITheme.SUCCESS_DARK);
            log.append("OVERALL STATUS: HEALTHY - Database is operating normally.\n");
        } else if (health.getStatus() == DatabaseHealth.HealthStatus.WARNING) {
            lblHealthOverall.setText("OVERALL: WARNING");
            lblHealthOverall.setBackground(UITheme.WARNING_DARK);
            log.append("OVERALL STATUS: WARNING - Data consistency warnings exist.\n");
        } else {
            lblHealthOverall.setText("OVERALL: ERROR");
            lblHealthOverall.setBackground(UITheme.DANGER_DARK);
            log.append("OVERALL STATUS: ERROR - Critical database errors detected.\n");
        }

        txtHealthDetails.setText(log.toString());
    }

    private String formatFileSize(long bytes) {
        if (bytes < 1024) return bytes + " B";
        int exp = (int) (Math.log(bytes) / Math.log(1024));
        char pre = "KMGTPE".charAt(exp - 1);
        return String.format("%.2f %sB", bytes / Math.pow(1024, exp), pre);
    }
}
