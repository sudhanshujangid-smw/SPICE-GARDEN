package com.restaurantbilling.invoice;

import com.restaurantbilling.model.Bill;
import com.restaurantbilling.model.OrderItem;
import com.restaurantbilling.model.RestaurantSettings;
import com.restaurantbilling.util.ApplicationSettings;
import com.restaurantbilling.util.FormatUtil;

import java.awt.*;
import java.awt.print.*;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;

public class InvoiceGenerator implements Printable {

    private final Bill bill;
    private final RestaurantSettings settings;

    public InvoiceGenerator(Bill bill) {
        this.bill = bill;
        this.settings = ApplicationSettings.getInstance().getSettings();
    }

    /**
     * Generates a clean text receipt.
     */
    public String generateTextReceipt() {
        StringBuilder sb = new StringBuilder();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String dateStr = (bill.getBillDate() != null) ? sdf.format(bill.getBillDate()) : sdf.format(new java.util.Date());

        String rName = settings.getRestaurantName();
        String rAddr = settings.getFormattedAddress();
        String rContact = settings.getFormattedContact();
        String rFooter = settings.getInvoiceFooter();

        sb.append("====================================================\n");
        sb.append(centerText(rName, 52)).append("\n");
        if (!rAddr.isEmpty()) sb.append(centerText(rAddr, 52)).append("\n");
        if (!rContact.isEmpty()) sb.append(centerText(rContact, 52)).append("\n");
        sb.append("====================================================\n");
        sb.append(String.format("Bill No   : %-20s Order No: #%-10d\n", bill.getBillNumber(), bill.getOrderId()));
        sb.append(String.format("Date      : %-30s\n", dateStr));
        String cust = (bill.getCustomerName() != null && !bill.getCustomerName().isEmpty()) ? bill.getCustomerName() : "Walk-in Customer";
        String phone = (bill.getCustomerPhone() != null) ? bill.getCustomerPhone() : "-";
        sb.append(String.format("Customer  : %-20s Phone   : %-15s\n", cust, phone));
        sb.append("----------------------------------------------------\n");
        sb.append(String.format("%-22s %5s %10s %11s\n", "Item", "Qty", "Price", "Amount"));
        sb.append("----------------------------------------------------\n");

        if (bill.getItems() != null && !bill.getItems().isEmpty()) {
            for (OrderItem item : bill.getItems()) {
                String name = item.getFoodItemName() != null ? item.getFoodItemName() : "Item #" + item.getFoodItemId();
                if (name.length() > 22) {
                    name = name.substring(0, 20) + "..";
                }
                sb.append(String.format("%-22s %5d %10s %11s\n",
                    name,
                    item.getQuantity(),
                    FormatUtil.formatCurrency(item.getUnitPrice()),
                    FormatUtil.formatCurrency(item.getSubtotal())
                ));
            }
        }

        sb.append("----------------------------------------------------\n");
        sb.append(String.format("%-35s %15s\n", "Subtotal:", FormatUtil.formatCurrency(bill.getSubtotal())));
        sb.append(String.format("%-35s %15s\n", "Discount:", FormatUtil.formatCurrency(bill.getDiscount())));
        sb.append(String.format("%-35s %15s\n", "Tax (GST):", FormatUtil.formatCurrency(bill.getTax())));
        sb.append("====================================================\n");
        sb.append(String.format("%-35s %15s\n", "GRAND TOTAL:", FormatUtil.formatCurrency(bill.getFinalAmount())));
        sb.append("====================================================\n");
        sb.append(centerText(rFooter != null && !rFooter.isEmpty() ? rFooter : "Thank You! Visit Again", 52)).append("\n");
        sb.append("====================================================\n");

        return sb.toString();
    }

    /**
     * Generates HTML formatted invoice for viewing / web rendering / PDF.
     */
    public String generateHtmlInvoice() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String dateStr = (bill.getBillDate() != null) ? sdf.format(bill.getBillDate()) : sdf.format(new java.util.Date());
        String cust = (bill.getCustomerName() != null && !bill.getCustomerName().isEmpty()) ? bill.getCustomerName() : "Walk-in Customer";
        String phone = (bill.getCustomerPhone() != null) ? bill.getCustomerPhone() : "-";

        String rName = settings.getRestaurantName();
        String rAddr = settings.getFormattedAddress();
        String rContact = settings.getFormattedContact();
        String rFooter = settings.getInvoiceFooter();

        StringBuilder sb = new StringBuilder();
        sb.append("<!DOCTYPE html><html><head><meta charset='utf-8'><title>Invoice ").append(bill.getBillNumber()).append("</title>");
        sb.append("<style>");
        sb.append("body { font-family: 'Segoe UI', Arial, sans-serif; margin: 30px; color: #333; }");
        sb.append(".header { text-align: center; border-bottom: 2px solid #333; padding-bottom: 10px; margin-bottom: 20px; }");
        sb.append(".meta-table { width: 100%; margin-bottom: 20px; border-collapse: collapse; }");
        sb.append(".meta-table td { padding: 4px; font-size: 14px; }");
        sb.append(".items-table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }");
        sb.append(".items-table th { background-color: #f1f3f5; border-bottom: 2px solid #ccc; text-align: left; padding: 8px; }");
        sb.append(".items-table td { border-bottom: 1px solid #eee; padding: 8px; }");
        sb.append(".totals-table { width: 40%; margin-left: auto; border-collapse: collapse; margin-bottom: 25px; }");
        sb.append(".totals-table td { padding: 6px; }");
        sb.append(".grand-total { font-weight: bold; font-size: 16px; border-top: 2px solid #333; border-bottom: 2px solid #333; }");
        sb.append(".footer { text-align: center; font-style: italic; color: #666; margin-top: 30px; border-top: 1px dashed #ccc; padding-top: 10px; }");
        sb.append("</style></head><body>");

        sb.append("<div class='header'>");
        sb.append("<h2>").append(rName).append("</h2>");
        sb.append("<p>").append(rAddr).append("<br>").append(rContact).append("</p>");
        sb.append("</div>");

        sb.append("<table class='meta-table'>");
        sb.append("<tr><td><strong>Bill Number:</strong> ").append(bill.getBillNumber()).append("</td>");
        sb.append("<td><strong>Order ID:</strong> #").append(bill.getOrderId()).append("</td></tr>");
        sb.append("<tr><td><strong>Date:</strong> ").append(dateStr).append("</td>");
        sb.append("<td><strong>Customer:</strong> ").append(cust).append(" (").append(phone).append(")</td></tr>");
        sb.append("</table>");

        sb.append("<table class='items-table'>");
        sb.append("<tr><th>Item Description</th><th style='text-align:center;'>Qty</th><th style='text-align:right;'>Unit Price</th><th style='text-align:right;'>Amount</th></tr>");

        if (bill.getItems() != null) {
            for (OrderItem item : bill.getItems()) {
                String name = item.getFoodItemName() != null ? item.getFoodItemName() : "Item #" + item.getFoodItemId();
                sb.append("<tr>");
                sb.append("<td>").append(name).append("</td>");
                sb.append("<td style='text-align:center;'>").append(item.getQuantity()).append("</td>");
                sb.append("<td style='text-align:right;'>").append(FormatUtil.formatCurrency(item.getUnitPrice())).append("</td>");
                sb.append("<td style='text-align:right;'>").append(FormatUtil.formatCurrency(item.getSubtotal())).append("</td>");
                sb.append("</tr>");
            }
        }

        sb.append("</table>");

        sb.append("<table class='totals-table'>");
        sb.append("<tr><td>Subtotal:</td><td style='text-align:right;'>").append(FormatUtil.formatCurrency(bill.getSubtotal())).append("</td></tr>");
        sb.append("<tr><td>Discount:</td><td style='text-align:right;'>").append(FormatUtil.formatCurrency(bill.getDiscount())).append("</td></tr>");
        sb.append("<tr><td>Tax (GST):</td><td style='text-align:right;'>").append(FormatUtil.formatCurrency(bill.getTax())).append("</td></tr>");
        sb.append("<tr class='grand-total'><td>GRAND TOTAL:</td><td style='text-align:right;'>").append(FormatUtil.formatCurrency(bill.getFinalAmount())).append("</td></tr>");
        sb.append("</table>");

        sb.append("<div class='footer'><p>").append(rFooter != null && !rFooter.isEmpty() ? rFooter : "Thank you for dining with us!").append("</p></div>");
        sb.append("</body></html>");

        return sb.toString();
    }

    /**
     * Saves the invoice to local file system in invoices/ directory.
     */
    public File saveInvoiceFile() throws IOException {
        File dir = new File("invoices");
        if (!dir.exists()) {
            dir.mkdirs();
        }

        File file = new File(dir, "Bill_" + bill.getBillNumber() + ".txt");
        try (FileWriter writer = new FileWriter(file)) {
            writer.write(generateTextReceipt());
        }

        File htmlFile = new File(dir, "Bill_" + bill.getBillNumber() + ".html");
        try (FileWriter writer = new FileWriter(htmlFile)) {
            writer.write(generateHtmlInvoice());
        }

        File pdfFile = new File(dir, "Bill_" + bill.getBillNumber() + ".pdf");
        try {
            com.restaurantbilling.report.PdfDocumentGenerator.exportInvoiceToPdf(bill, pdfFile);
        } catch (Exception ignored) {}

        return file;
    }

    /**
     * Exports the invoice directly to a specified PDF file.
     */
    public void exportPdfInvoice(File targetFile) throws Exception {
        com.restaurantbilling.report.PdfDocumentGenerator.exportInvoiceToPdf(bill, targetFile);
    }

    /**
     * Java 2D Printable implementation for printing.
     */
    @Override
    public int print(Graphics graphics, PageFormat pageFormat, int pageIndex) throws PrinterException {
        if (pageIndex > 0) {
            return NO_SUCH_PAGE;
        }

        Graphics2D g2d = (Graphics2D) graphics;
        g2d.translate(pageFormat.getImageableX(), pageFormat.getImageableY());

        g2d.setFont(new Font("Monospaced", Font.PLAIN, 9));
        int y = 20;

        String[] lines = generateTextReceipt().split("\n");
        for (String line : lines) {
            g2d.drawString(line, 10, y);
            y += 12;
        }

        return PAGE_EXISTS;
    }

    public boolean printInvoice() {
        PrinterJob job = PrinterJob.getPrinterJob();
        job.setPrintable(this);
        if (job.printDialog()) {
            try {
                job.print();
                return true;
            } catch (PrinterException e) {
                return false;
            }
        }
        return false;
    }

    private static String centerText(String text, int width) {
        if (text == null) return "";
        if (text.length() >= width) return text;
        int leftPadding = (width - text.length()) / 2;
        return " ".repeat(leftPadding) + text;
    }
}
