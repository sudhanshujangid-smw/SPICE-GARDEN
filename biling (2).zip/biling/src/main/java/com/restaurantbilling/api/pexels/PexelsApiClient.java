package com.restaurantbilling.api.pexels;

import com.google.gson.Gson;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;

public class PexelsApiClient {

    private static final String PEXELS_API_URL = "https://api.pexels.com/v1/search";
    private final HttpClient httpClient;
    private final Gson gson;

    public PexelsApiClient() {
        this.httpClient = HttpClient.newBuilder()
                .connectTimeout(Duration.ofSeconds(10))
                .build();
        this.gson = new Gson();
    }

    public PexelsResponse searchImages(String query, int perPage) throws Exception {
        String apiKey = System.getenv("PEXELS_API_KEY");
        if (apiKey == null || apiKey.trim().isEmpty()) {
            throw new Exception("PEXELS_API_KEY environment variable is not configured.");
        }

        String encodedQuery = URLEncoder.encode(query, StandardCharsets.UTF_8.toString());
        String urlString = PEXELS_API_URL + "?query=" + encodedQuery + "&per_page=" + perPage;

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(urlString))
                .header("Authorization", apiKey)
                .GET()
                .build();

        HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
        int statusCode = response.statusCode();

        if (statusCode == 200) {
            return gson.fromJson(response.body(), PexelsResponse.class);
        } else if (statusCode == 401) {
            throw new Exception("Pexels authentication failed. Check the API key.");
        } else if (statusCode == 403) {
            throw new Exception("Pexels access denied.");
        } else if (statusCode == 429) {
            throw new Exception("Pexels request limit reached. Please try again later.");
        } else {
            throw new Exception("Pexels API request failed: HTTP " + statusCode);
        }
    }
}
