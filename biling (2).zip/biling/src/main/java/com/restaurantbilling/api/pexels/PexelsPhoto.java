package com.restaurantbilling.api.pexels;

import com.google.gson.annotations.SerializedName;

public class PexelsPhoto {
    private long id;
    private String url;
    private String photographer;
    
    @SerializedName("photographer_url")
    private String photographerUrl;
    
    private PexelsSrc src;

    public long getId() { return id; }
    public void setId(long id) { this.id = id; }

    public String getUrl() { return url; }
    public void setUrl(String url) { this.url = url; }

    public String getPhotographer() { return photographer; }
    public void setPhotographer(String photographer) { this.photographer = photographer; }

    public String getPhotographerUrl() { return photographerUrl; }
    public void setPhotographerUrl(String photographerUrl) { this.photographerUrl = photographerUrl; }

    public PexelsSrc getSrc() { return src; }
    public void setSrc(PexelsSrc src) { this.src = src; }

    public static class PexelsSrc {
        private String original;
        private String large;
        private String medium;
        private String small;
        private String tiny;

        public String getOriginal() { return original; }
        public void setOriginal(String original) { this.original = original; }
        public String getLarge() { return large; }
        public void setLarge(String large) { this.large = large; }
        public String getMedium() { return medium; }
        public void setMedium(String medium) { this.medium = medium; }
        public String getSmall() { return small; }
        public void setSmall(String small) { this.small = small; }
        public String getTiny() { return tiny; }
        public void setTiny(String tiny) { this.tiny = tiny; }
    }
}
