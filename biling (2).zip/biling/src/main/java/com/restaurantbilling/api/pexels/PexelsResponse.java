package com.restaurantbilling.api.pexels;

import java.util.List;

public class PexelsResponse {
    private int page;
    private int per_page;
    private int total_results;
    private List<PexelsPhoto> photos;

    public int getPage() { return page; }
    public void setPage(int page) { this.page = page; }

    public int getPerPage() { return per_page; }
    public void setPerPage(int per_page) { this.per_page = per_page; }

    public int getTotalResults() { return total_results; }
    public void setTotalResults(int total_results) { this.total_results = total_results; }

    public List<PexelsPhoto> getPhotos() { return photos; }
    public void setPhotos(List<PexelsPhoto> photos) { this.photos = photos; }
}
