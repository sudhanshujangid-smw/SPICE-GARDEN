package com.restaurantbilling.report;

import com.lowagie.text.*;
import com.lowagie.text.Font;
import com.lowagie.text.pdf.*;
import com.restaurantbilling.model.Bill;
import com.restaurantbilling.model.OrderItem;
import com.restaurantbilling.model.RestaurantSettings;
import com.restaurantbilling.util.ApplicationSettings;
import com.restaurantbilling.util.FormatUtil;

import java.awt.Color;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

public class PdfDocumentGenerator {

    private static final Font FONT_TITLE = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 18, Color.BLACK);
    private static final Font FONT_SUBTITLE = FontFactory.getFont(FontFactory.HELVETICA, 10, Color.DARK_GRAY);
    private static final Font FONT_HEADER = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 12, Color.BLACK);
    private static final Font FONT_TH = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 10, Color.WHITE);
    private static final Font FONT_CELL = FontFactory.getFont(FontFactory.HELVETICA, 9, Color.BLACK);
    private static final Font FONT_CELL_BOLD = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 9, Color.BLACK);
    private static final Font FONT_FOOTER = FontFactory.getFont(FontFactory.HELVETICA_OBLIQUE, 8, Color.GRAY);

    /**
     * Exports a tabular report to a professional PDF document.
     */
    public static void exportReportToPdf(String reportTitle, String dateRangeLabel, String[] headers, List<String[]> rows, String summaryText, File targetFile) throws IOException, DocumentException {
        if (targetFile.getParentFile() != null && !targetFile.getParentFile().exists()) {
            targetFile.getParentFile().mkdirs();
        }

        RestaurantSettings settings = ApplicationSettings.getInstance().getSettings();
        Document document = new Document(PageSize.A4, 36, 36, 36, 36);
        PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream(targetFile));

        document.open();

        // 1. Restaurant Header
        String logoPath = settings.getLogoPath();
        if (logoPath != null && !logoPath.isEmpty()) {
            try {
                Image logo = Image.getInstance(logoPath);
                logo.scaleToFit(100, 60);
                logo.setAlignment(Element.ALIGN_CENTER);
                document.add(logo);
            } catch (Exception ignored) {}
        }

        Paragraph rName = new Paragraph(settings.getRestaurantName(), FONT_TITLE);
        rName.setAlignment(Element.ALIGN_CENTER);
        document.add(rName);

        String addrContact = settings.getFormattedAddress();
        if (!settings.getFormattedContact().isEmpty()) {
            addrContact += (addrContact.isEmpty() ? "" : " | ") + settings.getFormattedContact();
        }
        if (!addrContact.isEmpty()) {
            Paragraph rSub = new Paragraph(addrContact, FONT_SUBTITLE);
            rSub.setAlignment(Element.ALIGN_CENTER);
            document.add(rSub);
        }

        document.add(new Paragraph(" ")); // Spacer

        // 2. Report Title & Metadata Box
        PdfPTable metaTable = new PdfPTable(2);
        metaTable.setWidthPercentage(100);
        metaTable.setWidths(new float[]{60, 40});

        PdfPCell c1 = new PdfPCell(new Phrase("REPORT: " + reportTitle.toUpperCase(), FONT_HEADER));
        c1.setBorder(Rectangle.BOTTOM);
        c1.setBorderColor(new Color(13, 110, 253));
        c1.setBorderWidth(2f);
        c1.setPaddingBottom(6f);

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String metaRight = "Period: " + (dateRangeLabel != null ? dateRangeLabel : "All Time") +
                           "\nGenerated: " + sdf.format(new Date());
        PdfPCell c2 = new PdfPCell(new Phrase(metaRight, FONT_SUBTITLE));
        c2.setHorizontalAlignment(Element.ALIGN_RIGHT);
        c2.setBorder(Rectangle.BOTTOM);
        c2.setBorderColor(new Color(13, 110, 253));
        c2.setBorderWidth(2f);
        c2.setPaddingBottom(6f);

        metaTable.addCell(c1);
        metaTable.addCell(c2);
        document.add(metaTable);

        document.add(new Paragraph(" ")); // Spacer

        // 3. Optional Summary Box
        if (summaryText != null && !summaryText.trim().isEmpty()) {
            PdfPTable sumTable = new PdfPTable(1);
            sumTable.setWidthPercentage(100);
            PdfPCell sumCell = new PdfPCell(new Phrase(summaryText, FONT_CELL_BOLD));
            sumCell.setBackgroundColor(new Color(240, 244, 248));
            sumCell.setPadding(8f);
            sumCell.setBorderColor(new Color(200, 210, 220));
            sumTable.addCell(sumCell);
            document.add(sumTable);
            document.add(new Paragraph(" "));
        }

        // 4. Data Table
        if (headers != null && headers.length > 0) {
            PdfPTable dataTable = new PdfPTable(headers.length);
            dataTable.setWidthPercentage(100);
            dataTable.setHeaderRows(1);

            // Table Headers
            for (String h : headers) {
                PdfPCell th = new PdfPCell(new Phrase(h, FONT_TH));
                th.setBackgroundColor(new Color(33, 37, 41));
                th.setPadding(6f);
                th.setHorizontalAlignment(Element.ALIGN_CENTER);
                dataTable.addCell(th);
            }

            // Data Rows
            if (rows != null && !rows.isEmpty()) {
                boolean alternate = false;
                for (String[] row : rows) {
                    Color rowBg = alternate ? new Color(248, 249, 250) : Color.WHITE;
                    alternate = !alternate;

                    for (int i = 0; i < row.length; i++) {
                        String cellVal = (i < row.length && row[i] != null) ? row[i] : "";
                        PdfPCell td = new PdfPCell(new Phrase(cellVal, FONT_CELL));
                        td.setBackgroundColor(rowBg);
                        td.setPadding(5f);
                        td.setBorderColor(new Color(222, 226, 230));

                        // Right align numeric / currency cells
                        if (cellVal.startsWith("₹") || cellVal.startsWith("$") || cellVal.matches("^-?[0-9,]+(\\.[0-9]+)?$")) {
                            td.setHorizontalAlignment(Element.ALIGN_RIGHT);
                        }
                        dataTable.addCell(td);
                    }
                }
            } else {
                PdfPCell emptyCell = new PdfPCell(new Phrase("No data available for the selected period.", FONT_CELL));
                emptyCell.setColspan(headers.length);
                emptyCell.setHorizontalAlignment(Element.ALIGN_CENTER);
                emptyCell.setPadding(12f);
                dataTable.addCell(emptyCell);
            }

            document.add(dataTable);
        }

        document.add(new Paragraph(" "));

        // 5. Document Footer
        Paragraph footer = new Paragraph("Generated by Restaurant Billing System — Confidential Business Report", FONT_FOOTER);
        footer.setAlignment(Element.ALIGN_CENTER);
        document.add(footer);

        document.close();
    }

    /**
     * Exports a professional formatted bill/invoice to PDF.
     */
    public static void exportInvoiceToPdf(Bill bill, File targetFile) throws IOException, DocumentException {
        if (targetFile.getParentFile() != null && !targetFile.getParentFile().exists()) {
            targetFile.getParentFile().mkdirs();
        }

        RestaurantSettings settings = ApplicationSettings.getInstance().getSettings();
        Document document = new Document(PageSize.A5, 28, 28, 28, 28);
        PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream(targetFile));

        document.open();

        // 1. Header
        String logoPath = settings.getLogoPath();
        if (logoPath != null && !logoPath.isEmpty()) {
            try {
                Image logo = Image.getInstance(logoPath);
                logo.scaleToFit(100, 60);
                logo.setAlignment(Element.ALIGN_CENTER);
                document.add(logo);
            } catch (Exception ignored) {}
        }

        Paragraph rName = new Paragraph(settings.getRestaurantName(), FONT_TITLE);
        rName.setAlignment(Element.ALIGN_CENTER);
        document.add(rName);

        String addrContact = settings.getFormattedAddress();
        if (!settings.getFormattedContact().isEmpty()) {
            addrContact += (addrContact.isEmpty() ? "" : " | ") + settings.getFormattedContact();
        }
        if (!addrContact.isEmpty()) {
            Paragraph rSub = new Paragraph(addrContact, FONT_SUBTITLE);
            rSub.setAlignment(Element.ALIGN_CENTER);
            document.add(rSub);
        }

        document.add(new Paragraph(" "));

        // 2. Invoice Details
        PdfPTable meta = new PdfPTable(2);
        meta.setWidthPercentage(100);
        meta.setWidths(new float[]{50, 50});

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String billDate = bill.getBillDate() != null ? sdf.format(bill.getBillDate()) : sdf.format(new Date());
        String cust = (bill.getCustomerName() != null && !bill.getCustomerName().isEmpty()) ? bill.getCustomerName() : "Walk-in Customer";
        String phone = (bill.getCustomerPhone() != null && !bill.getCustomerPhone().isEmpty()) ? bill.getCustomerPhone() : "-";

        PdfPCell c1 = new PdfPCell(new Phrase("Bill Number: " + bill.getBillNumber() + "\nOrder ID: #" + bill.getOrderId(), FONT_CELL_BOLD));
        c1.setBorder(Rectangle.NO_BORDER);
        PdfPCell c2 = new PdfPCell(new Phrase("Date: " + billDate + "\nCustomer: " + cust + " (" + phone + ")", FONT_CELL));
        c2.setHorizontalAlignment(Element.ALIGN_RIGHT);
        c2.setBorder(Rectangle.NO_BORDER);

        meta.addCell(c1);
        meta.addCell(c2);
        document.add(meta);

        document.add(new Paragraph(" "));

        // 3. Items Table
        PdfPTable table = new PdfPTable(4);
        table.setWidthPercentage(100);
        table.setWidths(new float[]{45, 15, 20, 20});

        String[] headers = {"Item", "Qty", "Price", "Amount"};
        for (String h : headers) {
            PdfPCell th = new PdfPCell(new Phrase(h, FONT_TH));
            th.setBackgroundColor(new Color(13, 110, 253));
            th.setPadding(5f);
            if (!h.equals("Item")) {
                th.setHorizontalAlignment(Element.ALIGN_RIGHT);
            }
            table.addCell(th);
        }

        if (bill.getItems() != null) {
            for (OrderItem item : bill.getItems()) {
                String name = item.getFoodItemName() != null ? item.getFoodItemName() : "Item #" + item.getFoodItemId();

                PdfPCell nameCell = new PdfPCell(new Phrase(name, FONT_CELL));
                nameCell.setPadding(4f);
                nameCell.setBorderColor(new Color(222, 226, 230));
                table.addCell(nameCell);

                PdfPCell qtyCell = new PdfPCell(new Phrase(String.valueOf(item.getQuantity()), FONT_CELL));
                qtyCell.setHorizontalAlignment(Element.ALIGN_RIGHT);
                qtyCell.setPadding(4f);
                qtyCell.setBorderColor(new Color(222, 226, 230));
                table.addCell(qtyCell);

                PdfPCell priceCell = new PdfPCell(new Phrase(FormatUtil.formatCurrency(item.getUnitPrice()), FONT_CELL));
                priceCell.setHorizontalAlignment(Element.ALIGN_RIGHT);
                priceCell.setPadding(4f);
                priceCell.setBorderColor(new Color(222, 226, 230));
                table.addCell(priceCell);

                PdfPCell totalCell = new PdfPCell(new Phrase(FormatUtil.formatCurrency(item.getSubtotal()), FONT_CELL));
                totalCell.setHorizontalAlignment(Element.ALIGN_RIGHT);
                totalCell.setPadding(4f);
                totalCell.setBorderColor(new Color(222, 226, 230));
                table.addCell(totalCell);
            }
        }
        document.add(table);

        // 4. Totals Block
        PdfPTable totalsTable = new PdfPTable(2);
        totalsTable.setWidthPercentage(60);
        totalsTable.setHorizontalAlignment(Element.ALIGN_RIGHT);
        totalsTable.setWidths(new float[]{60, 40});

        addTotalRow(totalsTable, "Subtotal:", FormatUtil.formatCurrency(bill.getSubtotal()), false);
        addTotalRow(totalsTable, "Discount:", FormatUtil.formatCurrency(bill.getDiscount()), false);
        addTotalRow(totalsTable, "Tax (GST):", FormatUtil.formatCurrency(bill.getTax()), false);
        addTotalRow(totalsTable, "GRAND TOTAL:", FormatUtil.formatCurrency(bill.getFinalAmount()), true);

        document.add(totalsTable);

        document.add(new Paragraph(" "));

        // 5. Footer
        String footerText = settings.getInvoiceFooter();
        if (footerText == null || footerText.isEmpty()) {
            footerText = "Thank You! Visit Again";
        }
        Paragraph pFooter = new Paragraph(footerText, FONT_FOOTER);
        pFooter.setAlignment(Element.ALIGN_CENTER);
        document.add(pFooter);

        document.close();
    }

    private static void addTotalRow(PdfPTable table, String label, String value, boolean isGrandTotal) {
        Font font = isGrandTotal ? FONT_CELL_BOLD : FONT_CELL;
        PdfPCell cLabel = new PdfPCell(new Phrase(label, font));
        cLabel.setBorder(isGrandTotal ? Rectangle.TOP | Rectangle.BOTTOM : Rectangle.NO_BORDER);
        cLabel.setPadding(4f);

        PdfPCell cVal = new PdfPCell(new Phrase(value, font));
        cVal.setHorizontalAlignment(Element.ALIGN_RIGHT);
        cVal.setBorder(isGrandTotal ? Rectangle.TOP | Rectangle.BOTTOM : Rectangle.NO_BORDER);
        cVal.setPadding(4f);

        table.addCell(cLabel);
        table.addCell(cVal);
    }
}
