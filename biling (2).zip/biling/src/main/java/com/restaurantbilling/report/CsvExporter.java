package com.restaurantbilling.report;

import javax.swing.table.TableModel;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

public class CsvExporter {

    /**
     * Exports a Swing TableModel to a CSV file with RFC 4180 escaping.
     */
    public static void exportTableModelToCsv(TableModel model, File targetFile) throws IOException {
        if (targetFile.getParentFile() != null && !targetFile.getParentFile().exists()) {
            targetFile.getParentFile().mkdirs();
        }

        try (PrintWriter writer = new PrintWriter(new FileWriter(targetFile))) {
            // Write Column Headers
            int colCount = model.getColumnCount();
            for (int col = 0; col < colCount; col++) {
                writer.print(escapeCsvCell(model.getColumnName(col)));
                if (col < colCount - 1) {
                    writer.print(",");
                }
            }
            writer.println();

            // Write Data Rows
            int rowCount = model.getRowCount();
            for (int row = 0; row < rowCount; row++) {
                for (int col = 0; col < colCount; col++) {
                    Object val = model.getValueAt(row, col);
                    writer.print(escapeCsvCell(val != null ? val.toString() : ""));
                    if (col < colCount - 1) {
                        writer.print(",");
                    }
                }
                writer.println();
            }
        }
    }

    /**
     * Exports arbitrary headers and row data to a CSV file.
     */
    public static void exportDataToCsv(String[] headers, List<String[]> rows, File targetFile) throws IOException {
        if (targetFile.getParentFile() != null && !targetFile.getParentFile().exists()) {
            targetFile.getParentFile().mkdirs();
        }

        try (PrintWriter writer = new PrintWriter(new FileWriter(targetFile))) {
            // Headers
            if (headers != null && headers.length > 0) {
                for (int i = 0; i < headers.length; i++) {
                    writer.print(escapeCsvCell(headers[i]));
                    if (i < headers.length - 1) writer.print(",");
                }
                writer.println();
            }

            // Rows
            if (rows != null) {
                for (String[] row : rows) {
                    for (int i = 0; i < row.length; i++) {
                        writer.print(escapeCsvCell(row[i]));
                        if (i < row.length - 1) writer.print(",");
                    }
                    writer.println();
                }
            }
        }
    }

    /**
     * Escapes a CSV cell value according to RFC 4180.
     */
    public static String escapeCsvCell(String value) {
        if (value == null) {
            return "\"\"";
        }
        boolean needQuotes = value.contains(",") || value.contains("\"") || value.contains("\n") || value.contains("\r");
        String escaped = value.replace("\"", "\"\"");
        if (needQuotes) {
            return "\"" + escaped + "\"";
        }
        return escaped;
    }
}
