package com.restaurantbilling.report;

import com.restaurantbilling.model.RestaurantSettings;
import com.restaurantbilling.model.report.*;
import com.restaurantbilling.util.ApplicationSettings;
import com.restaurantbilling.util.FormatUtil;

import java.awt.*;
import java.awt.print.*;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class ReportGenerator implements Printable {

    private final String reportTitle;
    private final String dateRangeLabel;
    private final BillSummaryDTO billSummary;
    private final OrderSummaryDTO orderSummary;
    private final CustomerSummaryDTO customerSummary;
    private final List<ItemSalesDTO> itemSalesList;

    // Optional tabular data for Phase 16 specific report types
    private String[] tableHeaders;
    private List<String[]> tableRows;

    public ReportGenerator(String reportTitle, String dateRangeLabel, BillSummaryDTO billSummary, OrderSummaryDTO orderSummary, CustomerSummaryDTO customerSummary, List<ItemSalesDTO> itemSalesList) {
        this.reportTitle = reportTitle != null ? reportTitle : "Report";
        this.dateRangeLabel = dateRangeLabel != null ? dateRangeLabel : "All Time";
        this.billSummary = (billSummary != null) ? billSummary : new BillSummaryDTO();
        this.orderSummary = (orderSummary != null) ? orderSummary : new OrderSummaryDTO();
        this.customerSummary = (customerSummary != null) ? customerSummary : new CustomerSummaryDTO();
        this.itemSalesList = itemSalesList != null ? itemSalesList : new ArrayList<>();
    }

    public ReportGenerator(String reportTitle, String dateRangeLabel, String[] tableHeaders, List<String[]> tableRows) {
        this.reportTitle = reportTitle != null ? reportTitle : "Report";
        this.dateRangeLabel = dateRangeLabel != null ? dateRangeLabel : "All Time";
        this.billSummary = new BillSummaryDTO();
        this.orderSummary = new OrderSummaryDTO();
        this.customerSummary = new CustomerSummaryDTO();
        this.itemSalesList = new ArrayList<>();
        this.tableHeaders = tableHeaders;
        this.tableRows = tableRows != null ? tableRows : new ArrayList<>();
    }

    public String generateTextReport() {
        if (tableHeaders != null && tableRows != null) {
            return generateTabularTextReport();
        }

        StringBuilder sb = new StringBuilder();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String genDate = sdf.format(new Date());
        RestaurantSettings settings = ApplicationSettings.getInstance().getSettings();

        sb.append("======================================================================\n");
        sb.append(String.format(" %-50s\n", settings.getRestaurantName().toUpperCase()));
        sb.append(String.format(" %-50s\n", "RESTAURANT BILLING & ANALYTICS REPORT"));
        sb.append(String.format(" Title: %-30s Date Range: %-20s\n", reportTitle, dateRangeLabel));
        sb.append(String.format(" Generated On: %-50s\n", genDate));
        sb.append("======================================================================\n\n");

        sb.append("--- 1. EXECUTIVE SUMMARY ---\n");
        sb.append(String.format("  Total Bills Generated : %-15d Total Billing Amount : %-15s\n", billSummary.getTotalBills(), FormatUtil.formatCurrency(billSummary.getTotalBillingAmount())));
        sb.append(String.format("  Average Bill Amount   : %-15s Highest Bill Amount : %-15s\n", FormatUtil.formatCurrency(billSummary.getAverageBillAmount()), FormatUtil.formatCurrency(billSummary.getHighestBillAmount())));
        sb.append(String.format("  Total Orders Placed   : %-15d Completed Orders     : %-15d\n", orderSummary.getTotalOrders(), orderSummary.getCompletedOrders()));
        sb.append(String.format("  Pending Orders        : %-15d Cancelled Orders     : %-15d\n", orderSummary.getPendingOrders(), orderSummary.getCancelledOrders()));
        sb.append(String.format("  Total Customers       : %-15d Active Customers      : %-15d\n\n", customerSummary.getTotalCustomers(), customerSummary.getActiveCustomers()));

        sb.append("--- 2. TOP SELLING FOOD ITEMS ---\n");
        sb.append(String.format("  %-5s %-25s %-15s %10s %15s\n", "ID", "Item Name", "Category", "Qty Sold", "Revenue"));
        sb.append("  --------------------------------------------------------------------\n");

        if (itemSalesList != null && !itemSalesList.isEmpty()) {
            for (ItemSalesDTO item : itemSalesList) {
                sb.append(String.format("  %-5d %-25s %-15s %10d %15s\n",
                    item.getFoodItemId(),
                    item.getItemName(),
                    item.getCategory(),
                    item.getQuantitySold(),
                    FormatUtil.formatCurrency(item.getRevenue())
                ));
            }
        } else {
            sb.append("  No food item sales data available for this period.\n");
        }

        sb.append("  --------------------------------------------------------------------\n\n");
        sb.append("======================================================================\n");
        sb.append("                      END OF REPORT                                   \n");
        sb.append("======================================================================\n");

        return sb.toString();
    }

    private String generateTabularTextReport() {
        StringBuilder sb = new StringBuilder();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String genDate = sdf.format(new Date());
        RestaurantSettings settings = ApplicationSettings.getInstance().getSettings();

        sb.append("======================================================================\n");
        sb.append(String.format(" %-50s\n", settings.getRestaurantName().toUpperCase()));
        sb.append(String.format(" %-50s\n", reportTitle.toUpperCase() + " REPORT"));
        sb.append(String.format(" Period: %-25s Generated: %-25s\n", dateRangeLabel, genDate));
        sb.append("======================================================================\n\n");

        if (tableHeaders != null && tableHeaders.length > 0) {
            for (String h : tableHeaders) {
                sb.append(String.format("%-18s ", h));
            }
            sb.append("\n");
            sb.append("-".repeat(Math.max(40, tableHeaders.length * 19))).append("\n");

            if (tableRows != null && !tableRows.isEmpty()) {
                for (String[] row : tableRows) {
                    for (String cell : row) {
                        sb.append(String.format("%-18s ", cell != null ? cell : ""));
                    }
                    sb.append("\n");
                }
            } else {
                sb.append("  No data available for the selected period.\n");
            }
        }

        sb.append("\n======================================================================\n");
        sb.append("                      END OF REPORT                                   \n");
        sb.append("======================================================================\n");
        return sb.toString();
    }

    public File saveReportFile() throws IOException {
        File dir = new File("reports");
        if (!dir.exists()) {
            dir.mkdirs();
        }

        String safeTitle = reportTitle.replaceAll("[^a-zA-Z0-9_-]", "_");
        String dateSuffix = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        File file = new File(dir, safeTitle + "_" + dateSuffix + ".txt");

        try (FileWriter writer = new FileWriter(file)) {
            writer.write(generateTextReport());
        }

        return file;
    }

    public void exportPdf(File targetFile, String summaryText) throws Exception {
        if (tableHeaders != null && tableRows != null) {
            PdfDocumentGenerator.exportReportToPdf(reportTitle, dateRangeLabel, tableHeaders, tableRows, summaryText, targetFile);
        } else {
            // Convert executive summary to rows
            String[] headers = {"Metric", "Value"};
            List<String[]> rows = new ArrayList<>();
            rows.add(new String[]{"Total Bills Generated", String.valueOf(billSummary.getTotalBills())});
            rows.add(new String[]{"Total Billing Amount", FormatUtil.formatCurrency(billSummary.getTotalBillingAmount())});
            rows.add(new String[]{"Average Bill Amount", FormatUtil.formatCurrency(billSummary.getAverageBillAmount())});
            rows.add(new String[]{"Highest Bill Amount", FormatUtil.formatCurrency(billSummary.getHighestBillAmount())});
            rows.add(new String[]{"Lowest Bill Amount", FormatUtil.formatCurrency(billSummary.getLowestBillAmount())});
            rows.add(new String[]{"Total Orders Placed", String.valueOf(orderSummary.getTotalOrders())});
            rows.add(new String[]{"Completed Orders", String.valueOf(orderSummary.getCompletedOrders())});
            rows.add(new String[]{"Total Customers", String.valueOf(customerSummary.getTotalCustomers())});
            rows.add(new String[]{"Active Customers", String.valueOf(customerSummary.getActiveCustomers())});

            PdfDocumentGenerator.exportReportToPdf(reportTitle, dateRangeLabel, headers, rows, summaryText, targetFile);
        }
    }

    public void exportCsv(File targetFile) throws IOException {
        if (tableHeaders != null && tableRows != null) {
            CsvExporter.exportDataToCsv(tableHeaders, tableRows, targetFile);
        } else {
            String[] headers = {"Metric", "Value"};
            List<String[]> rows = new ArrayList<>();
            rows.add(new String[]{"Total Bills Generated", String.valueOf(billSummary.getTotalBills())});
            rows.add(new String[]{"Total Billing Amount", FormatUtil.formatCurrency(billSummary.getTotalBillingAmount())});
            rows.add(new String[]{"Average Bill Amount", FormatUtil.formatCurrency(billSummary.getAverageBillAmount())});
            rows.add(new String[]{"Highest Bill Amount", FormatUtil.formatCurrency(billSummary.getHighestBillAmount())});
            rows.add(new String[]{"Lowest Bill Amount", FormatUtil.formatCurrency(billSummary.getLowestBillAmount())});
            rows.add(new String[]{"Total Orders Placed", String.valueOf(orderSummary.getTotalOrders())});
            rows.add(new String[]{"Completed Orders", String.valueOf(orderSummary.getCompletedOrders())});
            rows.add(new String[]{"Total Customers", String.valueOf(customerSummary.getTotalCustomers())});
            rows.add(new String[]{"Active Customers", String.valueOf(customerSummary.getActiveCustomers())});

            CsvExporter.exportDataToCsv(headers, rows, targetFile);
        }
    }

    @Override
    public int print(Graphics graphics, PageFormat pageFormat, int pageIndex) throws PrinterException {
        if (pageIndex > 0) {
            return NO_SUCH_PAGE;
        }

        Graphics2D g2d = (Graphics2D) graphics;
        g2d.translate(pageFormat.getImageableX(), pageFormat.getImageableY());

        g2d.setFont(new Font("Monospaced", Font.PLAIN, 8));
        int y = 20;

        String[] lines = generateTextReport().split("\n");
        for (String line : lines) {
            g2d.drawString(line, 10, y);
            y += 11;
        }

        return PAGE_EXISTS;
    }

    public boolean printReport() {
        PrinterJob job = PrinterJob.getPrinterJob();
        job.setPrintable(this);
        if (job.printDialog()) {
            try {
                job.print();
                return true;
            } catch (PrinterException e) {
                return false;
            }
        }
        return false;
    }
}
