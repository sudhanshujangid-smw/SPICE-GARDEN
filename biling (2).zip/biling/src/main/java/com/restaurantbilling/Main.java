package com.restaurantbilling;

import com.restaurantbilling.gui.LoginFrame;
import com.restaurantbilling.gui.theme.UITheme;

import javax.swing.*;
import java.awt.*;

/**
 * Spice Garden Restaurant Billing System — Application Entry Point.
 */
public class Main {
    public static void main(String[] args) {
        // Apply FlatLaf Light Look and Feel with green-tuned component styling
        try {
            // Rounded components globally
            UIManager.put("Button.arc",        10);
            UIManager.put("Component.arc",     10);
            UIManager.put("ProgressBar.arc",   10);
            UIManager.put("TextComponent.arc", 8);

            // Scrollbar styling
            UIManager.put("ScrollBar.showButtons", false);
            UIManager.put("ScrollBar.width",       8);
            UIManager.put("ScrollBar.thumbArc",    10);
            UIManager.put("ScrollBar.thumb",       UITheme.PRIMARY_LIGHT);
            UIManager.put("ScrollBar.thumbHover",  UITheme.PRIMARY_LIGHT);

            // Focus ring color — green
            UIManager.put("Component.focusColor",  UITheme.PRIMARY);

            // Default font
            UIManager.put("defaultFont", UITheme.FONT_BODY);

            // Table
            UIManager.put("Table.rowHeight", 36);

            // Selection color — light green
            UIManager.put("List.selectionBackground",     UITheme.TABLE_SELECTION_BG);
            UIManager.put("Table.selectionBackground",    UITheme.TABLE_SELECTION_BG);
            UIManager.put("Table.selectionForeground",    UITheme.TEXT_PRIMARY);
            UIManager.put("TextField.selectionBackground", UITheme.PRIMARY_LIGHT);

            com.formdev.flatlaf.FlatLightLaf.setup();

        } catch (Throwable t) {
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception ignored) {}
        }

        // Launch UI on the Event Dispatch Thread
        SwingUtilities.invokeLater(() -> {
            LoginFrame loginFrame = new LoginFrame();
            loginFrame.setVisible(true);
        });
    }
}
