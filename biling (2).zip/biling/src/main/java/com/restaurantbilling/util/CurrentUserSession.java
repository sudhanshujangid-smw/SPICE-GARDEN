package com.restaurantbilling.util;

import com.restaurantbilling.model.User;
import java.time.LocalDateTime;

/**
 * CurrentUserSession provides high-level access to the active authenticated session.
 */
public class CurrentUserSession {

    public static User getUser() {
        return UserSession.getCurrentUser();
    }

    public static Integer getUserId() {
        return UserSession.getUserId();
    }

    public static String getUsername() {
        return UserSession.getUsername();
    }

    public static String getRole() {
        return UserSession.getRole();
    }

    public static LocalDateTime getLoginTime() {
        return UserSession.getLoginTime();
    }

    public static String getFormattedLoginTime() {
        return UserSession.getFormattedLoginTime();
    }

    public static boolean isAuthenticated() {
        return UserSession.isLoggedIn();
    }

    public static boolean isAdmin() {
        return UserSession.isAdmin();
    }

    public static boolean isStaff() {
        return UserSession.isStaff();
    }

    public static void clear() {
        UserSession.logout();
    }
}
