package com.restaurantbilling.util;

import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class PasswordUtil {

    /**
     * Computes the SHA-256 cryptographic hash of a plain-text password.
     */
    public static String hashPassword(String plainPassword) {
        if (plainPassword == null) {
            return null;
        }
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hashBytes = md.digest(plainPassword.getBytes(StandardCharsets.UTF_8));
            BigInteger number = new BigInteger(1, hashBytes);
            StringBuilder hexString = new StringBuilder(number.toString(16));
            while (hexString.length() < 64) {
                hexString.insert(0, '0');
            }
            return hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("SHA-256 algorithm not available.", e);
        }
    }

    /**
     * Verifies a plain-text password against a stored password hash or legacy plain-text password.
     */
    public static boolean verifyPassword(String plainPassword, String storedPassword) {
        if (plainPassword == null || storedPassword == null) {
            return false;
        }
        // 1. Direct hash match
        String computedHash = hashPassword(plainPassword);
        if (computedHash.equalsIgnoreCase(storedPassword)) {
            return true;
        }
        // 2. Legacy plain-text fallback (for seamless migration to hashed passwords)
        return plainPassword.equals(storedPassword);
    }

    /**
     * Checks whether a password string is already in SHA-256 hex format.
     */
    public static boolean isHashed(String password) {
        return password != null && password.length() == 64 && password.matches("^[0-9a-fA-F]{64}$");
    }
}
