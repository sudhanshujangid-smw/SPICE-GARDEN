package com.restaurantbilling.util;

import com.restaurantbilling.exception.ValidationException;
import com.restaurantbilling.model.Customer;

import java.util.regex.Pattern;

public class ValidationUtil {
    private static final Pattern EMAIL_PATTERN = Pattern.compile(
        "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,6}$"
    );

    private static final Pattern PHONE_PATTERN = Pattern.compile(
        "^(\\+91[\\-\\s]?)?[0]?(91)?[6789]\\d{9}$|^[0-9]{10}$"
    );

    public static void validateCustomer(Customer customer) throws ValidationException {
        if (customer == null) {
            throw new ValidationException("Customer information cannot be empty.");
        }

        // 1. Name validation
        if (customer.getName() == null || customer.getName().trim().isEmpty()) {
            throw new ValidationException("Customer name is required.");
        }

        if (customer.getName().trim().length() < 2) {
            throw new ValidationException("Customer name must be at least 2 characters long.");
        }

        // 2. Phone validation
        if (customer.getPhone() == null || customer.getPhone().trim().isEmpty()) {
            throw new ValidationException("Customer phone number is required.");
        }

        String sanitizedPhone = customer.getPhone().trim().replaceAll("[\\s\\-\\(\\)]", "");
        if (!PHONE_PATTERN.matcher(sanitizedPhone).matches() && !sanitizedPhone.matches("^[0-9]{10,15}$")) {
            throw new ValidationException("Invalid phone number. Please enter a valid 10-digit mobile number.");
        }

        // 3. Email validation (Optional, but if provided must be valid)
        if (customer.getEmail() != null && !customer.getEmail().trim().isEmpty()) {
            String email = customer.getEmail().trim();
            if (!EMAIL_PATTERN.matcher(email).matches()) {
                throw new ValidationException("Invalid email format (e.g., customer@example.com).");
            }
        }

        // 4. Status validation
        if (customer.getStatus() != null && !customer.getStatus().trim().isEmpty()) {
            String status = customer.getStatus().trim();
            if (!"Active".equalsIgnoreCase(status) && !"Inactive".equalsIgnoreCase(status)) {
                throw new ValidationException("Status must be either 'Active' or 'Inactive'.");
            }
        }
    }
}
