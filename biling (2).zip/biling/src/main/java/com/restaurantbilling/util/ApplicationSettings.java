package com.restaurantbilling.util;

import com.restaurantbilling.dao.SettingsDAO;
import com.restaurantbilling.dao.impl.SettingsDAOImpl;
import com.restaurantbilling.model.RestaurantSettings;

public class ApplicationSettings {

    private static ApplicationSettings instance;
    private RestaurantSettings settings;
    private final SettingsDAO settingsDAO;

    private ApplicationSettings() {
        this.settingsDAO = new SettingsDAOImpl();
        reload();
    }

    public static synchronized ApplicationSettings getInstance() {
        if (instance == null) {
            instance = new ApplicationSettings();
        }
        return instance;
    }

    public synchronized void reload() {
        try {
            this.settings = settingsDAO.getRestaurantSettings();
        } catch (Exception e) {
            this.settings = new RestaurantSettings(); // Fallback defaults
        }
    }

    public synchronized RestaurantSettings getSettings() {
        if (settings == null) {
            reload();
        }
        return settings;
    }

    public synchronized void setSettings(RestaurantSettings settings) {
        this.settings = settings;
    }

    public String getCurrencySymbol() {
        return getSettings().getCurrencySymbol();
    }

    public String getRestaurantName() {
        return getSettings().getRestaurantName();
    }
}
