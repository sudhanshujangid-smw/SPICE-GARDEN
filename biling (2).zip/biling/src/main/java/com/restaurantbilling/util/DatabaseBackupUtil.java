package com.restaurantbilling.util;

import com.restaurantbilling.database.DatabaseConnection;
import com.restaurantbilling.exception.DatabaseException;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.sql.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class DatabaseBackupUtil {

    private static final String[] KNOWN_MYSQLDUMP_PATHS = new String[]{
        "C:\\Program Files\\MySQL\\MySQL Server 8.0\\bin\\mysqldump.exe",
        "C:\\Program Files\\MySQL\\MySQL Server 8.1\\bin\\mysqldump.exe",
        "C:\\Program Files\\MySQL\\MySQL Server 8.2\\bin\\mysqldump.exe",
        "C:\\Program Files\\MySQL\\MySQL Server 8.3\\bin\\mysqldump.exe",
        "C:\\Program Files\\MySQL\\MySQL Server 8.4\\bin\\mysqldump.exe",
        "C:\\Program Files\\MySQL\\MySQL Server 5.7\\bin\\mysqldump.exe",
        "mysqldump.exe",
        "mysqldump"
    };

    /**
     * Finds the mysqldump executable path if available.
     */
    public static String findMysqldumpPath() {
        String override = System.getProperty("mysqldump.path");
        if (override != null && new File(override).exists()) {
            return override;
        }

        for (String path : KNOWN_MYSQLDUMP_PATHS) {
            File f = new File(path);
            if (f.exists() && f.canExecute()) {
                return f.getAbsolutePath();
            }
        }

        // Test running 'mysqldump --version' in PATH
        try {
            Process p = new ProcessBuilder("mysqldump", "--version").start();
            int exit = p.waitFor();
            if (exit == 0) {
                return "mysqldump";
            }
        } catch (Exception ignored) {
        }

        return null;
    }

    /**
     * Creates a database backup file at the specified target destination.
     */
    public static File createBackup(File targetFile) throws DatabaseException {
        if (targetFile == null) {
            throw new DatabaseException("Target backup file destination cannot be null.");
        }

        // Ensure parent directories exist
        File parent = targetFile.getParentFile();
        if (parent != null && !parent.exists()) {
            parent.mkdirs();
        }

        String mysqldumpPath = findMysqldumpPath();
        boolean dumpSuccess = false;

        if (mysqldumpPath != null) {
            try {
                dumpSuccess = executeMysqldump(mysqldumpPath, targetFile);
            } catch (Exception e) {
                dumpSuccess = false;
            }
        }

        // If mysqldump is unavailable or failed, fallback to high-fidelity JDBC SQL export
        if (!dumpSuccess) {
            try {
                exportDatabaseViaJdbc(targetFile);
                dumpSuccess = true;
            } catch (Exception ex) {
                throw new DatabaseException("Database backup failed: " + ex.getMessage(), ex);
            }
        }

        // Validate the generated backup
        validateBackupFile(targetFile);

        return targetFile;
    }

    private static boolean executeMysqldump(String dumpExecutable, File targetFile) throws IOException, InterruptedException {
        String host = DatabaseConnection.getHost();
        String port = DatabaseConnection.getPort();
        String dbName = DatabaseConnection.getDatabaseName();
        String user = DatabaseConnection.getUsername();
        String password = DatabaseConnection.getPassword();

        List<String> command = new ArrayList<>();
        command.add(dumpExecutable);
        command.add("-h");
        command.add(host != null && !host.isEmpty() ? host : "localhost");
        command.add("-P");
        command.add(port != null && !port.isEmpty() ? port : "3306");
        command.add("-u");
        command.add(user != null && !user.isEmpty() ? user : "root");
        if (password != null && !password.isEmpty()) {
            command.add("--password=" + password);
        }
        command.add("--databases");
        command.add(dbName != null && !dbName.isEmpty() ? dbName : "restaurant_billing");
        command.add("--add-drop-table");
        command.add("--routines");
        command.add("--triggers");

        ProcessBuilder pb = new ProcessBuilder(command);
        pb.redirectErrorStream(true);

        Process process = pb.start();

        try (InputStream in = process.getInputStream();
             FileOutputStream out = new FileOutputStream(targetFile)) {
            byte[] buffer = new byte[8192];
            int len;
            while ((len = in.read(buffer)) != -1) {
                out.write(buffer, 0, len);
            }
        }

        int exitCode = process.waitFor();
        return exitCode == 0 && targetFile.exists() && targetFile.length() > 50;
    }

    /**
     * Pure JDBC SQL Export engine fallback to guarantee database backup in all environments.
     */
    public static void exportDatabaseViaJdbc(File targetFile) throws SQLException, IOException {
        try (Connection conn = DatabaseConnection.getConnection();
             BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(targetFile), StandardCharsets.UTF_8))) {

            writer.write("-- ============================================================\n");
            writer.write("-- RESTAURANT BILLING SYSTEM - DATABASE BACKUP (SQL DUMP)\n");
            writer.write("-- Exported: " + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")) + "\n");
            writer.write("-- Database: " + DatabaseConnection.getDatabaseName() + "\n");
            writer.write("-- ============================================================\n\n");
            writer.write("SET FOREIGN_KEY_CHECKS = 0;\n\n");

            List<String> tables = List.of(
                "users",
                "food_items",
                "customers",
                "orders",
                "order_items",
                "bills",
                "system_settings",
                "backup_history"
            );

            for (String table : tables) {
                try {
                    // 1. Export Table Structure
                    try (Statement stmt = conn.createStatement();
                         ResultSet rs = stmt.executeQuery("SHOW CREATE TABLE `" + table + "`")) {
                        if (rs.next()) {
                            String createSql = rs.getString(2);
                            writer.write("-- ------------------------------------------------------------\n");
                            writer.write("-- Table structure for: " + table + "\n");
                            writer.write("-- ------------------------------------------------------------\n");
                            writer.write("DROP TABLE IF EXISTS `" + table + "`;\n");
                            writer.write(createSql + ";\n\n");
                        }
                    }

                    // 2. Export Table Data
                    try (Statement stmt = conn.createStatement();
                         ResultSet rs = stmt.executeQuery("SELECT * FROM `" + table + "`")) {
                        ResultSetMetaData md = rs.getMetaData();
                        int colCount = md.getColumnCount();

                        writer.write("-- Dumping data for: " + table + "\n");
                        while (rs.next()) {
                            StringBuilder row = new StringBuilder();
                            row.append("INSERT INTO `").append(table).append("` VALUES (");
                            for (int i = 1; i <= colCount; i++) {
                                Object val = rs.getObject(i);
                                if (val == null) {
                                    row.append("NULL");
                                } else if (val instanceof Number || val instanceof Boolean) {
                                    row.append(val);
                                } else {
                                    String str = val.toString().replace("\\", "\\\\").replace("'", "\\'");
                                    row.append("'").append(str).append("'");
                                }
                                if (i < colCount) {
                                    row.append(", ");
                                }
                            }
                            row.append(");\n");
                            writer.write(row.toString());
                        }
                        writer.write("\n");
                    }
                } catch (SQLException e) {
                    // If table does not exist, continue with other tables
                }
            }

            writer.write("SET FOREIGN_KEY_CHECKS = 1;\n");
            writer.write("-- Dump completed on " + LocalDateTime.now().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME) + "\n");
        }
    }

    /**
     * Validates that the backup file was successfully created and contains SQL data.
     */
    public static void validateBackupFile(File file) throws DatabaseException {
        if (file == null || !file.exists()) {
            throw new DatabaseException("Backup validation failed: File does not exist.");
        }
        if (file.length() == 0) {
            throw new DatabaseException("Backup validation failed: File is empty (0 bytes).");
        }

        try {
            List<String> firstLines = Files.readAllLines(file.toPath());
            boolean containsSql = false;
            for (String line : firstLines) {
                String trim = line.trim().toUpperCase();
                if (trim.contains("CREATE TABLE") || trim.contains("INSERT INTO") || 
                    trim.contains("MYSQL DUMP") || trim.contains("RESTAURANT BILLING") ||
                    trim.contains("SET FOREIGN_KEY_CHECKS") || trim.contains("USE `")) {
                    containsSql = true;
                    break;
                }
            }
            if (!containsSql && file.length() < 20) {
                throw new DatabaseException("Backup validation failed: File content is not a valid SQL backup.");
            }
        } catch (IOException e) {
            throw new DatabaseException("Backup validation failed: Could not read backup file.", e);
        }
    }
}
