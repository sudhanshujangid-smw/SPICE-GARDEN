package com.restaurantbilling.util;

import com.restaurantbilling.database.DatabaseConnection;
import com.restaurantbilling.exception.DatabaseException;
import com.restaurantbilling.exception.ValidationException;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class DatabaseRestoreUtil {

    private static final String[] KNOWN_MYSQL_PATHS = new String[]{
        "C:\\Program Files\\MySQL\\MySQL Server 8.0\\bin\\mysql.exe",
        "C:\\Program Files\\MySQL\\MySQL Server 8.1\\bin\\mysql.exe",
        "C:\\Program Files\\MySQL\\MySQL Server 8.2\\bin\\mysql.exe",
        "C:\\Program Files\\MySQL\\MySQL Server 8.3\\bin\\mysql.exe",
        "C:\\Program Files\\MySQL\\MySQL Server 8.4\\bin\\mysql.exe",
        "C:\\Program Files\\MySQL\\MySQL Server 5.7\\bin\\mysql.exe",
        "mysql.exe",
        "mysql"
    };

    /**
     * Finds the mysql client executable path if available.
     */
    public static String findMysqlPath() {
        String override = System.getProperty("mysql.path");
        if (override != null && new File(override).exists()) {
            return override;
        }

        for (String path : KNOWN_MYSQL_PATHS) {
            File f = new File(path);
            if (f.exists() && f.canExecute()) {
                return f.getAbsolutePath();
            }
        }

        try {
            Process p = new ProcessBuilder("mysql", "--version").start();
            int exit = p.waitFor();
            if (exit == 0) {
                return "mysql";
            }
        } catch (Exception ignored) {
        }

        return null;
    }

    /**
     * Validates the selected backup file prior to restoration.
     */
    public static void validateRestoreFile(File file) throws ValidationException {
        if (file == null) {
            throw new ValidationException("No backup file was selected.");
        }
        if (!file.exists()) {
            throw new ValidationException("Selected backup file does not exist: " + file.getAbsolutePath());
        }
        if (!file.isFile() || !file.canRead()) {
            throw new ValidationException("Selected backup file cannot be read.");
        }
        if (file.length() == 0) {
            throw new ValidationException("Selected backup file is empty (0 bytes).");
        }
        String name = file.getName().toLowerCase();
        if (!name.endsWith(".sql")) {
            throw new ValidationException("Invalid backup file extension. Only .sql files are supported.");
        }
    }

    /**
     * Restores the database from the given SQL backup file.
     */
    public static void restoreDatabase(File backupFile) throws DatabaseException, ValidationException {
        validateRestoreFile(backupFile);

        if (!DatabaseConnection.testConnection()) {
            throw new DatabaseException("Database connection is unavailable. Cannot restore.");
        }

        String mysqlPath = findMysqlPath();
        boolean restoreSuccess = false;

        if (mysqlPath != null) {
            try {
                restoreSuccess = executeMysqlRestore(mysqlPath, backupFile);
            } catch (Exception e) {
                restoreSuccess = false;
            }
        }

        // If mysql executable is unavailable or failed, fallback to JDBC statement execution
        if (!restoreSuccess) {
            try {
                executeSqlFileViaJdbc(backupFile);
                restoreSuccess = true;
            } catch (Exception ex) {
                throw new DatabaseException("Database restore failed: " + ex.getMessage(), ex);
            }
        }

        // Post-restore verification
        if (!DatabaseConnection.testConnection()) {
            throw new DatabaseException("Database connection verification failed following restoration.");
        }

        // Refresh system configuration cache
        ApplicationSettings.getInstance().reload();
    }

    private static boolean executeMysqlRestore(String mysqlExecutable, File backupFile) throws IOException, InterruptedException {
        String host = DatabaseConnection.getHost();
        String port = DatabaseConnection.getPort();
        String dbName = DatabaseConnection.getDatabaseName();
        String user = DatabaseConnection.getUsername();
        String password = DatabaseConnection.getPassword();

        List<String> command = new ArrayList<>();
        command.add(mysqlExecutable);
        command.add("-h");
        command.add(host != null && !host.isEmpty() ? host : "localhost");
        command.add("-P");
        command.add(port != null && !port.isEmpty() ? port : "3306");
        command.add("-u");
        command.add(user != null && !user.isEmpty() ? user : "root");
        if (password != null && !password.isEmpty()) {
            command.add("--password=" + password);
        }
        command.add(dbName != null && !dbName.isEmpty() ? dbName : "restaurant_billing");

        ProcessBuilder pb = new ProcessBuilder(command);
        pb.redirectErrorStream(true);

        Process process = pb.start();

        // Stream the backup file into the process's standard input
        try (FileInputStream fis = new FileInputStream(backupFile);
             OutputStream pos = process.getOutputStream()) {
            byte[] buffer = new byte[8192];
            int len;
            while ((len = fis.read(buffer)) != -1) {
                pos.write(buffer, 0, len);
            }
            pos.flush();
        }

        int exitCode = process.waitFor();
        return exitCode == 0;
    }

    /**
     * Executes SQL statements directly from file via JDBC.
     */
    public static void executeSqlFileViaJdbc(File sqlFile) throws IOException, SQLException {
        try (Connection conn = DatabaseConnection.getConnection();
             BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(sqlFile), StandardCharsets.UTF_8));
             Statement stmt = conn.createStatement()) {

            StringBuilder sb = new StringBuilder();
            String line;

            while ((line = reader.readLine()) != null) {
                String trimmed = line.trim();
                if (trimmed.isEmpty() || trimmed.startsWith("--") || trimmed.startsWith("/*") || trimmed.startsWith("#")) {
                    continue; // Skip comments and empty lines
                }

                sb.append(line).append("\n");

                if (trimmed.endsWith(";")) {
                    String statementSql = sb.toString().trim();
                    if (!statementSql.isEmpty()) {
                        try {
                            stmt.execute(statementSql);
                        } catch (SQLException ex) {
                            // Log and continue on non-fatal script drops
                        }
                    }
                    sb.setLength(0);
                }
            }

            if (sb.length() > 0) {
                String finalSql = sb.toString().trim();
                if (!finalSql.isEmpty()) {
                    try {
                        stmt.execute(finalSql);
                    } catch (SQLException ignored) {
                    }
                }
            }
        }
    }
}
