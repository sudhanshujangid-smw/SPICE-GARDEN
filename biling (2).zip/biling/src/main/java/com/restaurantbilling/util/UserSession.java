package com.restaurantbilling.util;

import com.restaurantbilling.model.User;
import java.time.LocalDateTime;

public class UserSession {
    private static User currentUser;
    private static LocalDateTime loginTime;

    public static void login(User user) {
        currentUser = user;
        loginTime = LocalDateTime.now();
    }

    public static void logout() {
        currentUser = null;
        loginTime = null;
    }

    public static User getCurrentUser() {
        return currentUser;
    }

    public static Integer getUserId() {
        return currentUser != null ? currentUser.getId() : null;
    }

    public static LocalDateTime getLoginTime() {
        return loginTime;
    }

    public static String getFormattedLoginTime() {
        return loginTime != null ? FormatUtil.formatDateTime(loginTime) : "-";
    }

    public static boolean isLoggedIn() {
        return currentUser != null;
    }

    public static boolean isAdmin() {
        return currentUser != null && "ADMIN".equalsIgnoreCase(currentUser.getRole());
    }

    public static boolean isStaff() {
        return currentUser != null && "STAFF".equalsIgnoreCase(currentUser.getRole());
    }

    public static String getUsername() {
        return currentUser != null ? currentUser.getUsername() : "Guest";
    }

    public static String getRole() {
        return currentUser != null ? currentUser.getRole() : "NONE";
    }
}
