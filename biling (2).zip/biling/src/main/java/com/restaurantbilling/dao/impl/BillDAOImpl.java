package com.restaurantbilling.dao.impl;

import com.restaurantbilling.dao.BillDAO;
import com.restaurantbilling.database.DatabaseConnection;
import com.restaurantbilling.exception.DatabaseException;
import com.restaurantbilling.model.Bill;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class BillDAOImpl implements BillDAO {

    @Override
    public Bill createBill(Connection conn, Bill bill) {
        String sql = "INSERT INTO bills (order_id, bill_number, subtotal, discount, tax, final_amount, payment_status) VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setInt(1, bill.getOrderId());
            stmt.setString(2, bill.getBillNumber());
            stmt.setBigDecimal(3, bill.getSubtotal());
            stmt.setBigDecimal(4, bill.getDiscount());
            stmt.setBigDecimal(5, bill.getTax());
            stmt.setBigDecimal(6, bill.getFinalAmount());
            stmt.setString(7, bill.getStatus() != null ? bill.getStatus() : "GENERATED");

            int affectedRows = stmt.executeUpdate();
            if (affectedRows == 0) {
                throw new DatabaseException("Failed to insert bill, no rows affected.");
            }

            try (ResultSet rs = stmt.getGeneratedKeys()) {
                if (rs.next()) {
                    bill.setId(rs.getInt(1));
                }
            }
            return bill;
        } catch (SQLException e) {
            throw new DatabaseException("Error creating bill record in database.", e);
        }
    }

    @Override
    public Bill createBill(Bill bill) {
        try (Connection conn = DatabaseConnection.getConnection()) {
            return createBill(conn, bill);
        } catch (SQLException e) {
            throw new DatabaseException("Failed to open database connection for bill creation.", e);
        }
    }

    @Override
    public Optional<Bill> findById(int id) {
        String sql = "SELECT b.id, b.order_id, b.bill_number, b.subtotal, b.discount, b.tax, b.final_amount, b.bill_date, b.payment_status AS status, " +
                     "c.name AS customer_name, c.phone AS customer_phone " +
                     "FROM bills b " +
                     "JOIN orders o ON b.order_id = o.id " +
                     "LEFT JOIN customers c ON o.customer_id = c.id " +
                     "WHERE b.id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return Optional.of(mapResultSetToBill(rs));
                }
            }
        } catch (SQLException e) {
            throw new DatabaseException("Unable to find bill by ID: " + id, e);
        }
        return Optional.empty();
    }

    @Override
    public Optional<Bill> findByOrderId(int orderId) {
        String sql = "SELECT b.id, b.order_id, b.bill_number, b.subtotal, b.discount, b.tax, b.final_amount, b.bill_date, b.payment_status AS status, " +
                     "c.name AS customer_name, c.phone AS customer_phone " +
                     "FROM bills b " +
                     "JOIN orders o ON b.order_id = o.id " +
                     "LEFT JOIN customers c ON o.customer_id = c.id " +
                     "WHERE b.order_id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, orderId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return Optional.of(mapResultSetToBill(rs));
                }
            }
        } catch (SQLException e) {
            throw new DatabaseException("Unable to find bill for order ID: " + orderId, e);
        }
        return Optional.empty();
    }

    @Override
    public Optional<Bill> findByBillNumber(String billNumber) {
        String sql = "SELECT b.id, b.order_id, b.bill_number, b.subtotal, b.discount, b.tax, b.final_amount, b.bill_date, b.payment_status AS status, " +
                     "c.name AS customer_name, c.phone AS customer_phone " +
                     "FROM bills b " +
                     "JOIN orders o ON b.order_id = o.id " +
                     "LEFT JOIN customers c ON o.customer_id = c.id " +
                     "WHERE b.bill_number = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, billNumber);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return Optional.of(mapResultSetToBill(rs));
                }
            }
        } catch (SQLException e) {
            throw new DatabaseException("Unable to find bill by bill number: " + billNumber, e);
        }
        return Optional.empty();
    }

    @Override
    public List<Bill> findAll() {
        return searchBills(null);
    }

    @Override
    public List<Bill> searchBills(String keyword) {
        StringBuilder sql = new StringBuilder(
            "SELECT b.id, b.order_id, b.bill_number, b.subtotal, b.discount, b.tax, b.final_amount, b.bill_date, b.payment_status AS status, " +
            "c.name AS customer_name, c.phone AS customer_phone " +
            "FROM bills b " +
            "JOIN orders o ON b.order_id = o.id " +
            "LEFT JOIN customers c ON o.customer_id = c.id " +
            "WHERE 1=1 "
        );
        List<Object> params = new ArrayList<>();

        if (keyword != null && !keyword.trim().isEmpty()) {
            String trimmed = keyword.trim();
            sql.append("AND (b.bill_number LIKE ? OR o.id = ? OR c.name LIKE ? OR c.phone LIKE ?) ");
            params.add("%" + trimmed + "%");
            int orderIdMatch = -1;
            try {
                orderIdMatch = Integer.parseInt(trimmed);
            } catch (NumberFormatException ignored) {}
            params.add(orderIdMatch);
            params.add("%" + trimmed + "%");
            params.add("%" + trimmed + "%");
        }

        sql.append("ORDER BY b.id DESC");

        List<Bill> list = new ArrayList<>();
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql.toString())) {

            for (int i = 0; i < params.size(); i++) {
                stmt.setObject(i + 1, params.get(i));
            }

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    list.add(mapResultSetToBill(rs));
                }
            }
        } catch (SQLException e) {
            throw new DatabaseException("Unable to search bills.", e);
        }
        return list;
    }

    @Override
    public boolean isOrderBilled(int orderId) {
        String sql = "SELECT COUNT(*) FROM bills WHERE order_id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, orderId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1) > 0;
                }
            }
        } catch (SQLException e) {
            throw new DatabaseException("Error checking if order is already billed.", e);
        }
        return false;
    }

    @Override
    public int countTotalBills() {
        String sql = "SELECT COUNT(*) FROM bills";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            if (rs.next()) {
                return rs.getInt(1);
            }
        } catch (SQLException e) {
            return 0;
        }
        return 0;
    }

    private Bill mapResultSetToBill(ResultSet rs) throws SQLException {
        Bill bill = new Bill();
        bill.setId(rs.getInt("id"));
        bill.setOrderId(rs.getInt("order_id"));
        bill.setBillNumber(rs.getString("bill_number"));
        bill.setSubtotal(rs.getBigDecimal("subtotal"));
        bill.setDiscount(rs.getBigDecimal("discount"));
        bill.setTax(rs.getBigDecimal("tax"));
        bill.setFinalAmount(rs.getBigDecimal("final_amount"));
        bill.setBillDate(rs.getTimestamp("bill_date"));
        bill.setStatus(rs.getString("status"));
        bill.setCustomerName(rs.getString("customer_name"));
        bill.setCustomerPhone(rs.getString("customer_phone"));
        return bill;
    }
}
