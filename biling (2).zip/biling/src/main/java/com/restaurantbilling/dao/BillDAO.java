package com.restaurantbilling.dao;

import com.restaurantbilling.model.Bill;

import java.sql.Connection;
import java.util.List;
import java.util.Optional;

public interface BillDAO {
    Bill createBill(Connection conn, Bill bill);
    Bill createBill(Bill bill);
    Optional<Bill> findById(int id);
    Optional<Bill> findByOrderId(int orderId);
    Optional<Bill> findByBillNumber(String billNumber);
    List<Bill> findAll();
    List<Bill> searchBills(String keyword);
    boolean isOrderBilled(int orderId);
    int countTotalBills();
}
