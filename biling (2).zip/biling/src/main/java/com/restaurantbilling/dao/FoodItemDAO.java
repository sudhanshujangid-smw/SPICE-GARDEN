package com.restaurantbilling.dao;

import com.restaurantbilling.model.FoodItem;
import java.util.List;
import java.util.Optional;

public interface FoodItemDAO {
    List<FoodItem> findAll();
    Optional<FoodItem> findById(int id);
    List<FoodItem> search(String keyword, String category);
    FoodItem save(FoodItem item);
    boolean update(FoodItem item);
    boolean delete(int id);
    int countTotalItems();
}
