package com.restaurantbilling.dao.impl;

import com.restaurantbilling.dao.DashboardDAO;
import com.restaurantbilling.database.DatabaseConnection;
import com.restaurantbilling.model.Bill;
import com.restaurantbilling.model.Order;
import com.restaurantbilling.model.dashboard.DashboardSummaryDTO;
import com.restaurantbilling.model.dashboard.OrderTrendDTO;
import com.restaurantbilling.model.report.BillingTrendDTO;
import com.restaurantbilling.model.report.ItemSalesDTO;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DashboardDAOImpl implements DashboardDAO {

    @Override
    public DashboardSummaryDTO getDashboardKPIs(String fromDate, String toDate) {
        DashboardSummaryDTO dto = new DashboardSummaryDTO();

        // 1. Bill KPI: Total Bills & Total Billed Amount
        // Actual schema: bills(id, order_id, bill_number, subtotal, discount, tax, final_amount, bill_date, status)
        boolean hasDateFilter = (fromDate != null && !fromDate.trim().isEmpty() && toDate != null && !toDate.trim().isEmpty());
        StringBuilder billSql = new StringBuilder("SELECT COUNT(id) AS total_bills, COALESCE(SUM(final_amount), 0) AS total_billed FROM bills");
        if (hasDateFilter) {
            billSql.append(" WHERE DATE(bill_date) BETWEEN ? AND ?");
        }

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(billSql.toString())) {
            if (hasDateFilter) {
                ps.setString(1, fromDate.trim());
                ps.setString(2, toDate.trim());
            }
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    dto.setTotalBills(rs.getInt("total_bills"));
                    dto.setTotalBilledAmount(rs.getBigDecimal("total_billed"));
                }
            }
        } catch (SQLException e) {
            System.err.println("[Dashboard] Bill KPI query failed");
            System.err.println("  Message   : " + e.getMessage());
            System.err.println("  SQLState  : " + e.getSQLState());
            System.err.println("  ErrorCode : " + e.getErrorCode());
        }

        // 2. Order KPI: Total Orders
        // Actual schema: orders(id, customer_id, order_date, subtotal, discount, tax, total, status)
        StringBuilder orderSql = new StringBuilder("SELECT COUNT(id) AS total_orders FROM orders");
        if (hasDateFilter) {
            orderSql.append(" WHERE DATE(order_date) BETWEEN ? AND ?");
        }

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(orderSql.toString())) {
            if (hasDateFilter) {
                ps.setString(1, fromDate.trim());
                ps.setString(2, toDate.trim());
            }
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    dto.setTotalOrders(rs.getInt("total_orders"));
                }
            }
        } catch (SQLException e) {
            System.err.println("[Dashboard] Order KPI query failed");
            System.err.println("  Message   : " + e.getMessage());
            System.err.println("  SQLState  : " + e.getSQLState());
            System.err.println("  ErrorCode : " + e.getErrorCode());
        }

        // 3. Customer KPI: Total Registered Customers
        // Actual table: customers, PK column: id (per schema.sql line 27)
        String customerSql = "SELECT COUNT(id) AS total_customers FROM customers";
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(customerSql)) {
            if (rs.next()) {
                dto.setTotalCustomers(rs.getInt("total_customers"));
            }
        } catch (SQLException e) {
            System.err.println("[Dashboard] Customer KPI query failed");
            System.err.println("  Message   : " + e.getMessage());
            System.err.println("  SQLState  : " + e.getSQLState());
            System.err.println("  ErrorCode : " + e.getErrorCode());
        }

        // 4. Menu Items KPI: Total Food Items
        // Actual table: food_items, PK column: id (per schema.sql line 17)
        String itemSql = "SELECT COUNT(id) AS total_items FROM food_items";
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(itemSql)) {
            if (rs.next()) {
                dto.setTotalMenuItems(rs.getInt("total_items"));
            }
        } catch (SQLException e) {
            System.err.println("[Dashboard] Food Items KPI query failed");
            System.err.println("  Message   : " + e.getMessage());
            System.err.println("  SQLState  : " + e.getSQLState());
            System.err.println("  ErrorCode : " + e.getErrorCode());
        }

        // 5. Average Bill Calculation
        if (dto.getTotalBills() > 0 && dto.getTotalBilledAmount() != null) {
            BigDecimal avg = dto.getTotalBilledAmount().divide(BigDecimal.valueOf(dto.getTotalBills()), 2, RoundingMode.HALF_UP);
            dto.setAverageBillAmount(avg);
        } else {
            dto.setAverageBillAmount(BigDecimal.ZERO);
        }

        return dto;
    }

    @Override
    public List<BillingTrendDTO> getBillingTrend(String fromDate, String toDate) {
        List<BillingTrendDTO> list = new ArrayList<>();
        boolean hasDateFilter = (fromDate != null && !fromDate.trim().isEmpty() && toDate != null && !toDate.trim().isEmpty());

        // Actual schema: bills(id, order_id, bill_number, subtotal, discount, tax, final_amount, bill_date, status)
        StringBuilder sql = new StringBuilder(
            "SELECT DATE(bill_date) AS period, COUNT(id) AS bill_count, COALESCE(SUM(final_amount), 0) AS total_amount " +
            "FROM bills"
        );
        if (hasDateFilter) {
            sql.append(" WHERE DATE(bill_date) BETWEEN ? AND ?");
        }
        sql.append(" GROUP BY DATE(bill_date) ORDER BY period ASC");

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql.toString())) {
            if (hasDateFilter) {
                ps.setString(1, fromDate.trim());
                ps.setString(2, toDate.trim());
            }
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    String period = rs.getString("period");
                    int count = rs.getInt("bill_count");
                    BigDecimal total = rs.getBigDecimal("total_amount");
                    list.add(new BillingTrendDTO(period, count, total));
                }
            }
        } catch (SQLException e) {
            System.err.println("[Dashboard] Billing trend query failed");
            System.err.println("  Message   : " + e.getMessage());
            System.err.println("  SQLState  : " + e.getSQLState());
            System.err.println("  ErrorCode : " + e.getErrorCode());
        }

        return list;
    }

    @Override
    public List<OrderTrendDTO> getOrderTrend(String fromDate, String toDate) {
        List<OrderTrendDTO> list = new ArrayList<>();
        boolean hasDateFilter = (fromDate != null && !fromDate.trim().isEmpty() && toDate != null && !toDate.trim().isEmpty());

        // Actual schema: orders(id, customer_id, order_date, subtotal, discount, tax, total, status)
        StringBuilder sql = new StringBuilder(
            "SELECT DATE(order_date) AS period, COUNT(id) AS order_count " +
            "FROM orders"
        );
        if (hasDateFilter) {
            sql.append(" WHERE DATE(order_date) BETWEEN ? AND ?");
        }
        sql.append(" GROUP BY DATE(order_date) ORDER BY period ASC");

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql.toString())) {
            if (hasDateFilter) {
                ps.setString(1, fromDate.trim());
                ps.setString(2, toDate.trim());
            }
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    String period = rs.getString("period");
                    int count = rs.getInt("order_count");
                    list.add(new OrderTrendDTO(period, count));
                }
            }
        } catch (SQLException e) {
            System.err.println("[Dashboard] Order trend query failed");
            System.err.println("  Message   : " + e.getMessage());
            System.err.println("  SQLState  : " + e.getSQLState());
            System.err.println("  ErrorCode : " + e.getErrorCode());
        }

        return list;
    }

    @Override
    public List<ItemSalesDTO> getTopMenuItems(String fromDate, String toDate, int limit) {
        List<ItemSalesDTO> list = new ArrayList<>();
        boolean hasDateFilter = (fromDate != null && !fromDate.trim().isEmpty() && toDate != null && !toDate.trim().isEmpty());

        // FIX: order_items has NO food_item_name column.
        // Actual schema:
        //   order_items(id, order_id, food_item_id, quantity, unit_price, subtotal)
        //   food_items(id, name, category, price, available, created_at)
        // The item name must come from food_items.name via LEFT JOIN on food_item_id.
        StringBuilder sql = new StringBuilder(
            "SELECT fi.name AS food_item_name, COALESCE(fi.category, 'General') AS category, " +
            "SUM(oi.quantity) AS total_qty, SUM(oi.item_total) AS total_revenue " +
            "FROM order_items oi " +
            "LEFT JOIN food_items fi ON oi.food_item_id = fi.id " +
            "LEFT JOIN orders o ON oi.order_id = o.id"
        );
        if (hasDateFilter) {
            sql.append(" WHERE DATE(o.order_date) BETWEEN ? AND ?");
        }
        sql.append(" GROUP BY oi.food_item_id, fi.name, fi.category ORDER BY total_qty DESC, total_revenue DESC LIMIT ?");

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql.toString())) {
            int pIndex = 1;
            if (hasDateFilter) {
                ps.setString(pIndex++, fromDate.trim());
                ps.setString(pIndex++, toDate.trim());
            }
            ps.setInt(pIndex, limit > 0 ? limit : 5);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    String name = rs.getString("food_item_name");
                    String cat = rs.getString("category");
                    int qty = rs.getInt("total_qty");
                    BigDecimal rev = rs.getBigDecimal("total_revenue");
                    list.add(new ItemSalesDTO(name, cat, qty, rev));
                }
            }
        } catch (SQLException e) {
            System.err.println("[Dashboard] Top menu items query failed");
            System.err.println("  Message   : " + e.getMessage());
            System.err.println("  SQLState  : " + e.getSQLState());
            System.err.println("  ErrorCode : " + e.getErrorCode());
        }

        return list;
    }

    @Override
    public List<Bill> getRecentBills(int limit) {
        List<Bill> list = new ArrayList<>();

        // FIX: orders table has NO customer_name or customer_phone columns.
        // Actual schema: orders(id, customer_id, order_date, subtotal, discount, tax, total, status)
        // Customer name/phone must be fetched via LEFT JOIN with customers table.
        // This matches the working pattern in BillDAOImpl.findAll() and BillDAOImpl.findById().
        String sql = "SELECT b.id, b.order_id, b.bill_number, b.subtotal, b.discount, b.tax, b.final_amount, b.bill_date, b.payment_status AS status, " +
                     "c.name AS customer_name, c.phone AS customer_phone " +
                     "FROM bills b " +
                     "LEFT JOIN orders o ON b.order_id = o.id " +
                     "LEFT JOIN customers c ON o.customer_id = c.id " +
                     "ORDER BY b.bill_date DESC, b.id DESC LIMIT ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, limit > 0 ? limit : 5);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Bill b = new Bill();
                    b.setId(rs.getInt("id"));
                    b.setOrderId(rs.getInt("order_id"));
                    b.setBillNumber(rs.getString("bill_number"));
                    b.setSubtotal(rs.getBigDecimal("subtotal"));
                    b.setDiscount(rs.getBigDecimal("discount"));
                    b.setTax(rs.getBigDecimal("tax"));
                    b.setFinalAmount(rs.getBigDecimal("final_amount"));
                    Timestamp ts = rs.getTimestamp("bill_date");
                    if (ts != null) {
                        b.setBillDate(ts);
                    }
                    b.setStatus(rs.getString("status"));
                    b.setCustomerName(rs.getString("customer_name"));
                    b.setCustomerPhone(rs.getString("customer_phone"));
                    list.add(b);
                }
            }
        } catch (SQLException e) {
            System.err.println("[Dashboard] Recent bills query failed");
            System.err.println("  Message   : " + e.getMessage());
            System.err.println("  SQLState  : " + e.getSQLState());
            System.err.println("  ErrorCode : " + e.getErrorCode());
        }

        return list;
    }

    @Override
    public List<Order> getRecentOrders(int limit) {
        List<Order> list = new ArrayList<>();

        // FIX: orders table has NO customer_name or customer_phone columns.
        // Actual schema: orders(id, customer_id, order_date, subtotal, discount, tax, total, status)
        // Customer name/phone must be fetched via LEFT JOIN with customers table.
        // This matches the working pattern in OrderDAOImpl.findById() and search().
        String sql = "SELECT o.id, o.customer_id, c.name AS customer_name, c.phone AS customer_phone, " +
                     "o.order_date, o.subtotal, o.discount, o.tax, o.total, o.status " +
                     "FROM orders o " +
                     "LEFT JOIN customers c ON o.customer_id = c.id " +
                     "ORDER BY o.order_date DESC, o.id DESC LIMIT ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, limit > 0 ? limit : 5);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Order o = new Order();
                    o.setId(rs.getInt("id"));
                    int custId = rs.getInt("customer_id");
                    if (!rs.wasNull()) {
                        o.setCustomerId(custId);
                    }
                    o.setCustomerName(rs.getString("customer_name"));
                    o.setCustomerPhone(rs.getString("customer_phone"));
                    Timestamp ts = rs.getTimestamp("order_date");
                    if (ts != null) {
                        o.setOrderDate(ts);
                    }
                    o.setSubtotal(rs.getBigDecimal("subtotal"));
                    o.setDiscount(rs.getBigDecimal("discount"));
                    o.setTax(rs.getBigDecimal("tax"));
                    o.setTotal(rs.getBigDecimal("total"));
                    o.setStatus(rs.getString("status"));
                    list.add(o);
                }
            }
        } catch (SQLException e) {
            System.err.println("[Dashboard] Recent orders query failed");
            System.err.println("  Message   : " + e.getMessage());
            System.err.println("  SQLState  : " + e.getSQLState());
            System.err.println("  ErrorCode : " + e.getErrorCode());
        }

        return list;
    }
}
