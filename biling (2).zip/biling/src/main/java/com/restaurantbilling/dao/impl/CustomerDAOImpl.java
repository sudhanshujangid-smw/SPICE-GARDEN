package com.restaurantbilling.dao.impl;

import com.restaurantbilling.dao.CustomerDAO;
import com.restaurantbilling.database.DatabaseConnection;
import com.restaurantbilling.exception.DatabaseException;
import com.restaurantbilling.model.Customer;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class CustomerDAOImpl implements CustomerDAO {

    @Override
    public List<Customer> findAll() {
        String sql = "SELECT id, name, phone, email, created_at, updated_at FROM customers ORDER BY id DESC";
        List<Customer> list = new ArrayList<>();
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                list.add(mapResultSetToCustomer(rs));
            }
        } catch (SQLException e) {
            System.err.println("REAL SQL EXCEPTION: " + e.getClass().getName());
            System.err.println("Message: " + e.getMessage());
            System.err.println("SQLState: " + e.getSQLState());
            System.err.println("Error Code: " + e.getErrorCode());
            throw new DatabaseException("Unable to load customers from database. " + e.getMessage(), e);
        }
        return list;
    }

    @Override
    public Optional<Customer> findById(int id) {
        String sql = "SELECT id, name, phone, email, created_at, updated_at FROM customers WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return Optional.of(mapResultSetToCustomer(rs));
                }
            }
        } catch (SQLException e) {
            throw new DatabaseException("Unable to find customer with ID: " + id, e);
        }
        return Optional.empty();
    }

    @Override
    public Optional<Customer> findByPhone(String phone) {
        String sql = "SELECT id, name, phone, email, created_at, updated_at FROM customers WHERE phone = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, phone.trim());
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return Optional.of(mapResultSetToCustomer(rs));
                }
            }
        } catch (SQLException e) {
            throw new DatabaseException("Unable to query customer by phone.", e);
        }
        return Optional.empty();
    }

    @Override
    public List<Customer> search(String keyword, String status) {
        StringBuilder sql = new StringBuilder("SELECT id, name, phone, email, created_at, updated_at FROM customers WHERE 1=1 ");
        List<Object> params = new ArrayList<>();

        if (keyword != null && !keyword.trim().isEmpty()) {
            sql.append("AND (name LIKE ? OR phone LIKE ? OR email LIKE ?) ");
            String term = "%" + keyword.trim() + "%";
            params.add(term);
            params.add(term);
            params.add(term);
        }

        if (status != null && !status.trim().equalsIgnoreCase("All")) {
            // Feature disabled: No status column in DB
        }

        sql.append("ORDER BY id DESC");

        List<Customer> list = new ArrayList<>();
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql.toString())) {

            for (int i = 0; i < params.size(); i++) {
                stmt.setObject(i + 1, params.get(i));
            }

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    list.add(mapResultSetToCustomer(rs));
                }
            }
        } catch (SQLException e) {
            throw new DatabaseException("Unable to search customers.", e);
        }
        return list;
    }

    @Override
    public Customer save(Customer customer) {
        String sql = "INSERT INTO customers (name, phone, email) VALUES (?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            stmt.setString(1, customer.getName().trim());
            stmt.setString(2, customer.getPhone().trim());
            stmt.setString(3, customer.getEmail() != null ? customer.getEmail().trim() : null);

            int affectedRows = stmt.executeUpdate();
            if (affectedRows == 0) {
                throw new DatabaseException("Saving customer failed, no rows affected.");
            }

            try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    customer.setId(generatedKeys.getInt(1));
                }
            }
            return customer;
        } catch (SQLException e) {
            throw new DatabaseException("Unable to save customer to database.", e);
        }
    }

    @Override
    public boolean update(Customer customer) {
        String sql = "UPDATE customers SET name = ?, phone = ?, email = ? WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, customer.getName().trim());
            stmt.setString(2, customer.getPhone().trim());
            stmt.setString(3, customer.getEmail() != null ? customer.getEmail().trim() : null);
            stmt.setInt(4, customer.getId());

            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            throw new DatabaseException("Unable to update customer.", e);
        }
    }

    @Override
    public boolean updateStatus(int id, String status) {
        String sql = "UPDATE customers SET email = email WHERE id = ?"; // No-op to avoid breaking logic
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);

            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            throw new DatabaseException("Unable to update customer status.", e);
        }
    }

    @Override
    public boolean delete(int id) {
        String sql = "DELETE FROM customers WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            // Check for foreign key constraints
            if (e.getErrorCode() == 1451) {
                throw new DatabaseException("Cannot delete customer because orders/bills are linked. Please deactivate the customer instead.", e);
            }
            throw new DatabaseException("Unable to delete customer.", e);
        }
    }

    @Override
    public boolean isPhoneRegistered(String phone, int excludeCustomerId) {
        String sql = "SELECT COUNT(*) FROM customers WHERE phone = ? AND id != ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, phone.trim());
            stmt.setInt(2, excludeCustomerId);

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1) > 0;
                }
            }
        } catch (SQLException e) {
            throw new DatabaseException("Unable to check phone uniqueness.", e);
        }
        return false;
    }

    @Override
    public int countActiveCustomers() {
        String sql = "SELECT COUNT(*) FROM customers";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            if (rs.next()) {
                return rs.getInt(1);
            }
        } catch (SQLException e) {
            return 0;
        }
        return 0;
    }

    private Customer mapResultSetToCustomer(ResultSet rs) throws SQLException {
        Customer c = new Customer();
        c.setId(rs.getInt("id"));
        c.setName(rs.getString("name"));
        c.setPhone(rs.getString("phone"));
        c.setEmail(rs.getString("email"));

        c.setCreatedAt(rs.getTimestamp("created_at"));
        c.setUpdatedAt(rs.getTimestamp("updated_at"));
        return c;
    }
}
