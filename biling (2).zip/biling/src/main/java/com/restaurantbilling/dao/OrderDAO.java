package com.restaurantbilling.dao;

import com.restaurantbilling.model.Order;

import java.sql.Connection;
import java.util.List;
import java.util.Optional;

public interface OrderDAO {
    int createOrder(Connection conn, Order order);
    Optional<Order> findById(int id);
    List<Order> findAll();
    List<Order> search(String keyword, String status);
    boolean updateStatus(int id, String status);
    boolean cancelOrder(int id);
    int countTotalOrders();
}
