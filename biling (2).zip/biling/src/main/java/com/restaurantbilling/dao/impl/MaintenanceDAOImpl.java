package com.restaurantbilling.dao.impl;

import com.restaurantbilling.dao.MaintenanceDAO;
import com.restaurantbilling.database.DatabaseConnection;
import com.restaurantbilling.model.maintenance.BackupRecord;
import com.restaurantbilling.model.maintenance.DatabaseHealth;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.*;

public class MaintenanceDAOImpl implements MaintenanceDAO {

    private static final List<String> REQUIRED_TABLES = List.of(
        "users",
        "food_items",
        "customers",
        "orders",
        "order_items",
        "bills",
        "system_settings"
    );

    public MaintenanceDAOImpl() {
        initBackupHistoryTableIfNotExists();
    }

    @Override
    public void initBackupHistoryTableIfNotExists() {
        String sql = "CREATE TABLE IF NOT EXISTS backup_history (" +
                     "id INT AUTO_INCREMENT PRIMARY KEY, " +
                     "backup_name VARCHAR(255) NOT NULL, " +
                     "backup_path VARCHAR(500) NOT NULL, " +
                     "file_size_bytes BIGINT NOT NULL, " +
                     "created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, " +
                     "created_by VARCHAR(50) DEFAULT 'admin', " +
                     "status VARCHAR(20) NOT NULL, " +
                     "backup_type VARCHAR(50) NOT NULL" +
                     ")";
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement()) {
            stmt.executeUpdate(sql);
        } catch (SQLException ignored) {
            // Silently handle if database is offline or creation fails
        }
    }

    @Override
    public DatabaseHealth checkDatabaseHealth() {
        DatabaseHealth health = new DatabaseHealth();

        try (Connection conn = DatabaseConnection.getConnection()) {
            if (conn == null || conn.isClosed()) {
                health.setConnected(false);
                health.setStatus(DatabaseHealth.HealthStatus.ERROR);
                return health;
            }

            health.setConnected(true);
            DatabaseMetaData metaData = conn.getMetaData();
            health.setDatabaseName(DatabaseConnection.getDatabaseName());
            health.setServerHost(DatabaseConnection.getHost() + ":" + DatabaseConnection.getPort());
            health.setDatabaseVersion(metaData.getDatabaseProductName() + " " + metaData.getDatabaseProductVersion());

            // 1. Check Required Tables
            Set<String> existingTables = new HashSet<>();
            try (ResultSet rs = metaData.getTables(conn.getCatalog(), null, "%", new String[]{"TABLE"})) {
                while (rs.next()) {
                    existingTables.add(rs.getString("TABLE_NAME").toLowerCase());
                }
            }

            List<String> missing = new ArrayList<>();
            for (String reqTable : REQUIRED_TABLES) {
                if (!existingTables.contains(reqTable.toLowerCase())) {
                    missing.add(reqTable);
                }
            }
            health.setMissingTables(missing);

            // 2. Fetch Row Counts & Verify Table Accessibility
            Map<String, Long> counts = new HashMap<>();
            for (String table : REQUIRED_TABLES) {
                if (existingTables.contains(table.toLowerCase())) {
                    try (Statement stmt = conn.createStatement();
                         ResultSet rs = stmt.executeQuery("SELECT COUNT(*) AS total FROM " + table)) {
                        if (rs.next()) {
                            counts.put(table, rs.getLong("total"));
                        }
                    } catch (SQLException e) {
                        counts.put(table, -1L);
                    }
                }
            }
            health.setTableCounts(counts);

            // 3. Non-destructive consistency checks
            List<String> consistencyIssues = checkDataConsistency(conn);
            health.setConsistencyIssues(consistencyIssues);

            // Determine Overall Health Status
            if (!missing.isEmpty()) {
                health.setStatus(DatabaseHealth.HealthStatus.ERROR);
            } else if (!consistencyIssues.isEmpty()) {
                health.setStatus(DatabaseHealth.HealthStatus.WARNING);
            } else {
                health.setStatus(DatabaseHealth.HealthStatus.HEALTHY);
            }

        } catch (SQLException e) {
            health.setConnected(false);
            health.setStatus(DatabaseHealth.HealthStatus.ERROR);
        }

        return health;
    }

    @Override
    public Map<String, Long> getTableRecordCounts() {
        Map<String, Long> counts = new LinkedHashMap<>();
        try (Connection conn = DatabaseConnection.getConnection()) {
            for (String table : REQUIRED_TABLES) {
                try (Statement stmt = conn.createStatement();
                     ResultSet rs = stmt.executeQuery("SELECT COUNT(*) AS total FROM " + table)) {
                    if (rs.next()) {
                        counts.put(table, rs.getLong("total"));
                    }
                } catch (SQLException e) {
                    counts.put(table, 0L);
                }
            }
        } catch (SQLException e) {
            // Return empty or default counts
        }
        return counts;
    }

    @Override
    public List<String> checkDataConsistency() {
        try (Connection conn = DatabaseConnection.getConnection()) {
            return checkDataConsistency(conn);
        } catch (SQLException e) {
            return List.of("Database unreachable: " + e.getMessage());
        }
    }

    private List<String> checkDataConsistency(Connection conn) {
        List<String> issues = new ArrayList<>();

        // Check 1: Order items with missing orders
        String sqlOrphanOrderItems = "SELECT COUNT(*) AS cnt FROM order_items oi LEFT JOIN orders o ON oi.order_id = o.id WHERE o.id IS NULL";
        checkQueryConsistency(conn, sqlOrphanOrderItems, "Found {0} order item(s) referencing non-existent order records.", issues);

        // Check 2: Order items with missing food items
        String sqlOrphanFoodItems = "SELECT COUNT(*) AS cnt FROM order_items oi LEFT JOIN food_items fi ON oi.food_item_id = fi.id WHERE fi.id IS NULL";
        checkQueryConsistency(conn, sqlOrphanFoodItems, "Found {0} order item(s) referencing deleted/missing menu food items.", issues);

        // Check 3: Bills with missing orders
        String sqlOrphanBills = "SELECT COUNT(*) AS cnt FROM bills b LEFT JOIN orders o ON b.order_id = o.id WHERE o.id IS NULL";
        checkQueryConsistency(conn, sqlOrphanBills, "Found {0} bill(s) referencing non-existent orders.", issues);

        // Check 4: Orders referencing non-existent customers
        String sqlOrphanOrders = "SELECT COUNT(*) AS cnt FROM orders o LEFT JOIN customers c ON o.customer_id = c.id WHERE o.customer_id IS NOT NULL AND c.id IS NULL";
        checkQueryConsistency(conn, sqlOrphanOrders, "Found {0} order(s) referencing non-existent customer IDs.", issues);

        // Check 5: Bills with negative totals
        String sqlNegativeBills = "SELECT COUNT(*) AS cnt FROM bills WHERE final_amount < 0";
        checkQueryConsistency(conn, sqlNegativeBills, "Found {0} bill(s) with invalid negative final amounts.", issues);

        return issues;
    }

    private void checkQueryConsistency(Connection conn, String sql, String messageTemplate, List<String> issues) {
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            if (rs.next()) {
                long count = rs.getLong("cnt");
                if (count > 0) {
                    issues.add(messageTemplate.replace("{0}", String.valueOf(count)));
                }
            }
        } catch (SQLException ignored) {
            // Ignore if schema does not support query
        }
    }

    @Override
    public void logBackupRecord(BackupRecord record) {
        String sql = "INSERT INTO backup_history (backup_name, backup_path, file_size_bytes, created_at, created_by, status, backup_type) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, record.getBackupName());
            ps.setString(2, record.getBackupPath());
            ps.setLong(3, record.getFileSizeBytes());
            ps.setTimestamp(4, Timestamp.valueOf(record.getCreatedAt() != null ? record.getCreatedAt() : LocalDateTime.now()));
            ps.setString(5, record.getCreatedBy() != null ? record.getCreatedBy() : "admin");
            ps.setString(6, record.getStatus() != null ? record.getStatus() : "SUCCESS");
            ps.setString(7, record.getBackupType() != null ? record.getBackupType() : "MANUAL");

            ps.executeUpdate();
            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) {
                    record.setId(rs.getInt(1));
                }
            }
        } catch (SQLException ignored) {
            // In case of logging failure, non-fatal
        }
    }

    @Override
    public List<BackupRecord> getBackupHistory() {
        List<BackupRecord> list = new ArrayList<>();
        String sql = "SELECT id, backup_name, backup_path, file_size_bytes, created_at, created_by, status, backup_type " +
                     "FROM backup_history ORDER BY id DESC LIMIT 50";
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                BackupRecord r = new BackupRecord();
                r.setId(rs.getInt("id"));
                r.setBackupName(rs.getString("backup_name"));
                r.setBackupPath(rs.getString("backup_path"));
                r.setFileSizeBytes(rs.getLong("file_size_bytes"));
                Timestamp ts = rs.getTimestamp("created_at");
                if (ts != null) {
                    r.setCreatedAt(ts.toLocalDateTime());
                }
                r.setCreatedBy(rs.getString("created_by"));
                r.setStatus(rs.getString("status"));
                r.setBackupType(rs.getString("backup_type"));
                list.add(r);
            }
        } catch (SQLException ignored) {
            // Return empty list if table not available
        }
        return list;
    }
}
