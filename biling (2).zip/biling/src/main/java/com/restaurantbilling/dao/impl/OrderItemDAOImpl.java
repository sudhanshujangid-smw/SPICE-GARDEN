package com.restaurantbilling.dao.impl;

import com.restaurantbilling.dao.OrderItemDAO;
import com.restaurantbilling.database.DatabaseConnection;
import com.restaurantbilling.exception.DatabaseException;
import com.restaurantbilling.model.OrderItem;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class OrderItemDAOImpl implements OrderItemDAO {

    @Override
    public void createOrderItems(Connection conn, int orderId, List<OrderItem> items) {
        String sql = "INSERT INTO order_items (order_id, food_item_id, quantity, unit_price, subtotal) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            for (OrderItem item : items) {
                stmt.setInt(1, orderId);
                stmt.setInt(2, item.getFoodItemId());
                stmt.setInt(3, item.getQuantity());
                stmt.setBigDecimal(4, item.getUnitPrice());
                stmt.setBigDecimal(5, item.getSubtotal());
                stmt.addBatch();
            }
            stmt.executeBatch();
        } catch (SQLException e) {
            throw new DatabaseException("Failed to save order items transactionally.", e);
        }
    }

    @Override
    public List<OrderItem> findByOrderId(int orderId) {
        String sql = "SELECT oi.id, oi.order_id, oi.food_item_id, f.name AS food_name, oi.quantity, oi.unit_price, oi.subtotal " +
                     "FROM order_items oi " +
                     "LEFT JOIN food_items f ON oi.food_item_id = f.id " +
                     "WHERE oi.order_id = ?";
        List<OrderItem> list = new ArrayList<>();
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, orderId);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    OrderItem item = new OrderItem(
                        rs.getInt("id"),
                        rs.getInt("order_id"),
                        rs.getInt("food_item_id"),
                        rs.getString("food_name"),
                        rs.getInt("quantity"),
                        rs.getBigDecimal("unit_price"),
                        rs.getBigDecimal("subtotal")
                    );
                    list.add(item);
                }
            }
        } catch (SQLException e) {
            throw new DatabaseException("Unable to fetch order items for order ID: " + orderId, e);
        }
        return list;
    }

    @Override
    public boolean deleteByOrderId(Connection conn, int orderId) {
        String sql = "DELETE FROM order_items WHERE order_id = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, orderId);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            throw new DatabaseException("Unable to delete order items for order ID: " + orderId, e);
        }
    }
}
