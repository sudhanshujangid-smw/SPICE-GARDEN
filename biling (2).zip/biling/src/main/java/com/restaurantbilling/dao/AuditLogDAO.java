package com.restaurantbilling.dao;

import com.restaurantbilling.model.audit.AuditLog;

import java.time.LocalDate;
import java.util.List;

public interface AuditLogDAO {

    /**
     * Persists an audit log record into MySQL.
     */
    void save(AuditLog log);

    /**
     * Searches and paginates audit log records matching the specified filters.
     */
    List<AuditLog> search(String keyword, String username, String module, String action, String status, LocalDate fromDate, LocalDate toDate, int limit, int offset);

    /**
     * Counts the total number of audit records matching the specified filters.
     */
    int count(String keyword, String username, String module, String action, String status, LocalDate fromDate, LocalDate toDate);

    /**
     * Initializes the audit_logs table and its performance indexes if not present.
     */
    void initAuditTableIfNotExists();
}
