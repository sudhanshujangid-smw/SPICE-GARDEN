package com.restaurantbilling.dao;

import com.restaurantbilling.model.OrderItem;

import java.sql.Connection;
import java.util.List;

public interface OrderItemDAO {
    void createOrderItems(Connection conn, int orderId, List<OrderItem> items);
    List<OrderItem> findByOrderId(int orderId);
    boolean deleteByOrderId(Connection conn, int orderId);
}
