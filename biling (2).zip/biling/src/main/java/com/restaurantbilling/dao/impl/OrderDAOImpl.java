package com.restaurantbilling.dao.impl;

import com.restaurantbilling.dao.OrderDAO;
import com.restaurantbilling.database.DatabaseConnection;
import com.restaurantbilling.exception.DatabaseException;
import com.restaurantbilling.model.Order;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class OrderDAOImpl implements OrderDAO {

    @Override
    public int createOrder(Connection conn, Order order) {
        String sql = "INSERT INTO orders (customer_id, subtotal, discount, tax, total, status) VALUES (?, ?, ?, ?, ?, ?)";
        try (PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            if (order.getCustomerId() != null && order.getCustomerId() > 0) {
                stmt.setInt(1, order.getCustomerId());
            } else {
                stmt.setNull(1, Types.INTEGER);
            }
            stmt.setBigDecimal(2, order.getSubtotal());
            stmt.setBigDecimal(3, order.getDiscount());
            stmt.setBigDecimal(4, order.getTax());
            stmt.setBigDecimal(5, order.getTotal());
            stmt.setString(6, order.getStatus() != null ? order.getStatus() : "PENDING");

            int affectedRows = stmt.executeUpdate();
            if (affectedRows == 0) {
                throw new DatabaseException("Creating order failed, no rows affected.");
            }

            try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    int orderId = generatedKeys.getInt(1);
                    order.setId(orderId);
                    return orderId;
                } else {
                    throw new DatabaseException("Creating order failed, no ID obtained.");
                }
            }
        } catch (SQLException e) {
            throw new DatabaseException("Failed to save order to database.", e);
        }
    }

    @Override
    public Optional<Order> findById(int id) {
        String sql = "SELECT o.id, o.customer_id, c.name AS customer_name, c.phone AS customer_phone, " +
                     "o.order_date, o.subtotal, o.discount, o.tax, o.total, o.status " +
                     "FROM orders o " +
                     "LEFT JOIN customers c ON o.customer_id = c.id " +
                     "WHERE o.id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return Optional.of(mapResultSetToOrder(rs));
                }
            }
        } catch (SQLException e) {
            throw new DatabaseException("Unable to find order by ID: " + id, e);
        }
        return Optional.empty();
    }

    @Override
    public List<Order> findAll() {
        return search(null, "All");
    }

    @Override
    public List<Order> search(String keyword, String status) {
        StringBuilder sql = new StringBuilder(
            "SELECT o.id, o.customer_id, c.name AS customer_name, c.phone AS customer_phone, " +
            "o.order_date, o.subtotal, o.discount, o.tax, o.total, o.status " +
            "FROM orders o " +
            "LEFT JOIN customers c ON o.customer_id = c.id " +
            "WHERE 1=1 "
        );
        List<Object> params = new ArrayList<>();

        if (keyword != null && !keyword.trim().isEmpty()) {
            String trimmed = keyword.trim();
            // Check if keyword is numeric order ID
            if (trimmed.matches("^\\d+$")) {
                sql.append("AND (o.id = ? OR c.name LIKE ? OR c.phone LIKE ?) ");
                params.add(Integer.parseInt(trimmed));
                params.add("%" + trimmed + "%");
                params.add("%" + trimmed + "%");
            } else {
                sql.append("AND (c.name LIKE ? OR c.phone LIKE ?) ");
                params.add("%" + trimmed + "%");
                params.add("%" + trimmed + "%");
            }
        }

        if (status != null && !status.trim().equalsIgnoreCase("All")) {
            sql.append("AND o.status = ? ");
            params.add(status.trim());
        }

        sql.append("ORDER BY o.id DESC");

        List<Order> list = new ArrayList<>();
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql.toString())) {

            for (int i = 0; i < params.size(); i++) {
                stmt.setObject(i + 1, params.get(i));
            }

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    list.add(mapResultSetToOrder(rs));
                }
            }
        } catch (SQLException e) {
            throw new DatabaseException("Unable to search orders.", e);
        }
        return list;
    }

    @Override
    public boolean updateStatus(int id, String status) {
        String sql = "UPDATE orders SET status = ? WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, status);
            stmt.setInt(2, id);

            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            throw new DatabaseException("Unable to update order status.", e);
        }
    }

    @Override
    public boolean cancelOrder(int id) {
        return updateStatus(id, "CANCELLED");
    }

    @Override
    public int countTotalOrders() {
        String sql = "SELECT COUNT(*) FROM orders";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            if (rs.next()) {
                return rs.getInt(1);
            }
        } catch (SQLException e) {
            return 0;
        }
        return 0;
    }

    private Order mapResultSetToOrder(ResultSet rs) throws SQLException {
        Order order = new Order();
        order.setId(rs.getInt("id"));
        int custId = rs.getInt("customer_id");
        if (!rs.wasNull()) {
            order.setCustomerId(custId);
        }
        order.setCustomerName(rs.getString("customer_name"));
        order.setCustomerPhone(rs.getString("customer_phone"));
        order.setOrderDate(rs.getTimestamp("order_date"));
        order.setSubtotal(rs.getBigDecimal("subtotal"));
        order.setDiscount(rs.getBigDecimal("discount"));
        order.setTax(rs.getBigDecimal("tax"));
        order.setTotal(rs.getBigDecimal("total"));
        order.setStatus(rs.getString("status"));
        return order;
    }
}
