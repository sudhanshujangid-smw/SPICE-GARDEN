package com.restaurantbilling.dao.impl;

import com.restaurantbilling.dao.FoodItemDAO;
import com.restaurantbilling.database.DatabaseConnection;
import com.restaurantbilling.exception.DatabaseException;
import com.restaurantbilling.model.FoodItem;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class FoodItemDAOImpl implements FoodItemDAO {

    @Override
    public List<FoodItem> findAll() {
        String sql = "SELECT id, name, category, price, available, image_url, image_source, pexels_photo_id, photographer_name, photographer_url FROM food_items ORDER BY id DESC";
        List<FoodItem> list = new ArrayList<>();
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                list.add(mapResultSetToFoodItem(rs));
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
            throw new DatabaseException("Unable to fetch food items.", e);
        }
        return list;
    }

    @Override
    public Optional<FoodItem> findById(int id) {
        String sql = "SELECT id, name, category, price, available, image_url, image_source, pexels_photo_id, photographer_name, photographer_url FROM food_items WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return Optional.of(mapResultSetToFoodItem(rs));
                }
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
            throw new DatabaseException("Error finding food item by ID.", e);
        }
        return Optional.empty();
    }

    @Override
    public List<FoodItem> search(String keyword, String category) {
        StringBuilder sql = new StringBuilder("SELECT id, name, category, price, available, image_url, image_source, pexels_photo_id, photographer_name, photographer_url FROM food_items WHERE 1=1 ");
        List<Object> params = new ArrayList<>();

        if (keyword != null && !keyword.trim().isEmpty()) {
            sql.append("AND name LIKE ? ");
            params.add("%" + keyword.trim() + "%");
        }

        if (category != null && !category.trim().equalsIgnoreCase("All")) {
            sql.append("AND category = ? ");
            params.add(category.trim());
        }

        sql.append("ORDER BY id DESC");

        List<FoodItem> list = new ArrayList<>();
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql.toString())) {

            for (int i = 0; i < params.size(); i++) {
                stmt.setObject(i + 1, params.get(i));
            }

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    list.add(mapResultSetToFoodItem(rs));
                }
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
            throw new DatabaseException("Error searching food items.", e);
        }
        return list;
    }

    @Override
    public FoodItem save(FoodItem item) {
        String sql = "INSERT INTO food_items (name, category, price, available, image_url, image_source, pexels_photo_id, photographer_name, photographer_url) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            stmt.setString(1, item.getName());
            stmt.setString(2, item.getCategory());
            stmt.setBigDecimal(3, item.getPrice());
            stmt.setBoolean(4, item.isAvailable());
            stmt.setString(5, item.getImageUrl());
            stmt.setString(6, item.getImageSource());
            if (item.getPexelsPhotoId() != null) {
                stmt.setLong(7, item.getPexelsPhotoId());
            } else {
                stmt.setNull(7, Types.BIGINT);
            }
            stmt.setString(8, item.getPhotographerName());
            stmt.setString(9, item.getPhotographerUrl());

            stmt.executeUpdate();
            try (ResultSet keys = stmt.getGeneratedKeys()) {
                if (keys.next()) {
                    item.setId(keys.getInt(1));
                }
            }
            return item;
        } catch (SQLException e) {
            System.out.println(e.getMessage());
            throw new DatabaseException("Unable to save food item.", e);
        }
    }

    @Override
    public boolean update(FoodItem item) {
        String sql = "UPDATE food_items SET name = ?, category = ?, price = ?, available = ?, image_url = ?, image_source = ?, pexels_photo_id = ?, photographer_name = ?, photographer_url = ? WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, item.getName());
            stmt.setString(2, item.getCategory());
            stmt.setBigDecimal(3, item.getPrice());
            stmt.setBoolean(4, item.isAvailable());
            stmt.setString(5, item.getImageUrl());
            stmt.setString(6, item.getImageSource());
            if (item.getPexelsPhotoId() != null) {
                stmt.setLong(7, item.getPexelsPhotoId());
            } else {
                stmt.setNull(7, Types.BIGINT);
            }
            stmt.setString(8, item.getPhotographerName());
            stmt.setString(9, item.getPhotographerUrl());
            stmt.setInt(10, item.getId());

            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.out.println(e.getMessage());
            throw new DatabaseException("Unable to update food item.", e);
        }
    }

    @Override
    public boolean delete(int id) {
        String sql = "DELETE FROM food_items WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.out.println(e.getMessage());
            throw new DatabaseException("Unable to delete food item.", e);
        }
    }

    @Override
    public int countTotalItems() {
        String sql = "SELECT COUNT(*) FROM food_items";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            if (rs.next()) {
                return rs.getInt(1);
            }
        } catch (SQLException e) {
            return 0;
        }
        return 0;
    }

    private FoodItem mapResultSetToFoodItem(ResultSet rs) throws SQLException {
        FoodItem item = new FoodItem(
            rs.getInt("id"),
            rs.getString("name"),
            rs.getString("category"),
            rs.getBigDecimal("price"),
            rs.getBoolean("available")
        );
        item.setImageUrl(rs.getString("image_url"));
        item.setImageSource(rs.getString("image_source"));
        long photoId = rs.getLong("pexels_photo_id");
        if (!rs.wasNull()) {
            item.setPexelsPhotoId(photoId);
        }
        item.setPhotographerName(rs.getString("photographer_name"));
        item.setPhotographerUrl(rs.getString("photographer_url"));
        return item;
    }
}
