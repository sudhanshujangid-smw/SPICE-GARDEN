package com.restaurantbilling.dao;

import com.restaurantbilling.model.RestaurantSettings;

import java.util.Map;
import java.util.Optional;

public interface SettingsDAO {
    Optional<String> getSetting(String key);
    Map<String, String> getAllSettings();
    RestaurantSettings getRestaurantSettings();
    boolean saveSetting(String key, String value, String updatedBy);
    boolean saveAllSettings(RestaurantSettings settings, String updatedBy);
}
