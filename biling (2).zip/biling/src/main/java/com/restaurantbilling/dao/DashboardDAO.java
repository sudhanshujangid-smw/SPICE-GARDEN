package com.restaurantbilling.dao;

import com.restaurantbilling.model.Bill;
import com.restaurantbilling.model.Order;
import com.restaurantbilling.model.dashboard.DashboardSummaryDTO;
import com.restaurantbilling.model.dashboard.OrderTrendDTO;
import com.restaurantbilling.model.report.BillingTrendDTO;
import com.restaurantbilling.model.report.ItemSalesDTO;

import java.util.List;

public interface DashboardDAO {

    /**
     * Retrieves aggregated KPI metrics for the specified date range.
     */
    DashboardSummaryDTO getDashboardKPIs(String fromDate, String toDate);

    /**
     * Retrieves daily billing trend for the specified date range.
     */
    List<BillingTrendDTO> getBillingTrend(String fromDate, String toDate);

    /**
     * Retrieves daily order volume trend for the specified date range.
     */
    List<OrderTrendDTO> getOrderTrend(String fromDate, String toDate);

    /**
     * Retrieves the top ordered menu items sorted by quantity.
     */
    List<ItemSalesDTO> getTopMenuItems(String fromDate, String toDate, int limit);

    /**
     * Retrieves the most recent bills.
     */
    List<Bill> getRecentBills(int limit);

    /**
     * Retrieves the most recent orders.
     */
    List<Order> getRecentOrders(int limit);
}
