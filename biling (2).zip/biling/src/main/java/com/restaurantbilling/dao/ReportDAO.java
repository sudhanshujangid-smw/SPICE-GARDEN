package com.restaurantbilling.dao;

import com.restaurantbilling.model.report.*;

import java.util.List;

public interface ReportDAO {
    BillSummaryDTO getBillSummary(String fromDate, String toDate);
    OrderSummaryDTO getOrderSummary(String fromDate, String toDate);
    CustomerSummaryDTO getCustomerSummary();
    List<ItemSalesDTO> getItemSalesReport(String fromDate, String toDate, int limit);
    List<BillingTrendDTO> getDailyBillingTrend(String fromDate, String toDate);
    List<BillingTrendDTO> getMonthlyBillingReport(int year);
    List<BillingTrendDTO> getMonthlyBillingReport(String fromDate, String toDate);
    List<OrderReportDTO> getOrderReport(String fromDate, String toDate, String status, int limit, int offset);
    int getOrderReportCount(String fromDate, String toDate, String status);
    List<CustomerReportDTO> getCustomerReport(String keyword, int limit, int offset);
    int getCustomerReportCount(String keyword);
    List<MenuReportDTO> getMenuReport(String fromDate, String toDate, String category);
}
