package com.restaurantbilling.dao;

import com.restaurantbilling.model.maintenance.BackupRecord;
import com.restaurantbilling.model.maintenance.DatabaseHealth;

import java.util.List;
import java.util.Map;

public interface MaintenanceDAO {

    /**
     * Checks connection status, required tables, accessibility and database metadata.
     */
    DatabaseHealth checkDatabaseHealth();

    /**
     * Retrieves table row counts using efficient SQL COUNT(*) operations.
     */
    Map<String, Long> getTableRecordCounts();

    /**
     * Executes non-destructive consistency checks for foreign keys and references.
     */
    List<String> checkDataConsistency();

    /**
     * Logs a backup operation into the backup history database table.
     */
    void logBackupRecord(BackupRecord record);

    /**
     * Retrieves the history of backups performed.
     */
    List<BackupRecord> getBackupHistory();

    /**
     * Ensures the backup_history table exists in the database.
     */
    void initBackupHistoryTableIfNotExists();
}
