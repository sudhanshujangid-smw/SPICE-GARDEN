package com.restaurantbilling.dao;

import com.restaurantbilling.model.Customer;

import java.util.List;
import java.util.Optional;

public interface CustomerDAO {
    List<Customer> findAll();
    Optional<Customer> findById(int id);
    Optional<Customer> findByPhone(String phone);
    List<Customer> search(String keyword, String status);
    Customer save(Customer customer);
    boolean update(Customer customer);
    boolean updateStatus(int id, String status);
    boolean delete(int id);
    boolean isPhoneRegistered(String phone, int excludeCustomerId);
    int countActiveCustomers();
}
