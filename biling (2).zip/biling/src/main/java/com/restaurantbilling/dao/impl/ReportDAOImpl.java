package com.restaurantbilling.dao.impl;

import com.restaurantbilling.dao.ReportDAO;
import com.restaurantbilling.database.DatabaseConnection;
import com.restaurantbilling.exception.DatabaseException;
import com.restaurantbilling.model.report.*;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.DateFormatSymbols;
import java.util.ArrayList;
import java.util.List;

public class ReportDAOImpl implements ReportDAO {

    private static final String DEFAULT_MIN_DATE = "1970-01-01";
    private static final String DEFAULT_MAX_DATE = "2099-12-31";

    @Override
    public BillSummaryDTO getBillSummary(String fromDate, String toDate) {
        String from = (fromDate != null && !fromDate.trim().isEmpty()) ? fromDate.trim() : DEFAULT_MIN_DATE;
        String to = (toDate != null && !toDate.trim().isEmpty()) ? toDate.trim() : DEFAULT_MAX_DATE;

        String sql = "SELECT COUNT(*) AS total_bills, " +
                     "COALESCE(SUM(final_amount), 0) AS total_amount, " +
                     "COALESCE(AVG(final_amount), 0) AS avg_amount, " +
                     "COALESCE(MAX(final_amount), 0) AS max_amount, " +
                     "COALESCE(MIN(final_amount), 0) AS min_amount " +
                     "FROM bills " +
                     "WHERE DATE(bill_date) BETWEEN ? AND ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, from);
            stmt.setString(2, to);

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    int count = rs.getInt("total_bills");
                    return new BillSummaryDTO(
                        count,
                        rs.getBigDecimal("total_amount"),
                        count > 0 ? rs.getBigDecimal("avg_amount") : BigDecimal.ZERO,
                        count > 0 ? rs.getBigDecimal("max_amount") : BigDecimal.ZERO,
                        count > 0 ? rs.getBigDecimal("min_amount") : BigDecimal.ZERO
                    );
                }
            }
        } catch (SQLException e) {
            throw new DatabaseException("Error generating bill summary report.", e);
        }
        return new BillSummaryDTO();
    }

    @Override
    public OrderSummaryDTO getOrderSummary(String fromDate, String toDate) {
        String from = (fromDate != null && !fromDate.trim().isEmpty()) ? fromDate.trim() : DEFAULT_MIN_DATE;
        String to = (toDate != null && !toDate.trim().isEmpty()) ? toDate.trim() : DEFAULT_MAX_DATE;

        String sql = "SELECT COUNT(*) AS total_orders, " +
                     "SUM(CASE WHEN status = 'COMPLETED' THEN 1 ELSE 0 END) AS completed_orders, " +
                     "SUM(CASE WHEN status = 'PENDING' THEN 1 ELSE 0 END) AS pending_orders, " +
                     "SUM(CASE WHEN status = 'CANCELLED' THEN 1 ELSE 0 END) AS cancelled_orders, " +
                     "SUM(CASE WHEN status IN ('PREPARING', 'READY', 'CONFIRMED') THEN 1 ELSE 0 END) AS preparing_orders, " +
                     "COALESCE(SUM(total), 0) AS total_val " +
                     "FROM orders " +
                     "WHERE DATE(order_date) BETWEEN ? AND ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, from);
            stmt.setString(2, to);

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return new OrderSummaryDTO(
                        rs.getInt("total_orders"),
                        rs.getInt("completed_orders"),
                        rs.getInt("pending_orders"),
                        rs.getInt("cancelled_orders"),
                        rs.getInt("preparing_orders"),
                        rs.getBigDecimal("total_val")
                    );
                }
            }
        } catch (SQLException e) {
            throw new DatabaseException("Error generating order summary report.", e);
        }
        return new OrderSummaryDTO();
    }

    @Override
    public CustomerSummaryDTO getCustomerSummary() {
        String sql = "SELECT " +
                     "(SELECT COUNT(*) FROM customers) AS total_cust, " +
                     "(SELECT COUNT(*) FROM customers) AS active_cust, " +
                     "(SELECT COUNT(DISTINCT customer_id) FROM orders WHERE customer_id IS NOT NULL) AS cust_with_orders, " +
                     "(SELECT COUNT(*) FROM orders) AS total_orders";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            if (rs.next()) {
                int totalCust = rs.getInt("total_cust");
                int activeCust = rs.getInt("active_cust");
                int custWithOrders = rs.getInt("cust_with_orders");
                int totalOrders = rs.getInt("total_orders");
                double avgOrders = (totalCust > 0) ? ((double) totalOrders / totalCust) : 0.0;

                return new CustomerSummaryDTO(totalCust, activeCust, custWithOrders, avgOrders);
            }
        } catch (SQLException e) {
            System.err.println("Exception class: " + e.getClass().getName());
            System.err.println("Exception message: " + e.getMessage());
            System.err.println("SQLState: " + e.getSQLState());
            System.err.println("Error code: " + e.getErrorCode());
            e.printStackTrace();
            throw new DatabaseException("Error generating customer summary report.", e);
        }
        return new CustomerSummaryDTO();
    }

    @Override
    public List<ItemSalesDTO> getItemSalesReport(String fromDate, String toDate, int limit) {
        String from = (fromDate != null && !fromDate.trim().isEmpty()) ? fromDate.trim() : DEFAULT_MIN_DATE;
        String to = (toDate != null && !toDate.trim().isEmpty()) ? toDate.trim() : DEFAULT_MAX_DATE;
        int queryLimit = limit > 0 ? limit : 100;

        String sql = "SELECT oi.food_item_id, " +
                     "COALESCE(f.name, CONCAT('Item #', oi.food_item_id)) AS food_name, " +
                     "COALESCE(f.category, 'General') AS food_category, " +
                     "SUM(oi.quantity) AS total_quantity_sold, " +
                     "SUM(oi.item_total) AS total_revenue " +
                     "FROM order_items oi " +
                     "JOIN orders o ON oi.order_id = o.id " +
                     "LEFT JOIN food_items f ON oi.food_item_id = f.id " +
                     "WHERE o.status != 'CANCELLED' AND DATE(o.order_date) BETWEEN ? AND ? " +
                     "GROUP BY oi.food_item_id, f.name, f.category " +
                     "ORDER BY total_quantity_sold DESC, total_revenue DESC " +
                     "LIMIT ?";

        List<ItemSalesDTO> list = new ArrayList<>();
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, from);
            stmt.setString(2, to);
            stmt.setInt(3, queryLimit);

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    list.add(new ItemSalesDTO(
                        rs.getInt("food_item_id"),
                        rs.getString("food_name"),
                        rs.getString("food_category"),
                        rs.getInt("total_quantity_sold"),
                        rs.getBigDecimal("total_revenue")
                    ));
                }
            }
        } catch (SQLException e) {
            throw new DatabaseException("Error generating item sales report.", e);
        }
        return list;
    }

    @Override
    public List<BillingTrendDTO> getDailyBillingTrend(String fromDate, String toDate) {
        String from = (fromDate != null && !fromDate.trim().isEmpty()) ? fromDate.trim() : DEFAULT_MIN_DATE;
        String to = (toDate != null && !toDate.trim().isEmpty()) ? toDate.trim() : DEFAULT_MAX_DATE;

        String sql = "SELECT DATE(b.bill_date) AS bill_day, " +
                     "COUNT(DISTINCT b.id) AS bill_count, " +
                     "COUNT(DISTINCT b.order_id) AS order_count, " +
                     "COALESCE(SUM(b.final_amount), 0) AS daily_amount " +
                     "FROM bills b " +
                     "WHERE DATE(b.bill_date) BETWEEN ? AND ? " +
                     "GROUP BY DATE(b.bill_date) " +
                     "ORDER BY DATE(b.bill_date) ASC";

        List<BillingTrendDTO> list = new ArrayList<>();
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, from);
            stmt.setString(2, to);

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    list.add(new BillingTrendDTO(
                        rs.getString("bill_day"),
                        rs.getInt("bill_count"),
                        rs.getInt("order_count"),
                        rs.getBigDecimal("daily_amount")
                    ));
                }
            }
        } catch (SQLException e) {
            throw new DatabaseException("Error generating daily billing trend.", e);
        }
        return list;
    }

    @Override
    public List<BillingTrendDTO> getMonthlyBillingReport(int year) {
        String sql = "SELECT MONTH(bill_date) AS b_month, " +
                     "COUNT(*) AS bill_count, " +
                     "COUNT(order_id) AS order_count, " +
                     "COALESCE(SUM(final_amount), 0) AS monthly_amount " +
                     "FROM bills " +
                     "WHERE YEAR(bill_date) = ? " +
                     "GROUP BY MONTH(bill_date) " +
                     "ORDER BY b_month ASC";

        String[] monthNames = new DateFormatSymbols().getMonths();
        List<BillingTrendDTO> list = new ArrayList<>();

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, year);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    int monthNum = rs.getInt("b_month");
                    String label = (monthNum >= 1 && monthNum <= 12) ? monthNames[monthNum - 1] : "Month " + monthNum;
                    list.add(new BillingTrendDTO(
                        label,
                        rs.getInt("bill_count"),
                        rs.getInt("order_count"),
                        rs.getBigDecimal("monthly_amount")
                    ));
                }
            }
        } catch (SQLException e) {
            throw new DatabaseException("Error generating monthly billing report for year: " + year, e);
        }
        return list;
    }

    @Override
    public List<BillingTrendDTO> getMonthlyBillingReport(String fromDate, String toDate) {
        String from = (fromDate != null && !fromDate.trim().isEmpty()) ? fromDate.trim() : DEFAULT_MIN_DATE;
        String to = (toDate != null && !toDate.trim().isEmpty()) ? toDate.trim() : DEFAULT_MAX_DATE;

        String sql = "SELECT DATE_FORMAT(bill_date, '%Y-%m') AS ym, " +
                     "YEAR(bill_date) AS b_year, " +
                     "MONTH(bill_date) AS b_month, " +
                     "COUNT(*) AS bill_count, " +
                     "COUNT(order_id) AS order_count, " +
                     "COALESCE(SUM(final_amount), 0) AS monthly_amount " +
                     "FROM bills " +
                     "WHERE DATE(bill_date) BETWEEN ? AND ? " +
                     "GROUP BY DATE_FORMAT(bill_date, '%Y-%m'), YEAR(bill_date), MONTH(bill_date) " +
                     "ORDER BY ym ASC";

        String[] monthNames = new DateFormatSymbols().getMonths();
        List<BillingTrendDTO> list = new ArrayList<>();

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, from);
            stmt.setString(2, to);

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    int monthNum = rs.getInt("b_month");
                    int yr = rs.getInt("b_year");
                    String monthName = (monthNum >= 1 && monthNum <= 12) ? monthNames[monthNum - 1] : "Month " + monthNum;
                    String label = monthName + " " + yr;
                    list.add(new BillingTrendDTO(
                        label,
                        rs.getInt("bill_count"),
                        rs.getInt("order_count"),
                        rs.getBigDecimal("monthly_amount")
                    ));
                }
            }
        } catch (SQLException e) {
            throw new DatabaseException("Error generating date-bounded monthly billing report.", e);
        }
        return list;
    }

    @Override
    public List<OrderReportDTO> getOrderReport(String fromDate, String toDate, String status, int limit, int offset) {
        String from = (fromDate != null && !fromDate.trim().isEmpty()) ? fromDate.trim() : DEFAULT_MIN_DATE;
        String to = (toDate != null && !toDate.trim().isEmpty()) ? toDate.trim() : DEFAULT_MAX_DATE;
        String filterStatus = (status != null && !status.trim().isEmpty()) ? status.trim() : "ALL";

        String sql = "SELECT o.id AS order_id, " +
                     "o.order_date, " +
                     "COALESCE(c.name, 'Walk-in Customer') AS customer_name, " +
                     "COALESCE(item_counts.cnt, 0) AS item_count, " +
                     "o.status, " +
                     "COALESCE(b.bill_number, 'N/A') AS bill_number, " +
                     "o.total " +
                     "FROM orders o " +
                     "LEFT JOIN customers c ON o.customer_id = c.id " +
                     "LEFT JOIN bills b ON o.id = b.order_id " +
                     "LEFT JOIN (SELECT order_id, COUNT(*) AS cnt FROM order_items GROUP BY order_id) item_counts ON o.id = item_counts.order_id " +
                     "WHERE DATE(o.order_date) BETWEEN ? AND ? " +
                     "  AND (? = 'ALL' OR o.status = ?) " +
                     "ORDER BY o.order_date DESC, o.id DESC " +
                     "LIMIT ? OFFSET ?";

        List<OrderReportDTO> list = new ArrayList<>();
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, from);
            stmt.setString(2, to);
            stmt.setString(3, filterStatus);
            stmt.setString(4, filterStatus);
            stmt.setInt(5, limit > 0 ? limit : 50);
            stmt.setInt(6, Math.max(offset, 0));

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    list.add(new OrderReportDTO(
                        rs.getInt("order_id"),
                        rs.getTimestamp("order_date"),
                        rs.getString("customer_name"),
                        rs.getInt("item_count"),
                        rs.getString("status"),
                        rs.getString("bill_number"),
                        rs.getBigDecimal("total")
                    ));
                }
            }
        } catch (SQLException e) {
            throw new DatabaseException("Error retrieving order report data.", e);
        }
        return list;
    }

    @Override
    public int getOrderReportCount(String fromDate, String toDate, String status) {
        String from = (fromDate != null && !fromDate.trim().isEmpty()) ? fromDate.trim() : DEFAULT_MIN_DATE;
        String to = (toDate != null && !toDate.trim().isEmpty()) ? toDate.trim() : DEFAULT_MAX_DATE;
        String filterStatus = (status != null && !status.trim().isEmpty()) ? status.trim() : "ALL";

        String sql = "SELECT COUNT(*) AS total_count " +
                     "FROM orders o " +
                     "WHERE DATE(o.order_date) BETWEEN ? AND ? " +
                     "  AND (? = 'ALL' OR o.status = ?)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, from);
            stmt.setString(2, to);
            stmt.setString(3, filterStatus);
            stmt.setString(4, filterStatus);

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("total_count");
                }
            }
        } catch (SQLException e) {
            throw new DatabaseException("Error counting order report records.", e);
        }
        return 0;
    }

    @Override
    public List<CustomerReportDTO> getCustomerReport(String keyword, int limit, int offset) {
        String kw = (keyword != null && !keyword.trim().isEmpty()) ? "%" + keyword.trim() + "%" : null;

        String sql = "SELECT c.id AS customer_id, " +
                     "c.name AS customer_name, " +
                     "c.phone AS customer_phone, " +
                     "COUNT(DISTINCT o.id) AS total_orders, " +
                     "COALESCE(SUM(b.final_amount), 0) AS total_billed_amount, " +
                     "MAX(o.order_date) AS last_order_date " +
                     "FROM customers c " +
                     "LEFT JOIN orders o ON c.id = o.customer_id " +
                     "LEFT JOIN bills b ON o.id = b.order_id " +
                     "WHERE (? IS NULL OR c.name LIKE ? OR c.phone LIKE ?) " +
                     "GROUP BY c.id, c.name, c.phone " +
                     "ORDER BY total_billed_amount DESC, total_orders DESC " +
                     "LIMIT ? OFFSET ?";

        List<CustomerReportDTO> list = new ArrayList<>();
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, kw);
            stmt.setString(2, kw);
            stmt.setString(3, kw);
            stmt.setInt(4, limit > 0 ? limit : 50);
            stmt.setInt(5, Math.max(offset, 0));

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    list.add(new CustomerReportDTO(
                        rs.getInt("customer_id"),
                        rs.getString("customer_name"),
                        rs.getString("customer_phone"),
                        rs.getInt("total_orders"),
                        rs.getBigDecimal("total_billed_amount"),
                        rs.getTimestamp("last_order_date")
                    ));
                }
            }
        } catch (SQLException e) {
            throw new DatabaseException("Error retrieving customer report data.", e);
        }
        return list;
    }

    @Override
    public int getCustomerReportCount(String keyword) {
        String kw = (keyword != null && !keyword.trim().isEmpty()) ? "%" + keyword.trim() + "%" : null;

        String sql = "SELECT COUNT(*) AS total_count " +
                     "FROM customers c " +
                     "WHERE (? IS NULL OR c.name LIKE ? OR c.phone LIKE ?)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, kw);
            stmt.setString(2, kw);
            stmt.setString(3, kw);

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("total_count");
                }
            }
        } catch (SQLException e) {
            throw new DatabaseException("Error counting customer report records.", e);
        }
        return 0;
    }

    @Override
    public List<MenuReportDTO> getMenuReport(String fromDate, String toDate, String category) {
        String from = (fromDate != null && !fromDate.trim().isEmpty()) ? fromDate.trim() : DEFAULT_MIN_DATE;
        String to = (toDate != null && !toDate.trim().isEmpty()) ? toDate.trim() : DEFAULT_MAX_DATE;
        String filterCategory = (category != null && !category.trim().isEmpty()) ? category.trim() : "ALL";

        String sql = "SELECT f.id AS food_item_id, " +
                     "f.name AS food_name, " +
                     "f.category AS food_category, " +
                     "f.price AS unit_price, " +
                     "COALESCE(SUM(oi.quantity), 0) AS total_qty_ordered, " +
                     "COALESCE(SUM(oi.item_total), 0) AS total_billing " +
                     "FROM food_items f " +
                     "LEFT JOIN order_items oi ON f.id = oi.food_item_id " +
                     "LEFT JOIN orders o ON oi.order_id = o.id AND o.status != 'CANCELLED' AND DATE(o.order_date) BETWEEN ? AND ? " +
                     "WHERE (? = 'ALL' OR f.category = ?) " +
                     "GROUP BY f.id, f.name, f.category, f.price " +
                     "ORDER BY total_billing DESC, total_qty_ordered DESC";

        List<MenuReportDTO> list = new ArrayList<>();
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, from);
            stmt.setString(2, to);
            stmt.setString(3, filterCategory);
            stmt.setString(4, filterCategory);

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    list.add(new MenuReportDTO(
                        rs.getInt("food_item_id"),
                        rs.getString("food_name"),
                        rs.getString("food_category"),
                        rs.getBigDecimal("unit_price"),
                        rs.getInt("total_qty_ordered"),
                        rs.getBigDecimal("total_billing")
                    ));
                }
            }
        } catch (SQLException e) {
            throw new DatabaseException("Error generating menu item performance report.", e);
        }
        return list;
    }
}
