package com.restaurantbilling.dao.impl;

import com.restaurantbilling.dao.SettingsDAO;
import com.restaurantbilling.database.DatabaseConnection;
import com.restaurantbilling.exception.DatabaseException;
import com.restaurantbilling.model.RestaurantSettings;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

public class SettingsDAOImpl implements SettingsDAO {

    @Override
    public Optional<String> getSetting(String key) {
        String sql = "SELECT setting_value FROM system_settings WHERE setting_key = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, key);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return Optional.ofNullable(rs.getString("setting_value"));
                }
            }
        } catch (SQLException e) {
            // Suppress error if table does not exist yet
            return Optional.empty();
        }
        return Optional.empty();
    }

    @Override
    public Map<String, String> getAllSettings() {
        String sql = "SELECT setting_key, setting_value FROM system_settings";
        Map<String, String> map = new HashMap<>();
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                map.put(rs.getString("setting_key"), rs.getString("setting_value"));
            }
        } catch (SQLException e) {
            return map;
        }
        return map;
    }

    @Override
    public RestaurantSettings getRestaurantSettings() {
        RestaurantSettings settings = new RestaurantSettings();
        Map<String, String> map = getAllSettings();

        if (map.isEmpty()) {
            return settings; // Return default settings
        }

        if (map.containsKey("restaurant_name")) settings.setRestaurantName(map.get("restaurant_name"));
        if (map.containsKey("restaurant_address")) settings.setAddress(map.get("restaurant_address"));
        if (map.containsKey("restaurant_city")) settings.setCity(map.get("restaurant_city"));
        if (map.containsKey("restaurant_state")) settings.setState(map.get("restaurant_state"));
        if (map.containsKey("restaurant_pincode")) settings.setPincode(map.get("restaurant_pincode"));
        if (map.containsKey("restaurant_phone")) settings.setPhone(map.get("restaurant_phone"));
        if (map.containsKey("restaurant_email")) settings.setEmail(map.get("restaurant_email"));
        if (map.containsKey("restaurant_website")) settings.setWebsite(map.get("restaurant_website"));
        if (map.containsKey("restaurant_logo_path")) settings.setLogoPath(map.get("restaurant_logo_path"));
        if (map.containsKey("invoice_header")) settings.setInvoiceHeader(map.get("invoice_header"));
        if (map.containsKey("invoice_footer")) settings.setInvoiceFooter(map.get("invoice_footer"));
        if (map.containsKey("currency_symbol")) settings.setCurrencySymbol(map.get("currency_symbol"));

        if (map.containsKey("tax_rate")) {
            try {
                settings.setTaxRate(Double.parseDouble(map.get("tax_rate")));
            } catch (NumberFormatException ignored) {}
        }

        return settings;
    }

    @Override
    public boolean saveSetting(String key, String value, String updatedBy) {
        String sql = "INSERT INTO system_settings (setting_key, setting_value, updated_by) " +
                     "VALUES (?, ?, ?) " +
                     "ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value), updated_by = VALUES(updated_by), updated_at = CURRENT_TIMESTAMP";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, key);
            stmt.setString(2, value != null ? value : "");
            stmt.setString(3, updatedBy != null ? updatedBy : "admin");

            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            throw new DatabaseException("Error saving setting '" + key + "' to database.", e);
        }
    }

    @Override
    public boolean saveAllSettings(RestaurantSettings s, String updatedBy) {
        Map<String, String> entries = new HashMap<>();
        entries.put("restaurant_name", s.getRestaurantName());
        entries.put("restaurant_address", s.getAddress());
        entries.put("restaurant_city", s.getCity());
        entries.put("restaurant_state", s.getState());
        entries.put("restaurant_pincode", s.getPincode());
        entries.put("restaurant_phone", s.getPhone());
        entries.put("restaurant_email", s.getEmail());
        entries.put("restaurant_website", s.getWebsite());
        entries.put("restaurant_logo_path", s.getLogoPath());
        entries.put("invoice_header", s.getInvoiceHeader());
        entries.put("invoice_footer", s.getInvoiceFooter());
        entries.put("currency_symbol", s.getCurrencySymbol());
        entries.put("tax_rate", String.valueOf(s.getTaxRate()));

        String sql = "INSERT INTO system_settings (setting_key, setting_value, updated_by) " +
                     "VALUES (?, ?, ?) " +
                     "ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value), updated_by = VALUES(updated_by), updated_at = CURRENT_TIMESTAMP";

        try (Connection conn = DatabaseConnection.getConnection()) {
            conn.setAutoCommit(false);
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                for (Map.Entry<String, String> entry : entries.entrySet()) {
                    stmt.setString(1, entry.getKey());
                    stmt.setString(2, entry.getValue() != null ? entry.getValue() : "");
                    stmt.setString(3, updatedBy != null ? updatedBy : "admin");
                    stmt.addBatch();
                }
                stmt.executeBatch();
                conn.commit();
                return true;
            } catch (Exception e) {
                conn.rollback();
                throw new DatabaseException("Failed to batch save settings.", e);
            } finally {
                conn.setAutoCommit(true);
            }
        } catch (SQLException e) {
            throw new DatabaseException("Database error saving restaurant settings.", e);
        }
    }
}
