package com.restaurantbilling.dao.impl;

import com.restaurantbilling.dao.AuditLogDAO;
import com.restaurantbilling.database.DatabaseConnection;
import com.restaurantbilling.model.audit.AuditLog;

import java.sql.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class AuditLogDAOImpl implements AuditLogDAO {

    public AuditLogDAOImpl() {
        initAuditTableIfNotExists();
    }

    @Override
    public void initAuditTableIfNotExists() {
        String sql = "CREATE TABLE IF NOT EXISTS audit_logs (" +
                     "id INT AUTO_INCREMENT PRIMARY KEY, " +
                     "user_id INT, " +
                     "username VARCHAR(50) NOT NULL, " +
                     "module VARCHAR(50) NOT NULL, " +
                     "action VARCHAR(50) NOT NULL, " +
                     "description TEXT, " +
                     "timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP, " +
                     "status VARCHAR(20) NOT NULL DEFAULT 'SUCCESS', " +
                     "INDEX idx_audit_user (username), " +
                     "INDEX idx_audit_module (module), " +
                     "INDEX idx_audit_action (action), " +
                     "INDEX idx_audit_timestamp (timestamp), " +
                     "INDEX idx_audit_status (status), " +
                     "FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL" +
                     ")";
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement()) {
            stmt.executeUpdate(sql);
        } catch (SQLException ignored) {
            // Silently handle if database is offline during startup initialization
        }
    }

    @Override
    public void save(AuditLog log) {
        if (log == null) return;

        String sql = "INSERT INTO audit_logs (user_id, username, module, action, description, timestamp, status) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            if (log.getUserId() != null && log.getUserId() > 0) {
                ps.setInt(1, log.getUserId());
            } else {
                ps.setNull(1, Types.INTEGER);
            }
            ps.setString(2, log.getUsername() != null ? log.getUsername() : "SYSTEM");
            ps.setString(3, log.getModule() != null ? log.getModule() : "SYSTEM");
            ps.setString(4, log.getAction() != null ? log.getAction() : "UNKNOWN");
            ps.setString(5, log.getDescription() != null ? log.getDescription() : "");
            ps.setTimestamp(6, Timestamp.valueOf(log.getTimestamp() != null ? log.getTimestamp() : LocalDateTime.now()));
            ps.setString(7, log.getStatus() != null ? log.getStatus() : "SUCCESS");

            ps.executeUpdate();
            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) {
                    log.setId(rs.getInt(1));
                }
            }
        } catch (SQLException ignored) {
            // Non-fatal if database is offline during audit call
        }
    }

    @Override
    public List<AuditLog> search(String keyword, String username, String module, String action, String status, LocalDate fromDate, LocalDate toDate, int limit, int offset) {
        List<AuditLog> list = new ArrayList<>();
        StringBuilder sql = new StringBuilder("SELECT id, user_id, username, module, action, description, timestamp, status FROM audit_logs WHERE 1=1 ");
        List<Object> params = new ArrayList<>();

        buildFilterQuery(sql, params, keyword, username, module, action, status, fromDate, toDate);

        sql.append(" ORDER BY timestamp DESC, id DESC LIMIT ? OFFSET ?");
        params.add(limit > 0 ? limit : 50);
        params.add(Math.max(offset, 0));

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql.toString())) {

            for (int i = 0; i < params.size(); i++) {
                ps.setObject(i + 1, params.get(i));
            }

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    AuditLog log = new AuditLog();
                    log.setId(rs.getInt("id"));
                    int uid = rs.getInt("user_id");
                    if (!rs.wasNull()) {
                        log.setUserId(uid);
                    }
                    log.setUsername(rs.getString("username"));
                    log.setModule(rs.getString("module"));
                    log.setAction(rs.getString("action"));
                    log.setDescription(rs.getString("description"));
                    Timestamp ts = rs.getTimestamp("timestamp");
                    if (ts != null) {
                        log.setTimestamp(ts.toLocalDateTime());
                    }
                    log.setStatus(rs.getString("status"));
                    list.add(log);
                }
            }
        } catch (SQLException ignored) {
        }

        return list;
    }

    @Override
    public int count(String keyword, String username, String module, String action, String status, LocalDate fromDate, LocalDate toDate) {
        StringBuilder sql = new StringBuilder("SELECT COUNT(*) AS total FROM audit_logs WHERE 1=1 ");
        List<Object> params = new ArrayList<>();

        buildFilterQuery(sql, params, keyword, username, module, action, status, fromDate, toDate);

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql.toString())) {

            for (int i = 0; i < params.size(); i++) {
                ps.setObject(i + 1, params.get(i));
            }

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("total");
                }
            }
        } catch (SQLException ignored) {
        }

        return 0;
    }

    private void buildFilterQuery(StringBuilder sql, List<Object> params, String keyword, String username, String module, String action, String status, LocalDate fromDate, LocalDate toDate) {
        if (keyword != null && !keyword.trim().isEmpty()) {
            sql.append(" AND (description LIKE ? OR username LIKE ? OR action LIKE ?)");
            String pattern = "%" + keyword.trim() + "%";
            params.add(pattern);
            params.add(pattern);
            params.add(pattern);
        }

        if (username != null && !username.trim().isEmpty() && !"ALL".equalsIgnoreCase(username.trim())) {
            sql.append(" AND username = ?");
            params.add(username.trim());
        }

        if (module != null && !module.trim().isEmpty() && !"ALL".equalsIgnoreCase(module.trim())) {
            sql.append(" AND module = ?");
            params.add(module.trim());
        }

        if (action != null && !action.trim().isEmpty() && !"ALL".equalsIgnoreCase(action.trim())) {
            sql.append(" AND action = ?");
            params.add(action.trim());
        }

        if (status != null && !status.trim().isEmpty() && !"ALL".equalsIgnoreCase(status.trim())) {
            sql.append(" AND status = ?");
            params.add(status.trim());
        }

        if (fromDate != null) {
            sql.append(" AND timestamp >= ?");
            params.add(Timestamp.valueOf(fromDate.atStartOfDay()));
        }

        if (toDate != null) {
            sql.append(" AND timestamp <= ?");
            params.add(Timestamp.valueOf(toDate.atTime(23, 59, 59)));
        }
    }
}
