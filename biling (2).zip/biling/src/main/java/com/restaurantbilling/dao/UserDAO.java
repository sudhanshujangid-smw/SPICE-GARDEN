package com.restaurantbilling.dao;

import com.restaurantbilling.model.User;
import java.util.Optional;

public interface UserDAO {
    Optional<User> findByUsername(String username);
    Optional<User> authenticate(String username, String password);
    boolean updatePassword(int userId, String newHashedPassword);
}
