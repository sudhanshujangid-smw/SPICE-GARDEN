package com.restaurantbilling.service;

import com.restaurantbilling.dao.FoodItemDAO;
import com.restaurantbilling.dao.impl.FoodItemDAOImpl;
import com.restaurantbilling.exception.ValidationException;
import com.restaurantbilling.model.FoodItem;
import com.restaurantbilling.util.UserSession;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

public class FoodItemService {
    private final FoodItemDAO foodItemDAO;
    private final AuditService auditService;

    public FoodItemService() {
        this.foodItemDAO = new FoodItemDAOImpl();
        this.auditService = new AuditService();
    }

    public FoodItemService(FoodItemDAO foodItemDAO) {
        this.foodItemDAO = foodItemDAO;
        this.auditService = new AuditService();
    }

    public FoodItemService(FoodItemDAO foodItemDAO, AuditService auditService) {
        this.foodItemDAO = foodItemDAO;
        this.auditService = auditService;
    }

    public List<FoodItem> getAllFoodItems() {
        return foodItemDAO.findAll();
    }

    public Optional<FoodItem> getFoodItemById(int id) {
        return foodItemDAO.findById(id);
    }

    public List<FoodItem> searchFoodItems(String keyword, String category) {
        return foodItemDAO.search(keyword, category);
    }

    public FoodItem addFoodItem(FoodItem item) throws ValidationException {
        checkAdminPermission("add food item");
        validateFoodItem(item);
        FoodItem saved = foodItemDAO.save(item);
        auditService.log("MENU", "MENU_CREATED", "Added menu item: " + saved.getName() + " (Category: " + saved.getCategory() + ", Price: " + saved.getPrice() + ")", "SUCCESS");
        return saved;
    }

    public boolean updateFoodItem(FoodItem item) throws ValidationException {
        checkAdminPermission("update food item");
        if (item.getId() <= 0) {
            throw new ValidationException("Invalid food item ID.");
        }
        validateFoodItem(item);
        boolean updated = foodItemDAO.update(item);
        if (updated) {
            auditService.log("MENU", "MENU_UPDATED", "Updated menu item: " + item.getName() + " (ID: " + item.getId() + ", Price: " + item.getPrice() + ")", "SUCCESS");
        }
        return updated;
    }

    public boolean deleteFoodItem(int id) throws ValidationException {
        checkAdminPermission("delete food item");
        Optional<FoodItem> existing = foodItemDAO.findById(id);
        String name = existing.map(FoodItem::getName).orElse("ID #" + id);

        boolean deleted = foodItemDAO.delete(id);
        if (deleted) {
            auditService.log("MENU", "MENU_DELETED", "Deleted menu item: " + name + " (ID: " + id + ")", "SUCCESS");
        }
        return deleted;
    }

    public int getTotalFoodItemCount() {
        return foodItemDAO.countTotalItems();
    }

    private void validateFoodItem(FoodItem item) throws ValidationException {
        if (item == null) {
            throw new ValidationException("Food item details cannot be empty.");
        }
        if (item.getName() == null || item.getName().trim().isEmpty()) {
            throw new ValidationException("Food item name is required.");
        }
        if (item.getCategory() == null || item.getCategory().trim().isEmpty()) {
            throw new ValidationException("Category is required.");
        }
        if (item.getPrice() == null || item.getPrice().compareTo(BigDecimal.ZERO) < 0) {
            throw new ValidationException("Price must be a valid positive amount.");
        }
    }

    private void checkAdminPermission(String operation) throws ValidationException {
        if (UserSession.isLoggedIn() && !UserSession.isAdmin()) {
            auditService.log("MENU", "ACCESS_DENIED", "Unauthorized attempt by " + UserSession.getUsername() + " to " + operation + ".", "DENIED");
            throw new ValidationException("Access Denied: Only ADMIN can " + operation + ".");
        }
    }
}
