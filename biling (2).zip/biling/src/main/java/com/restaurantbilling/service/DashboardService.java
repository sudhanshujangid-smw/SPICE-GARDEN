package com.restaurantbilling.service;

import com.restaurantbilling.dao.DashboardDAO;
import com.restaurantbilling.dao.impl.DashboardDAOImpl;
import com.restaurantbilling.exception.ValidationException;
import com.restaurantbilling.model.Bill;
import com.restaurantbilling.model.Order;
import com.restaurantbilling.model.dashboard.DashboardSummaryDTO;
import com.restaurantbilling.model.dashboard.OrderTrendDTO;
import com.restaurantbilling.model.report.BillingTrendDTO;
import com.restaurantbilling.model.report.ItemSalesDTO;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

public class DashboardService {

    private final DashboardDAO dashboardDAO;

    public DashboardService() {
        this.dashboardDAO = new DashboardDAOImpl();
    }

    public DashboardService(DashboardDAO dashboardDAO) {
        this.dashboardDAO = dashboardDAO;
    }

    /**
     * Validates date range constraints (format YYYY-MM-DD and fromDate <= toDate).
     */
    public void validateDateRange(String fromDate, String toDate) throws ValidationException {
        if (fromDate == null || fromDate.trim().isEmpty() || toDate == null || toDate.trim().isEmpty()) {
            return; // Allowed: query without date range
        }

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        sdf.setLenient(false);

        Date from;
        Date to;

        try {
            from = sdf.parse(fromDate.trim());
        } catch (ParseException e) {
            throw new ValidationException("Invalid 'From Date' format. Please use YYYY-MM-DD format.");
        }

        try {
            to = sdf.parse(toDate.trim());
        } catch (ParseException e) {
            throw new ValidationException("Invalid 'To Date' format. Please use YYYY-MM-DD format.");
        }

        if (from.after(to)) {
            throw new ValidationException("From date cannot be after the To date.");
        }
    }

    public DashboardSummaryDTO getDashboardKPIs(String fromDate, String toDate) throws ValidationException {
        validateDateRange(fromDate, toDate);
        return dashboardDAO.getDashboardKPIs(fromDate, toDate);
    }

    public List<BillingTrendDTO> getBillingTrend(String fromDate, String toDate) throws ValidationException {
        validateDateRange(fromDate, toDate);
        return dashboardDAO.getBillingTrend(fromDate, toDate);
    }

    public List<OrderTrendDTO> getOrderTrend(String fromDate, String toDate) throws ValidationException {
        validateDateRange(fromDate, toDate);
        return dashboardDAO.getOrderTrend(fromDate, toDate);
    }

    public List<ItemSalesDTO> getTopMenuItems(String fromDate, String toDate, int limit) throws ValidationException {
        validateDateRange(fromDate, toDate);
        return dashboardDAO.getTopMenuItems(fromDate, toDate, limit);
    }

    public List<Bill> getRecentBills(int limit) {
        return dashboardDAO.getRecentBills(limit > 0 ? limit : 5);
    }

    public List<Order> getRecentOrders(int limit) {
        return dashboardDAO.getRecentOrders(limit > 0 ? limit : 5);
    }
}
