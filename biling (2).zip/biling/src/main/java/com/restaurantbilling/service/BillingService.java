package com.restaurantbilling.service;

import com.restaurantbilling.dao.BillDAO;
import com.restaurantbilling.dao.OrderDAO;
import com.restaurantbilling.dao.OrderItemDAO;
import com.restaurantbilling.dao.impl.BillDAOImpl;
import com.restaurantbilling.dao.impl.OrderDAOImpl;
import com.restaurantbilling.dao.impl.OrderItemDAOImpl;
import com.restaurantbilling.database.DatabaseConnection;
import com.restaurantbilling.exception.DatabaseException;
import com.restaurantbilling.exception.ValidationException;
import com.restaurantbilling.model.Bill;
import com.restaurantbilling.model.Order;
import com.restaurantbilling.model.OrderItem;
import com.restaurantbilling.util.UserSession;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Optional;

public class BillingService {

    private final BillDAO billDAO;
    private final OrderDAO orderDAO;
    private final OrderItemDAO orderItemDAO;
    private final AuditService auditService;

    public BillingService() {
        this.billDAO = new BillDAOImpl();
        this.orderDAO = new OrderDAOImpl();
        this.orderItemDAO = new OrderItemDAOImpl();
        this.auditService = new AuditService();
    }

    public BillingService(BillDAO billDAO, OrderDAO orderDAO, OrderItemDAO orderItemDAO) {
        this.billDAO = billDAO;
        this.orderDAO = orderDAO;
        this.orderItemDAO = orderItemDAO;
        this.auditService = new AuditService();
    }

    public BillingService(BillDAO billDAO, OrderDAO orderDAO, OrderItemDAO orderItemDAO, AuditService auditService) {
        this.billDAO = billDAO;
        this.orderDAO = orderDAO;
        this.orderItemDAO = orderItemDAO;
        this.auditService = auditService;
    }

    /**
     * Generates a new bill for the given order after validating duplicate prevention.
     */
    public Bill generateBillForOrder(int orderId) throws ValidationException {
        checkLoggedIn("generate bill");

        // 1. Duplicate check
        if (billDAO.isOrderBilled(orderId)) {
            Optional<Bill> existing = billDAO.findByOrderId(orderId);
            if (existing.isPresent()) {
                throw new ValidationException("This order has already been billed. (Bill #" + existing.get().getBillNumber() + ")");
            }
            throw new ValidationException("This order has already been billed.");
        }

        // 2. Fetch order
        Optional<Order> orderOpt = orderDAO.findById(orderId);
        if (orderOpt.isEmpty()) {
            throw new ValidationException("Order #" + orderId + " not found.");
        }

        Order order = orderOpt.get();
        if ("CANCELLED".equalsIgnoreCase(order.getStatus())) {
            throw new ValidationException("Cannot generate bill for a cancelled order.");
        }

        // 3. Fetch order items (preserving historical prices)
        List<OrderItem> items = orderItemDAO.findByOrderId(orderId);
        if (items.isEmpty()) {
            throw new ValidationException("Order has no items to bill.");
        }

        // 4. Calculate Bill Totals using BigDecimal
        BigDecimal subtotal = order.getSubtotal() != null ? order.getSubtotal() : BigDecimal.ZERO;
        BigDecimal discount = order.getDiscount() != null ? order.getDiscount() : BigDecimal.ZERO;
        BigDecimal tax = order.getTax() != null ? order.getTax() : BigDecimal.ZERO;
        BigDecimal grandTotal = subtotal.subtract(discount).add(tax);

        // 5. Generate Unique Bill Number
        String datePrefix = new SimpleDateFormat("yyyyMMdd").format(new Date());
        String billNumber = "BILL-" + datePrefix + "-" + String.format("%04d", orderId);

        Bill bill = new Bill(orderId, billNumber, subtotal, discount, tax, grandTotal);
        bill.setCustomerName(order.getCustomerName());
        bill.setCustomerPhone(order.getCustomerPhone());
        bill.setItems(items);

        // 6. Save in Transaction
        Connection conn = null;
        try {
            conn = DatabaseConnection.getConnection();
            conn.setAutoCommit(false); // BEGIN

            Bill createdBill = billDAO.createBill(conn, bill);

            // Update order status to COMPLETED upon bill generation
            orderDAO.updateStatus(orderId, "COMPLETED");

            conn.commit(); // COMMIT
            createdBill.setCustomerName(order.getCustomerName());
            createdBill.setCustomerPhone(order.getCustomerPhone());
            createdBill.setItems(items);

            auditService.log("BILLING", "BILL_GENERATED", "Generated " + createdBill.getBillNumber() + " for order #" + orderId + " (Grand Total: " + createdBill.getFinalAmount() + ")", "SUCCESS");
            return createdBill;
        } catch (Exception ex) {
            if (conn != null) {
                try {
                    conn.rollback(); // ROLLBACK
                } catch (SQLException ignored) {}
            }
            throw new DatabaseException("Failed to save bill transactionally: " + ex.getMessage(), ex);
        } finally {
            if (conn != null) {
                try {
                    conn.setAutoCommit(true);
                    conn.close();
                } catch (SQLException ignored) {}
            }
        }
    }

    public Optional<Bill> getBillDetails(int billId) {
        Optional<Bill> billOpt = billDAO.findById(billId);
        billOpt.ifPresent(bill -> {
            List<OrderItem> items = orderItemDAO.findByOrderId(bill.getOrderId());
            bill.setItems(items);
        });
        return billOpt;
    }

    public Optional<Bill> getBillByOrderId(int orderId) {
        Optional<Bill> billOpt = billDAO.findByOrderId(orderId);
        billOpt.ifPresent(bill -> {
            List<OrderItem> items = orderItemDAO.findByOrderId(bill.getOrderId());
            bill.setItems(items);
        });
        return billOpt;
    }

    public List<Bill> getAllBills() {
        return billDAO.findAll();
    }

    public List<Bill> searchBills(String keyword) {
        return billDAO.searchBills(keyword);
    }

    public boolean isOrderAlreadyBilled(int orderId) {
        return billDAO.isOrderBilled(orderId);
    }

    public int getTotalBillCount() {
        return billDAO.countTotalBills();
    }

    private void checkLoggedIn(String operation) throws ValidationException {
        if (!UserSession.isLoggedIn()) {
            auditService.log("BILLING", "ACCESS_DENIED", "Unauthenticated attempt to " + operation + ".", "DENIED");
            throw new ValidationException("Access Denied: You must be logged in to " + operation + ".");
        }
    }
}
