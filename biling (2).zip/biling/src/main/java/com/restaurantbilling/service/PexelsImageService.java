package com.restaurantbilling.service;

import com.restaurantbilling.api.pexels.PexelsApiClient;
import com.restaurantbilling.api.pexels.PexelsPhoto;
import com.restaurantbilling.api.pexels.PexelsResponse;

import javax.imageio.ImageIO;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.net.URL;
import java.util.List;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.io.ByteArrayInputStream;
import java.awt.image.RenderedImage;

public class PexelsImageService {

    private final PexelsApiClient apiClient;
    private final File cacheDir;
    private final HttpClient imageHttpClient;

    public PexelsImageService() {
        this.apiClient = new PexelsApiClient();
        this.cacheDir = new File("cache/pexels");
        if (!cacheDir.exists()) {
            cacheDir.mkdirs();
        }
        this.imageHttpClient = HttpClient.newBuilder()
                .followRedirects(HttpClient.Redirect.NORMAL)
                .connectTimeout(Duration.ofSeconds(10))
                .build();
    }

    public List<PexelsPhoto> searchFoodImages(String dishName) throws Exception {
        if (dishName == null || dishName.trim().isEmpty()) {
            throw new Exception("Dish name cannot be empty");
        }
        String query = dishName.trim() + " food";
        PexelsResponse response = apiClient.searchImages(query, 12);
        if (response.getPhotos() == null || response.getPhotos().isEmpty()) {
            throw new Exception("No suitable food images found.");
        }
        return response.getPhotos();
    }

    public Image getCachedOrDownloadImage(long photoId, String imageUrlStr) throws Exception {
        File cachedFile = new File(cacheDir, photoId + ".jpg");
        if (cachedFile.exists() && cachedFile.length() > 0) {
            try {
                BufferedImage image = ImageIO.read(cachedFile);
                if (image != null) {
                    return image;
                }
            } catch (Exception e) {
                // Ignore and fall through to re-download
            }
            cachedFile.delete(); // Delete corrupt or unrecognized cache file
        }

        Image image = downloadAndValidateImage(photoId, imageUrlStr);
        if (image != null) {
            ImageIO.write((RenderedImage) image, "jpg", cachedFile);
        }
        return image;
    }
    
    public Image loadDirectImage(long photoId, String imageUrlStr) throws Exception {
        return downloadAndValidateImage(photoId, imageUrlStr);
    }
    
    private Image downloadAndValidateImage(long photoId, String imageUrlStr) throws Exception {
        try {
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(new URI(imageUrlStr))
                    .timeout(Duration.ofSeconds(15))
                    .header("User-Agent", "Mozilla/5.0")
                    .GET()
                    .build();

            HttpResponse<byte[]> response = imageHttpClient.send(request, HttpResponse.BodyHandlers.ofByteArray());
            
            if (response.statusCode() != 200) {
                System.err.println("Pexels image download: Photo ID: " + photoId + 
                                   " | Status: " + response.statusCode() + 
                                   " | URL: " + new URI(imageUrlStr).getHost() + new URI(imageUrlStr).getPath());
                throw new Exception("HTTP " + response.statusCode());
            }

            byte[] body = response.body();
            try (ByteArrayInputStream bais = new ByteArrayInputStream(body)) {
                BufferedImage image = ImageIO.read(bais);
                if (image == null) {
                    String contentType = response.headers().firstValue("Content-Type").orElse("unknown");
                    System.err.println("Pexels image download: Photo ID: " + photoId + 
                                       " | Status: 200 | Content-Type: " + contentType + 
                                       " | Bytes: " + body.length + " | ImageIO: NULL (not an image)");
                    throw new Exception("Downloaded response is not recognized as an image.");
                }
                return image;
            }
        } catch (Exception ex) {
            System.err.println("Pexels image download: Photo ID: " + photoId + " | Exception: " + ex.getClass().getSimpleName() + " - " + ex.getMessage());
            throw ex;
        }
    }
}
