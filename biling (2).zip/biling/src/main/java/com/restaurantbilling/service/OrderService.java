package com.restaurantbilling.service;

import com.restaurantbilling.dao.FoodItemDAO;
import com.restaurantbilling.dao.OrderDAO;
import com.restaurantbilling.dao.OrderItemDAO;
import com.restaurantbilling.dao.impl.FoodItemDAOImpl;
import com.restaurantbilling.dao.impl.OrderDAOImpl;
import com.restaurantbilling.dao.impl.OrderItemDAOImpl;
import com.restaurantbilling.database.DatabaseConnection;
import com.restaurantbilling.exception.DatabaseException;
import com.restaurantbilling.exception.ValidationException;
import com.restaurantbilling.model.FoodItem;
import com.restaurantbilling.model.Order;
import com.restaurantbilling.model.OrderItem;
import com.restaurantbilling.util.UserSession;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

public class OrderService {

    private final OrderDAO orderDAO;
    private final OrderItemDAO orderItemDAO;
    private final FoodItemDAO foodItemDAO;
    private final AuditService auditService;

    public OrderService() {
        this.orderDAO = new OrderDAOImpl();
        this.orderItemDAO = new OrderItemDAOImpl();
        this.foodItemDAO = new FoodItemDAOImpl();
        this.auditService = new AuditService();
    }

    public OrderService(OrderDAO orderDAO, OrderItemDAO orderItemDAO, FoodItemDAO foodItemDAO) {
        this.orderDAO = orderDAO;
        this.orderItemDAO = orderItemDAO;
        this.foodItemDAO = foodItemDAO;
        this.auditService = new AuditService();
    }

    public OrderService(OrderDAO orderDAO, OrderItemDAO orderItemDAO, FoodItemDAO foodItemDAO, AuditService auditService) {
        this.orderDAO = orderDAO;
        this.orderItemDAO = orderItemDAO;
        this.foodItemDAO = foodItemDAO;
        this.auditService = auditService;
    }

    /**
     * Creates an order with items inside a single ACID JDBC transaction.
     */
    public Order createOrder(Order order, List<OrderItem> items) throws ValidationException {
        checkLoggedIn("create order");

        // 1. Basic validation
        if (order == null) {
            throw new ValidationException("Order data cannot be empty.");
        }
        if (items == null || items.isEmpty()) {
            throw new ValidationException("Cannot place an empty order. Please add at least one item.");
        }

        // 2. Validate items & quantities
        BigDecimal calculatedSubtotal = BigDecimal.ZERO;
        for (OrderItem item : items) {
            if (item.getQuantity() <= 0) {
                throw new ValidationException("Item quantity must be greater than 0.");
            }
            if (item.getUnitPrice() == null || item.getUnitPrice().compareTo(BigDecimal.ZERO) < 0) {
                throw new ValidationException("Invalid item unit price.");
            }

            // Calculate line total with BigDecimal
            BigDecimal lineTotal = item.getUnitPrice().multiply(BigDecimal.valueOf(item.getQuantity()));
            item.setSubtotal(lineTotal);
            calculatedSubtotal = calculatedSubtotal.add(lineTotal);
        }

        // 3. Check for availability race conditions in the database
        for (OrderItem item : items) {
            Optional<FoodItem> currentDbItem = foodItemDAO.findById(item.getFoodItemId());
            if (currentDbItem.isEmpty() || !currentDbItem.get().isAvailable()) {
                String itemName = (item.getFoodItemName() != null) ? item.getFoodItemName() : "Item #" + item.getFoodItemId();
                throw new ValidationException("Food item '" + itemName + "' is no longer available. Please review the order.");
            }
        }

        // 4. Calculate final totals
        order.setSubtotal(calculatedSubtotal);

        BigDecimal discount = order.getDiscount() != null ? order.getDiscount() : BigDecimal.ZERO;
        if (discount.compareTo(BigDecimal.ZERO) < 0 || discount.compareTo(calculatedSubtotal) > 0) {
            throw new ValidationException("Discount cannot be negative or exceed subtotal.");
        }
        order.setDiscount(discount);

        BigDecimal tax = order.getTax() != null ? order.getTax() : BigDecimal.ZERO;
        if (tax.compareTo(BigDecimal.ZERO) < 0) {
            throw new ValidationException("Tax cannot be negative.");
        }
        order.setTax(tax);

        BigDecimal grandTotal = calculatedSubtotal.subtract(discount).add(tax);
        order.setTotal(grandTotal);

        if (order.getStatus() == null || order.getStatus().trim().isEmpty()) {
            order.setStatus("PENDING");
        }

        // 5. Execute Transactional Persistence
        Connection conn = null;
        try {
            conn = DatabaseConnection.getConnection();
            conn.setAutoCommit(false); // BEGIN TRANSACTION

            int orderId = orderDAO.createOrder(conn, order);
            order.setId(orderId);

            for (OrderItem item : items) {
                item.setOrderId(orderId);
            }
            orderItemDAO.createOrderItems(conn, orderId, items);

            conn.commit(); // COMMIT TRANSACTION
            order.setItems(items);

            auditService.log("ORDER", "ORDER_CREATED", "Created order ID #" + orderId + " (" + items.size() + " items, Total: " + order.getTotal() + ")", "SUCCESS");
            return order;
        } catch (Exception ex) {
            if (conn != null) {
                try {
                    conn.rollback(); // ROLLBACK TRANSACTION ON FAILURE
                } catch (SQLException rollbackEx) {
                    // Log or suppress rollback error
                }
            }
            throw new DatabaseException("Order creation failed and transaction was rolled back: " + ex.getMessage(), ex);
        } finally {
            if (conn != null) {
                try {
                    conn.setAutoCommit(true);
                    conn.close();
                } catch (SQLException ignored) {}
            }
        }
    }

    public List<Order> getAllOrders() {
        return orderDAO.findAll();
    }

    public Optional<Order> getOrderDetails(int orderId) {
        Optional<Order> orderOpt = orderDAO.findById(orderId);
        orderOpt.ifPresent(order -> {
            List<OrderItem> items = orderItemDAO.findByOrderId(orderId);
            order.setItems(items);
        });
        return orderOpt;
    }

    public List<Order> searchOrders(String keyword, String status) {
        return orderDAO.search(keyword, status);
    }

    public boolean updateOrderStatus(int orderId, String newStatus) throws ValidationException {
        checkLoggedIn("update order status");

        Optional<Order> current = orderDAO.findById(orderId);
        if (current.isEmpty()) {
            throw new ValidationException("Order not found.");
        }

        String currentStatus = current.get().getStatus();
        if ("CANCELLED".equalsIgnoreCase(currentStatus)) {
            throw new ValidationException("Cancelled orders cannot be modified.");
        }
        if ("COMPLETED".equalsIgnoreCase(currentStatus) && !"CANCELLED".equalsIgnoreCase(newStatus)) {
            throw new ValidationException("Completed orders cannot change status.");
        }

        boolean updated = orderDAO.updateStatus(orderId, newStatus);
        if (updated) {
            String action = "CANCELLED".equalsIgnoreCase(newStatus) ? "ORDER_CANCELLED" : "ORDER_UPDATED";
            auditService.log("ORDER", action, "Updated order ID #" + orderId + " status from " + currentStatus + " to " + newStatus, "SUCCESS");
        }
        return updated;
    }

    public boolean cancelOrder(int orderId) throws ValidationException {
        checkLoggedIn("cancel order");

        Optional<Order> current = orderDAO.findById(orderId);
        if (current.isEmpty()) {
            throw new ValidationException("Order not found.");
        }

        if ("CANCELLED".equalsIgnoreCase(current.get().getStatus())) {
            throw new ValidationException("Order is already cancelled.");
        }

        boolean cancelled = orderDAO.cancelOrder(orderId);
        if (cancelled) {
            auditService.log("ORDER", "ORDER_CANCELLED", "Cancelled order ID #" + orderId, "SUCCESS");
        }
        return cancelled;
    }

    public int getTotalOrderCount() {
        return orderDAO.countTotalOrders();
    }

    private void checkLoggedIn(String operation) throws ValidationException {
        if (!UserSession.isLoggedIn()) {
            auditService.log("ORDER", "ACCESS_DENIED", "Unauthenticated attempt to " + operation + ".", "DENIED");
            throw new ValidationException("Access Denied: You must be logged in to " + operation + ".");
        }
    }
}
