package com.restaurantbilling.service;

import com.restaurantbilling.dao.SettingsDAO;
import com.restaurantbilling.dao.impl.SettingsDAOImpl;
import com.restaurantbilling.exception.ValidationException;
import com.restaurantbilling.model.RestaurantSettings;
import com.restaurantbilling.util.ApplicationSettings;
import com.restaurantbilling.util.UserSession;

import java.util.regex.Pattern;

public class SettingsService {

    private final SettingsDAO settingsDAO;
    private final AuditService auditService;
    private static final Pattern EMAIL_PATTERN = Pattern.compile("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,6}$");

    public SettingsService() {
        this.settingsDAO = new SettingsDAOImpl();
        this.auditService = new AuditService();
    }

    public SettingsService(SettingsDAO settingsDAO) {
        this.settingsDAO = settingsDAO;
        this.auditService = new AuditService();
    }

    public SettingsService(SettingsDAO settingsDAO, AuditService auditService) {
        this.settingsDAO = settingsDAO;
        this.auditService = auditService;
    }

    public RestaurantSettings getSettings() {
        return settingsDAO.getRestaurantSettings();
    }

    public void validateSettings(RestaurantSettings settings) throws ValidationException {
        if (settings == null) {
            throw new ValidationException("Settings cannot be null.");
        }

        // 1. Restaurant Name
        if (settings.getRestaurantName() == null || settings.getRestaurantName().trim().isEmpty()) {
            throw new ValidationException("Restaurant name is required.");
        }

        // 2. Email format (optional, but validated if present)
        if (settings.getEmail() != null && !settings.getEmail().trim().isEmpty()) {
            if (!EMAIL_PATTERN.matcher(settings.getEmail().trim()).matches()) {
                throw new ValidationException("Invalid email format (e.g., contact@restaurant.com).");
            }
        }

        // 3. Tax rate validation
        if (settings.getTaxRate() < 0.0) {
            throw new ValidationException("Tax rate cannot be negative.");
        }

        // 4. PIN code format (optional)
        if (settings.getPincode() != null && !settings.getPincode().trim().isEmpty()) {
            String pin = settings.getPincode().trim();
            if (!pin.matches("^[0-9]{4,10}$")) {
                throw new ValidationException("PIN / Postal code must contain valid numeric digits.");
            }
        }
    }

    public boolean saveSettings(RestaurantSettings settings) throws ValidationException {
        // Enforce Admin Access
        if (UserSession.isLoggedIn() && !UserSession.isAdmin()) {
            auditService.log("SETTINGS", "ACCESS_DENIED", "Unauthorized attempt by " + UserSession.getUsername() + " to modify restaurant settings.", "DENIED");
            throw new ValidationException("Access Denied: Only ADMIN can configure system settings.");
        }

        // Validate
        validateSettings(settings);

        // Persist to MySQL
        String username = UserSession.getUsername();
        boolean saved = settingsDAO.saveAllSettings(settings, username);

        if (saved) {
            // Update in-memory singleton cache
            ApplicationSettings.getInstance().setSettings(settings);
            auditService.log("SETTINGS", "SETTINGS_UPDATED", "Updated restaurant configuration for '" + settings.getRestaurantName() + "'.", "SUCCESS");
        }

        return saved;
    }
}
