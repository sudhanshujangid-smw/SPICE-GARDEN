package com.restaurantbilling.service;

import com.restaurantbilling.dao.AuditLogDAO;
import com.restaurantbilling.dao.impl.AuditLogDAOImpl;
import com.restaurantbilling.exception.ValidationException;
import com.restaurantbilling.model.audit.AuditLog;
import com.restaurantbilling.util.UserSession;

import java.time.LocalDate;
import java.util.List;

public class AuditService {

    private final AuditLogDAO auditLogDAO;

    public AuditService() {
        this.auditLogDAO = new AuditLogDAOImpl();
    }

    public AuditService(AuditLogDAO auditLogDAO) {
        this.auditLogDAO = auditLogDAO;
    }

    /**
     * Records an audit event using the active user session.
     */
    public void log(String module, String action, String description, String status) {
        Integer userId = UserSession.getUserId();
        String username = UserSession.getUsername();
        log(userId, username, module, action, description, status);
    }

    /**
     * Records an audit event with explicit user credentials.
     */
    public void log(Integer userId, String username, String module, String action, String description, String status) {
        try {
            AuditLog log = new AuditLog(userId, username, module, action, description, status != null ? status : "SUCCESS");
            auditLogDAO.save(log);
        } catch (Exception ignored) {
            // Auditing failures must not break business logic operations
        }
    }

    /**
     * Retrieves paginated audit logs. Enforces ADMIN permission.
     */
    public List<AuditLog> getAuditLogs(String keyword, String username, String module, String action, String status, LocalDate fromDate, LocalDate toDate, int page, int pageSize) throws ValidationException {
        if (!UserSession.isAdmin()) {
            log("SECURITY", "ACCESS_DENIED", "Unauthorized attempt by " + UserSession.getUsername() + " to view audit logs.", "DENIED");
            throw new ValidationException("Access Denied: Only ADMIN can view system audit logs.");
        }

        int limit = pageSize > 0 ? pageSize : 50;
        int offset = Math.max(page - 1, 0) * limit;

        return auditLogDAO.search(keyword, username, module, action, status, fromDate, toDate, limit, offset);
    }

    /**
     * Counts matching audit logs. Enforces ADMIN permission.
     */
    public int getTotalLogCount(String keyword, String username, String module, String action, String status, LocalDate fromDate, LocalDate toDate) throws ValidationException {
        if (!UserSession.isAdmin()) {
            throw new ValidationException("Access Denied: Only ADMIN can query audit logs.");
        }
        return auditLogDAO.count(keyword, username, module, action, status, fromDate, toDate);
    }
}
