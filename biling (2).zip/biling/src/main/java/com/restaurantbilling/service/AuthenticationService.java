package com.restaurantbilling.service;

import com.restaurantbilling.dao.UserDAO;
import com.restaurantbilling.dao.impl.UserDAOImpl;
import com.restaurantbilling.exception.ValidationException;
import com.restaurantbilling.model.User;
import com.restaurantbilling.util.PasswordUtil;
import com.restaurantbilling.util.UserSession;

import java.util.Optional;

public class AuthenticationService {
    private final UserDAO userDAO;
    private final AuditService auditService;

    public AuthenticationService() {
        this.userDAO = new UserDAOImpl();
        this.auditService = new AuditService();
    }

    public AuthenticationService(UserDAO userDAO) {
        this.userDAO = userDAO;
        this.auditService = new AuditService();
    }

    public AuthenticationService(UserDAO userDAO, AuditService auditService) {
        this.userDAO = userDAO;
        this.auditService = auditService;
    }

    public User login(String username, String password) throws ValidationException {
        if (username == null || username.trim().isEmpty()) {
            auditService.log(null, "UNKNOWN", "AUTH", "LOGIN_FAILED", "Login attempt failed: Empty username.", "FAILED");
            throw new ValidationException("Username cannot be empty.");
        }
        if (password == null || password.trim().isEmpty()) {
            auditService.log(null, username.trim(), "AUTH", "LOGIN_FAILED", "Login attempt failed: Empty password.", "FAILED");
            throw new ValidationException("Password cannot be empty.");
        }

        Optional<User> userOpt = userDAO.authenticate(username.trim(), password.trim());
        if (userOpt.isPresent()) {
            User user = userOpt.get();
            UserSession.login(user);
            auditService.log(user.getId(), user.getUsername(), "AUTH", "LOGIN_SUCCESS", "User '" + user.getUsername() + "' (" + user.getRole() + ") logged in successfully.", "SUCCESS");
            return user;
        } else {
            auditService.log(null, username.trim(), "AUTH", "LOGIN_FAILED", "Login attempt failed for username '" + username.trim() + "'.", "FAILED");
            throw new ValidationException("Invalid username or password.");
        }
    }

    public void logout() {
        if (UserSession.isLoggedIn()) {
            auditService.log(UserSession.getUserId(), UserSession.getUsername(), "AUTH", "LOGOUT", "User '" + UserSession.getUsername() + "' logged out.", "SUCCESS");
        }
        UserSession.logout();
    }

    public boolean changePassword(int userId, String currentPassword, String newPassword, String confirmPassword) throws ValidationException {
        if (userId <= 0) {
            throw new ValidationException("Invalid user session for password change.");
        }
        if (currentPassword == null || currentPassword.trim().isEmpty()) {
            throw new ValidationException("Current password cannot be empty.");
        }
        if (newPassword == null || newPassword.trim().isEmpty()) {
            throw new ValidationException("New password cannot be empty.");
        }
        if (newPassword.length() < 4) {
            throw new ValidationException("New password must be at least 4 characters long.");
        }
        if (!newPassword.equals(confirmPassword)) {
            throw new ValidationException("New password and confirmation do not match.");
        }

        // Verify current password
        String username = UserSession.getUsername();
        Optional<User> userOpt = userDAO.findByUsername(username);
        if (userOpt.isEmpty()) {
            throw new ValidationException("User account not found.");
        }

        User user = userOpt.get();
        if (!PasswordUtil.verifyPassword(currentPassword, user.getPassword())) {
            auditService.log(userId, username, "SECURITY", "PASSWORD_CHANGE_FAILED", "Password change failed: Incorrect current password.", "FAILED");
            throw new ValidationException("Current password is incorrect.");
        }

        String hashed = PasswordUtil.hashPassword(newPassword);
        boolean updated = userDAO.updatePassword(userId, hashed);
        if (updated) {
            user.setPassword(hashed);
            auditService.log(userId, username, "SECURITY", "PASSWORD_CHANGED", "User '" + username + "' changed password successfully.", "SUCCESS");
        }
        return updated;
    }
}
