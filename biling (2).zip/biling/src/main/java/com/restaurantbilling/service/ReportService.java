package com.restaurantbilling.service;

import com.restaurantbilling.dao.ReportDAO;
import com.restaurantbilling.dao.impl.ReportDAOImpl;
import com.restaurantbilling.exception.ValidationException;
import com.restaurantbilling.model.report.*;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

public class ReportService {

    private final ReportDAO reportDAO;

    public ReportService() {
        this.reportDAO = new ReportDAOImpl();
    }

    public ReportService(ReportDAO reportDAO) {
        this.reportDAO = reportDAO;
    }

    public void validateDateRange(String fromDate, String toDate) throws ValidationException {
        if (fromDate == null || fromDate.trim().isEmpty() || toDate == null || toDate.trim().isEmpty()) {
            return; // Unbounded dates allowed
        }

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        sdf.setLenient(false);
        try {
            Date start = sdf.parse(fromDate.trim());
            Date end = sdf.parse(toDate.trim());

            if (start.after(end)) {
                throw new ValidationException("Invalid date range: 'From Date' cannot be after 'To Date'.");
            }
        } catch (ParseException e) {
            throw new ValidationException("Invalid date format. Please use YYYY-MM-DD format.");
        }
    }

    public BillSummaryDTO getBillSummary(String fromDate, String toDate) throws ValidationException {
        validateDateRange(fromDate, toDate);
        return reportDAO.getBillSummary(fromDate, toDate);
    }

    public OrderSummaryDTO getOrderSummary(String fromDate, String toDate) throws ValidationException {
        validateDateRange(fromDate, toDate);
        return reportDAO.getOrderSummary(fromDate, toDate);
    }

    public CustomerSummaryDTO getCustomerSummary() {
        return reportDAO.getCustomerSummary();
    }

    public List<ItemSalesDTO> getItemSalesReport(String fromDate, String toDate, int limit) throws ValidationException {
        validateDateRange(fromDate, toDate);
        return reportDAO.getItemSalesReport(fromDate, toDate, limit);
    }

    public List<BillingTrendDTO> getDailyBillingTrend(String fromDate, String toDate) throws ValidationException {
        validateDateRange(fromDate, toDate);
        return reportDAO.getDailyBillingTrend(fromDate, toDate);
    }

    public List<BillingTrendDTO> getMonthlyBillingReport(int year) {
        return reportDAO.getMonthlyBillingReport(year);
    }

    public List<BillingTrendDTO> getMonthlyBillingReport(String fromDate, String toDate) throws ValidationException {
        validateDateRange(fromDate, toDate);
        return reportDAO.getMonthlyBillingReport(fromDate, toDate);
    }

    public List<OrderReportDTO> getOrderReport(String fromDate, String toDate, String status, int page, int pageSize) throws ValidationException {
        validateDateRange(fromDate, toDate);
        int limit = pageSize > 0 ? pageSize : 50;
        int offset = Math.max(page - 1, 0) * limit;
        return reportDAO.getOrderReport(fromDate, toDate, status, limit, offset);
    }

    public int getOrderReportCount(String fromDate, String toDate, String status) throws ValidationException {
        validateDateRange(fromDate, toDate);
        return reportDAO.getOrderReportCount(fromDate, toDate, status);
    }

    public List<CustomerReportDTO> getCustomerReport(String keyword, int page, int pageSize) {
        int limit = pageSize > 0 ? pageSize : 50;
        int offset = Math.max(page - 1, 0) * limit;
        return reportDAO.getCustomerReport(keyword, limit, offset);
    }

    public int getCustomerReportCount(String keyword) {
        return reportDAO.getCustomerReportCount(keyword);
    }

    public List<MenuReportDTO> getMenuReport(String fromDate, String toDate, String category) throws ValidationException {
        validateDateRange(fromDate, toDate);
        return reportDAO.getMenuReport(fromDate, toDate, category);
    }
}
