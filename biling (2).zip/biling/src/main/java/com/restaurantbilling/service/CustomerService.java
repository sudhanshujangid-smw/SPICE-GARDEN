package com.restaurantbilling.service;

import com.restaurantbilling.dao.CustomerDAO;
import com.restaurantbilling.dao.impl.CustomerDAOImpl;
import com.restaurantbilling.exception.ValidationException;
import com.restaurantbilling.model.Customer;
import com.restaurantbilling.util.UserSession;
import com.restaurantbilling.util.ValidationUtil;

import java.util.List;
import java.util.Optional;

public class CustomerService {
    private final CustomerDAO customerDAO;
    private final AuditService auditService;

    public CustomerService() {
        this.customerDAO = new CustomerDAOImpl();
        this.auditService = new AuditService();
    }

    public CustomerService(CustomerDAO customerDAO) {
        this.customerDAO = customerDAO;
        this.auditService = new AuditService();
    }

    public CustomerService(CustomerDAO customerDAO, AuditService auditService) {
        this.customerDAO = customerDAO;
        this.auditService = auditService;
    }

    public List<Customer> getAllCustomers() {
        return customerDAO.findAll();
    }

    public Optional<Customer> getCustomerById(int id) {
        return customerDAO.findById(id);
    }

    public Optional<Customer> getCustomerByPhone(String phone) {
        return customerDAO.findByPhone(phone);
    }

    public List<Customer> searchCustomers(String keyword, String status) {
        return customerDAO.search(keyword, status);
    }

    public Customer addCustomer(Customer customer) throws ValidationException {
        checkAdminOrStaffPermission("add customer");

        // 1. Validation
        ValidationUtil.validateCustomer(customer);

        // 2. Duplicate phone check
        if (customerDAO.isPhoneRegistered(customer.getPhone(), 0)) {
            throw new ValidationException("Customer already exists or the provided phone number is already registered.");
        }

        // 3. Save
        Customer saved = customerDAO.save(customer);
        auditService.log("CUSTOMER", "CUSTOMER_CREATED", "Registered customer: " + saved.getName() + " (Phone: " + saved.getPhone() + ")", "SUCCESS");
        return saved;
    }

    public boolean updateCustomer(Customer customer) throws ValidationException {
        checkAdminPermission("update customer");

        if (customer.getId() <= 0) {
            throw new ValidationException("Invalid customer ID.");
        }

        // 1. Validation
        ValidationUtil.validateCustomer(customer);

        // 2. Duplicate phone check (excluding self)
        if (customerDAO.isPhoneRegistered(customer.getPhone(), customer.getId())) {
            throw new ValidationException("Another customer is already registered with this phone number.");
        }

        // 3. Update
        boolean updated = customerDAO.update(customer);
        if (updated) {
            auditService.log("CUSTOMER", "CUSTOMER_UPDATED", "Updated customer: " + customer.getName() + " (ID: " + customer.getId() + ", Phone: " + customer.getPhone() + ")", "SUCCESS");
        }
        return updated;
    }

    public boolean setCustomerStatus(int id, String status) throws ValidationException {
        checkAdminPermission("change customer status");

        if (id <= 0) {
            throw new ValidationException("Invalid customer ID.");
        }

        if (!"Active".equalsIgnoreCase(status) && !"Inactive".equalsIgnoreCase(status)) {
            throw new ValidationException("Status must be Active or Inactive.");
        }

        boolean updated = customerDAO.updateStatus(id, status);
        if (updated) {
            auditService.log("CUSTOMER", "CUSTOMER_UPDATED", "Changed status of customer ID #" + id + " to " + status, "SUCCESS");
        }
        return updated;
    }

    public boolean deleteCustomer(int id) throws ValidationException {
        checkAdminPermission("delete customer");

        if (id <= 0) {
            throw new ValidationException("Invalid customer ID.");
        }

        Optional<Customer> existing = customerDAO.findById(id);
        String name = existing.map(Customer::getName).orElse("ID #" + id);

        boolean deleted = customerDAO.delete(id);
        if (deleted) {
            auditService.log("CUSTOMER", "CUSTOMER_DELETED", "Deleted customer: " + name + " (ID: " + id + ")", "SUCCESS");
        }
        return deleted;
    }

    public int getActiveCustomerCount() {
        return customerDAO.countActiveCustomers();
    }

    private void checkAdminPermission(String operation) throws ValidationException {
        if (UserSession.isLoggedIn() && !UserSession.isAdmin()) {
            auditService.log("CUSTOMER", "ACCESS_DENIED", "Unauthorized attempt by " + UserSession.getUsername() + " to " + operation + ".", "DENIED");
            throw new ValidationException("Access Denied: Only ADMIN can " + operation + ".");
        }
    }

    private void checkAdminOrStaffPermission(String operation) throws ValidationException {
        if (!UserSession.isLoggedIn()) {
            auditService.log("CUSTOMER", "ACCESS_DENIED", "Unauthenticated attempt to " + operation + ".", "DENIED");
            throw new ValidationException("Access Denied: You must be logged in to " + operation + ".");
        }
    }
}
