package com.restaurantbilling.service;

import com.restaurantbilling.dao.MaintenanceDAO;
import com.restaurantbilling.dao.impl.MaintenanceDAOImpl;
import com.restaurantbilling.database.DatabaseConnection;
import com.restaurantbilling.exception.DatabaseException;
import com.restaurantbilling.exception.ValidationException;
import com.restaurantbilling.model.maintenance.BackupRecord;
import com.restaurantbilling.model.maintenance.DatabaseHealth;
import com.restaurantbilling.util.ApplicationSettings;
import com.restaurantbilling.util.DatabaseBackupUtil;
import com.restaurantbilling.util.DatabaseRestoreUtil;
import com.restaurantbilling.util.UserSession;

import java.io.File;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;

public class MaintenanceService {

    private final MaintenanceDAO maintenanceDAO;
    private final AuditService auditService;

    public MaintenanceService() {
        this.maintenanceDAO = new MaintenanceDAOImpl();
        this.auditService = new AuditService();
    }

    public MaintenanceService(MaintenanceDAO maintenanceDAO) {
        this.maintenanceDAO = maintenanceDAO;
        this.auditService = new AuditService();
    }

    public MaintenanceService(MaintenanceDAO maintenanceDAO, AuditService auditService) {
        this.maintenanceDAO = maintenanceDAO;
        this.auditService = auditService;
    }

    /**
     * Checks permission. Throws ValidationException if current user is not ADMIN.
     */
    public void requireAdminPermission() throws ValidationException {
        if (!UserSession.isAdmin()) {
            auditService.log("MAINTENANCE", "ACCESS_DENIED", "Unauthorized attempt by " + UserSession.getUsername() + " to execute maintenance administrative action.", "DENIED");
            throw new ValidationException("Access Denied: You do not have permission to perform this maintenance operation. ADMIN privileges required.");
        }
    }

    /**
     * Retrieves database health status, missing tables, and diagnostics.
     */
    public DatabaseHealth getHealthStatus() {
        return maintenanceDAO.checkDatabaseHealth();
    }

    /**
     * Retrieves real-time table record counts.
     */
    public Map<String, Long> getDataSummary() {
        return maintenanceDAO.getTableRecordCounts();
    }

    /**
     * Executes non-destructive consistency checks.
     */
    public List<String> checkDataConsistency() {
        return maintenanceDAO.checkDataConsistency();
    }

    /**
     * Creates a validated database backup.
     */
    public BackupRecord createBackup(File targetFile, String backupType) throws ValidationException, DatabaseException {
        requireAdminPermission();

        if (!DatabaseConnection.testConnection()) {
            throw new DatabaseException("Database connection is unavailable. Cannot create backup.");
        }

        if (targetFile == null) {
            throw new ValidationException("Backup destination path cannot be empty.");
        }

        // Perform backup
        DatabaseBackupUtil.createBackup(targetFile);

        // Build history record
        BackupRecord record = new BackupRecord();
        record.setBackupName(targetFile.getName());
        record.setBackupPath(targetFile.getAbsolutePath());
        record.setFileSizeBytes(targetFile.length());
        record.setCreatedAt(LocalDateTime.now());
        record.setCreatedBy(UserSession.getUsername());
        record.setStatus("SUCCESS");
        record.setBackupType(backupType != null ? backupType : "MANUAL");

        maintenanceDAO.logBackupRecord(record);

        auditService.log("MAINTENANCE", "BACKUP_CREATED", "Database backup created: " + targetFile.getName() + " (" + targetFile.length() + " bytes, Type: " + record.getBackupType() + ")", "SUCCESS");

        return record;
    }

    /**
     * Performs a safe database restoration with automatic pre-restore safety backup.
     */
    public boolean restoreDatabase(File backupFile) throws ValidationException, DatabaseException {
        requireAdminPermission();

        if (!DatabaseConnection.testConnection()) {
            throw new DatabaseException("Database connection is unavailable. Cannot restore database.");
        }

        DatabaseRestoreUtil.validateRestoreFile(backupFile);

        auditService.log("MAINTENANCE", "RESTORE_STARTED", "Initiating database restoration from: " + backupFile.getName(), "SUCCESS");

        // 1. Automatic Pre-Restore Safety Backup
        File parentDir = backupFile.getParentFile();
        if (parentDir == null) {
            parentDir = new File("backups");
        }
        if (!parentDir.exists()) {
            parentDir.mkdirs();
        }

        String safetyFileName = "safety_backup_" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd_HH-mm-ss")) + ".sql";
        File safetyFile = new File(parentDir, safetyFileName);

        try {
            createBackup(safetyFile, "SAFETY_PRE_RESTORE");
        } catch (Exception e) {
            auditService.log("MAINTENANCE", "RESTORE_FAILED", "Safety pre-restore backup failed. Aborting restore.", "FAILED");
            throw new DatabaseException("Safety backup could not be created prior to restore. Restore cancelled to prevent data loss. Error: " + e.getMessage(), e);
        }

        // 2. Perform Selected Backup Restore
        try {
            DatabaseRestoreUtil.restoreDatabase(backupFile);
        } catch (Exception ex) {
            auditService.log("MAINTENANCE", "RESTORE_FAILED", "Database restore failed for file " + backupFile.getName() + ": " + ex.getMessage(), "FAILED");
            throw ex;
        }

        // 3. Re-verify Connection and Refresh System Cache
        if (!DatabaseConnection.testConnection()) {
            auditService.log("MAINTENANCE", "RESTORE_FAILED", "Post-restore connection verification failed.", "FAILED");
            throw new DatabaseException("Database connection verification failed after restoration.");
        }

        ApplicationSettings.getInstance().reload();

        auditService.log("MAINTENANCE", "RESTORE_COMPLETED", "Database successfully restored from " + backupFile.getName() + ". System configuration reloaded.", "SUCCESS");

        return true;
    }

    /**
     * Retrieves the history of backups.
     */
    public List<BackupRecord> getBackupHistory() {
        return maintenanceDAO.getBackupHistory();
    }
}
