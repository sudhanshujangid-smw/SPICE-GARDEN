package com.restaurantbilling.seed;

import com.restaurantbilling.api.pexels.PexelsPhoto;
import com.restaurantbilling.dao.FoodItemDAO;
import com.restaurantbilling.dao.impl.FoodItemDAOImpl;
import com.restaurantbilling.model.FoodItem;
import com.restaurantbilling.service.PexelsImageService;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;

public class VegetarianMenuSeeder {

    private static final FoodItemDAO foodItemDAO = new FoodItemDAOImpl();
    private static final PexelsImageService pexelsImageService = new PexelsImageService();

    // Data structure for seeding
    static class SeedCategory {
        String categoryName;
        List<SeedItem> items;
        SeedCategory(String categoryName, List<SeedItem> items) {
            this.categoryName = categoryName;
            this.items = items;
        }
    }

    static class SeedItem {
        String name;
        BigDecimal price;
        SeedItem(String name, double price) {
            this.name = name;
            this.price = BigDecimal.valueOf(price);
        }
    }

    private static final List<SeedCategory> SEED_DATA = Arrays.asList(
            new SeedCategory("Pizza", Arrays.asList(
                    new SeedItem("Margherita Pizza", 199.00),
                    new SeedItem("Double Cheese Pizza", 249.00),
                    new SeedItem("Farmhouse Pizza", 299.00),
                    new SeedItem("Veggie Delight Pizza", 279.00),
                    new SeedItem("Paneer Tikka Pizza", 349.00),
                    new SeedItem("Corn & Cheese Pizza", 249.00),
                    new SeedItem("Capsicum & Onion Pizza", 219.00),
                    new SeedItem("Mushroom Pizza", 299.00),
                    new SeedItem("Spinach & Corn Pizza", 259.00),
                    new SeedItem("Mexican Veg Pizza", 329.00),
                    new SeedItem("Italian Veg Pizza", 319.00),
                    new SeedItem("Peri Peri Veg Pizza", 309.00),
                    new SeedItem("BBQ Paneer Pizza", 359.00),
                    new SeedItem("Cheese Burst Veg Pizza", 399.00),
                    new SeedItem("Loaded Veg Pizza", 379.00),
                    new SeedItem("Four Cheese Pizza", 429.00),
                    new SeedItem("Garden Fresh Pizza", 269.00),
                    new SeedItem("Mediterranean Veg Pizza", 349.00),
                    new SeedItem("Tandoori Paneer Pizza", 369.00),
                    new SeedItem("Achari Paneer Pizza", 359.00)
            )),
            new SeedCategory("Burgers", Arrays.asList(
                    new SeedItem("Classic Veg Burger", 99.00),
                    new SeedItem("Cheese Veg Burger", 119.00),
                    new SeedItem("Crispy Veg Burger", 129.00),
                    new SeedItem("Paneer Burger", 149.00),
                    new SeedItem("Paneer Tikka Burger", 169.00),
                    new SeedItem("Mexican Veg Burger", 139.00),
                    new SeedItem("Peri Peri Veg Burger", 129.00),
                    new SeedItem("Mushroom Burger", 149.00),
                    new SeedItem("Corn & Cheese Burger", 119.00),
                    new SeedItem("Aloo Tikki Burger", 89.00),
                    new SeedItem("Double Cheese Veg Burger", 159.00),
                    new SeedItem("Spicy Veg Burger", 129.00),
                    new SeedItem("BBQ Paneer Burger", 179.00),
                    new SeedItem("Schezwan Veg Burger", 139.00),
                    new SeedItem("Loaded Veg Burger", 199.00)
            )),
            new SeedCategory("Starters", Arrays.asList(
                    new SeedItem("French Fries", 99.00),
                    new SeedItem("Peri Peri Fries", 119.00),
                    new SeedItem("Cheese Fries", 149.00),
                    new SeedItem("Garlic Bread", 109.00),
                    new SeedItem("Cheese Garlic Bread", 149.00),
                    new SeedItem("Bruschetta", 159.00),
                    new SeedItem("Vegetable Spring Rolls", 179.00),
                    new SeedItem("Crispy Corn", 199.00),
                    new SeedItem("Crispy Potato", 149.00),
                    new SeedItem("Chilli Potato", 169.00),
                    new SeedItem("Honey Chilli Potato", 179.00),
                    new SeedItem("Paneer Fingers", 229.00),
                    new SeedItem("Cheese Balls", 199.00),
                    new SeedItem("Veg Cheese Balls", 189.00),
                    new SeedItem("Stuffed Mushrooms", 249.00),
                    new SeedItem("Crispy Mushroom", 229.00),
                    new SeedItem("Vegetable Cutlet", 139.00),
                    new SeedItem("Hara Bhara Kebab", 199.00),
                    new SeedItem("Aloo Tikki", 119.00),
                    new SeedItem("Veg Seekh Kebab", 219.00),
                    new SeedItem("Corn Cheese Nuggets", 179.00)
            )),
            new SeedCategory("Indian Starters", Arrays.asList(
                    new SeedItem("Paneer Tikka", 269.00),
                    new SeedItem("Achari Paneer Tikka", 279.00),
                    new SeedItem("Malai Paneer Tikka", 289.00),
                    new SeedItem("Tandoori Paneer", 269.00),
                    new SeedItem("Hariyali Paneer Tikka", 279.00),
                    new SeedItem("Mushroom Tikka", 249.00),
                    new SeedItem("Tandoori Mushroom", 239.00),
                    new SeedItem("Tandoori Aloo", 199.00),
                    new SeedItem("Dahi Ke Kebab", 229.00),
                    new SeedItem("Tandoori Soya Chaap", 219.00),
                    new SeedItem("Achari Soya Chaap", 229.00),
                    new SeedItem("Malai Soya Chaap", 239.00),
                    new SeedItem("Afghani Soya Chaap", 249.00)
            )),
            new SeedCategory("Continental", Arrays.asList(
                    new SeedItem("Veg Grilled Sandwich", 129.00),
                    new SeedItem("Grilled Cheese Sandwich", 149.00),
                    new SeedItem("Vegetable Au Gratin", 299.00),
                    new SeedItem("Creamy Vegetable Bake", 329.00),
                    new SeedItem("Cheesy Vegetable Casserole", 349.00),
                    new SeedItem("Herb Grilled Vegetables", 249.00),
                    new SeedItem("Grilled Mushroom", 269.00),
                    new SeedItem("Creamy Mushroom", 289.00),
                    new SeedItem("Vegetable Lasagna", 359.00),
                    new SeedItem("Baked Mac & Cheese", 319.00),
                    new SeedItem("Cheese Macaroni", 299.00),
                    new SeedItem("Veg Cutlet with Fries", 199.00),
                    new SeedItem("Paneer Steak", 349.00),
                    new SeedItem("Grilled Paneer with Vegetables", 329.00),
                    new SeedItem("Vegetable Stuffed Pasta Bake", 349.00),
                    new SeedItem("Creamy Spinach & Corn", 279.00),
                    new SeedItem("Garlic Herb Potatoes", 199.00),
                    new SeedItem("Loaded Baked Potato", 229.00)
            )),
            new SeedCategory("Pasta", Arrays.asList(
                    new SeedItem("White Sauce Pasta", 249.00),
                    new SeedItem("Red Sauce Pasta", 229.00),
                    new SeedItem("Pink Sauce Pasta", 259.00),
                    new SeedItem("Arrabbiata Pasta", 239.00),
                    new SeedItem("Alfredo Pasta", 269.00),
                    new SeedItem("Pesto Pasta", 279.00),
                    new SeedItem("Creamy Mushroom Pasta", 289.00),
                    new SeedItem("Spinach Corn Pasta", 259.00),
                    new SeedItem("Veggie Pasta", 239.00),
                    new SeedItem("Cheese Pasta", 269.00),
                    new SeedItem("Four Cheese Pasta", 319.00),
                    new SeedItem("Paneer Tikka Pasta", 299.00),
                    new SeedItem("Peri Peri Pasta", 249.00),
                    new SeedItem("Mexican Pasta", 279.00)
            )),
            new SeedCategory("Sandwiches", Arrays.asList(
                    new SeedItem("Bombay Veg Sandwich", 119.00),
                    new SeedItem("Cheese Corn Sandwich", 139.00),
                    new SeedItem("Paneer Tikka Sandwich", 169.00),
                    new SeedItem("Club Veg Sandwich", 179.00),
                    new SeedItem("Mexican Veg Sandwich", 159.00),
                    new SeedItem("Mushroom Cheese Sandwich", 169.00),
                    new SeedItem("Spinach Corn Sandwich", 149.00),
                    new SeedItem("Peri Peri Veg Sandwich", 139.00),
                    new SeedItem("Cheese Chilli Toast", 129.00),
                    new SeedItem("Garlic Cheese Toast", 119.00),
                    new SeedItem("Vegetable Panini", 189.00),
                    new SeedItem("Caprese Sandwich", 199.00)
            )),
            new SeedCategory("Wraps", Arrays.asList(
                    new SeedItem("Veg Wrap", 129.00),
                    new SeedItem("Paneer Wrap", 159.00),
                    new SeedItem("Paneer Tikka Wrap", 179.00),
                    new SeedItem("Mexican Veg Wrap", 149.00),
                    new SeedItem("Peri Peri Paneer Wrap", 169.00),
                    new SeedItem("Cheese Veg Wrap", 149.00),
                    new SeedItem("Mushroom Wrap", 159.00),
                    new SeedItem("Schezwan Veg Wrap", 139.00),
                    new SeedItem("Tandoori Paneer Roll", 189.00),
                    new SeedItem("Achari Paneer Roll", 179.00),
                    new SeedItem("Soya Chaap Roll", 169.00),
                    new SeedItem("Veg Spring Roll", 149.00)
            )),
            new SeedCategory("Indian Main Course", Arrays.asList(
                    new SeedItem("Paneer Butter Masala", 289.00),
                    new SeedItem("Shahi Paneer", 299.00),
                    new SeedItem("Kadai Paneer", 279.00),
                    new SeedItem("Paneer Lababdar", 289.00),
                    new SeedItem("Palak Paneer", 269.00),
                    new SeedItem("Matar Paneer", 259.00),
                    new SeedItem("Chilli Paneer", 279.00),
                    new SeedItem("Paneer Do Pyaza", 269.00),
                    new SeedItem("Paneer Tikka Masala", 319.00),
                    new SeedItem("Mix Veg", 219.00),
                    new SeedItem("Veg Kolhapuri", 239.00),
                    new SeedItem("Veg Handi", 249.00),
                    new SeedItem("Malai Kofta", 279.00),
                    new SeedItem("Veg Kofta Curry", 259.00),
                    new SeedItem("Dal Makhani", 249.00),
                    new SeedItem("Dal Tadka", 189.00),
                    new SeedItem("Dal Fry", 169.00),
                    new SeedItem("Chana Masala", 199.00),
                    new SeedItem("Rajma Masala", 189.00),
                    new SeedItem("Aloo Jeera", 149.00),
                    new SeedItem("Aloo Gobi", 169.00),
                    new SeedItem("Bhindi Masala", 179.00),
                    new SeedItem("Mushroom Masala", 269.00),
                    new SeedItem("Mushroom Do Pyaza", 259.00),
                    new SeedItem("Palak Corn", 229.00),
                    new SeedItem("Corn Masala", 219.00),
                    new SeedItem("Plain Naan", 40.00),
                    new SeedItem("Butter Naan", 50.00),
                    new SeedItem("Garlic Naan", 60.00),
                    new SeedItem("Cheese Naan", 80.00),
                    new SeedItem("Tandoori Roti", 25.00),
                    new SeedItem("Butter Roti", 30.00),
                    new SeedItem("Missi Roti", 40.00),
                    new SeedItem("Laccha Paratha", 50.00),
                    new SeedItem("Pudina Paratha", 60.00),
                    new SeedItem("Stuffed Paneer Paratha", 80.00),
                    new SeedItem("Aloo Paratha", 60.00)
            )),
            new SeedCategory("Chinese", Arrays.asList(
                    new SeedItem("Veg Hakka Noodles", 189.00),
                    new SeedItem("Schezwan Noodles", 199.00),
                    new SeedItem("Chilli Garlic Noodles", 199.00),
                    new SeedItem("Veg Chowmein", 179.00),
                    new SeedItem("Singapore Noodles", 219.00),
                    new SeedItem("Veg Fried Rice", 189.00),
                    new SeedItem("Schezwan Fried Rice", 199.00),
                    new SeedItem("Chilli Garlic Fried Rice", 199.00),
                    new SeedItem("Manchurian Fried Rice", 229.00),
                    new SeedItem("Paneer Fried Rice", 239.00),
                    new SeedItem("Veg Manchurian", 219.00),
                    new SeedItem("Dry Veg Manchurian", 229.00),
                    new SeedItem("Honey Chilli Paneer", 279.00),
                    new SeedItem("Crispy Chilli Corn", 219.00),
                    new SeedItem("Chilli Mushroom", 249.00),
                    new SeedItem("Hot Garlic Mushroom", 259.00),
                    new SeedItem("Veg Momos", 129.00),
                    new SeedItem("Fried Veg Momos", 149.00),
                    new SeedItem("Tandoori Veg Momos", 179.00),
                    new SeedItem("Paneer Momos", 169.00)
            )),
            new SeedCategory("Rice & Biryani", Arrays.asList(
                    new SeedItem("Veg Biryani", 249.00),
                    new SeedItem("Paneer Biryani", 279.00),
                    new SeedItem("Hyderabadi Veg Biryani", 269.00),
                    new SeedItem("Vegetable Pulao", 199.00),
                    new SeedItem("Jeera Rice", 149.00),
                    new SeedItem("Peas Pulao", 169.00),
                    new SeedItem("Mushroom Rice", 229.00),
                    new SeedItem("Paneer Rice", 239.00),
                    new SeedItem("Schezwan Rice", 189.00)
            )),
            new SeedCategory("Soups", Arrays.asList(
                    new SeedItem("Tomato Soup", 119.00),
                    new SeedItem("Sweet Corn Soup", 129.00),
                    new SeedItem("Veg Clear Soup", 109.00),
                    new SeedItem("Hot & Sour Veg Soup", 129.00),
                    new SeedItem("Manchow Veg Soup", 139.00),
                    new SeedItem("Cream of Mushroom Soup", 149.00),
                    new SeedItem("Cream of Tomato Soup", 139.00),
                    new SeedItem("Cream of Spinach Soup", 139.00),
                    new SeedItem("Broccoli Soup", 159.00),
                    new SeedItem("Vegetable Minestrone Soup", 149.00)
            )),
            new SeedCategory("Salads", Arrays.asList(
                    new SeedItem("Garden Fresh Salad", 99.00),
                    new SeedItem("Greek Salad", 149.00),
                    new SeedItem("Caesar Salad - Vegetarian", 159.00),
                    new SeedItem("Corn Salad", 119.00),
                    new SeedItem("Sprouts Salad", 109.00),
                    new SeedItem("Paneer Salad", 149.00),
                    new SeedItem("Mediterranean Salad", 169.00),
                    new SeedItem("Russian Salad", 139.00),
                    new SeedItem("Cucumber Tomato Salad", 89.00),
                    new SeedItem("Fruit Salad", 179.00)
            )),
            new SeedCategory("Desserts", Arrays.asList(
                    new SeedItem("Gulab Jamun", 79.00),
                    new SeedItem("Rasmalai", 99.00),
                    new SeedItem("Brownie", 119.00),
                    new SeedItem("Chocolate Brownie with Ice Cream", 169.00),
                    new SeedItem("Chocolate Lava Cake", 149.00),
                    new SeedItem("Cheesecake", 199.00),
                    new SeedItem("Chocolate Mousse", 159.00),
                    new SeedItem("Vanilla Ice Cream", 69.00),
                    new SeedItem("Chocolate Ice Cream", 79.00),
                    new SeedItem("Strawberry Ice Cream", 79.00),
                    new SeedItem("Butterscotch Ice Cream", 89.00),
                    new SeedItem("Mango Ice Cream", 89.00),
                    new SeedItem("Kulfi", 59.00),
                    new SeedItem("Kesar Kulfi", 69.00),
                    new SeedItem("Fruit Cream", 149.00),
                    new SeedItem("Gajar Halwa", 119.00),
                    new SeedItem("Moong Dal Halwa", 129.00),
                    new SeedItem("Shahi Tukda", 139.00)
            )),
            new SeedCategory("Beverages", Arrays.asList(
                    new SeedItem("Fresh Lime Water", 59.00),
                    new SeedItem("Sweet Lime Soda", 79.00),
                    new SeedItem("Mint Lime Soda", 89.00),
                    new SeedItem("Fresh Orange Juice", 119.00),
                    new SeedItem("Watermelon Juice", 99.00),
                    new SeedItem("Pineapple Juice", 109.00),
                    new SeedItem("Mango Shake", 129.00),
                    new SeedItem("Chocolate Shake", 139.00),
                    new SeedItem("Vanilla Shake", 119.00),
                    new SeedItem("Strawberry Shake", 129.00),
                    new SeedItem("Oreo Shake", 149.00),
                    new SeedItem("Cold Coffee", 119.00),
                    new SeedItem("Iced Coffee", 129.00),
                    new SeedItem("Hot Coffee", 69.00),
                    new SeedItem("Cappuccino", 99.00),
                    new SeedItem("Latte", 109.00),
                    new SeedItem("Masala Tea", 49.00),
                    new SeedItem("Green Tea", 59.00),
                    new SeedItem("Lemon Tea", 59.00),
                    new SeedItem("Hot Chocolate", 129.00)
            )),
            new SeedCategory("Mocktails", Arrays.asList(
                    new SeedItem("Virgin Mojito", 149.00),
                    new SeedItem("Blue Lagoon Mocktail", 159.00),
                    new SeedItem("Green Apple Mocktail", 159.00),
                    new SeedItem("Watermelon Mojito", 149.00),
                    new SeedItem("Strawberry Mojito", 159.00),
                    new SeedItem("Virgin Pina Colada", 169.00),
                    new SeedItem("Fresh Fruit Punch", 179.00),
                    new SeedItem("Mango Mojito", 159.00),
                    new SeedItem("Mint Cooler", 139.00),
                    new SeedItem("Citrus Cooler", 149.00)
            ))
    );

    public static void main(String[] args) {
        System.out.println("Starting Vegetarian Menu Seeder...");
        int totalAdded = 0;
        int totalSkipped = 0;
        int imagesFetched = 0;
        int imagesFailed = 0;

        for (SeedCategory category : SEED_DATA) {
            System.out.println("\nProcessing Category: " + category.categoryName);
            for (SeedItem sItem : category.items) {
                // 1. Check for duplicates
                List<FoodItem> existing = foodItemDAO.search(sItem.name, "All");
                boolean exists = false;
                for (FoodItem e : existing) {
                    if (e.getName().equalsIgnoreCase(sItem.name)) {
                        exists = true;
                        break;
                    }
                }

                if (exists) {
                    System.out.println("  [SKIP] " + sItem.name + " already exists.");
                    totalSkipped++;
                    continue;
                }

                // 2. Fetch Pexels Image
                FoodItem newItem = new FoodItem(sItem.name, category.categoryName, sItem.price, true);
                
                // Do not fetch images for Breads/Rotis to save API limits as they rarely have good generic matches, but will try for others
                boolean shouldFetchImage = !sItem.name.contains("Roti") && !sItem.name.contains("Naan") && !sItem.name.contains("Paratha");
                
                if (shouldFetchImage) {
                    try {
                        System.out.print("  [FETCH] Image for '" + sItem.name + "'... ");
                        List<PexelsPhoto> photos = pexelsImageService.searchFoodImages(sItem.name);
                        if (photos != null && !photos.isEmpty()) {
                            PexelsPhoto photo = photos.get(0); // get best match
                            newItem.setPexelsPhotoId(photo.getId());
                            newItem.setImageUrl(photo.getSrc().getMedium());
                            newItem.setPhotographerName(photo.getPhotographer());
                            newItem.setPhotographerUrl(photo.getPhotographerUrl());
                            newItem.setImageSource("Pexels");
                            System.out.println("SUCCESS (" + photo.getId() + ")");
                            imagesFetched++;
                        }
                    } catch (Exception e) {
                        System.out.println("FAILED (" + e.getMessage() + ")");
                        imagesFailed++;
                    }

                    // Respect API Rate limits - pause for 1 second between requests
                    try {
                        Thread.sleep(1000);
                    } catch (InterruptedException ignored) {}
                } else {
                    System.out.println("  [SKIP-IMG] " + sItem.name);
                }

                // 3. Save to DB
                foodItemDAO.save(newItem);
                System.out.println("  [ADDED] " + sItem.name + " - ₹" + sItem.price);
                totalAdded++;
            }
        }

        System.out.println("\n=================================");
        System.out.println("SEEDING COMPLETE");
        System.out.println("=================================");
        System.out.println("Total Items Added: " + totalAdded);
        System.out.println("Total Items Skipped: " + totalSkipped);
        System.out.println("Images Successfully Fetched: " + imagesFetched);
        System.out.println("Images Failed to Fetch: " + imagesFailed);
    }
}
