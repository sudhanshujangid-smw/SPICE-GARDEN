package com.restaurantbilling.model.report;

import java.math.BigDecimal;
import java.sql.Timestamp;

/**
 * Data Transfer Object representing customer purchasing metrics for reporting.
 */
public class CustomerReportDTO {
    private int customerId;
    private String customerName;
    private String customerPhone;
    private int totalOrders;
    private BigDecimal totalBilledAmount;
    private Timestamp lastOrderDate;

    public CustomerReportDTO() {
        this.totalOrders = 0;
        this.totalBilledAmount = BigDecimal.ZERO;
    }

    public CustomerReportDTO(int customerId, String customerName, String customerPhone, int totalOrders, BigDecimal totalBilledAmount, Timestamp lastOrderDate) {
        this.customerId = customerId;
        this.customerName = customerName != null ? customerName : "Unknown";
        this.customerPhone = customerPhone != null ? customerPhone : "-";
        this.totalOrders = totalOrders;
        this.totalBilledAmount = totalBilledAmount != null ? totalBilledAmount : BigDecimal.ZERO;
        this.lastOrderDate = lastOrderDate;
    }

    public int getCustomerId() {
        return customerId;
    }

    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getCustomerPhone() {
        return customerPhone;
    }

    public void setCustomerPhone(String customerPhone) {
        this.customerPhone = customerPhone;
    }

    public int getTotalOrders() {
        return totalOrders;
    }

    public void setTotalOrders(int totalOrders) {
        this.totalOrders = totalOrders;
    }

    public BigDecimal getTotalBilledAmount() {
        return totalBilledAmount;
    }

    public void setTotalBilledAmount(BigDecimal totalBilledAmount) {
        this.totalBilledAmount = totalBilledAmount;
    }

    public Timestamp getLastOrderDate() {
        return lastOrderDate;
    }

    public void setLastOrderDate(Timestamp lastOrderDate) {
        this.lastOrderDate = lastOrderDate;
    }
}
