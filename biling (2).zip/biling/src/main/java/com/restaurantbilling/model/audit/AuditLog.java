package com.restaurantbilling.model.audit;

import java.time.LocalDateTime;

public class AuditLog {
    private int id;
    private Integer userId;
    private String username;
    private String module;      // e.g. "AUTH", "MENU", "CUSTOMER", "ORDER", "BILLING", "SETTINGS", "MAINTENANCE", "SECURITY"
    private String action;      // e.g. "LOGIN_SUCCESS", "LOGIN_FAILED", "LOGOUT", "MENU_CREATED", "ORDER_CREATED", etc.
    private String description;
    private LocalDateTime timestamp;
    private String status;      // "SUCCESS", "FAILED", "DENIED", "WARNING"

    public AuditLog() {
        this.timestamp = LocalDateTime.now();
        this.status = "SUCCESS";
    }

    public AuditLog(int id, Integer userId, String username, String module, String action, String description, LocalDateTime timestamp, String status) {
        this.id = id;
        this.userId = userId;
        this.username = username;
        this.module = module;
        this.action = action;
        this.description = description;
        this.timestamp = timestamp;
        this.status = status;
    }

    public AuditLog(Integer userId, String username, String module, String action, String description, String status) {
        this.userId = userId;
        this.username = username;
        this.module = module;
        this.action = action;
        this.description = description;
        this.timestamp = LocalDateTime.now();
        this.status = status;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getModule() {
        return module;
    }

    public void setModule(String module) {
        this.module = module;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public LocalDateTime getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(LocalDateTime timestamp) {
        this.timestamp = timestamp;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
