package com.restaurantbilling.model.report;

import java.math.BigDecimal;

public class OrderSummaryDTO {
    private int totalOrders;
    private int completedOrders;
    private int pendingOrders;
    private int cancelledOrders;
    private int preparingOrders;
    private BigDecimal totalOrderValue;

    public OrderSummaryDTO() {
        this.totalOrderValue = BigDecimal.ZERO;
    }

    public OrderSummaryDTO(int totalOrders, int completedOrders, int pendingOrders, int cancelledOrders, int preparingOrders, BigDecimal totalOrderValue) {
        this.totalOrders = totalOrders;
        this.completedOrders = completedOrders;
        this.pendingOrders = pendingOrders;
        this.cancelledOrders = cancelledOrders;
        this.preparingOrders = preparingOrders;
        this.totalOrderValue = totalOrderValue != null ? totalOrderValue : BigDecimal.ZERO;
    }

    public int getTotalOrders() {
        return totalOrders;
    }

    public void setTotalOrders(int totalOrders) {
        this.totalOrders = totalOrders;
    }

    public int getCompletedOrders() {
        return completedOrders;
    }

    public void setCompletedOrders(int completedOrders) {
        this.completedOrders = completedOrders;
    }

    public int getPendingOrders() {
        return pendingOrders;
    }

    public void setPendingOrders(int pendingOrders) {
        this.pendingOrders = pendingOrders;
    }

    public int getCancelledOrders() {
        return cancelledOrders;
    }

    public void setCancelledOrders(int cancelledOrders) {
        this.cancelledOrders = cancelledOrders;
    }

    public int getPreparingOrders() {
        return preparingOrders;
    }

    public void setPreparingOrders(int preparingOrders) {
        this.preparingOrders = preparingOrders;
    }

    public BigDecimal getTotalOrderValue() {
        return totalOrderValue;
    }

    public void setTotalOrderValue(BigDecimal totalOrderValue) {
        this.totalOrderValue = totalOrderValue;
    }
}
