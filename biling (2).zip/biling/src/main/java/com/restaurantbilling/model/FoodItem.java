package com.restaurantbilling.model;

import java.math.BigDecimal;

public class FoodItem {
    private int id;
    private String name;
    private String category;
    private BigDecimal price;
    private boolean available;
    private String imageUrl;
    private String imageSource;
    private Long pexelsPhotoId;
    private String photographerName;
    private String photographerUrl;

    public FoodItem() {
        this.available = true;
    }

    public FoodItem(int id, String name, String category, BigDecimal price, boolean available) {
        this(id, name, category, price, available, null);
    }

    public FoodItem(int id, String name, String category, BigDecimal price, boolean available, String imageUrl) {
        this.id = id;
        this.name = name;
        this.category = category;
        this.price = price;
        this.available = available;
        this.imageUrl = imageUrl;
    }

    public FoodItem(String name, String category, BigDecimal price, boolean available) {
        this(name, category, price, available, null);
    }

    public FoodItem(String name, String category, BigDecimal price, boolean available, String imageUrl) {
        this.name = name;
        this.category = category;
        this.price = price;
        this.available = available;
        this.imageUrl = imageUrl;
    }

    public String getImageSource() {
        return imageSource;
    }

    public void setImageSource(String imageSource) {
        this.imageSource = imageSource;
    }

    public Long getPexelsPhotoId() {
        return pexelsPhotoId;
    }

    public void setPexelsPhotoId(Long pexelsPhotoId) {
        this.pexelsPhotoId = pexelsPhotoId;
    }

    public String getPhotographerName() {
        return photographerName;
    }

    public void setPhotographerName(String photographerName) {
        this.photographerName = photographerName;
    }

    public String getPhotographerUrl() {
        return photographerUrl;
    }

    public void setPhotographerUrl(String photographerUrl) {
        this.photographerUrl = photographerUrl;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public boolean isAvailable() {
        return available;
    }

    public void setAvailable(boolean available) {
        this.available = available;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    @Override
    public String toString() {
        return name + " (₹" + price + ")";
    }
}
