package com.restaurantbilling.model.dashboard;

import java.math.BigDecimal;

public class DashboardSummaryDTO {
    private int totalBills;
    private BigDecimal totalBilledAmount;
    private int totalOrders;
    private int totalCustomers;
    private int totalMenuItems;
    private BigDecimal averageBillAmount;

    public DashboardSummaryDTO() {
        this.totalBills = 0;
        this.totalBilledAmount = BigDecimal.ZERO;
        this.totalOrders = 0;
        this.totalCustomers = 0;
        this.totalMenuItems = 0;
        this.averageBillAmount = BigDecimal.ZERO;
    }

    public DashboardSummaryDTO(int totalBills, BigDecimal totalBilledAmount, int totalOrders, int totalCustomers, int totalMenuItems, BigDecimal averageBillAmount) {
        this.totalBills = totalBills;
        this.totalBilledAmount = (totalBilledAmount != null) ? totalBilledAmount : BigDecimal.ZERO;
        this.totalOrders = totalOrders;
        this.totalCustomers = totalCustomers;
        this.totalMenuItems = totalMenuItems;
        this.averageBillAmount = (averageBillAmount != null) ? averageBillAmount : BigDecimal.ZERO;
    }

    public int getTotalBills() {
        return totalBills;
    }

    public void setTotalBills(int totalBills) {
        this.totalBills = totalBills;
    }

    public BigDecimal getTotalBilledAmount() {
        return totalBilledAmount;
    }

    public void setTotalBilledAmount(BigDecimal totalBilledAmount) {
        this.totalBilledAmount = totalBilledAmount;
    }

    public int getTotalOrders() {
        return totalOrders;
    }

    public void setTotalOrders(int totalOrders) {
        this.totalOrders = totalOrders;
    }

    public int getTotalCustomers() {
        return totalCustomers;
    }

    public void setTotalCustomers(int totalCustomers) {
        this.totalCustomers = totalCustomers;
    }

    public int getTotalMenuItems() {
        return totalMenuItems;
    }

    public void setTotalMenuItems(int totalMenuItems) {
        this.totalMenuItems = totalMenuItems;
    }

    public BigDecimal getAverageBillAmount() {
        return averageBillAmount;
    }

    public void setAverageBillAmount(BigDecimal averageBillAmount) {
        this.averageBillAmount = averageBillAmount;
    }
}
