package com.restaurantbilling.model.report;

import java.math.BigDecimal;

public class BillSummaryDTO {
    private int totalBills;
    private BigDecimal totalBillingAmount;
    private BigDecimal averageBillAmount;
    private BigDecimal highestBillAmount;
    private BigDecimal lowestBillAmount;

    public BillSummaryDTO() {
        this.totalBills = 0;
        this.totalBillingAmount = BigDecimal.ZERO;
        this.averageBillAmount = BigDecimal.ZERO;
        this.highestBillAmount = BigDecimal.ZERO;
        this.lowestBillAmount = BigDecimal.ZERO;
    }

    public BillSummaryDTO(int totalBills, BigDecimal totalBillingAmount, BigDecimal averageBillAmount, BigDecimal highestBillAmount, BigDecimal lowestBillAmount) {
        this.totalBills = totalBills;
        this.totalBillingAmount = totalBillingAmount != null ? totalBillingAmount : BigDecimal.ZERO;
        this.averageBillAmount = averageBillAmount != null ? averageBillAmount : BigDecimal.ZERO;
        this.highestBillAmount = highestBillAmount != null ? highestBillAmount : BigDecimal.ZERO;
        this.lowestBillAmount = lowestBillAmount != null ? lowestBillAmount : BigDecimal.ZERO;
    }

    public int getTotalBills() {
        return totalBills;
    }

    public void setTotalBills(int totalBills) {
        this.totalBills = totalBills;
    }

    public BigDecimal getTotalBillingAmount() {
        return totalBillingAmount;
    }

    public void setTotalBillingAmount(BigDecimal totalBillingAmount) {
        this.totalBillingAmount = totalBillingAmount;
    }

    public BigDecimal getAverageBillAmount() {
        return averageBillAmount;
    }

    public void setAverageBillAmount(BigDecimal averageBillAmount) {
        this.averageBillAmount = averageBillAmount;
    }

    public BigDecimal getHighestBillAmount() {
        return highestBillAmount;
    }

    public void setHighestBillAmount(BigDecimal highestBillAmount) {
        this.highestBillAmount = highestBillAmount;
    }

    public BigDecimal getLowestBillAmount() {
        return lowestBillAmount;
    }

    public void setLowestBillAmount(BigDecimal lowestBillAmount) {
        this.lowestBillAmount = lowestBillAmount;
    }
}
