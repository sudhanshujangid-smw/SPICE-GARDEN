package com.restaurantbilling.model;

import java.sql.Timestamp;

public class Customer {
    private int id;
    private String name;
    private String phone;
    private String email;
    private String address;
    private String status; // "Active" or "Inactive"
    private Timestamp createdAt;
    private Timestamp updatedAt;

    public Customer() {
        this.status = "Active";
    }

    public Customer(String name, String phone, String email, String status) {
        this.name = name;
        this.phone = phone;
        this.email = email;
        this.status = (status != null && !status.trim().isEmpty()) ? status : "Active";
    }

    public Customer(int id, String name, String phone, String email, String status) {
        this(name, phone, email, status);
        this.id = id;
    }

    public Customer(String name, String phone, String email, String address, String status) {
        this(name, phone, email, status);
        this.address = address;
    }

    public Customer(int id, String name, String phone, String email, String address, String status) {
        this(name, phone, email, address, status);
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Timestamp getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }

    public Timestamp getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Timestamp updatedAt) {
        this.updatedAt = updatedAt;
    }

    @Override
    public String toString() {
        return name + " (" + phone + ")";
    }
}
