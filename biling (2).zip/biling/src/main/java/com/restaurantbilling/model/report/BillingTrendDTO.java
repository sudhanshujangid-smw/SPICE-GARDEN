package com.restaurantbilling.model.report;

import java.math.BigDecimal;

public class BillingTrendDTO {
    private String periodLabel; // e.g. "2026-08-22" or "August 2026"
    private int billCount;
    private int orderCount;
    private BigDecimal totalAmount;

    public BillingTrendDTO() {
        this.billCount = 0;
        this.orderCount = 0;
        this.totalAmount = BigDecimal.ZERO;
    }

    public BillingTrendDTO(String periodLabel, int billCount, int orderCount, BigDecimal totalAmount) {
        this.periodLabel = periodLabel;
        this.billCount = billCount;
        this.orderCount = orderCount;
        this.totalAmount = totalAmount != null ? totalAmount : BigDecimal.ZERO;
    }

    public BillingTrendDTO(String periodLabel, int billCount, BigDecimal totalAmount) {
        this(periodLabel, billCount, 0, totalAmount);
    }

    public String getPeriodLabel() {
        return periodLabel;
    }

    public void setPeriodLabel(String periodLabel) {
        this.periodLabel = periodLabel;
    }

    public int getBillCount() {
        return billCount;
    }

    public void setBillCount(int billCount) {
        this.billCount = billCount;
    }

    public int getOrderCount() {
        return orderCount;
    }

    public void setOrderCount(int orderCount) {
        this.orderCount = orderCount;
    }

    public BigDecimal getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(BigDecimal totalAmount) {
        this.totalAmount = totalAmount;
    }
}
