package com.restaurantbilling.model.report;

import java.math.BigDecimal;

/**
 * Data Transfer Object representing menu item performance for reporting.
 */
public class MenuReportDTO {
    private int foodItemId;
    private String foodName;
    private String category;
    private BigDecimal price;
    private int quantityOrdered;
    private BigDecimal totalBilling;

    public MenuReportDTO() {
        this.price = BigDecimal.ZERO;
        this.quantityOrdered = 0;
        this.totalBilling = BigDecimal.ZERO;
    }

    public MenuReportDTO(int foodItemId, String foodName, String category, BigDecimal price, int quantityOrdered, BigDecimal totalBilling) {
        this.foodItemId = foodItemId;
        this.foodName = foodName != null ? foodName : "Item #" + foodItemId;
        this.category = category != null ? category : "General";
        this.price = price != null ? price : BigDecimal.ZERO;
        this.quantityOrdered = quantityOrdered;
        this.totalBilling = totalBilling != null ? totalBilling : BigDecimal.ZERO;
    }

    public int getFoodItemId() {
        return foodItemId;
    }

    public void setFoodItemId(int foodItemId) {
        this.foodItemId = foodItemId;
    }

    public String getFoodName() {
        return foodName;
    }

    public void setFoodName(String foodName) {
        this.foodName = foodName;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public int getQuantityOrdered() {
        return quantityOrdered;
    }

    public void setQuantityOrdered(int quantityOrdered) {
        this.quantityOrdered = quantityOrdered;
    }

    public BigDecimal getTotalBilling() {
        return totalBilling;
    }

    public void setTotalBilling(BigDecimal totalBilling) {
        this.totalBilling = totalBilling;
    }
}
