package com.restaurantbilling.model.dashboard;

public class OrderTrendDTO {
    private String periodLabel;
    private int orderCount;

    public OrderTrendDTO() {
    }

    public OrderTrendDTO(String periodLabel, int orderCount) {
        this.periodLabel = periodLabel;
        this.orderCount = orderCount;
    }

    public String getPeriodLabel() {
        return periodLabel;
    }

    public void setPeriodLabel(String periodLabel) {
        this.periodLabel = periodLabel;
    }

    public int getOrderCount() {
        return orderCount;
    }

    public void setOrderCount(int orderCount) {
        this.orderCount = orderCount;
    }
}
