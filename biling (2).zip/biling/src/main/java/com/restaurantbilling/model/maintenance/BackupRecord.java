package com.restaurantbilling.model.maintenance;

import java.time.LocalDateTime;

public class BackupRecord {
    private int id;
    private String backupName;
    private String backupPath;
    private long fileSizeBytes;
    private LocalDateTime createdAt;
    private String createdBy;
    private String status; // "SUCCESS", "FAILED"
    private String backupType; // "MANUAL", "SAFETY_PRE_RESTORE"

    public BackupRecord() {
        this.createdAt = LocalDateTime.now();
        this.status = "SUCCESS";
        this.backupType = "MANUAL";
    }

    public BackupRecord(int id, String backupName, String backupPath, long fileSizeBytes, LocalDateTime createdAt, String createdBy, String status, String backupType) {
        this.id = id;
        this.backupName = backupName;
        this.backupPath = backupPath;
        this.fileSizeBytes = fileSizeBytes;
        this.createdAt = createdAt;
        this.createdBy = createdBy;
        this.status = status;
        this.backupType = backupType;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getBackupName() {
        return backupName;
    }

    public void setBackupName(String backupName) {
        this.backupName = backupName;
    }

    public String getBackupPath() {
        return backupPath;
    }

    public void setBackupPath(String backupPath) {
        this.backupPath = backupPath;
    }

    public long getFileSizeBytes() {
        return fileSizeBytes;
    }

    public void setFileSizeBytes(long fileSizeBytes) {
        this.fileSizeBytes = fileSizeBytes;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getBackupType() {
        return backupType;
    }

    public void setBackupType(String backupType) {
        this.backupType = backupType;
    }
}
