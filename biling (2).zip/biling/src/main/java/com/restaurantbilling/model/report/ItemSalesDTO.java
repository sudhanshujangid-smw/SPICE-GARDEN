package com.restaurantbilling.model.report;

import java.math.BigDecimal;

public class ItemSalesDTO {
    private int foodItemId;
    private String itemName;
    private String category;
    private int quantitySold;
    private BigDecimal revenue;

    public ItemSalesDTO() {
        this.quantitySold = 0;
        this.revenue = BigDecimal.ZERO;
    }

    public ItemSalesDTO(int foodItemId, String itemName, String category, int quantitySold, BigDecimal revenue) {
        this.foodItemId = foodItemId;
        this.itemName = itemName;
        this.category = category;
        this.quantitySold = quantitySold;
        this.revenue = revenue != null ? revenue : BigDecimal.ZERO;
    }

    public ItemSalesDTO(String itemName, String category, int quantitySold, BigDecimal revenue) {
        this(0, itemName, category, quantitySold, revenue);
    }

    public int getFoodItemId() {
        return foodItemId;
    }

    public void setFoodItemId(int foodItemId) {
        this.foodItemId = foodItemId;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public int getQuantitySold() {
        return quantitySold;
    }

    public void setQuantitySold(int quantitySold) {
        this.quantitySold = quantitySold;
    }

    public BigDecimal getRevenue() {
        return revenue;
    }

    public void setRevenue(BigDecimal revenue) {
        this.revenue = revenue;
    }
}
