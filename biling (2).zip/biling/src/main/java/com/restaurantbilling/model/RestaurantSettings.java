package com.restaurantbilling.model;

public class RestaurantSettings {
    private String restaurantName = "Restaurant Billing System";
    private String address = "123 Food Street, City Center";
    private String city = "Bengaluru";
    private String state = "Karnataka";
    private String pincode = "560001";
    private String phone = "+91 98765 43210";
    private String email = "contact@restaurantbilling.com";
    private String website = "www.restaurantbilling.com";
    private String logoPath = "";
    private String invoiceHeader = "TAX INVOICE / BILL OF SUPPLY";
    private String invoiceFooter = "Thank you for dining with us! Visit again.";
    private String currencySymbol = "₹";
    private double taxRate = 0.0;

    public RestaurantSettings() {}

    public String getRestaurantName() {
        return restaurantName;
    }

    public void setRestaurantName(String restaurantName) {
        this.restaurantName = restaurantName;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getPincode() {
        return pincode;
    }

    public void setPincode(String pincode) {
        this.pincode = pincode;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getWebsite() {
        return website;
    }

    public void setWebsite(String website) {
        this.website = website;
    }

    public String getLogoPath() {
        return logoPath;
    }

    public void setLogoPath(String logoPath) {
        this.logoPath = logoPath;
    }

    public String getInvoiceHeader() {
        return invoiceHeader;
    }

    public void setInvoiceHeader(String invoiceHeader) {
        this.invoiceHeader = invoiceHeader;
    }

    public String getInvoiceFooter() {
        return invoiceFooter;
    }

    public void setInvoiceFooter(String invoiceFooter) {
        this.invoiceFooter = invoiceFooter;
    }

    public String getCurrencySymbol() {
        return currencySymbol;
    }

    public void setCurrencySymbol(String currencySymbol) {
        this.currencySymbol = currencySymbol;
    }

    public double getTaxRate() {
        return taxRate;
    }

    public void setTaxRate(double taxRate) {
        this.taxRate = taxRate;
    }

    public String getFormattedAddress() {
        StringBuilder sb = new StringBuilder();
        if (address != null && !address.trim().isEmpty()) sb.append(address.trim());
        if (city != null && !city.trim().isEmpty()) sb.append(", ").append(city.trim());
        if (state != null && !state.trim().isEmpty()) sb.append(", ").append(state.trim());
        if (pincode != null && !pincode.trim().isEmpty()) sb.append(" - ").append(pincode.trim());
        return sb.toString();
    }

    public String getFormattedContact() {
        StringBuilder sb = new StringBuilder();
        if (phone != null && !phone.trim().isEmpty()) sb.append("Phone: ").append(phone.trim());
        if (email != null && !email.trim().isEmpty()) {
            if (sb.length() > 0) sb.append(" | ");
            sb.append("Email: ").append(email.trim());
        }
        return sb.toString();
    }
}
