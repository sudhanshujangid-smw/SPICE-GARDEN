package com.restaurantbilling.model.report;

import java.math.BigDecimal;
import java.sql.Timestamp;

/**
 * Data Transfer Object representing an aggregated or detailed order in reporting.
 */
public class OrderReportDTO {
    private int orderId;
    private Timestamp orderDate;
    private String customerName;
    private int itemCount;
    private String status;
    private String billNumber;
    private BigDecimal totalAmount;

    public OrderReportDTO() {
        this.totalAmount = BigDecimal.ZERO;
        this.status = "PENDING";
        this.billNumber = "N/A";
        this.customerName = "Walk-in Customer";
    }

    public OrderReportDTO(int orderId, Timestamp orderDate, String customerName, int itemCount, String status, String billNumber, BigDecimal totalAmount) {
        this.orderId = orderId;
        this.orderDate = orderDate;
        this.customerName = (customerName != null && !customerName.trim().isEmpty()) ? customerName : "Walk-in Customer";
        this.itemCount = itemCount;
        this.status = (status != null && !status.trim().isEmpty()) ? status : "PENDING";
        this.billNumber = (billNumber != null && !billNumber.trim().isEmpty()) ? billNumber : "N/A";
        this.totalAmount = (totalAmount != null) ? totalAmount : BigDecimal.ZERO;
    }

    public int getOrderId() {
        return orderId;
    }

    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }

    public Timestamp getOrderDate() {
        return orderDate;
    }

    public void setOrderDate(Timestamp orderDate) {
        this.orderDate = orderDate;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public int getItemCount() {
        return itemCount;
    }

    public void setItemCount(int itemCount) {
        this.itemCount = itemCount;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getBillNumber() {
        return billNumber;
    }

    public void setBillNumber(String billNumber) {
        this.billNumber = billNumber;
    }

    public BigDecimal getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(BigDecimal totalAmount) {
        this.totalAmount = totalAmount;
    }
}
