package com.restaurantbilling.model.maintenance;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DatabaseHealth {

    public enum HealthStatus {
        HEALTHY,
        WARNING,
        ERROR
    }

    private boolean connected;
    private String databaseName;
    private String serverHost;
    private String databaseVersion;
    private List<String> missingTables;
    private Map<String, Long> tableCounts;
    private List<String> consistencyIssues;
    private HealthStatus status;
    private LocalDateTime checkedAt;

    public DatabaseHealth() {
        this.missingTables = new ArrayList<>();
        this.tableCounts = new HashMap<>();
        this.consistencyIssues = new ArrayList<>();
        this.status = HealthStatus.HEALTHY;
        this.checkedAt = LocalDateTime.now();
    }

    public boolean isConnected() {
        return connected;
    }

    public void setConnected(boolean connected) {
        this.connected = connected;
    }

    public String getDatabaseName() {
        return databaseName;
    }

    public void setDatabaseName(String databaseName) {
        this.databaseName = databaseName;
    }

    public String getServerHost() {
        return serverHost;
    }

    public void setServerHost(String serverHost) {
        this.serverHost = serverHost;
    }

    public String getDatabaseVersion() {
        return databaseVersion;
    }

    public void setDatabaseVersion(String databaseVersion) {
        this.databaseVersion = databaseVersion;
    }

    public List<String> getMissingTables() {
        return missingTables;
    }

    public void setMissingTables(List<String> missingTables) {
        this.missingTables = missingTables;
    }

    public Map<String, Long> getTableCounts() {
        return tableCounts;
    }

    public void setTableCounts(Map<String, Long> tableCounts) {
        this.tableCounts = tableCounts;
    }

    public List<String> getConsistencyIssues() {
        return consistencyIssues;
    }

    public void setConsistencyIssues(List<String> consistencyIssues) {
        this.consistencyIssues = consistencyIssues;
    }

    public HealthStatus getStatus() {
        return status;
    }

    public void setStatus(HealthStatus status) {
        this.status = status;
    }

    public LocalDateTime getCheckedAt() {
        return checkedAt;
    }

    public void setCheckedAt(LocalDateTime checkedAt) {
        this.checkedAt = checkedAt;
    }
}
