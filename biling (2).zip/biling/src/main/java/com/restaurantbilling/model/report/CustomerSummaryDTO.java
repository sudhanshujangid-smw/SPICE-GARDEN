package com.restaurantbilling.model.report;

public class CustomerSummaryDTO {
    private int totalCustomers;
    private int activeCustomers;
    private int customersWithOrders;
    private double averageOrdersPerCustomer;

    public CustomerSummaryDTO() {}

    public CustomerSummaryDTO(int totalCustomers, int activeCustomers, int customersWithOrders, double averageOrdersPerCustomer) {
        this.totalCustomers = totalCustomers;
        this.activeCustomers = activeCustomers;
        this.customersWithOrders = customersWithOrders;
        this.averageOrdersPerCustomer = averageOrdersPerCustomer;
    }

    public int getTotalCustomers() {
        return totalCustomers;
    }

    public void setTotalCustomers(int totalCustomers) {
        this.totalCustomers = totalCustomers;
    }

    public int getActiveCustomers() {
        return activeCustomers;
    }

    public void setActiveCustomers(int activeCustomers) {
        this.activeCustomers = activeCustomers;
    }

    public int getCustomersWithOrders() {
        return customersWithOrders;
    }

    public void setCustomersWithOrders(int customersWithOrders) {
        this.customersWithOrders = customersWithOrders;
    }

    public double getAverageOrdersPerCustomer() {
        return averageOrdersPerCustomer;
    }

    public void setAverageOrdersPerCustomer(double averageOrdersPerCustomer) {
        this.averageOrdersPerCustomer = averageOrdersPerCustomer;
    }
}
