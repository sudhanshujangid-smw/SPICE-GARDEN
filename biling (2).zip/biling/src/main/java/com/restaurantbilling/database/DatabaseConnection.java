package com.restaurantbilling.database;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

/**
 * Spice Garden Restaurant Billing System — Centralized Database Connection Manager.
 * 
 * Precedence Order for Configuration:
 * 1. Environment Variables (DB_URL, DB_HOST, DB_PORT, DB_NAME, DB_USERNAME, DB_PASSWORD)
 * 2. System Properties (-Ddb.url, -Ddb.host, -Ddb.port, -Ddb.name, -Ddb.user, -Ddb.password)
 * 3. Local properties file (./db.properties or ./config/db.properties)
 * 4. Classpath resources (db.properties)
 * 5. Default Fallbacks (localhost:3306/restaurant_billing, root, "")
 */
public class DatabaseConnection {

    private static final String DEFAULT_HOST = "localhost";
    private static final String DEFAULT_PORT = "3306";
    private static final String DEFAULT_DB   = "restaurant_billing";
    private static final String DEFAULT_USER = "root";
    private static final String DEFAULT_PASS = "";

    private static String host;
    private static String port;
    private static String dbName;
    private static String username;
    private static String password;
    private static String url;

    private static boolean driverLoaded = false;

    static {
        loadConfiguration();
    }

    /**
     * Loads database configuration from environment, system properties, and properties files.
     */
    public static synchronized void loadConfiguration() {
        Properties props = new Properties();

        // Check if there is any configuration available.
        boolean configFound = false;

        // 1. Try loading from classpath: db.properties
        try (InputStream in = DatabaseConnection.class.getResourceAsStream("/db.properties")) {
            if (in != null) {
                props.load(in);
                configFound = true;
            }
        } catch (Exception ignored) {}

        // 2. Try loading from working directory: ./db.properties or ./config/db.properties
        File localFile = new File("db.properties");
        if (localFile.exists() && localFile.canRead()) {
            try (FileInputStream fis = new FileInputStream(localFile)) {
                props.load(fis);
                configFound = true;
            } catch (Exception ignored) {}
        } else {
            File configFile = new File("config/db.properties");
            if (configFile.exists() && configFile.canRead()) {
                try (FileInputStream fis = new FileInputStream(configFile)) {
                    props.load(fis);
                    configFound = true;
                } catch (Exception ignored) {}
            }
        }

        // Host
        String envHost = System.getenv("DB_HOST");
        String propHost = System.getProperty("db.host", props.getProperty("db.host", DEFAULT_HOST));
        host = (envHost != null && !envHost.trim().isEmpty()) ? envHost.trim() : propHost.trim();

        // Port
        String envPort = System.getenv("DB_PORT");
        String propPort = System.getProperty("db.port", props.getProperty("db.port", DEFAULT_PORT));
        port = (envPort != null && !envPort.trim().isEmpty()) ? envPort.trim() : propPort.trim();

        // Database Name
        String envDb = System.getenv("DB_NAME");
        String propDb = System.getProperty("db.name", props.getProperty("db.name", DEFAULT_DB));
        dbName = (envDb != null && !envDb.trim().isEmpty()) ? envDb.trim() : propDb.trim();

        // Username
        String envUser = System.getenv("DB_USERNAME");
        if (envUser == null || envUser.trim().isEmpty()) {
            envUser = System.getenv("DB_USER");
        }
        String propUser = System.getProperty("db.user", System.getProperty("db.username", props.getProperty("db.username", props.getProperty("db.user", DEFAULT_USER))));
        username = (envUser != null && !envUser.trim().isEmpty()) ? envUser.trim() : propUser.trim();

        // Password
        String envPass = System.getenv("DB_PASSWORD");
        if (envPass == null) {
            envPass = System.getenv("DB_PASS");
        }
        String propPass = System.getProperty("db.password", System.getProperty("db.pass", props.getProperty("db.password", props.getProperty("db.pass", DEFAULT_PASS))));
        password = (envPass != null) ? envPass : propPass;

        // Custom URL (if specified)
        String envUrl = System.getenv("DB_URL");
        String propUrl = System.getProperty("db.url", props.getProperty("db.url", null));
        if (envUrl != null && !envUrl.trim().isEmpty()) {
            url = envUrl.trim();
        } else if (propUrl != null && !propUrl.trim().isEmpty()) {
            url = propUrl.trim();
        } else {
            buildUrl();
        }

        ensureDriver();
    }


    private static void buildUrl() {
        url = "jdbc:mysql://" + host + ":" + port + "/" + dbName 
            + "?useSSL=false&serverTimezone=UTC&allowPublicKeyRetrieval=true&zeroDateTimeBehavior=CONVERT_TO_NULL";
    }

    private static void ensureDriver() {
        if (!driverLoaded) {
            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
                driverLoaded = true;
            } catch (ClassNotFoundException e) {
                System.err.println("[DatabaseConnection] MySQL JDBC Driver not found in classpath: " + e.getMessage());
            }
        }
    }

    public static synchronized void setCredentials(String user, String pass) {
        username = (user != null) ? user.trim() : DEFAULT_USER;
        password = (pass != null) ? pass : "";
        saveConfiguration();
    }

    public static synchronized void setDatabaseTarget(String h, String p, String db, String user, String pass) {
        host = (h != null && !h.trim().isEmpty()) ? h.trim() : DEFAULT_HOST;
        port = (p != null && !p.trim().isEmpty()) ? p.trim() : DEFAULT_PORT;
        dbName = (db != null && !db.trim().isEmpty()) ? db.trim() : DEFAULT_DB;
        username = (user != null) ? user.trim() : DEFAULT_USER;
        password = (pass != null) ? pass : "";
        buildUrl();
        saveConfiguration();
    }

    public static synchronized void saveConfiguration() {
        Properties props = new Properties();
        props.setProperty("db.host", host);
        props.setProperty("db.port", port);
        props.setProperty("db.name", dbName);
        props.setProperty("db.username", username);
        props.setProperty("db.password", password);
        props.setProperty("db.url", url);
        
        File localFile = new File("db.properties");
        try (java.io.FileOutputStream fos = new java.io.FileOutputStream(localFile)) {
            props.store(fos, "Restaurant Billing System - Database Configuration");
        } catch (Exception e) {
            System.err.println("[DatabaseConnection] Error saving configuration: " + e.getMessage());
        }
    }

    public static String getHost() {
        return host;
    }

    public static String getPort() {
        return port;
    }

    public static String getDatabaseName() {
        return dbName;
    }

    public static String getUsername() {
        return username;
    }

    public static String getPassword() {
        return password;
    }

    public static String getUrl() {
        return url;
    }

    public static Connection getConnection() throws SQLException {
        ensureDriver();
        
        // Check if configuration is missing or empty
        boolean hasLocalFile = new File("db.properties").exists() || new File("config/db.properties").exists();
        boolean hasClasspathFile = DatabaseConnection.class.getResourceAsStream("/db.properties") != null;
        
        if (!hasLocalFile && !hasClasspathFile && (password == null || password.isEmpty())) {
            throw new SQLException("Database configuration is missing.");
        }
        
        try {
            return DriverManager.getConnection(url, username, password);
        } catch (SQLException e) {
            if (e.getMessage() != null && e.getMessage().contains("Access denied")) {
                throw new SQLException("Database authentication failed. Please check the configured MySQL username and password.", e);
            }
            throw e;
        }
    }

    /**
     * Tests whether a database connection can be established.
     *
     * @return true if MySQL is reachable and accepts credentials, false otherwise.
     */
    public static boolean testConnection() {
        try (Connection conn = getConnection()) {
            if (conn == null || conn.isClosed()) {
                return false;
            }
            try (Statement stmt = conn.createStatement()) {
                return stmt.execute("SELECT 1");
            }
        } catch (Exception e) {
            return false;
        }
    }
}
