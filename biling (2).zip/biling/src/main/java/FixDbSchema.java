import com.restaurantbilling.database.DatabaseConnection;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.SQLException;

public class FixDbSchema {
    public static void main(String[] args) {
        System.out.println("Connecting to database using db.properties...");
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement()) {
             
            System.out.println("Connection established. Adding image_url...");
            try {
                stmt.execute("ALTER TABLE food_items ADD COLUMN image_url VARCHAR(500)");
                System.out.println("Added image_url");
            } catch (SQLException e) {
                System.out.println("Error adding image_url: " + e.getMessage());
            }

            try {
                stmt.execute("ALTER TABLE food_items ADD COLUMN image_source VARCHAR(50)");
                System.out.println("Added image_source");
            } catch (SQLException e) {
                System.out.println("Error adding image_source: " + e.getMessage());
            }

            try {
                stmt.execute("ALTER TABLE food_items ADD COLUMN pexels_photo_id BIGINT");
                System.out.println("Added pexels_photo_id");
            } catch (SQLException e) {
                System.out.println("Error adding pexels_photo_id: " + e.getMessage());
            }

            try {
                stmt.execute("ALTER TABLE food_items ADD COLUMN photographer_name VARCHAR(255)");
                System.out.println("Added photographer_name");
            } catch (SQLException e) {
                System.out.println("Error adding photographer_name: " + e.getMessage());
            }

            try {
                stmt.execute("ALTER TABLE food_items ADD COLUMN photographer_url VARCHAR(500)");
                System.out.println("Added photographer_url");
            } catch (SQLException e) {
                System.out.println("Error adding photographer_url: " + e.getMessage());
            }

            System.out.println("Schema fix complete.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
