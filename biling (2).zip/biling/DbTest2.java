import java.sql.*;
public class DbTest2 {
    public static void main(String[] args) {
        String url = "jdbc:mysql://localhost:3306/restaurant_billing?useSSL=false&serverTimezone=UTC&allowPublicKeyRetrieval=true";
        String user = "root";
        String password = ""; 
        try (Connection conn = DriverManager.getConnection(url, user, password)) {
            System.out.println("Connected to DB!");
            try (Statement stmt = conn.createStatement()) {
                ResultSet rs = stmt.executeQuery("SHOW TABLES");
                while(rs.next()) {
                    System.out.println("Table: " + rs.getString(1));
                }
                rs = stmt.executeQuery("SELECT COUNT(*) FROM customers");
                if (rs.next()) System.out.println("Customers count: " + rs.getInt(1));
                
                rs = stmt.executeQuery("SELECT * FROM customers LIMIT 1");
                ResultSetMetaData rsmd = rs.getMetaData();
                for (int i=1; i<=rsmd.getColumnCount(); i++) {
                    System.out.println("Col " + i + ": " + rsmd.getColumnName(i));
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
