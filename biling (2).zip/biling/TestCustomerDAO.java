import com.restaurantbilling.dao.impl.CustomerDAOImpl;
import com.restaurantbilling.database.DatabaseConnection;
import java.util.List;
import com.restaurantbilling.model.Customer;

public class TestCustomerDAO {
    public static void main(String[] args) throws Exception {
        System.out.println("Testing with password ''...");
        DatabaseConnection.setCredentials("root", "");
        testDb();
        System.out.println("Testing with password 'root'...");
        DatabaseConnection.setCredentials("root", "root");
        testDb();
    }

    private static void testDb() {
        try {
            CustomerDAOImpl dao = new CustomerDAOImpl();
            List<Customer> customers = dao.findAll();
            System.out.println("Found customers: " + customers.size());
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}
