import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class AlterDb {
    public static void main(String[] args) {
        String url = "jdbc:mysql://localhost:3306/restaurant_billing?useSSL=false&serverTimezone=UTC&allowPublicKeyRetrieval=true";
        String user = "root";
        String password = "";
        
        try (Connection conn = DriverManager.getConnection(url, user, password);
             Statement stmt = conn.createStatement()) {
            
            try {
                stmt.execute("ALTER TABLE food_items ADD COLUMN image_source VARCHAR(50) DEFAULT 'Pexels'");
                System.out.println("Added image_source");
            } catch(Exception e) { System.out.println(e.getMessage()); }
            
            try {
                stmt.execute("ALTER TABLE food_items ADD COLUMN pexels_photo_id BIGINT");
                System.out.println("Added pexels_photo_id");
            } catch(Exception e) { System.out.println(e.getMessage()); }
            
            try {
                stmt.execute("ALTER TABLE food_items ADD COLUMN photographer_name VARCHAR(255)");
                System.out.println("Added photographer_name");
            } catch(Exception e) { System.out.println(e.getMessage()); }
            
            try {
                stmt.execute("ALTER TABLE food_items ADD COLUMN photographer_url VARCHAR(500)");
                System.out.println("Added photographer_url");
            } catch(Exception e) { System.out.println(e.getMessage()); }
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
