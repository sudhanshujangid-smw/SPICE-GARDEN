import java.sql.*;
public class DbTest3 {
    public static void main(String[] args) {
        String url = "jdbc:mysql://localhost:3306/restaurant_billing?useSSL=false&serverTimezone=UTC&allowPublicKeyRetrieval=true";
        String user = "root";
        String password = "root"; 
        try (Connection conn = DriverManager.getConnection(url, user, password)) {
            System.out.println("Connected to DB with password 'root'!");
            try (Statement stmt = conn.createStatement()) {
                ResultSet rs = stmt.executeQuery("SHOW TABLES");
                while(rs.next()) {
                    System.out.println("Table: " + rs.getString(1));
                }
                rs = stmt.executeQuery("SELECT COUNT(*) FROM customers");
                if (rs.next()) System.out.println("Customers count: " + rs.getInt(1));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
