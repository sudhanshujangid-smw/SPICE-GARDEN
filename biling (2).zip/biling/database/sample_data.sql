-- Sample Data for Restaurant Billing System

USE restaurant_billing;

-- Default Users
INSERT INTO users (username, password, role) VALUES
('admin', 'admin123', 'ADMIN'),
('staff', 'staff123', 'STAFF')
ON DUPLICATE KEY UPDATE username=username;

-- Sample Food Items
INSERT INTO food_items (name, category, price, available, image_url) VALUES
('Paneer Tikka', 'Starter', 180.00, TRUE, 'https://images.pexels.com/photos/3926124/pexels-photo-3926124.jpeg'),
('Veg Spring Rolls', 'Starter', 150.00, TRUE, 'https://images.pexels.com/photos/461198/pexels-photo-461198.jpeg'),
('Chicken Tikka', 'Starter', 240.00, TRUE, 'https://images.pexels.com/photos/2233729/pexels-photo-2233729.jpeg'),
('Veg Biryani', 'Main Course', 220.00, TRUE, 'https://images.pexels.com/photos/1624487/pexels-photo-1624487.jpeg'),
('Chicken Biryani', 'Main Course', 280.00, TRUE, 'https://images.pexels.com/photos/7394819/pexels-photo-7394819.jpeg'),
('Butter Naan', 'Breads', 45.00, TRUE, 'https://images.pexels.com/photos/1117862/pexels-photo-1117862.jpeg'),
('Garlic Naan', 'Breads', 60.00, TRUE, 'https://images.pexels.com/photos/2092897/pexels-photo-2092897.jpeg'),
('Cold Coffee', 'Beverages', 120.00, TRUE, 'https://images.pexels.com/photos/302899/pexels-photo-302899.jpeg'),
('Mango Lassi', 'Beverages', 90.00, TRUE, 'https://images.pexels.com/photos/2109099/pexels-photo-2109099.jpeg'),
('Gulab Jamun', 'Dessert', 80.00, TRUE, 'https://images.pexels.com/photos/3026808/pexels-photo-3026808.jpeg')
ON DUPLICATE KEY UPDATE name=name;

-- Sample Customers
INSERT INTO customers (name, phone, email, address, status) VALUES
('Rahul Sharma', '9876543210', 'rahul@example.com', '123 MG Road, Bengaluru', 'Active'),
('Priya Patel', '9876543211', 'priya@example.com', '45 Park Street, Kolkata', 'Active'),
('Amit Verma', '9876543212', 'amit.verma@example.com', '78 Sector 18, Noida', 'Active'),
('Sneha Reddy', '9876543213', 'sneha.r@example.com', '12 Jubilee Hills, Hyderabad', 'Inactive'),
('Vikram Singh', '9876543214', 'vikram.s@example.com', '56 Malviya Nagar, Jaipur', 'Active')
ON DUPLICATE KEY UPDATE phone=phone;

-- Default System Settings
INSERT INTO system_settings (setting_key, setting_value, description, updated_by) VALUES
('restaurant_name', 'Restaurant Billing System', 'Official Restaurant Name', 'admin'),
('restaurant_address', '123 Food Street, City Center', 'Restaurant Street Address', 'admin'),
('restaurant_city', 'Bengaluru', 'City', 'admin'),
('restaurant_state', 'Karnataka', 'State', 'admin'),
('restaurant_pincode', '560001', 'Postal PIN Code', 'admin'),
('restaurant_phone', '+91 98765 43210', 'Primary Contact Phone', 'admin'),
('restaurant_email', 'contact@restaurantbilling.com', 'Official Contact Email', 'admin'),
('restaurant_website', 'www.restaurantbilling.com', 'Official Website', 'admin'),
('restaurant_logo_path', '', 'Path to Restaurant Logo Image', 'admin'),
('invoice_header', 'TAX INVOICE / BILL OF SUPPLY', 'Invoice Header Text', 'admin'),
('invoice_footer', 'Thank you for dining with us! Visit again.', 'Invoice Footer / Thank You Note', 'admin'),
('currency_symbol', '₹', 'Display Currency Symbol', 'admin'),
('tax_rate', '0.0', 'Applicable Tax / GST Percentage', 'admin')
ON DUPLICATE KEY UPDATE setting_key=setting_key;
