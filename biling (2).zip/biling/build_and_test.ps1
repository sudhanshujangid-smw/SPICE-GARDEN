# Create output directories if they don't exist
if (-not (Test-Path "target\classes")) { New-Item -ItemType Directory -Path "target\classes" -Force }
if (-not (Test-Path "target\test-classes")) { New-Item -ItemType Directory -Path "target\test-classes" -Force }

# Find required jars in .m2 repository
$jarList = Get-ChildItem -Path "$env:USERPROFILE\.m2\repository" -Filter "*.jar" -Recurse | Select-Object -ExpandProperty FullName
$classpath = $jarList -join ";"

# Collect all main java files without BOM
$mainFiles = Get-ChildItem -Path "src\main\java" -Filter "*.java" -Recurse | Select-Object -ExpandProperty FullName
[System.IO.File]::WriteAllLines("sources_main.txt", $mainFiles)

Write-Host "Compiling main sources ($($mainFiles.Count) files) with TieredStopAtLevel=1..."
javac -J-XX:TieredStopAtLevel=1 -J-XX:+UseSerialGC -J-Xmx64m -cp "$classpath" -d "target\classes" "@sources_main.txt"

if ($LASTEXITCODE -ne 0) {
    Write-Error "Main compilation failed with exit code $LASTEXITCODE"
    exit $LASTEXITCODE
}
Write-Host "Main compilation SUCCESSFUL."

# Collect all test java files without BOM
$testFiles = Get-ChildItem -Path "src\test\java" -Filter "*.java" -Recurse | Select-Object -ExpandProperty FullName
[System.IO.File]::WriteAllLines("sources_test.txt", $testFiles)

$testClasspath = "target\classes;" + $classpath
Write-Host "Compiling test sources ($($testFiles.Count) files)..."
javac -J-XX:TieredStopAtLevel=1 -J-XX:+UseSerialGC -J-Xmx64m -cp "$testClasspath" -d "target\test-classes" "@sources_test.txt"

if ($LASTEXITCODE -ne 0) {
    Write-Error "Test compilation failed with exit code $LASTEXITCODE"
    exit $LASTEXITCODE
}
Write-Host "Test compilation SUCCESSFUL."

# Run Phase 16 AdvancedReportingTest
Write-Host "`nRunning Phase 16 AdvancedReportingTest..."
$runClasspath = "target\classes;target\test-classes;" + $classpath
java -XX:TieredStopAtLevel=1 -XX:+UseSerialGC -Xmx64m -cp "$runClasspath" com.restaurantbilling.AdvancedReportingTest

# Run Phase 15 DashboardAnalyticsTest
Write-Host "`nRunning Phase 15 DashboardAnalyticsTest..."
java -XX:TieredStopAtLevel=1 -XX:+UseSerialGC -Xmx64m -cp "$runClasspath" com.restaurantbilling.DashboardAnalyticsTest

# Run Phase 14 AuditSecurityTest
Write-Host "`nRunning Phase 14 AuditSecurityTest..."
java -XX:TieredStopAtLevel=1 -XX:+UseSerialGC -Xmx64m -cp "$runClasspath" com.restaurantbilling.AuditSecurityTest

# Run Regression Tests
Write-Host "`nRunning Regression Test: MaintenanceServiceTest..."
java -XX:TieredStopAtLevel=1 -XX:+UseSerialGC -Xmx64m -cp "$runClasspath" com.restaurantbilling.MaintenanceServiceTest

Write-Host "`nRunning Regression Test: SettingsServiceTest..."
java -XX:TieredStopAtLevel=1 -XX:+UseSerialGC -Xmx64m -cp "$runClasspath" com.restaurantbilling.SettingsServiceTest

Write-Host "`nRunning Regression Test: BillingServiceTest..."
java -XX:TieredStopAtLevel=1 -XX:+UseSerialGC -Xmx64m -cp "$runClasspath" com.restaurantbilling.BillingServiceTest

Write-Host "`nRunning Regression Test: ReportServiceTest..."
java -XX:TieredStopAtLevel=1 -XX:+UseSerialGC -Xmx64m -cp "$runClasspath" com.restaurantbilling.ReportServiceTest

Write-Host "`nRunning Regression Test: OrderServiceTest..."
java -XX:TieredStopAtLevel=1 -XX:+UseSerialGC -Xmx64m -cp "$runClasspath" com.restaurantbilling.OrderServiceTest

Write-Host "`nRunning Regression Test: CustomerValidationTest..."
java -XX:TieredStopAtLevel=1 -XX:+UseSerialGC -Xmx64m -cp "$runClasspath" com.restaurantbilling.CustomerValidationTest
