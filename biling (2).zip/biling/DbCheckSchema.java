import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;

public class DbCheckSchema {
    public static void main(String[] args) {
        String url = "jdbc:mysql://localhost:3306/restaurant_billing?useSSL=false&serverTimezone=UTC&allowPublicKeyRetrieval=true";
        String user = "root";
        String password = "root";
        
        try (Connection conn = DriverManager.getConnection(url, user, password);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM food_items LIMIT 1")) {
            
            ResultSetMetaData meta = rs.getMetaData();
            int count = meta.getColumnCount();
            System.out.println("Columns in food_items:");
            boolean hasImageUrl = false;
            for (int i = 1; i <= count; i++) {
                String colName = meta.getColumnName(i);
                System.out.println("- " + colName);
                if (colName.equalsIgnoreCase("image_url")) {
                    hasImageUrl = true;
                }
            }
            if (hasImageUrl) {
                System.out.println("RESULT: image_url column EXISTS.");
            } else {
                System.out.println("RESULT: image_url column DOES NOT EXIST.");
            }
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
