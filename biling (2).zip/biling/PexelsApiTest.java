import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;

public class PexelsApiTest {
    public static void main(String[] args) {
        String apiKey = System.getenv("PEXELS_API_KEY");

        if (apiKey == null || apiKey.trim().isEmpty()) {
            System.out.println("PEXELS_API_KEY environment variable is not configured.");
            return;
        }

        System.out.println("PEXELS_API_KEY detected.");

        try {
            HttpClient client = HttpClient.newBuilder()
                    .connectTimeout(Duration.ofSeconds(10))
                    .build();

            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create("https://api.pexels.com/v1/search?query=paneer%20tikka&per_page=5"))
                    .header("Authorization", apiKey)
                    .GET()
                    .build();

            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

            int statusCode = response.statusCode();
            System.out.println("Pexels API Status: " + statusCode);

            if (statusCode == 200) {
                System.out.println("Pexels API connection successful.");
                String body = response.body();
                
                // Very basic JSON parsing since we don't have a JSON library dependency available here
                int photoCount = 0;
                int index = body.indexOf("\"photographer\"");
                while (index != -1) {
                    photoCount++;
                    index = body.indexOf("\"photographer\"", index + 1);
                }
                
                System.out.println("Photo results found: " + photoCount);
                
            } else if (statusCode == 401) {
                System.out.println("Pexels API authentication failed. Check the API key.");
            } else if (statusCode == 403) {
                System.out.println("Pexels API access denied.");
            } else if (statusCode == 429) {
                System.out.println("Pexels API rate limit reached.");
            } else {
                System.out.println("Pexels API request failed: HTTP " + statusCode);
            }

        } catch (Exception e) {
            System.out.println("Exception occurred: " + e.getMessage());
        }
    }
}
