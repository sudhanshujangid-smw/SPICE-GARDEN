# PHASE 7 — MENU MANAGEMENT & FOOD ITEM CRUD

## Project

Continue developing the new **Restaurant Billing System**.

Completed phases:

- PHASE 1 — Project Setup & Foundation
- PHASE 2 — MySQL Database Design & Implementation
- PHASE 3 — JDBC Database Connectivity
- PHASE 4 — Model Classes & DAO Foundation
- PHASE 5 — Authentication & Login System
- PHASE 6 — Main Dashboard & Application Navigation

Current phase:

- PHASE 7 — Menu Management & Food Item CRUD

Technology stack:

- Java 21
- Java Swing
- MySQL 8.x
- JDBC
- Maven
- IntelliJ IDEA
- MVC + DAO architecture

Master documentation:

`Restaurant_Billing_System_Complete_Documentation.md`

Treat the existing documentation and Phase 2 database schema as the source of truth.

---

# 1. PHASE 7 OBJECTIVE

Implement the complete **Menu Management** module.

The module must allow authorized users to manage restaurant food items.

Main architecture:

```text
MenuManagementPanel
        ↓
Menu/FoodItem Controller or Service
        ↓
FoodItemDAO
        ↓
FoodItemDAOImpl
        ↓
DatabaseConnection
        ↓
MySQL
```

The module must support:

```text
Create Food Item
View Food Items
Search Food Items
Filter Food Items
Update Food Item
Enable/Disable Food Item
Delete Food Item
```

---

# 2. IMPORTANT RULES

Do NOT redesign the database.

Do NOT create a second food-item table.

Use the existing:

```text
FoodItem
FoodItemDAO
FoodItemDAOImpl
```

from previous phases.

Do NOT implement:

- Orders
- Billing
- Payments
- Reports
- Customer management

Those belong to later phases.

---

# 3. FOOD ITEM DATA

Use the fields defined by the existing database schema.

The Java `FoodItem` model should remain synchronized with the actual MySQL table.

At minimum, the UI should work with:

```text
Food Item ID
Name
Category
Price
Availability
```

If the Phase 2 schema contains additional fields, preserve and support them appropriately.

Do NOT remove existing database fields merely to simplify the UI.

---

# 4. MENU MANAGEMENT PANEL

Replace the Phase 6 placeholder:

```text
MenuManagementPanel
```

with the real functional module.

Suggested layout:

```text
+-------------------------------------------------------------+
| MENU MANAGEMENT                                             |
+-------------------------------------------------------------+
| Search [_____________] Category [All ▼] Availability [All] |
|                                                             |
| [ Add Food Item ]                                           |
+-------------------------------------------------------------+
| ID | Name | Category | Price | Available | Actions         |
|----|------|----------|-------|-----------|-----------------|
| 1  | ...  | ...      | ...   | Yes       | Edit | Delete   |
| 2  | ...  | ...      | ...   | No        | Edit | Enable   |
+-------------------------------------------------------------+
```

Use a `JTable`.

---

# 5. MENU TABLE

Create a clean table displaying food items.

Recommended columns:

```text
ID
Name
Category
Price
Availability
Actions
```

Do not place large amounts of business logic inside table renderers.

Use appropriate table models.

Recommended:

```text
DefaultTableModel
```

or a custom `TableModel` if appropriate.

---

# 6. ADD FOOD ITEM

Create a form for adding a new food item.

Possible form:

```text
Food Name
[________________________]

Category
[________________________]

Price
[________________________]

Availability
[✓] Available

[ SAVE ] [ CLEAR ] [ CANCEL ]
```

Use appropriate Swing controls.

---

# 7. VALIDATION

Before saving:

### Food name

Must not be empty.

Error:

```text
Food item name is required.
```

### Category

Must not be empty.

Error:

```text
Category is required.
```

### Price

Must:

```text
be numeric
be greater than or equal to 0
```

Invalid:

```text
abc
-50
```

Valid:

```text
100
99.50
250.00
```

Use `BigDecimal` for the Java value.

---

# 8. PRICE HANDLING

Continue using:

```text
BigDecimal
```

for prices.

Never convert food prices to:

```text
double
float
```

when storing or calculating monetary values.

Example:

```java
BigDecimal price = new BigDecimal(priceText);
```

Handle invalid numeric input safely.

---

# 9. ADD OPERATION

When SAVE is clicked:

```text
Validate input
      ↓
Create FoodItem
      ↓
FoodItemService
      ↓
FoodItemDAO.save()
      ↓
MySQL
      ↓
Success
      ↓
Refresh table
      ↓
Clear form
```

Do not directly execute SQL from the Swing panel.

---

# 10. FOOD ITEM SERVICE

If not already present, create:

```text
service/
└── FoodItemService.java
```

Responsibilities:

- Validate food item data.
- Coordinate DAO operations.
- Apply menu-related business rules.
- Provide clean methods for GUI.

Example conceptual methods:

```text
addFoodItem()
getAllFoodItems()
searchFoodItems()
updateFoodItem()
deleteFoodItem()
setAvailability()
```

The GUI should communicate with the Service layer rather than directly with DAO implementations.

---

# 11. EDIT FOOD ITEM

Provide an Edit action.

Flow:

```text
Select food item
      ↓
Click Edit
      ↓
Load existing data
      ↓
Display form
      ↓
Modify
      ↓
Validate
      ↓
Update
      ↓
Refresh table
```

The existing ID must not accidentally change.

---

# 12. UPDATE FOOD ITEM

The update operation must modify only the intended record.

Use:

```text
UPDATE food_items
SET ...
WHERE id = ?
```

using:

```text
PreparedStatement
```

Never build SQL using user input concatenation.

---

# 13. DELETE FOOD ITEM

Implement delete functionality.

Before deletion show confirmation:

```text
Are you sure you want to delete this food item?
```

Buttons:

```text
Yes
No
```

If the food item is referenced by existing orders, respect database foreign-key constraints.

Do NOT blindly delete historical menu records if doing so would break order history.

If the project requirements prefer preserving historical menu items, use availability/deactivation instead of physical deletion.

Follow the database design and master documentation.

---

# 14. AVAILABILITY MANAGEMENT

Food items must support:

```text
Available
Unavailable
```

Use a clear UI representation.

Example:

```text
Available
Unavailable
```

or:

```text
✓ Available
✕ Unavailable
```

Provide an action such as:

```text
Enable
Disable
```

depending on current status.

---

# 15. AVAILABILITY VS DELETE

Do not confuse:

```text
Unavailable
```

with:

```text
Deleted
```

An unavailable item may still exist in the database but should not be selectable for new orders.

This distinction is important for preserving restaurant/menu history.

---

# 16. SEARCH

Implement real-time or button-triggered search.

Search should support at least:

```text
Food item name
```

Example:

```text
Search:
[ pizza ]
```

Results:

```text
Pizza Margherita
Chicken Pizza
Paneer Pizza
```

Use parameterized SQL.

Do not load unnecessary data repeatedly.

---

# 17. CATEGORY FILTER

Provide:

```text
Category
[ All ▼ ]
```

Possible categories depend on the project's database/data.

Examples:

```text
Starters
Main Course
Pizza
Burger
Beverages
Desserts
```

Do NOT hardcode these categories if the database has a category structure.

If categories are stored as strings in the existing schema, dynamically derive/filter from available data.

---

# 18. AVAILABILITY FILTER

Provide:

```text
Availability
[ All ▼ ]
```

Options:

```text
All
Available
Unavailable
```

Filtering should work together with search and category.

Example:

```text
Search = Pizza
Category = Pizza
Availability = Available
```

should show only matching available pizza items.

---

# 19. COMBINED FILTERING

Support:

```text
Search
+
Category
+
Availability
```

Example:

```text
Search: Burger
Category: Main Course
Availability: Available
```

The table should update correctly.

Avoid fetching the entire database unnecessarily for every keystroke if the dataset becomes large.

---

# 20. CLEAR FILTERS

Provide:

```text
[ Clear Filters ]
```

Behavior:

```text
Search → empty
Category → All
Availability → All
Table → all food items
```

---

# 21. TABLE REFRESH

After:

```text
Add
Update
Delete
Enable
Disable
```

refresh the table.

Do not require the user to restart the application.

---

# 22. EMPTY DATA STATE

If there are no food items:

Display:

```text
No food items found.
```

Do not leave the table appearing broken.

If a filter produces no results:

```text
No food items match the selected filters.
```

---

# 23. ERROR HANDLING

If saving fails:

```text
Unable to save food item.
Please try again.
```

If updating fails:

```text
Unable to update food item.
```

If deleting fails:

```text
Unable to delete food item.
The item may be referenced by existing records.
```

Do not show raw SQL stack traces to normal users.

---

# 24. SUCCESS MESSAGES

After successful operations:

### Add

```text
Food item added successfully.
```

### Update

```text
Food item updated successfully.
```

### Delete

```text
Food item deleted successfully.
```

### Availability

```text
Food item availability updated.
```

Keep messages short and clear.

---

# 25. FORM DESIGN

Use a reusable form approach if practical.

Do not duplicate the complete add/edit UI unnecessarily.

Preferred concept:

```text
FoodItemFormPanel
```

used for:

```text
ADD
EDIT
```

This reduces duplicated code.

---

# 26. DIALOG VS PANEL

The main menu should remain inside:

```text
MainFrame
```

For add/edit, a modal dialog may be used:

```text
FoodItemDialog
```

This is acceptable if it keeps the interface clean.

Recommended structure:

```text
MainFrame
   ↓
MenuManagementPanel
   ↓
FoodItemDialog
```

---

# 27. ROLE-BASED ACCESS

Use the authenticated role from:

```text
UserSession
```

Suggested behavior:

### ADMIN

Can:

```text
Add
Edit
Delete
Enable/Disable
Search
Filter
View
```

### STAFF

Follow the project's documented permissions.

If STAFF should not modify menu data:

```text
Add → disabled
Edit → disabled
Delete → disabled
Availability → disabled
```

but STAFF can:

```text
View
Search
Filter
```

Do not invent permission rules if the master documentation specifies different behavior.

---

# 28. AUTHORIZATION CHECK

Do not rely only on hiding buttons.

Before performing sensitive operations:

```text
Add
Update
Delete
Availability Change
```

the service/controller should verify authorization where appropriate.

The GUI restriction is only a usability layer.

---

# 29. DATABASE OPERATIONS

Use the existing:

```text
FoodItemDAO
FoodItemDAOImpl
```

from Phase 4.

Do not create duplicate DAO classes.

Required operations should include:

```text
findAll()
findById()
findByCategory()
search()
save()
update()
delete()
updateAvailability()
```

Use the existing architecture.

---

# 30. DATABASE QUERY SAFETY

Every query containing user-controlled input must use:

```text
PreparedStatement
```

Never:

```java
"SELECT * FROM food_items WHERE name LIKE '%" + search + "%'"
```

Use parameterized queries.

---

# 31. PERFORMANCE

The menu module must remain responsive.

For normal restaurant-sized datasets:

```text
Load → Table
```

should be fast.

Avoid:

```text
SELECT *
```

repeatedly for every small UI action when unnecessary.

If the dataset grows, use efficient filtering/search queries.

Do not introduce complex caching without a demonstrated need.

---

# 32. THREADING

Database operations should not unnecessarily block the Swing Event Dispatch Thread.

For operations that may take noticeable time:

```text
SwingWorker
```

or an equivalent background mechanism may be used.

After completion:

```text
Update Swing UI on EDT
```

Do not manipulate Swing components from arbitrary background threads.

---

# 33. UI DESIGN

The Menu Management screen should visually match the Phase 6 dashboard.

Maintain:

- same typography
- same spacing
- same button style
- same navigation/sidebar
- same window structure
- same visual hierarchy

Do not create a completely different design for this module.

---

# 34. TABLE ACTIONS

Each row should provide appropriate actions.

Possible:

```text
[Edit] [Delete]
```

For availability:

```text
[Disable]
```

or:

```text
[Enable]
```

Do not make the table visually cluttered.

---

# 35. DOUBLE-CLICK SUPPORT

Optionally allow:

```text
Double-click row
```

to open the edit dialog.

If implemented, ensure it does not conflict with normal row selection.

---

# 36. CONFIRMATION DIALOGS

Use confirmation for destructive operations.

Delete:

```text
Delete Food Item?

This action cannot be undone.
```

Availability changes generally do not require confirmation unless the project UI design calls for it.

---

# 37. NO HARDCODED DATABASE DATA

Do NOT write:

```text
Pizza
Burger
Coffee
```

directly into the Java GUI as permanent data.

Food items must come from MySQL.

Sample data belongs in:

```text
database/sample_data.sql
```

---

# 38. SAMPLE DATA

If the database currently has no menu data, use the existing sample-data mechanism.

Do not silently insert demo records every time the application starts.

Do not automatically duplicate sample items.

---

# 39. AUDIT FIELDS

If the database schema includes:

```text
created_at
updated_at
```

ensure they are handled correctly.

Prefer database-generated timestamps where the schema already provides them.

Do not unnecessarily overwrite `created_at` during updates.

---

# 40. PROJECT STRUCTURE AFTER PHASE 7

The relevant structure should become:

```text
src/
└── main/
    ├── java/
    │   └── com/
    │       └── restaurantbilling/
    │           │
    │           ├── model/
    │           │   └── FoodItem.java
    │           │
    │           ├── dao/
    │           │   ├── FoodItemDAO.java
    │           │   └── impl/
    │           │       └── FoodItemDAOImpl.java
    │           │
    │           ├── service/
    │           │   ├── AuthenticationService.java
    │           │   └── FoodItemService.java
    │           │
    │           ├── gui/
    │           │   ├── MainFrame.java
    │           │   │
    │           │   └── menu/
    │           │       ├── MenuManagementPanel.java
    │           │       └── FoodItemDialog.java
    │           │
    │           ├── database/
    │           │   └── DatabaseConnection.java
    │           │
    │           └── util/
    │               └── UserSession.java
    │
    └── resources/
```

Only create additional helper/controller classes if genuinely useful.

---

# 41. TESTING

Test all major operations.

## Test 1 — Load Menu

Expected:

```text
PASS
Food items loaded from MySQL.
```

## Test 2 — Add Food Item

Example:

```text
Name: Veg Burger
Category: Burger
Price: 149.00
Available: Yes
```

Expected:

```text
PASS
Record inserted.
```

---

## Test 3 — Edit Food Item

Change:

```text
149.00 → 159.00
```

Expected:

```text
PASS
Database and table updated.
```

---

## Test 4 — Delete Food Item

Delete a test item.

Expected:

```text
PASS
Correct record deleted or safely blocked by database relationship.
```

---

## Test 5 — Disable Food Item

Expected:

```text
PASS
Availability changes to Unavailable.
```

---

## Test 6 — Enable Food Item

Expected:

```text
PASS
Availability changes to Available.
```

---

## Test 7 — Search

Search:

```text
Pizza
```

Expected:

```text
PASS
Only matching food items displayed.
```

---

## Test 8 — Category Filter

Expected:

```text
PASS
Correct category displayed.
```

---

## Test 9 — Availability Filter

Expected:

```text
PASS
Only selected availability displayed.
```

---

## Test 10 — Combined Filter

Test:

```text
Search + Category + Availability
```

Expected:

```text
PASS
Correct combined results.
```

---

## Test 11 — Invalid Price

Enter:

```text
abc
```

Expected:

```text
PASS
Validation error.
No database insert.
```

---

## Test 12 — Negative Price

Enter:

```text
-100
```

Expected:

```text
PASS
Validation error.
```

---

## Test 13 — Empty Name

Expected:

```text
PASS
Validation error.
```

---

## Test 14 — Unauthorized STAFF Operation

If STAFF is read-only according to the project requirements:

Expected:

```text
PASS
STAFF cannot modify menu data.
```

---

# 42. DATABASE VALIDATION

After each CRUD operation, verify the actual MySQL record.

Example:

```text
GUI
 ↓
Save
 ↓
DAO
 ↓
MySQL
 ↓
SELECT
 ↓
Correct data
```

Do not rely only on the GUI table.

---

# 43. PHASE 7 SECURITY CHECKLIST

Verify:

```text
[ ] PreparedStatement used
[ ] No SQL injection
[ ] No database credentials in GUI
[ ] Role permissions respected
[ ] Unauthorized modifications blocked
[ ] No raw SQL errors shown to users
[ ] No passwords exposed
```

---

# 44. PHASE 7 PERFORMANCE CHECKLIST

Verify:

```text
[ ] Menu loads quickly
[ ] Search is responsive
[ ] Filters are responsive
[ ] GUI does not freeze unnecessarily
[ ] No repeated unnecessary database calls
[ ] No duplicate rows after refresh
[ ] No duplicate event listeners
```

---

# 45. PHASE 7 SUCCESS CRITERIA

Phase 7 is complete only when:

```text
[ ] Menu Management panel implemented
[ ] Food item table implemented
[ ] Add food item works
[ ] Edit food item works
[ ] Delete/deactivate works
[ ] Enable/disable works
[ ] Search works
[ ] Category filter works
[ ] Availability filter works
[ ] Combined filters work
[ ] Clear filters works
[ ] Validation works
[ ] BigDecimal used for price
[ ] MySQL data is correctly synchronized
[ ] DAO layer reused
[ ] Service layer implemented
[ ] Role restrictions work
[ ] UI remains responsive
[ ] Maven build succeeds
[ ] Application runs successfully
```

---

# 46. DO NOT START PHASE 8

Do NOT automatically implement:

```text
Customer Management
Customer CRUD
Customer Search
Customer History
```

These belong to the next phase.

Stop after Phase 7 validation.

---

# 47. REQUIRED FINAL REPORT

After implementation, provide:

## A. Files Created/Modified

List all files.

## B. Menu Architecture

Show:

```text
MenuManagementPanel
        ↓
FoodItemService
        ↓
FoodItemDAO
        ↓
FoodItemDAOImpl
        ↓
DatabaseConnection
        ↓
MySQL
```

## C. Features Completed

```text
Add: PASS/FAIL
View: PASS/FAIL
Edit: PASS/FAIL
Delete: PASS/FAIL
Enable: PASS/FAIL
Disable: PASS/FAIL
Search: PASS/FAIL
Category Filter: PASS/FAIL
Availability Filter: PASS/FAIL
Combined Filter: PASS/FAIL
Validation: PASS/FAIL
Role Restriction: PASS/FAIL
```

## D. Database Validation

Confirm that GUI changes are correctly reflected in MySQL.

## E. Problems

List unresolved issues.

## F. Final Status

If all requirements pass:

```text
PHASE 7 COMPLETE

NEXT:
PHASE 8 — Customer Management & Customer CRUD
```

Do NOT automatically start Phase 8.

Wait for explicit approval.