# PHASE 2 — MYSQL DATABASE DESIGN & IMPLEMENTATION

## Project

Continue developing the new **Restaurant Billing System** created in PHASE 1.

The project uses:

- Java 21
- Java Swing
- MySQL 8.x
- JDBC
- Maven
- IntelliJ IDEA
- MVC + DAO architecture

The master project specification is:

`Restaurant_Billing_System_Complete_Documentation.md`

Treat that documentation as the project's source of truth.

---

# 1. PHASE 2 OBJECTIVE

Implement the complete MySQL database for the Restaurant Billing System.

At the end of this phase:

1. MySQL database must exist.
2. All core tables must be created.
3. Primary keys must be defined.
4. Foreign keys must be defined.
5. Relationships must be correct.
6. Appropriate constraints must be added.
7. Appropriate indexes must be added.
8. Sample data must be available.
9. `schema.sql` must be executable.
10. `sample_data.sql` must be executable.
11. Database design must support all future application modules.
12. The database must be tested independently before moving to JDBC implementation.

Do NOT implement the complete GUI in this phase.

Do NOT implement the complete billing UI in this phase.

Do NOT move to PHASE 3 automatically.

---

# 2. DATABASE NAME

Use:

```text
restaurant_billing
```

Database creation:

```sql
CREATE DATABASE IF NOT EXISTS restaurant_billing;
USE restaurant_billing;
```

Use a suitable character set and collation, preferably:

```text
utf8mb4
```

---

# 3. CORE TABLES

Create the following tables:

```text
users
food_items
customers
orders
order_items
bills
```

These tables must support:

```text
Authentication
Menu Management
Customer Management
Order Management
Billing
Bill History
Reports
```

Do not create unnecessary tables that are not required by the documented scope.

---

# 4. USERS TABLE

Purpose:

Store application login accounts and their roles.

Recommended structure:

```text
users
--------------------------------
id
username
password
role
created_at
updated_at
```

Requirements:

- `id` must be the primary key.
- Username must be unique.
- Username must not be NULL.
- Password must not be NULL.
- Role must not be NULL.
- Role should support at least:
  - ADMIN
  - STAFF
- Add timestamps where appropriate.

Use suitable VARCHAR lengths.

Do not hardcode a plaintext production password into Java source code.

For this development phase, sample credentials may be inserted into `sample_data.sql`, but clearly identify them as development/demo credentials.

---

# 5. FOOD_ITEMS TABLE

Purpose:

Store restaurant menu items.

Recommended structure:

```text
food_items
--------------------------------
id
name
category
price
available
created_at
updated_at
```

Requirements:

- `id` primary key.
- `name` required.
- `category` required.
- `price` required.
- Price must be greater than zero.
- `available` should have a sensible default such as TRUE.
- Add indexes for frequently searched fields where appropriate.

Suggested categories:

```text
Starter
Main Course
Bread
Rice
Beverage
Dessert
```

Do not create a separate category table in this phase unless the master requirements specifically require it.

---

# 6. CUSTOMERS TABLE

Purpose:

Store customer information.

Recommended structure:

```text
customers
--------------------------------
id
name
phone
email
created_at
updated_at
```

Requirements:

- `id` primary key.
- `name` required.
- `phone` should be stored as VARCHAR, not INT.
- Email can be optional.
- Add an index on phone.
- Do not unnecessarily make email unique unless the application requirements demand it.

A customer should be able to have multiple orders.

Relationship:

```text
customers 1 ---- N orders
```

---

# 7. ORDERS TABLE

Purpose:

Store the main order transaction.

Recommended structure:

```text
orders
--------------------------------
id
customer_id
order_date
subtotal
discount
tax
total
status
created_at
updated_at
```

Requirements:

- `id` primary key.
- `customer_id` foreign key to `customers.id`.
- `order_date` required.
- Monetary fields should use `DECIMAL`, never FLOAT.
- `subtotal` must not be negative.
- `discount` must not be negative.
- `tax` must not be negative.
- `total` must not be negative.
- Add an appropriate order status.

Suggested statuses:

```text
PENDING
CONFIRMED
COMPLETED
CANCELLED
```

Use sensible defaults where appropriate.

Relationship:

```text
customers 1 ---- N orders
```

---

# 8. ORDER_ITEMS TABLE

Purpose:

Store the individual food items inside an order.

Recommended structure:

```text
order_items
--------------------------------
id
order_id
food_item_id
quantity
price
item_total
created_at
```

Requirements:

- `id` primary key.
- `order_id` foreign key to `orders.id`.
- `food_item_id` foreign key to `food_items.id`.
- Quantity must be greater than zero.
- Price must not be negative.
- Item total must not be negative.

Important:

Store the actual price charged at the time of purchase in the `price` column.

Do NOT depend only on the current price in `food_items`.

Reason:

If a food item costs ₹150 today and ₹180 next month, old bills must still show the original purchase price.

Formula:

```text
item_total = price × quantity
```

Relationships:

```text
orders 1 ---- N order_items

food_items 1 ---- N order_items
```

---

# 9. BILLS TABLE

Purpose:

Store the final billing information.

Recommended structure:

```text
bills
--------------------------------
id
order_id
bill_number
subtotal
discount
tax
final_amount
payment_method
payment_status
bill_date
created_at
```

Requirements:

- `id` primary key.
- `order_id` foreign key to `orders.id`.
- `bill_number` must be unique.
- `subtotal` must not be negative.
- `discount` must not be negative.
- `tax` must not be negative.
- `final_amount` must not be negative.
- Payment method should support common options.
- Payment status should support basic payment states.

Suggested payment methods:

```text
CASH
CARD
UPI
OTHER
```

Suggested payment statuses:

```text
PENDING
PAID
CANCELLED
```

Relationship:

```text
orders 1 ---- 1 bills
```

If the design enforces one bill per order, make `order_id` unique.

---

# 10. DATABASE RELATIONSHIP

The final database should follow:

```text
USERS
  |
  | authentication only
  |
  +-----------------------------------+

CUSTOMERS
    |
    | 1:N
    v
  ORDERS
    |
    | 1:N
    v
ORDER_ITEMS
    ^
    |
    | N:1
    |
FOOD_ITEMS

ORDERS
    |
    | 1:1
    v
  BILLS
```

Detailed relationships:

```text
customers.id
      |
      +---- orders.customer_id

orders.id
      |
      +---- order_items.order_id
      |
      +---- bills.order_id

food_items.id
      |
      +---- order_items.food_item_id
```

---

# 11. FOREIGN KEY RULES

Use proper foreign keys.

Recommended behavior:

### Customer → Orders

Do not automatically delete historical orders when a customer is deleted.

Prefer a safe strategy such as:

```text
RESTRICT
```

or another approach consistent with preserving historical billing data.

### Orders → Order Items

When an order is deleted, its order items may be deleted with it if the application design permits deletion.

A suitable approach may be:

```text
ON DELETE CASCADE
```

### Orders → Bills

Do not allow accidental deletion of an order that has a bill.

Use a safe referential strategy.

### Food Items → Order Items

Do not delete historical order information simply because a menu item is removed.

Prefer soft deletion through:

```text
available = FALSE
```

instead of physically deleting a food item that has historical references.

---

# 12. MONETARY DATA TYPES

This is important.

For all money-related fields, use:

```sql
DECIMAL(10,2)
```

or an appropriate larger precision if required.

Do NOT use:

```text
FLOAT
DOUBLE
```

for billing amounts.

Money fields include:

```text
food_items.price
orders.subtotal
orders.discount
orders.tax
orders.total
order_items.price
order_items.item_total
bills.subtotal
bills.discount
bills.tax
bills.final_amount
```

---

# 13. CONSTRAINTS

Use appropriate constraints.

Examples:

```text
PRIMARY KEY
FOREIGN KEY
NOT NULL
UNIQUE
DEFAULT
CHECK
```

Where supported and appropriate, add checks such as:

```text
price > 0
quantity > 0
subtotal >= 0
discount >= 0
tax >= 0
total >= 0
```

Do not rely entirely on database constraints for validation; Java validation will also be implemented in later phases.

---

# 14. INDEXING

Create indexes where they will improve common operations.

Recommended candidates:

```text
users.username
food_items.name
food_items.category
customers.phone
orders.customer_id
orders.order_date
order_items.order_id
order_items.food_item_id
bills.bill_number
bills.order_id
bills.bill_date
```

Do not create excessive indexes unnecessarily.

---

# 15. BILL NUMBER

Bill numbers must be unique.

Example format:

```text
BILL-2026-000001
BILL-2026-000002
BILL-2026-000003
```

The database should enforce uniqueness.

The final bill-number generation strategy can be implemented in the Java service layer in a later phase.

Do not make the database design dependent on a hardcoded bill number.

---

# 16. SAMPLE DATA

Create realistic sample data in:

```text
database/sample_data.sql
```

Include at least:

### Users

At least:

```text
1 ADMIN
1 STAFF
```

### Food Items

At least 10 realistic restaurant items covering multiple categories.

Example categories:

```text
Starters
Main Course
Bread
Rice
Beverages
Desserts
```

### Customers

At least 5 sample customers.

### Orders

Create several realistic sample orders.

### Order Items

Each sample order should contain multiple items where appropriate.

### Bills

Create corresponding bills for completed sample orders.

Ensure all foreign-key relationships are valid.

---

# 17. SAMPLE FOOD DATA

Use realistic examples such as:

```text
Paneer Tikka
Veg Spring Roll
Paneer Butter Masala
Dal Tadka
Veg Biryani
Butter Naan
Tandoori Roti
Cold Coffee
Fresh Lime Soda
Gulab Jamun
```

Use reasonable sample prices.

Do not use fictional invalid numeric values.

---

# 18. DATABASE SCRIPT ORDER

`schema.sql` should execute in the correct dependency order.

Recommended:

```text
1. CREATE DATABASE
2. USE DATABASE
3. CREATE users
4. CREATE food_items
5. CREATE customers
6. CREATE orders
7. CREATE order_items
8. CREATE bills
9. CREATE indexes/constraints if needed
```

`sample_data.sql` should execute only after the schema exists.

---

# 19. SQL SCRIPT QUALITY

The SQL files must:

- Be readable.
- Be properly formatted.
- Use comments for major sections.
- Be safe to execute on a fresh database.
- Avoid duplicate sample data where practical.
- Respect foreign-key dependencies.
- Avoid invalid SQL.
- Use explicit column lists for INSERT statements.

Example:

```sql
INSERT INTO food_items
    (name, category, price, available)
VALUES
    ('Paneer Tikka', 'Starter', 180.00, TRUE);
```

---

# 20. DATABASE TESTING

After creating the database, execute tests manually using MySQL.

Verify:

```sql
SHOW DATABASES;
USE restaurant_billing;
SHOW TABLES;
```

Check table structures:

```sql
DESCRIBE users;
DESCRIBE food_items;
DESCRIBE customers;
DESCRIBE orders;
DESCRIBE order_items;
DESCRIBE bills;
```

Verify relationships using:

```sql
SHOW CREATE TABLE orders;
SHOW CREATE TABLE order_items;
SHOW CREATE TABLE bills;
```

---

# 21. CRUD TESTING

Test at least:

## Users

```text
INSERT
SELECT
```

## Food Items

```text
INSERT
SELECT
UPDATE
DELETE/availability update
```

## Customers

```text
INSERT
SELECT
UPDATE
DELETE
```

## Orders

```text
INSERT
SELECT
```

## Order Items

```text
INSERT
SELECT
```

## Bills

```text
INSERT
SELECT
```

---

# 22. RELATIONSHIP TESTING

Test that an order cannot reference a nonexistent customer.

Test that an order item cannot reference a nonexistent order.

Test that an order item cannot reference a nonexistent food item.

Test that a bill cannot reference a nonexistent order.

Test the one-bill-per-order rule if implemented.

---

# 23. HISTORICAL DATA PROTECTION

This is an important design requirement.

The system must preserve historical billing information.

For example:

```text
Food Item:
Paneer Tikka

Current Price:
₹200
```

An old order may have:

```text
Price at purchase:
₹180
```

The old bill must continue to show:

```text
₹180
```

Therefore:

```text
order_items.price
```

must store the price charged at the time of purchase.

Do not calculate old bills using the current `food_items.price`.

---

# 24. DATABASE NORMALIZATION

Design the database to avoid unnecessary duplication.

Important principles:

- Food information belongs in `food_items`.
- Customer information belongs in `customers`.
- Order header information belongs in `orders`.
- Individual ordered products belong in `order_items`.
- Final billing information belongs in `bills`.
- Authentication information belongs in `users`.

Do not store a complete list of food names in a single column such as:

```text
"Paneer Tikka, Biryani, Coffee"
```

Use normalized `order_items` records instead.

---

# 25. DATABASE SECURITY

Do not commit real credentials.

The database scripts should not contain personal or production passwords.

Development sample credentials may be used for demonstration, but clearly label them as demo credentials.

Future Java implementation should use:

```text
PreparedStatement
```

for SQL queries.

---

# 26. DO NOT IMPLEMENT YET

Do NOT implement these features in Phase 2:

```text
Login GUI
Dashboard GUI
Menu GUI
Customer GUI
Order GUI
Billing GUI
Reports GUI
Animations
Final UI design
```

These belong to later phases.

The only goal is to make the database complete and reliable.

---

# 27. FILES TO CREATE/UPDATE

At minimum:

```text
database/schema.sql
database/sample_data.sql
```

If necessary, update:

```text
README.md
```

to show:

```text
Current Status: PHASE 2 — Database Implementation
```

Do not unnecessarily modify Java application files.

---

# 28. DATABASE VALIDATION CHECKLIST

Before completing Phase 2:

```text
[ ] restaurant_billing database created
[ ] users table created
[ ] food_items table created
[ ] customers table created
[ ] orders table created
[ ] order_items table created
[ ] bills table created

[ ] Primary keys verified
[ ] Foreign keys verified
[ ] Unique constraints verified
[ ] NOT NULL constraints verified
[ ] CHECK constraints verified where appropriate
[ ] Default values verified
[ ] Indexes verified

[ ] Money fields use DECIMAL
[ ] Quantity validation exists
[ ] Historical item price stored
[ ] Bill number unique
[ ] Order/bill relationship correct

[ ] Sample users inserted
[ ] Sample food items inserted
[ ] Sample customers inserted
[ ] Sample orders inserted
[ ] Sample order items inserted
[ ] Sample bills inserted

[ ] CRUD SQL tested
[ ] Foreign-key behavior tested
[ ] Database scripts execute successfully
[ ] No SQL errors
```

---

# 29. IMPORTANT QUALITY REQUIREMENT

Do not simply create tables because they exist in the documentation.

Think about how the Java application will use them in later phases.

The database must support:

```text
Login
    ↓
Menu
    ↓
Customer
    ↓
Order
    ↓
Order Items
    ↓
Billing
    ↓
Bill History
    ↓
Reports
```

The database should be stable enough that later Java modules can be built without redesigning the entire schema.

---

# 30. FINAL PHASE 2 REPORT

After completing the implementation, provide:

## Database

```text
Database Name:
restaurant_billing
```

## Tables

List all tables.

## Relationships

Explain every foreign-key relationship.

## SQL Files

List:

```text
database/schema.sql
database/sample_data.sql
```

## Sample Data

Report how many records were inserted into each table.

## Validation

Report whether:

```text
Schema execution: PASS/FAIL
Sample data execution: PASS/FAIL
CRUD testing: PASS/FAIL
Relationship testing: PASS/FAIL
Constraint testing: PASS/FAIL
```

## Problems

List any unresolved issues.

## Next Phase

If everything passes, report:

```text
PHASE 2 COMPLETE

NEXT:
PHASE 3 — JDBC Database Connectivity
```

Do NOT start PHASE 3 automatically.

Wait for explicit approval.