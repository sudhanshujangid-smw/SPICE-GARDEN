# PHASE 3 — JDBC DATABASE CONNECTIVITY

## Project

Continue developing the new **Restaurant Billing System**.

Completed phases:

- PHASE 1 — Project Setup & Foundation
- PHASE 2 — MySQL Database Design & Implementation

Current phase:

- PHASE 3 — JDBC Database Connectivity

Technology stack:

- Java 21
- Java Swing
- MySQL 8.x
- JDBC
- Maven
- IntelliJ IDEA
- MVC + DAO architecture

The master project specification is:

`Restaurant_Billing_System_Complete_Documentation.md`

Treat it as the source of truth.

---

# 1. PHASE 3 OBJECTIVE

Connect the Java application to the MySQL database created in PHASE 2.

At the end of this phase:

```text
Java Application
       ↓
DatabaseConnection
       ↓
JDBC
       ↓
MySQL Server
       ↓
restaurant_billing
```

The connection must be tested successfully before Phase 3 is considered complete.

---

# 2. IMPORTANT RULES

Do NOT redesign the database created in PHASE 2 unless a genuine compatibility problem is discovered.

Do NOT implement the login system yet.

Do NOT implement the dashboard yet.

Do NOT implement menu management yet.

Do NOT implement billing yet.

Do NOT create DAO CRUD implementations yet except small connectivity tests required to verify the connection.

The main goal is a clean, reusable JDBC connection layer.

---

# 3. DATABASE CONFIGURATION

The application must connect to:

```text
Database:
restaurant_billing

Host:
localhost

Port:
3306
```

The final JDBC URL should follow this pattern:

```text
jdbc:mysql://localhost:3306/restaurant_billing
```

Use the actual database username and password configured on the developer's machine.

Do NOT hardcode real credentials throughout the Java source code.

---

# 4. CONFIGURATION MANAGEMENT

Create a centralized configuration mechanism.

Preferred structure:

```text
src/main/resources/
└── db.properties
```

The configuration should contain values conceptually similar to:

```properties
db.url=jdbc:mysql://localhost:3306/restaurant_billing
db.username=YOUR_USERNAME
db.password=YOUR_PASSWORD
```

Do not commit real passwords to GitHub.

If a local configuration file contains credentials, ensure it is excluded from Git where appropriate.

Provide a safe example configuration if useful:

```text
db.properties.example
```

containing placeholders rather than real credentials.

---

# 5. DATABASE CONNECTION CLASS

Create:

```text
database/
└── DatabaseConnection.java
```

Responsibilities:

1. Load database configuration.
2. Load the MySQL JDBC driver if required by the chosen JDBC setup.
3. Create a JDBC connection.
4. Return the connection to callers.
5. Handle SQL exceptions properly.
6. Provide clean error information.
7. Avoid duplicate connection logic throughout the application.

Recommended conceptual API:

```java
getConnection()
```

The exact implementation is up to the project's architecture.

---

# 6. CONNECTION MANAGEMENT

Use proper JDBC resource management.

For queries/statements/results, prefer:

```java
try-with-resources
```

Do not leave:

```text
Connection
Statement
PreparedStatement
ResultSet
```

open unnecessarily.

Avoid memory/resource leaks.

---

# 7. MYSQL JDBC DRIVER

Verify that the Maven project contains the appropriate MySQL Connector/J dependency.

Do not manually copy random JDBC JAR files into the project if Maven can manage the dependency.

After adding/updating the dependency:

```text
Maven reload
       ↓
Compile
       ↓
Run
```

must work correctly.

---

# 8. CONNECTION TEST

Create a small test mechanism.

It may be:

```text
DatabaseConnectionTest
```

or a controlled test in the application startup during this phase.

The test should:

1. Attempt connection.
2. Verify that the connection is not null.
3. Verify the database name.
4. Optionally execute a simple query.
5. Close resources correctly.

Example test query:

```sql
SELECT 1;
```

You may also verify:

```sql
SELECT DATABASE();
```

Expected database:

```text
restaurant_billing
```

---

# 9. TEST DATABASE METADATA

As part of the connectivity test, verify that Java can communicate with the expected MySQL database.

A successful test should be able to retrieve information such as:

```text
Database:
restaurant_billing

Connection:
SUCCESS

JDBC:
SUCCESS

MySQL:
CONNECTED
```

Do not expose database passwords in logs.

---

# 10. ERROR HANDLING

Handle common database problems gracefully.

Examples:

### MySQL server unavailable

Display/log:

```text
Unable to connect to MySQL.
Please verify that the MySQL server is running.
```

### Incorrect credentials

Display/log:

```text
Database authentication failed.
Please verify the configured database credentials.
```

### Database does not exist

Display/log:

```text
Database 'restaurant_billing' was not found.
Please execute the database setup scripts.
```

### JDBC driver missing

Display/log:

```text
MySQL JDBC driver is unavailable.
Please verify the Maven dependency.
```

Do not expose raw passwords or sensitive configuration.

---

# 11. CUSTOM DATABASE EXCEPTION

If useful, create:

```text
exception/
└── DatabaseException.java
```

This can provide a clean application-level exception instead of exposing low-level SQL details throughout the GUI and service layers.

Do not over-engineer the exception system.

---

# 12. LOGGING

Use a simple and maintainable logging approach.

For development, meaningful messages are acceptable.

Examples:

```text
INFO  Database connection established.
INFO  Database connection closed.
ERROR Database connection failed.
```

Never log:

```text
Database password
```

or other sensitive credentials.

If a logging dependency is not necessary at this stage, avoid adding one unnecessarily.

---

# 13. CONNECTION TEST THROUGH MAIN APPLICATION

After implementing the connection layer, make sure the application can run the connectivity test.

The flow can temporarily be:

```text
Main
  ↓
DatabaseConnection
  ↓
MySQL
  ↓
Connection Test
  ↓
Swing Test Window / Console Result
```

This is only a Phase 3 verification mechanism.

Do not turn this into the final application startup workflow.

---

# 14. DO NOT USE A SINGLE GLOBAL CONNECTION

Do not create a permanently open static connection such as:

```text
one connection kept open forever
```

The architecture should allow safe connection creation and closure.

If a connection-pooling mechanism is considered later, it must be justified by actual project requirements.

For the current desktop application, keep the implementation simple and reliable.

---

# 15. JDBC PREPARED STATEMENT FOUNDATION

Although full DAO implementation belongs to later phases, prepare the project to use:

```text
PreparedStatement
```

for parameterized SQL.

Do not construct SQL queries by directly concatenating user input.

Avoid patterns such as:

```text
"SELECT * FROM users WHERE username = '" + username + "'"
```

Future DAO classes must use parameterized queries.

---

# 16. DATABASE LAYER STRUCTURE

The final structure after this phase should be similar to:

```text
src/
└── main/
    ├── java/
    │   └── com/
    │       └── restaurantbilling/
    │           │
    │           ├── Main.java
    │           │
    │           ├── database/
    │           │   └── DatabaseConnection.java
    │           │
    │           ├── exception/
    │           │   └── DatabaseException.java
    │           │
    │           ├── model/
    │           ├── dao/
    │           ├── service/
    │           ├── gui/
    │           └── util/
    │
    └── resources/
        ├── db.properties
        └── db.properties.example
```

Only create files that are actually required.

---

# 17. DATABASE CONNECTION VALIDATION

The Java test must verify:

```text
[ ] MySQL driver available
[ ] Connection URL valid
[ ] Username valid
[ ] Password valid
[ ] MySQL server reachable
[ ] restaurant_billing exists
[ ] Connection successfully established
[ ] SELECT 1 succeeds
[ ] SELECT DATABASE() returns restaurant_billing
[ ] Resources are closed
```

---

# 18. MAVEN VALIDATION

Run a clean Maven build.

The project must successfully pass the equivalent of:

```text
mvn clean compile
```

If tests are implemented:

```text
mvn test
```

must also be executed.

Fix all compilation errors before declaring Phase 3 complete.

---

# 19. INTELLIJ VALIDATION

Verify:

1. Project opens correctly.
2. Maven dependencies resolve.
3. Java 21 is selected.
4. Resources are recognized.
5. `db.properties` is loaded correctly.
6. Main application runs.
7. JDBC connection succeeds.

Do not assume that a Maven build succeeding automatically means the runtime database connection works.

Both must be tested.

---

# 20. GIT SECURITY

Before completing the phase, check that sensitive database credentials are not committed.

Recommended:

```text
db.properties
```

should be ignored if it contains real credentials.

Provide:

```text
db.properties.example
```

with placeholders:

```properties
db.url=jdbc:mysql://localhost:3306/restaurant_billing
db.username=YOUR_USERNAME
db.password=YOUR_PASSWORD
```

The README should explain how the developer creates the local configuration.

---

# 21. README UPDATE

Update:

```text
README.md
```

with a database setup section.

Include:

```text
1. Install MySQL.
2. Start MySQL Server.
3. Create restaurant_billing database using schema.sql.
4. Execute sample_data.sql.
5. Configure local db.properties.
6. Run the Java application.
```

Clearly state:

```text
Current Status:
PHASE 3 — JDBC Database Connectivity
```

---

# 22. PHASE 3 TEST SCENARIOS

Test at least the following:

### Test 1 — Correct configuration

Expected:

```text
PASS
Connection established.
```

### Test 2 — MySQL stopped

Expected:

```text
FAIL gracefully
No application crash.
Meaningful error.
```

### Test 3 — Incorrect password

Expected:

```text
FAIL gracefully
Authentication error.
```

### Test 4 — Incorrect database name

Expected:

```text
FAIL gracefully
Database not found.
```

### Test 5 — SELECT 1

Expected:

```text
PASS
```

### Test 6 — SELECT DATABASE()

Expected:

```text
restaurant_billing
```

### Test 7 — Resource cleanup

Expected:

```text
Connection/resources closed correctly.
```

---

# 23. IMPORTANT: DO NOT MODIFY PHASE 2 DATABASE UNNECESSARILY

The Phase 2 schema is already the foundation for:

```text
users
food_items
customers
orders
order_items
bills
```

Do not change table names, relationships, or columns merely for convenience.

If a real issue is discovered:

1. Identify the issue.
2. Explain why it is necessary.
3. Make the smallest safe modification.
4. Update `schema.sql`.
5. Update `sample_data.sql` if necessary.
6. Retest the database.

---

# 24. CODE QUALITY

Follow these rules:

- Java 21.
- Clear class names.
- Clear method names.
- Small focused methods.
- No duplicated connection code.
- No hardcoded credentials.
- No SQL injection vulnerabilities.
- Proper exception handling.
- Proper resource management.
- No unnecessary dependencies.
- No unnecessary static state.
- Keep the database layer independent from Swing GUI code.

---

# 25. PHASE 3 SUCCESS CRITERIA

Phase 3 is complete only when all of these are true:

```text
[ ] MySQL JDBC dependency works
[ ] db.properties configuration works
[ ] DatabaseConnection.java works
[ ] Java connects to MySQL
[ ] restaurant_billing is detected
[ ] SELECT 1 succeeds
[ ] Database metadata can be read
[ ] Connection failures are handled
[ ] Resources are properly closed
[ ] No passwords appear in logs
[ ] No credentials committed to Git
[ ] Maven compilation succeeds
[ ] IntelliJ execution succeeds
[ ] Database connection test succeeds
```

---

# 26. REQUIRED FINAL REPORT

After completing the phase, provide a report containing:

## A. Files Created

List all new/modified files.

## B. Maven Dependencies

List the MySQL JDBC dependency.

## C. Database Configuration

Show the configuration structure without revealing real passwords.

## D. Connection Architecture

Show:

```text
Java
 ↓
DatabaseConnection
 ↓
JDBC Driver
 ↓
MySQL
 ↓
restaurant_billing
```

## E. Tests

Report:

```text
JDBC Driver Test: PASS/FAIL
Database Connection: PASS/FAIL
SELECT 1: PASS/FAIL
Database Name Check: PASS/FAIL
Resource Cleanup: PASS/FAIL
Maven Compile: PASS/FAIL
Application Run: PASS/FAIL
```

## F. Problems

List unresolved problems, if any.

## G. Final Status

If everything passes:

```text
PHASE 3 COMPLETE

NEXT:
PHASE 4 — Model Classes & DAO Foundation
```

Do NOT automatically start Phase 4.

Wait for explicit approval.