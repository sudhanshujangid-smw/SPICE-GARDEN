# PHASE 8 — CUSTOMER MANAGEMENT & CUSTOMER CRUD

## Project

Continue developing the new **Restaurant Billing System**.

Completed phases:

- PHASE 1 — Project Setup & Foundation
- PHASE 2 — MySQL Database Design & Implementation
- PHASE 3 — JDBC Database Connectivity
- PHASE 4 — Model Classes & DAO Foundation
- PHASE 5 — Authentication & Login System
- PHASE 6 — Main Dashboard & Application Navigation
- PHASE 7 — Menu Management & Food Item CRUD

Current phase:

- PHASE 8 — Customer Management & Customer CRUD

Technology:

- Java 21
- Java Swing
- MySQL 8.x
- JDBC
- Maven
- IntelliJ IDEA
- MVC + DAO architecture

Master documentation:

`Restaurant_Billing_System_Complete_Documentation.md`

Treat the existing documentation and existing database schema as the source of truth.

---

# 1. PHASE 8 OBJECTIVE

Implement a complete Customer Management module.

The module must allow authorized users to:

- Add customers
- View customers
- Search customers
- Update customers
- Delete/deactivate customers where appropriate
- Filter customers
- View customer details
- Select customers later during order creation

Main architecture:

CustomerManagementPanel
        ↓
CustomerService
        ↓
CustomerDAO
        ↓
CustomerDAOImpl
        ↓
DatabaseConnection
        ↓
MySQL

Do NOT implement Orders or Billing in this phase.

---

# 2. IMPORTANT DATABASE RULE

Use the existing customer table from Phase 2.

Do NOT:

- create another customer table
- rename the existing table without necessity
- duplicate customer data
- create a separate database

The Java model must match the actual MySQL schema.

If the schema contains additional customer fields, preserve them.

---

# 3. CUSTOMER INFORMATION

Use the fields already defined in the database.

Typical fields may include:

Customer ID
Name
Phone
Email
Address
Created Date
Updated Date
Status

If the actual schema differs, follow the actual schema instead of inventing fields.

---

# 4. CUSTOMER MANAGEMENT UI

Replace the Phase 6 customer placeholder with a functional:

CustomerManagementPanel

Recommended layout:

+-------------------------------------------------------------+
| CUSTOMER MANAGEMENT                                         |
+-------------------------------------------------------------+
| Search [________________]  Status [All ▼]                  |
|                                                             |
| [ Add Customer ] [ Clear Filters ]                         |
+-------------------------------------------------------------+
| ID | Name | Phone | Email | Status | Actions               |
|----|------|-------|-------|--------|----------------------|
| 1  | ...  | ...   | ...   | Active | Edit | Delete         |
| 2  | ...  | ...   | ...   | Active | Edit | Delete         |
+-------------------------------------------------------------+

Use JTable.

---

# 5. CUSTOMER TABLE

Display appropriate fields.

Recommended:

ID
Name
Phone
Email
Status
Actions

Do not display unnecessary sensitive information.

Use a clean and readable table.

---

# 6. ADD CUSTOMER

Create a reusable customer form/dialog.

Suggested fields:

Customer Name
Phone Number
Email
Address
Status

Buttons:

[SAVE]
[CLEAR]
[CANCEL]

Use the actual database fields.

---

# 7. CUSTOMER VALIDATION

Validate all input before database operations.

## Name

Required.

Example error:

Customer name is required.

Do not allow only whitespace.

---

## Phone

Validate according to the application's requirements.

For Indian restaurant usage, support normal Indian mobile formats such as:

10-digit mobile numbers.

Do not make validation unnecessarily restrictive if the project needs international customers.

---

## Email

If email is optional:

- empty email → allowed
- provided email → validate basic email format

Example:

customer@example.com

Do not use an excessively complicated regex.

---

## Address

If required by the schema/business rules:

Validate that it is not empty.

If optional:

Allow empty address.

---

# 8. CUSTOMER SERVICE

Create:

service/CustomerService.java

Responsibilities:

- Validate customer data
- Add customer
- Retrieve customers
- Search customers
- Update customers
- Deactivate customers
- Delete customers when safe
- Retrieve customer by ID

Conceptual methods:

addCustomer()
getAllCustomers()
getCustomerById()
searchCustomers()
updateCustomer()
deleteCustomer()
setCustomerStatus()

The GUI should not directly call SQL.

---

# 9. CUSTOMER DAO

Reuse:

CustomerDAO

and:

CustomerDAOImpl

created during previous phases.

If the DAO methods are incomplete, complete them instead of creating duplicate DAO classes.

Recommended operations:

findAll()
findById()
search()
save()
update()
delete()
updateStatus()

Use PreparedStatement for every parameterized operation.

---

# 10. ADD CUSTOMER FLOW

When SAVE is clicked:

Validate
    ↓
Create Customer object
    ↓
CustomerService
    ↓
CustomerDAO
    ↓
MySQL
    ↓
Success
    ↓
Refresh JTable
    ↓
Clear form

Do not execute SQL directly from the Swing panel.

---

# 11. DUPLICATE CUSTOMER CHECK

Before creating a customer, check whether duplicate information already exists when appropriate.

For example:

Phone number may be unique depending on the database design.

If the schema has a unique constraint, respect it.

If a duplicate occurs:

Display:

Customer already exists or the provided phone number is already registered.

Do not crash the application.

Do not create duplicate records automatically.

---

# 12. EDIT CUSTOMER

Provide an Edit action.

Flow:

Select customer
    ↓
Edit
    ↓
Load existing data
    ↓
Display form
    ↓
Modify
    ↓
Validate
    ↓
Update
    ↓
Refresh table

Customer ID must remain unchanged.

---

# 13. DELETE CUSTOMER

Customer deletion must be handled carefully.

Customers may later be referenced by:

- Orders
- Bills
- Payments

Therefore:

DO NOT blindly physically delete customers if foreign-key relationships exist.

Prefer:

Active
Inactive

status/deactivation when required.

If physical deletion is safe according to the database schema, it may be allowed.

Follow the existing database design.

---

# 14. CUSTOMER STATUS

Support status if present in the schema.

Recommended:

Active
Inactive

Actions:

[Deactivate]

and:

[Activate]

An inactive customer should remain available for historical records but may be restricted from new orders according to business rules.

---

# 15. SEARCH

Implement customer search.

Search should support:

Name
Phone
Email

Example:

Search:

rahul

Possible results:

Rahul Sharma
Rahul Verma

Search should use parameterized SQL.

Do not concatenate search text into SQL.

---

# 16. SEARCH PERFORMANCE

Do not unnecessarily reload the entire customer database for every character typed.

For small datasets, controlled filtering is acceptable.

For larger datasets, use database-side search.

Use:

LIKE ?

with PreparedStatement.

---

# 17. STATUS FILTER

Add:

Status [All ▼]

Options:

All
Active
Inactive

Filtering should update the customer table.

---

# 18. COMBINED SEARCH + FILTER

Support:

Search + Status

Example:

Search:

rahul

Status:

Active

Expected:

Only active customers matching "rahul".

---

# 19. CLEAR FILTERS

Provide:

[ Clear Filters ]

Behavior:

Search → empty
Status → All
Table → all customers

---

# 20. CUSTOMER DETAILS

Allow the user to select a customer and view details.

Possible:

Double-click customer row

or:

[View]

Show:

Customer ID
Name
Phone
Email
Address
Status
Created Date

Do not expose unnecessary internal information.

---

# 21. CUSTOMER FORM

Prefer one reusable:

CustomerDialog

for both:

ADD
EDIT

Conceptually:

CustomerManagementPanel
        ↓
CustomerDialog
        ↓
CustomerService

Avoid duplicating the same form code twice.

---

# 22. TABLE ACTIONS

Recommended:

[View]
[Edit]
[Deactivate/Activate]

Delete should only be provided if safe and permitted.

Do not overload the table with too many buttons.

---

# 23. ROLE-BASED ACCESS

Use:

UserSession

from Phase 5.

Follow the project's documented permissions.

Typical approach:

ADMIN:

Add
Edit
Deactivate
Delete if permitted
View
Search

STAFF:

View
Search
Select customer for future order operations

If the project's documentation specifies different permissions, follow the documentation.

---

# 24. AUTHORIZATION

Do not rely only on hiding GUI buttons.

Sensitive operations should also be protected at the service/business layer.

For example:

CustomerService.updateCustomer()

must not blindly assume that every user is authorized.

Use the existing authentication/session architecture.

---

# 25. CUSTOMER SELECTION PREPARATION

Prepare the module so future Order Management can select a customer.

Create a clean way to retrieve:

Customer ID
Customer Name
Phone

The future Order module should be able to use the selected customer without duplicating the customer database.

Do NOT implement order creation yet.

---

# 26. DATABASE OPERATIONS

Use parameterized SQL.

Example:

SELECT:

SELECT id, name, phone, email, address, status
FROM customers
WHERE name LIKE ?

Use:

PreparedStatement

Never:

"SELECT ... WHERE name LIKE '%" + search + "%'"

---

# 27. ERROR HANDLING

Database failure:

Unable to load customers.

Save failure:

Unable to save customer.

Update failure:

Unable to update customer.

Delete/deactivation failure:

Unable to update customer status.

Do not show raw SQL errors to normal users.

Technical details should be logged for developers.

---

# 28. SUCCESS MESSAGES

After successful operations:

Customer added successfully.

Customer updated successfully.

Customer status updated successfully.

Customer deleted successfully.

Keep messages concise.

---

# 29. EMPTY DATA

If there are no customers:

No customers found.

If search/filter produces no result:

No customers match the selected criteria.

Do not display a broken-looking empty JTable.

---

# 30. UI CONSISTENCY

The Customer Management screen must match:

Phase 6 Dashboard
Phase 7 Menu Management

Maintain:

- same colors
- same typography
- same spacing
- same buttons
- same table style
- same sidebar
- same top bar
- same navigation system

Do not create a separate visual theme.

---

# 31. PERFORMANCE

Customer operations must remain responsive.

Avoid unnecessary repeated database queries.

Do not block the Swing Event Dispatch Thread for long-running operations.

Use SwingWorker where appropriate.

After background operations:

Update Swing components safely on the EDT.

---

# 32. PROJECT STRUCTURE AFTER PHASE 8

Relevant structure:

src/
└── main/
    ├── java/
    │   └── com/
    │       └── restaurantbilling/
    │           │
    │           ├── model/
    │           │   └── Customer.java
    │           │
    │           ├── dao/
    │           │   ├── CustomerDAO.java
    │           │   └── impl/
    │           │       └── CustomerDAOImpl.java
    │           │
    │           ├── service/
    │           │   ├── AuthenticationService.java
    │           │   ├── FoodItemService.java
    │           │   └── CustomerService.java
    │           │
    │           ├── gui/
    │           │   ├── MainFrame.java
    │           │   │
    │           │   └── customer/
    │           │       ├── CustomerManagementPanel.java
    │           │       └── CustomerDialog.java
    │           │
    │           ├── database/
    │           │   └── DatabaseConnection.java
    │           │
    │           └── util/
    │               └── UserSession.java
    │
    └── resources/

Do not create unnecessary duplicate classes.

---

# 33. TESTING

Perform all of the following tests.

## Test 1 — Load Customers

Expected:

PASS

Customers load from MySQL.

---

## Test 2 — Add Customer

Example:

Name:
Rahul Sharma

Phone:
9876543210

Email:
rahul@example.com

Expected:

PASS

Customer inserted into MySQL.

---

## Test 3 — Edit Customer

Change:

Rahul Sharma
→
Rahul Kumar Sharma

Expected:

PASS

Database updated.

---

## Test 4 — Search by Name

Search:

Rahul

Expected:

PASS

Matching customers displayed.

---

## Test 5 — Search by Phone

Search:

9876543210

Expected:

PASS

Correct customer displayed.

---

## Test 6 — Search by Email

Search:

rahul@example.com

Expected:

PASS

Correct customer displayed.

---

## Test 7 — Status Filter

Select:

Active

Expected:

PASS

Only active customers displayed.

---

## Test 8 — Combined Search + Status

Search:

Rahul

Status:

Active

Expected:

PASS

Correct results.

---

## Test 9 — Clear Filters

Expected:

PASS

All customers displayed again.

---

## Test 10 — Invalid Email

Enter:

abc@

Expected:

PASS

Validation error.

---

## Test 11 — Invalid Phone

Enter an invalid phone number.

Expected:

PASS

Validation error according to project rules.

---

## Test 12 — Empty Name

Expected:

PASS

Customer is not saved.

---

## Test 13 — Duplicate Customer

Use an existing unique phone number if the database enforces uniqueness.

Expected:

PASS

Duplicate is handled gracefully.

---

## Test 14 — Deactivate Customer

Expected:

PASS

Status changes to Inactive.

---

## Test 15 — Activate Customer

Expected:

PASS

Status changes to Active.

---

## Test 16 — Role Restriction

Verify permissions for ADMIN and STAFF according to the documentation.

Expected:

PASS

Unauthorized operations are blocked.

---

# 34. DATABASE VALIDATION

After every important operation verify MySQL.

Example:

Add:

GUI
 ↓
CustomerService
 ↓
CustomerDAO
 ↓
MySQL
 ↓
SELECT
 ↓
Correct record

Do not rely only on the JTable.

---

# 35. SECURITY CHECKLIST

Verify:

[ ] PreparedStatement used
[ ] No SQL injection
[ ] No SQL directly in GUI
[ ] Database credentials hidden
[ ] Role restrictions applied
[ ] Unauthorized operations blocked
[ ] Raw SQL errors not shown
[ ] No unnecessary customer data exposed

---

# 36. PERFORMANCE CHECKLIST

Verify:

[ ] Customer list loads correctly
[ ] Search is responsive
[ ] Filtering is responsive
[ ] No duplicate rows
[ ] No duplicate event listeners
[ ] GUI does not freeze
[ ] No unnecessary database calls
[ ] Refresh works correctly

---

# 37. PHASE 8 SUCCESS CRITERIA

Phase 8 is complete only when:

[ ] Customer Management implemented
[ ] Customer table implemented
[ ] Add customer works
[ ] Edit customer works
[ ] View customer works
[ ] Search works
[ ] Status filter works
[ ] Combined filtering works
[ ] Clear filters works
[ ] Validation works
[ ] Duplicate handling works
[ ] Activate/deactivate works
[ ] Safe deletion handled
[ ] CustomerService implemented
[ ] CustomerDAO reused
[ ] MySQL synchronization verified
[ ] Role restrictions work
[ ] UI matches existing application
[ ] Maven build succeeds
[ ] Application runs successfully

---

# 38. DO NOT START PHASE 9

Do NOT implement:

- Order Management
- Order creation
- Cart
- Order items
- Table/order number management
- Billing

Those belong to the next functional phase.

Stop after Phase 8 validation.

---

# 39. REQUIRED FINAL REPORT

After completing implementation, provide:

## Files Created/Modified

List every file.

## Customer Architecture

Show:

CustomerManagementPanel
        ↓
CustomerService
        ↓
CustomerDAO
        ↓
CustomerDAOImpl
        ↓
DatabaseConnection
        ↓
MySQL

## Feature Test Results

Add:
PASS/FAIL

View:
PASS/FAIL

Edit:
PASS/FAIL

Search:
PASS/FAIL

Filter:
PASS/FAIL

Combined Filter:
PASS/FAIL

Activate:
PASS/FAIL

Deactivate:
PASS/FAIL

Delete:
PASS/FAIL

Validation:
PASS/FAIL

Role Restriction:
PASS/FAIL

Database:
PASS/FAIL

Maven Build:
PASS/FAIL

## Problems

List unresolved problems.

## Final Status

If all requirements pass:

PHASE 8 COMPLETE

NEXT:

PHASE 9 — Order Management & Order Creation

Do NOT automatically start Phase 9.

Wait for explicit approval.