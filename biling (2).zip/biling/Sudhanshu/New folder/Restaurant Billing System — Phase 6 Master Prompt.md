# PHASE 6 — MAIN DASHBOARD & APPLICATION NAVIGATION

## Project

Continue developing the new **Restaurant Billing System**.

Completed phases:

- PHASE 1 — Project Setup & Foundation
- PHASE 2 — MySQL Database Design & Implementation
- PHASE 3 — JDBC Database Connectivity
- PHASE 4 — Model Classes & DAO Foundation
- PHASE 5 — Authentication & Login System

Current phase:

- PHASE 6 — Main Dashboard & Application Navigation

Technology stack:

- Java 21
- Java Swing
- MySQL 8.x
- JDBC
- Maven
- IntelliJ IDEA
- MVC + DAO architecture

Master documentation:

`Restaurant_Billing_System_Complete_Documentation.md`

Treat the existing documentation, database schema, and completed phases as the source of truth.

---

# 1. PHASE 6 OBJECTIVE

Replace the temporary dashboard from Phase 5 with the proper main application dashboard.

The dashboard must act as the central navigation shell for the Restaurant Billing System.

Main flow:

```text
Login
  ↓
Authentication
  ↓
UserSession
  ↓
Main Dashboard
  ↓
Application Modules
```

The dashboard must be designed so that future modules can be plugged into it without rebuilding the entire application.

---

# 2. IMPORTANT RULES

Do NOT implement the complete restaurant modules in this phase.

Do NOT implement:

- Menu Management CRUD
- Customer Management CRUD
- Order Management
- Billing
- Payment Processing
- Reports
- Advanced Analytics

Only create the dashboard and navigation framework.

Use placeholders where future modules are required.

---

# 3. DASHBOARD ARCHITECTURE

Use a main window structure such as:

```text
MainFrame
│
├── Sidebar
│
├── TopBar
│
└── ContentPanel
       │
       └── Current Module
```

Conceptually:

```text
+------------------------------------------------------+
| Top Bar                         User | Role | Logout |
+-------------+----------------------------------------+
|             |                                        |
| Dashboard   |                                        |
| Menu        |                                        |
| Customers   |             Content Area               |
| Orders      |                                        |
| Billing     |                                        |
| Reports     |                                        |
|             |                                        |
| Settings    |                                        |
| Logout      |                                        |
+-------------+----------------------------------------+
```

---

# 4. MAIN FRAME

Create or replace the temporary dashboard with:

```text
gui/
└── MainFrame.java
```

Responsibilities:

- Display the application shell.
- Display logged-in user information.
- Provide navigation.
- Load modules into the content area.
- Handle logout.
- Maintain consistent application layout.

Do not place database queries directly inside `MainFrame`.

---

# 5. APPLICATION TITLE

Use:

```text
Restaurant Billing System
```

The window title should clearly identify the application.

---

# 6. SIDEBAR NAVIGATION

Create a professional sidebar.

Recommended navigation:

```text
Dashboard
Menu Management
Customers
Orders
Billing
Reports
Settings
```

At the bottom:

```text
Logout
```

Use icons only if they improve clarity.

Do not depend on external icon files unnecessarily.

---

# 7. TOP BAR

The top bar should display:

```text
Restaurant Billing System
```

and current user information:

```text
Username: <username>
Role: <role>
```

Also provide:

```text
Logout
```

or a user/profile menu.

---

# 8. USER SESSION INTEGRATION

Use:

```text
UserSession
```

created in Phase 5.

The dashboard must obtain:

```text
username
role
userId
```

from the current session.

Do NOT ask the database again simply to display the logged-in username.

---

# 9. CONTENT PANEL

Create a central content area:

```text
ContentPanel
```

When a sidebar item is selected, the corresponding module should appear inside this area.

Preferred Swing architecture:

```text
MainFrame
    ↓
JPanel contentPanel
    ↓
CardLayout
    ↓
Different module panels
```

Use `CardLayout` or an equally clean navigation mechanism.

Avoid opening dozens of separate JFrame windows.

---

# 10. DASHBOARD HOME PANEL

Create:

```text
gui/dashboard/
└── DashboardPanel.java
```

The dashboard home should contain summary cards.

Since actual database statistics belong to future phases, use controlled placeholders if necessary.

Example:

```text
+----------------+ +----------------+ +----------------+
| Today's Orders | | Today's Sales  | | Menu Items     |
|      --        | |      --        | |      --        |
+----------------+ +----------------+ +----------------+
```

Do not create fake database statistics that appear to be real.

Clearly keep placeholders until the relevant modules are implemented.

---

# 11. WELCOME SECTION

Dashboard should show:

```text
Welcome, <username>
```

and:

```text
Role: ADMIN
```

or:

```text
Role: STAFF
```

Use the current `UserSession`.

---

# 12. QUICK ACTIONS

Create placeholder quick-action buttons:

```text
New Order
Manage Menu
Customers
Generate Bill
```

These should either:

1. Navigate to the appropriate placeholder panel, or
2. Display a clear "Module coming in a future phase" message.

Do not implement the actual business functionality yet.

---

# 13. MODULE PLACEHOLDER PANELS

Create lightweight placeholder panels for future modules.

Recommended:

```text
gui/
├── dashboard/
│   └── DashboardPanel.java
│
├── menu/
│   └── MenuManagementPanel.java
│
├── customer/
│   └── CustomerManagementPanel.java
│
├── order/
│   └── OrderManagementPanel.java
│
├── billing/
│   └── BillingPanel.java
│
├── report/
│   └── ReportsPanel.java
│
└── settings/
    └── SettingsPanel.java
```

These panels do NOT need their final functionality yet.

Each placeholder should clearly identify its module.

Example:

```text
Menu Management

This module will be implemented in a future phase.
```

Do not display this message if the module already has partial functionality.

---

# 14. ROLE-BASED NAVIGATION

Use the authenticated user's role.

ADMIN should have access to administrative modules.

STAFF should have access to operational modules.

For example:

```text
ADMIN
├── Dashboard
├── Menu Management
├── Customers
├── Orders
├── Billing
├── Reports
└── Settings
```

STAFF may have:

```text
STAFF
├── Dashboard
├── Customers
├── Orders
└── Billing
```

Do not permanently assume this exact permission matrix if the master documentation specifies another one.

Use the project's documented requirements as the source of truth.

---

# 15. AUTHORIZATION

Navigation visibility and authorization should not be the same thing.

A hidden button is not sufficient security.

Prepare the architecture so future service/controller operations can also verify permissions.

Use the existing session/role mechanism.

Do not implement an unnecessarily complicated permission system in this phase.

---

# 16. LOGOUT

Logout must work from the main dashboard.

Flow:

```text
Logout
  ↓
Confirmation Dialog
  ↓
UserSession.logout()
  ↓
MainFrame closes
  ↓
LoginFrame opens
```

Use a confirmation message such as:

```text
Are you sure you want to logout?
```

Buttons:

```text
Yes
No
```

After logout:

```text
UserSession.isLoggedIn() == false
```

---

# 17. WINDOW MANAGEMENT

Avoid creating multiple instances of the dashboard.

Bad:

```text
Dashboard button
 ↓
new MainFrame()
```

every time the user clicks it.

Instead, maintain one main application frame.

Use panels inside the frame for module navigation.

---

# 18. GUI RESPONSIVENESS

The interface should remain responsive.

Avoid long-running database queries directly on the Swing Event Dispatch Thread.

Future database operations should use appropriate background processing.

Do not introduce unnecessary multithreading in this phase.

---

# 19. UI DESIGN

Use a modern professional restaurant management style.

Recommended:

- clean sidebar
- clear navigation hierarchy
- professional typography
- consistent spacing
- readable buttons
- clear active navigation state
- clean dashboard cards
- subtle hover effects
- appropriate borders and separators

Avoid excessive gradients, animations, or visual clutter.

The application should look like a professional desktop POS/restaurant management system.

---

# 20. RESPONSIVE WINDOW BEHAVIOR

The dashboard should support:

- maximized window
- resizing
- reasonable minimum size
- sidebar remaining usable
- content area adapting to available space

Use appropriate:

```text
BorderLayout
CardLayout
GridBagLayout
GridLayout
BoxLayout
```

where appropriate.

Avoid absolute positioning.

Do NOT use:

```text
setLayout(null)
```

for the entire application.

---

# 21. NAVIGATION CONTROLLER

If useful, create:

```text
util/
└── NavigationManager.java
```

or:

```text
controller/
└── NavigationController.java
```

Responsibilities:

- switch dashboard panels
- manage active navigation state
- prevent unnecessary duplicate panels
- provide centralized navigation

Do not over-engineer this component.

---

# 22. MODULE ENUM

If useful, create a centralized navigation identifier.

For example:

```text
DASHBOARD
MENU
CUSTOMERS
ORDERS
BILLING
REPORTS
SETTINGS
```

This prevents random string names being scattered throughout the GUI.

---

# 23. ACTIVE MENU STATE

When a user selects:

```text
Menu Management
```

the sidebar should clearly indicate that it is active.

Example:

```text
Dashboard
Menu Management  ← ACTIVE
Customers
Orders
Billing
```

When switching to another module, update the active state.

---

# 24. DASHBOARD HOME BUTTON

Clicking:

```text
Dashboard
```

must always return to:

```text
DashboardPanel
```

Do not create another frame.

---

# 25. FUTURE MODULE INTEGRATION

The architecture must make it easy to replace:

```text
MenuManagementPanel placeholder
```

with the actual:

```text
MenuManagementPanel
```

in a future phase.

Do not tightly couple dashboard navigation to unfinished module internals.

---

# 26. ERROR HANDLING

If a module fails to load:

Do not crash the whole application.

Show a controlled message such as:

```text
Unable to open this module.
Please try again.
```

Technical details should be logged appropriately.

---

# 27. MAIN APPLICATION FLOW

Final flow after Phase 6:

```text
Application Start
       ↓
LoginFrame
       ↓
AuthenticationService
       ↓
UserSession
       ↓
MainFrame
       ↓
DashboardPanel
       ↓
Navigation
 ┌─────┼─────┬──────┬──────┐
 ↓     ↓     ↓      ↓      ↓
Menu Customers Orders Billing Reports
```

---

# 28. PROJECT STRUCTURE AFTER PHASE 6

Use a structure similar to:

```text
src/
└── main/
    ├── java/
    │   └── com/
    │       └── restaurantbilling/
    │           │
    │           ├── Main.java
    │           │
    │           ├── model/
    │           │
    │           ├── dao/
    │           │   └── impl/
    │           │
    │           ├── database/
    │           │   └── DatabaseConnection.java
    │           │
    │           ├── service/
    │           │   └── AuthenticationService.java
    │           │
    │           ├── gui/
    │           │   │
    │           │   ├── LoginFrame.java
    │           │   ├── MainFrame.java
    │           │   │
    │           │   ├── dashboard/
    │           │   │   └── DashboardPanel.java
    │           │   │
    │           │   ├── menu/
    │           │   │   └── MenuManagementPanel.java
    │           │   │
    │           │   ├── customer/
    │           │   │   └── CustomerManagementPanel.java
    │           │   │
    │           │   ├── order/
    │           │   │   └── OrderManagementPanel.java
    │           │   │
    │           │   ├── billing/
    │           │   │   └── BillingPanel.java
    │           │   │
    │           │   ├── report/
    │           │   │   └── ReportsPanel.java
    │           │   │
    │           │   └── settings/
    │           │       └── SettingsPanel.java
    │           │
    │           ├── util/
    │           │   ├── UserSession.java
    │           │   └── NavigationManager.java
    │           │
    │           └── exception/
    │
    └── resources/
```

Only create classes that are actually required.

---

# 29. TESTING

Test the following.

## Test 1 — Login → Dashboard

```text
Login
 ↓
Valid credentials
 ↓
MainFrame
```

Expected:

```text
PASS
```

---

## Test 2 — Dashboard username

Expected:

```text
PASS
Correct username displayed.
```

---

## Test 3 — Dashboard role

Expected:

```text
PASS
Correct role displayed.
```

---

## Test 4 — Navigation

Test:

```text
Dashboard
Menu
Customers
Orders
Billing
Reports
Settings
```

Expected:

```text
PASS
Correct panel opens.
```

---

## Test 5 — Active menu

Expected:

```text
PASS
Selected navigation item is visibly active.
```

---

## Test 6 — Logout

Expected:

```text
MainFrame
 ↓
Logout
 ↓
Session cleared
 ↓
LoginFrame
```

---

## Test 7 — Re-login

After logout:

```text
STAFF logout
 ↓
ADMIN login
```

Expected:

```text
PASS
Correct role and username appear.
```

---

## Test 8 — Window resize

Resize the application.

Expected:

```text
PASS
Layout remains usable.
```

---

## Test 9 — Multiple dashboard instances

Click Dashboard repeatedly.

Expected:

```text
PASS
No duplicate MainFrame windows.
```

---

## Test 10 — Unauthorized navigation

Test role restrictions defined by the project.

Expected:

```text
PASS
Unauthorized module is unavailable or safely blocked.
```

---

# 30. PERFORMANCE TEST

Verify:

```text
[ ] Application starts quickly
[ ] Dashboard opens quickly
[ ] Navigation does not freeze UI
[ ] No unnecessary database queries
[ ] No duplicate frames
[ ] No memory/resource leaks
```

---

# 31. SECURITY CHECK

Verify:

```text
[ ] UserSession required
[ ] Logout clears session
[ ] Role is read from authenticated session
[ ] No password stored in session
[ ] No database credentials in GUI
[ ] GUI does not execute SQL directly
[ ] Unauthorized navigation is controlled
```

---

# 32. PHASE 6 SUCCESS CRITERIA

Phase 6 is complete only when:

```text
[ ] MainFrame created
[ ] DashboardPanel created
[ ] Sidebar created
[ ] TopBar created
[ ] ContentPanel created
[ ] CardLayout/navigation implemented
[ ] User information displayed
[ ] Role displayed
[ ] Dashboard home works
[ ] Module placeholders work
[ ] Active navigation state works
[ ] Logout works
[ ] Session clears correctly
[ ] Role-based navigation prepared
[ ] Window resizing works
[ ] No duplicate dashboard windows
[ ] Maven build succeeds
[ ] Application runs successfully
```

---

# 33. DO NOT START PHASE 7

Do NOT automatically implement:

- Menu Management
- Food Item CRUD
- Category Management
- Menu search
- Menu filtering

These belong to the next functional phase.

Stop after Phase 6 validation.

---

# 34. REQUIRED FINAL REPORT

After implementation, provide:

## A. Files Created

List all created/modified files.

## B. Dashboard Architecture

Show:

```text
Login
 ↓
UserSession
 ↓
MainFrame
 ├── DashboardPanel
 ├── MenuManagementPanel
 ├── CustomerManagementPanel
 ├── OrderManagementPanel
 ├── BillingPanel
 ├── ReportsPanel
 └── SettingsPanel
```

## C. Navigation Test Results

```text
Dashboard: PASS/FAIL
Menu: PASS/FAIL
Customers: PASS/FAIL
Orders: PASS/FAIL
Billing: PASS/FAIL
Reports: PASS/FAIL
Settings: PASS/FAIL
Logout: PASS/FAIL
Re-login: PASS/FAIL
Role restriction: PASS/FAIL
Window resize: PASS/FAIL
Maven build: PASS/FAIL
```

## D. Problems

List unresolved problems.

## E. Final Status

If everything passes:

```text
PHASE 6 COMPLETE

NEXT:
PHASE 7 — Menu Management & Food Item CRUD
```

Do NOT automatically start Phase 7.

Wait for explicit approval.