# PHASE 4 — MODEL CLASSES & DAO FOUNDATION

## Project

Continue developing the new **Restaurant Billing System**.

Completed:

- PHASE 1 — Project Setup & Foundation
- PHASE 2 — MySQL Database Design & Implementation
- PHASE 3 — JDBC Database Connectivity

Current:

- PHASE 4 — Model Classes & DAO Foundation

Technology:

- Java 21
- Java Swing
- MySQL 8.x
- JDBC
- Maven
- IntelliJ IDEA
- MVC + DAO architecture

The master specification is:

`Restaurant_Billing_System_Complete_Documentation.md`

Treat the documentation and the database created in Phase 2 as the source of truth.

---

# 1. PHASE 4 OBJECTIVE

Create the Java **Model layer** and **DAO foundation** required by all future modules.

The architecture should become:

```text
GUI
 ↓
Service
 ↓
DAO
 ↓
DatabaseConnection
 ↓
JDBC
 ↓
MySQL
```

At the end of this phase:

```text
MySQL Database
       ↑
       │ JDBC
       │
DatabaseConnection
       ↑
       │
      DAO
       ↑
       │
     Model
```

The DAO layer must be capable of performing basic database operations.

---

# 2. IMPORTANT RULES

Do NOT build the final GUI.

Do NOT build the dashboard.

Do NOT build the login screen.

Do NOT build the billing screen.

Do NOT build reports.

Do NOT implement unnecessary business logic inside DAO classes.

Do NOT change the database schema unless a genuine compatibility problem is discovered.

DAO classes must focus on database operations.

Business calculations and business rules belong in the future Service layer.

---

# 3. MODEL CLASSES

Create Java model/entity classes corresponding to the Phase 2 database.

Create:

```text
model/
├── User.java
├── FoodItem.java
├── Customer.java
├── Order.java
├── OrderItem.java
└── Bill.java
```

These classes represent database records.

---

# 4. MODEL DESIGN RULES

Use normal Java classes with:

- private fields
- constructors
- getters
- setters
- `toString()`
- appropriate validation where simple
- appropriate `equals()` / `hashCode()` where useful

Do not place database SQL inside model classes.

Do not place Swing code inside model classes.

Do not place large business calculations inside model classes.

---

# 5. USER MODEL

Create:

```text
model/User.java
```

Fields should correspond to the database.

Recommended:

```text
Long/Integer id
String username
String password
String role
LocalDateTime createdAt
LocalDateTime updatedAt
```

Use Java types appropriate for the database.

The model should support:

```text
ADMIN
STAFF
```

Do not store encrypted passwords in the model unless the authentication architecture specifically requires it.

Never print passwords in `toString()`.

For example, `toString()` must NOT expose:

```text
password=...
```

---

# 6. FOOD ITEM MODEL

Create:

```text
model/FoodItem.java
```

Fields:

```text
id
name
category
price
available
createdAt
updatedAt
```

Use:

```text
BigDecimal
```

for price.

Do NOT use:

```text
float
double
```

for monetary values.

---

# 7. CUSTOMER MODEL

Create:

```text
model/Customer.java
```

Fields:

```text
id
name
phone
email
createdAt
updatedAt
```

Phone must be:

```text
String
```

not an integer.

---

# 8. ORDER MODEL

Create:

```text
model/Order.java
```

Fields:

```text
id
customerId
orderDate
subtotal
discount
tax
total
status
createdAt
updatedAt
```

Use:

```text
BigDecimal
```

for:

```text
subtotal
discount
tax
total
```

Possible status values:

```text
PENDING
CONFIRMED
COMPLETED
CANCELLED
```

---

# 9. ORDER ITEM MODEL

Create:

```text
model/OrderItem.java
```

Fields:

```text
id
orderId
foodItemId
quantity
price
itemTotal
createdAt
```

Use:

```text
BigDecimal price
BigDecimal itemTotal
int quantity
```

Remember:

`price` represents the price charged when the item was ordered.

It must not automatically depend on the current `FoodItem.price`.

---

# 10. BILL MODEL

Create:

```text
model/Bill.java
```

Fields:

```text
id
orderId
billNumber
subtotal
discount
tax
finalAmount
paymentMethod
paymentStatus
billDate
createdAt
```

Use `BigDecimal` for monetary values.

Payment methods:

```text
CASH
CARD
UPI
OTHER
```

Payment status:

```text
PENDING
PAID
CANCELLED
```

---

# 11. DAO INTERFACES

Create DAO interfaces.

Recommended:

```text
dao/
├── UserDAO.java
├── FoodItemDAO.java
├── CustomerDAO.java
├── OrderDAO.java
├── OrderItemDAO.java
└── BillDAO.java
```

The interfaces should define database operations without containing implementation details.

---

# 12. USER DAO

Create:

```text
UserDAO.java
```

Possible operations:

```java
User findById(int id);

User findByUsername(String username);

List<User> findAll();

boolean save(User user);

boolean update(User user);

boolean delete(int id);
```

Only include operations that are actually needed.

The authentication-specific method:

```text
findByUsername()
```

will be important in a later login phase.

---

# 13. FOOD ITEM DAO

Create:

```text
FoodItemDAO.java
```

Operations:

```text
findById()
findAll()
findByCategory()
search()
save()
update()
delete()
updateAvailability()
```

The DAO should use parameterized SQL.

---

# 14. CUSTOMER DAO

Create:

```text
CustomerDAO.java
```

Operations:

```text
findById()
findAll()
search()
findByPhone()
save()
update()
delete()
```

Search should eventually support fields such as:

```text
name
phone
email
```

Use `PreparedStatement`.

---

# 15. ORDER DAO

Create:

```text
OrderDAO.java
```

Operations should support:

```text
findById()
findAll()
findByCustomer()
findByDate()
save()
update()
updateStatus()
delete()
```

Do not implement complicated billing calculations inside this DAO.

---

# 16. ORDER ITEM DAO

Create:

```text
OrderItemDAO.java
```

Operations:

```text
findById()
findByOrderId()
save()
update()
delete()
deleteByOrderId()
```

The DAO must correctly retrieve all items belonging to an order.

---

# 17. BILL DAO

Create:

```text
BillDAO.java
```

Operations:

```text
findById()
findByOrderId()
findByBillNumber()
findAll()
findByDate()
save()
updatePaymentStatus()
```

`billNumber` must be treated as unique.

---

# 18. DAO IMPLEMENTATION PACKAGE

Create:

```text
dao/
└── impl/
    ├── UserDAOImpl.java
    ├── FoodItemDAOImpl.java
    ├── CustomerDAOImpl.java
    ├── OrderDAOImpl.java
    ├── OrderItemDAOImpl.java
    └── BillDAOImpl.java
```

The interfaces define the contract.

The implementation classes contain JDBC code.

Architecture:

```text
UserDAO
   ↑
   |
UserDAOImpl
   ↓
DatabaseConnection
```

Same structure for all other DAOs.

---

# 19. JDBC IMPLEMENTATION RULES

Every DAO implementation must use:

```text
DatabaseConnection
```

created in Phase 3.

Do NOT create a separate MySQL connection implementation in every DAO.

Bad:

```text
UserDAOImpl → own connection
FoodItemDAOImpl → own connection
CustomerDAOImpl → own connection
```

Correct:

```text
UserDAOImpl
FoodItemDAOImpl
CustomerDAOImpl
       ↓
DatabaseConnection
       ↓
MySQL
```

---

# 20. PREPARED STATEMENT

All parameterized SQL queries must use:

```java
PreparedStatement
```

Never construct user-dependent SQL using string concatenation.

Bad:

```java
"SELECT * FROM users WHERE username = '" + username + "'"
```

Correct approach:

```text
SELECT * FROM users WHERE username = ?
```

with:

```text
PreparedStatement
```

---

# 21. RESULTSET MAPPING

Create clean mapping from database rows to Java objects.

For example:

```text
ResultSet
   ↓
User object
```

and:

```text
ResultSet
   ↓
FoodItem object
```

Do not duplicate large amounts of mapping code unnecessarily.

If appropriate, use private mapping helper methods inside each DAO implementation.

Example concept:

```java
private User mapResultSetToUser(ResultSet rs)
```

---

# 22. RESOURCE MANAGEMENT

Every DAO operation must correctly close:

```text
Connection
PreparedStatement
ResultSet
```

Use:

```java
try-with-resources
```

where appropriate.

Do not leave connections open.

Do not leave result sets open.

Do not leave statements open.

---

# 23. EXCEPTION HANDLING

DAO classes should handle SQL exceptions appropriately.

Do not silently ignore:

```text
SQLException
```

Do not use:

```java
e.printStackTrace();
```

as the only error-handling strategy throughout the application.

Use the project's database/application exception strategy from Phase 3.

If a custom exception is used, preserve the original cause.

---

# 24. TRANSACTION PREPARATION

Do not fully implement complex order transactions yet.

However, design the DAO layer so that future transactions can support:

```text
Create Order
      ↓
Create Order Items
      ↓
Create Bill
      ↓
Commit
```

or:

```text
Failure
   ↓
Rollback
```

Do not use separate uncontrolled commits for operations that will later need to be atomic.

Full transaction implementation will be handled in the Order/Billing service phase.

---

# 25. CRUD IMPLEMENTATION

Implement basic CRUD for the appropriate entities.

### User

```text
CREATE
READ
UPDATE
DELETE
```

### Food Item

```text
CREATE
READ
UPDATE
DELETE/availability
```

### Customer

```text
CREATE
READ
UPDATE
DELETE
```

### Order

```text
CREATE
READ
UPDATE
DELETE
```

### Order Item

```text
CREATE
READ
UPDATE
DELETE
```

### Bill

```text
CREATE
READ
UPDATE
```

Avoid deleting bills unnecessarily because billing history should be preserved.

---

# 26. TEST DAO OPERATIONS

Create DAO tests or controlled test classes.

Recommended:

```text
src/test/java/
└── com/restaurantbilling/
    └── dao/
        ├── UserDAOTest.java
        ├── FoodItemDAOTest.java
        ├── CustomerDAOTest.java
        ├── OrderDAOTest.java
        ├── OrderItemDAOTest.java
        └── BillDAOTest.java
```

Use the actual database only if the test environment is configured for it.

Do not destroy real development data during tests.

---

# 27. DAO TEST SCENARIOS

## User

Test:

```text
findById
findByUsername
findAll
save
update
```

Do not permanently delete important sample users during automated testing.

---

## Food Item

Test:

```text
findById
findAll
findByCategory
search
save
update
updateAvailability
```

---

## Customer

Test:

```text
findById
findAll
findByPhone
search
save
update
```

---

## Order

Test:

```text
findById
findAll
findByCustomer
findByDate
save
updateStatus
```

---

## Order Item

Test:

```text
findByOrderId
save
update
delete
```

---

## Bill

Test:

```text
findById
findByOrderId
findByBillNumber
findAll
save
updatePaymentStatus
```

---

# 28. DATABASE INTEGRITY

DAO implementations must respect the database constraints from Phase 2.

For example:

```text
Invalid customer ID
        ↓
Foreign-key error
```

Do not bypass foreign-key constraints.

Similarly:

```text
Invalid order ID
        ↓
OrderItem insert must fail safely
```

---

# 29. MODEL VALIDATION

Keep model validation lightweight.

Examples:

### FoodItem

```text
name cannot be empty
price cannot be negative
```

### Customer

```text
name cannot be empty
```

### OrderItem

```text
quantity > 0
price >= 0
```

Do not place complete business validation in model classes.

Detailed validation belongs in the future Service layer.

---

# 30. MONEY HANDLING

All monetary values must remain:

```text
BigDecimal
```

throughout the Java application.

Do not convert database money values into:

```text
double
float
```

This includes:

```text
FoodItem.price
Order.subtotal
Order.discount
Order.tax
Order.total
OrderItem.price
OrderItem.itemTotal
Bill.subtotal
Bill.discount
Bill.tax
Bill.finalAmount
```

---

# 31. DATE/TIME HANDLING

Use modern Java date/time classes where appropriate:

```text
LocalDate
LocalDateTime
```

Do not use old date APIs unnecessarily.

Map SQL date/time values correctly.

---

# 32. DAO CODE STRUCTURE

Keep DAO methods readable.

Each DAO method should generally follow:

```text
1. Define SQL
2. Get connection
3. Create PreparedStatement
4. Set parameters
5. Execute query/update
6. Map result
7. Return result
8. Close resources
9. Handle exception
```

Avoid putting unrelated logic inside DAO methods.

---

# 33. NO GUI DEPENDENCY

The DAO layer must work independently from Swing.

DAO classes must NOT:

```text
show JOptionPane
create JFrame
access Swing components
read text directly from JTextField
```

Bad:

```text
CustomerDAO → JTextField
```

Correct:

```text
CustomerFrame
      ↓
CustomerService
      ↓
CustomerDAO
```

The Service layer will be introduced/expanded in the next phases.

---

# 34. NO BUSINESS CALCULATIONS IN DAO

Do not implement:

```text
tax calculation
discount calculation
final bill calculation
```

inside DAO classes.

DAO should store/retrieve data.

Business logic belongs in the Service layer.

---

# 35. PACKAGE STRUCTURE AFTER PHASE 4

The project should now resemble:

```text
RestaurantBillingSystem/
│
├── src/
│   ├── main/
│   │   ├── java/
│   │   │   └── com/
│   │   │       └── restaurantbilling/
│   │   │           │
│   │   │           ├── Main.java
│   │   │           │
│   │   │           ├── model/
│   │   │           │   ├── User.java
│   │   │           │   ├── FoodItem.java
│   │   │           │   ├── Customer.java
│   │   │           │   ├── Order.java
│   │   │           │   ├── OrderItem.java
│   │   │           │   └── Bill.java
│   │   │           │
│   │   │           ├── dao/
│   │   │           │   ├── UserDAO.java
│   │   │           │   ├── FoodItemDAO.java
│   │   │           │   ├── CustomerDAO.java
│   │   │           │   ├── OrderDAO.java
│   │   │           │   ├── OrderItemDAO.java
│   │   │           │   ├── BillDAO.java
│   │   │           │   │
│   │   │           │   └── impl/
│   │   │           │       ├── UserDAOImpl.java
│   │   │           │       ├── FoodItemDAOImpl.java
│   │   │           │       ├── CustomerDAOImpl.java
│   │   │           │       ├── OrderDAOImpl.java
│   │   │           │       ├── OrderItemDAOImpl.java
│   │   │           │       └── BillDAOImpl.java
│   │   │           │
│   │   │           ├── database/
│   │   │           │   └── DatabaseConnection.java
│   │   │           │
│   │   │           ├── service/
│   │   │           │
│   │   │           ├── gui/
│   │   │           │
│   │   │           ├── util/
│   │   │           │
│   │   │           └── exception/
│   │   │
│   │   └── resources/
│   │       ├── db.properties
│   │       └── db.properties.example
│   │
│   └── test/
│       └── java/
│
├── database/
│   ├── schema.sql
│   └── sample_data.sql
│
├── docs/
├── screenshots/
├── pom.xml
├── README.md
└── .gitignore
```

---

# 36. CODE QUALITY REQUIREMENTS

Follow these rules:

- Java 21.
- Clean naming.
- Proper encapsulation.
- No duplicated SQL connection code.
- No hardcoded credentials.
- No SQL injection.
- PreparedStatement for parameters.
- try-with-resources.
- Meaningful exceptions.
- No Swing dependencies in DAO.
- No business logic in DAO.
- BigDecimal for money.
- LocalDate/LocalDateTime for dates.
- Avoid unnecessary complexity.
- Keep interfaces and implementations separate.

---

# 37. PHASE 4 VALIDATION

Before completing Phase 4, verify:

```text
[ ] User model created
[ ] FoodItem model created
[ ] Customer model created
[ ] Order model created
[ ] OrderItem model created
[ ] Bill model created

[ ] UserDAO created
[ ] FoodItemDAO created
[ ] CustomerDAO created
[ ] OrderDAO created
[ ] OrderItemDAO created
[ ] BillDAO created

[ ] All DAO implementations created
[ ] JDBC connection reused from Phase 3
[ ] PreparedStatement used
[ ] ResultSet mapping works
[ ] try-with-resources used
[ ] SQL exceptions handled
[ ] Basic CRUD tested
[ ] Foreign-key behavior tested
[ ] BigDecimal used for money
[ ] No passwords exposed
[ ] No Swing code inside DAO
[ ] No business calculations inside DAO
[ ] Maven compile succeeds
[ ] Tests pass
```

---

# 38. DO NOT START NEXT PHASE

Do not automatically implement:

```text
Login
Dashboard
Menu GUI
Customer GUI
Order GUI
Billing GUI
Reports
```

These belong to later phases.

Stop after Phase 4 validation.

---

# 39. REQUIRED FINAL REPORT

After completing Phase 4, provide:

## 1. Models Created

List:

```text
User
FoodItem
Customer
Order
OrderItem
Bill
```

## 2. DAO Interfaces

List all DAO interfaces.

## 3. DAO Implementations

List all implementation classes.

## 4. Database Operations Tested

Report CRUD/search operations tested for each DAO.

## 5. Architecture

Show:

```text
Model
   ↓
DAO Interface
   ↓
DAO Implementation
   ↓
DatabaseConnection
   ↓
JDBC
   ↓
MySQL
```

## 6. Test Results

Report:

```text
Model compilation: PASS/FAIL
DAO compilation: PASS/FAIL
Database connection: PASS/FAIL
User DAO: PASS/FAIL
FoodItem DAO: PASS/FAIL
Customer DAO: PASS/FAIL
Order DAO: PASS/FAIL
OrderItem DAO: PASS/FAIL
Bill DAO: PASS/FAIL
Maven build: PASS/FAIL
```

## 7. Problems

List all unresolved issues.

## 8. Final Status

If all requirements pass:

```text
PHASE 4 COMPLETE

NEXT:
PHASE 5 — Authentication & Login System
```

Do NOT automatically start Phase 5.

Wait for explicit approval.