# PHASE 11 — REPORTS & ANALYTICS

## Project

Continue developing the existing **Restaurant Billing System**.

### Technology
- Java 21
- Java Swing
- MySQL 8.x
- JDBC
- Maven
- IntelliJ IDEA
- MVC + DAO architecture

### Completed Phases
- Phase 1 — Project Setup & Foundation
- Phase 2 — MySQL Database
- Phase 3 — JDBC Connectivity
- Phase 4 — Model Classes & DAO Foundation
- Phase 5 — Authentication & Login
- Phase 6 — Main Dashboard & Navigation
- Phase 7 — Menu Management
- Phase 8 — Customer Management
- Phase 9 — Order Management
- Phase 10 — Bill Generation & Invoice Management

### Current Phase
**PHASE 11 — REPORTS & ANALYTICS**

---

## IMPORTANT BUSINESS RULE

This Restaurant Billing System **does not process payments**.

There is **NO payment module**.

Reports and analytics must be based only on:
- Orders
- Order Items
- Food Items
- Customers
- Generated Bills

### DO NOT IMPLEMENT

- Payment reports
- Cash reports
- Card reports
- UPI reports
- Payment-method analytics
- Payment collection reports
- Transaction reports
- Refund reports

The system is only a restaurant billing and reporting system.

---

# 1. PHASE OBJECTIVE

Implement a complete Reports & Analytics module.

The module should provide:

- Total bills generated
- Total billing amount
- Daily billing
- Weekly billing
- Monthly billing
- Yearly billing
- Best-selling food items
- Most ordered food items
- Number of orders
- Number of customers
- Average bill value
- Billing trends
- Date-wise billing
- Item-wise performance
- Customer/order statistics

Reports must use **real MySQL data**.

Do not use dummy or hardcoded statistics.

---

# 2. REPORTS DASHBOARD

Create:

`ReportsDashboardPanel`

Suggested layout:

```text
+----------------------------------------------------------------+
|                    REPORTS & ANALYTICS                         |
+----------------------------------------------------------------+
|                                                                |
| TOTAL BILLS        TOTAL BILLING       TOTAL ORDERS            |
|    125              ₹85,450             140                   |
|                                                                |
| CUSTOMERS          AVG BILL                                  |
|    98              ₹683.60                                   |
|                                                                |
+----------------------------------------------------------------+
| DATE FILTER                                                   |
| From: [__/__/____]   To: [__/__/____]   [APPLY] [RESET]       |
+----------------------------------------------------------------+
|                                                                |
|                  BILLING TREND                                |
|                                                                |
|                 [ LINE / BAR CHART ]                          |
|                                                                |
+----------------------------------------------------------------+
| TOP SELLING ITEMS                                             |
|----------------------------------------------------------------|
| Item Name          Quantity Sold       Revenue                |
| Pizza              120                  ₹30,000                |
| Burger             95                   ₹14,250                |
| Pasta              80                   ₹12,000                |
+----------------------------------------------------------------+
```

Maintain the existing application's UI theme.

---

# 3. REPORT TYPES

Implement:

1. Daily Billing Report
2. Weekly Billing Report
3. Monthly Billing Report
4. Yearly Billing Report
5. Item Sales Report
6. Top-Selling Items Report
7. Order Summary Report
8. Customer Summary Report
9. Bill Summary Report
10. Billing Trend Report

Only implement reports supported by the existing database.

---

# 4. DAILY BILLING REPORT

Allow the user to select a date.

Show:

- Total Bills
- Total Orders
- Total Billing Amount
- Average Bill Amount

Detailed table:

- Bill Number
- Order Number
- Customer
- Bill Date
- Subtotal
- Discount
- Tax
- Grand Total

---

# 5. WEEKLY REPORT

Allow the user to select a week/date range.

Show:

- Total Bills
- Total Orders
- Total Billing Amount
- Average Bill

Daily breakdown:

```text
Date
Bills
Orders
Billing Amount
```

---

# 6. MONTHLY REPORT

Allow selection of:

- Month
- Year

Show:

- Total Bills
- Total Orders
- Total Billing Amount
- Average Bill Amount

Daily breakdown:

```text
Date
Bills
Orders
Amount
```

---

# 7. YEARLY REPORT

Allow selection of year.

Display:

```text
Month
Bills
Orders
Billing Amount
```

Example:

```text
January      120      ₹80,000
February     135      ₹92,000
March        150      ₹1,05,000
```

---

# 8. ITEM SALES REPORT

Show:

- Food Item
- Category
- Quantity Sold
- Revenue

Use order-item data.

Do not calculate historical revenue using current menu prices.

Use the actual prices stored with the order items.

---

# 9. TOP-SELLING ITEMS

Show highest-selling food items.

Allow:

- Top 5
- Top 10
- Top 20

Default:

**Top 10**

Sort by:

- Quantity Sold
- Optionally Revenue

---

# 10. ORDER SUMMARY REPORT

Show:

- Total Orders
- Completed Orders
- Pending Orders
- Cancelled Orders
- Other statuses defined in the project

Use only existing order statuses.

Do not create new statuses.

---

# 11. CUSTOMER SUMMARY

Show useful customer statistics:

- Total Customers
- Customers with Orders
- Number of Orders
- Average Orders per Customer
- Top Customers by Number of Orders

Do not expose unnecessary personal information.

---

# 12. BILL SUMMARY

Show:

- Total Bills
- Total Billing Amount
- Average Bill
- Highest Bill
- Lowest Bill

Formula:

```text
Average Bill =
Total Billing Amount / Number of Bills
```

Use `BigDecimal` for monetary values.

---

# 13. BILLING TREND

Create graphical representations of billing trends.

Possible charts:

- Daily billing
- Weekly billing
- Monthly billing
- Yearly billing

Use Java Swing-compatible chart technology already present in the project.

If no chart library exists, use a lightweight Maven-compatible chart library.

Do not add unnecessary dependencies.

---

# 14. CHART TYPES

Recommended:

### Line Chart
For billing trends.

### Bar Chart
For top-selling items.

### Pie/Donut Chart
For category distribution only if existing data supports it.

Do not create meaningless charts.

---

# 15. DATE FILTER

Provide:

```text
From Date:
[__/__/____]

To Date:
[__/__/____]

[APPLY] [RESET]
```

Validation:

From Date cannot be greater than To Date.

If invalid:

```text
Invalid date range.
```

Do not execute the report query.

---

# 16. QUICK DATE FILTERS

Provide optional quick filters:

```text
[Today]
[Yesterday]
[This Week]
[This Month]
[This Year]
```

These should automatically populate the date range.

Use the system's local date.

---

# 17. REPORT SERVICE

Create:

`ReportService`

Responsibilities:

- Get daily report
- Get weekly report
- Get monthly report
- Get yearly report
- Get item sales
- Get top-selling items
- Get order statistics
- Get customer statistics
- Get bill statistics
- Get billing trends

Do not place SQL queries inside Swing panels.

---

# 18. REPORT DAO

Create/use:

`ReportDAO`

Implementation:

`ReportDAOImpl`

Possible methods:

```text
getDailyReport()
getWeeklyReport()
getMonthlyReport()
getYearlyReport()
getItemSalesReport()
getTopSellingItems()
getOrderSummary()
getCustomerSummary()
getBillSummary()
getBillingTrend()
```

Use the actual existing database schema.

---

# 19. SQL PERFORMANCE

Reports may contain large amounts of data.

Therefore:

- Perform aggregation inside MySQL.
- Use `GROUP BY` where appropriate.
- Use `SUM()`.
- Use `COUNT()`.
- Use `AVG()`.
- Use `MIN()`.
- Use `MAX()`.
- Use `ORDER BY`.
- Use `LIMIT` for top-item reports.

Do not load thousands of records into Java and calculate everything manually.

Prefer database aggregation.

---

# 20. PREPARED STATEMENTS

All dynamic values must use `PreparedStatement`.

Examples:

- From Date
- To Date
- Item ID
- Category
- Search values
- Report filters

Never concatenate user input into SQL.

---

# 21. REPORT DTOs

If needed, create dedicated DTO/model classes.

Examples:

```text
DailyReportDTO
MonthlyReportDTO
ItemSalesDTO
TopSellingItemDTO
OrderSummaryDTO
CustomerSummaryDTO
BillSummaryDTO
BillingTrendDTO
```

Do not create unnecessary classes if existing models already provide the required structure.

---

# 22. DASHBOARD CARDS

Reports dashboard should contain:

### Card 1
TOTAL BILLS

### Card 2
TOTAL BILLING

### Card 3
TOTAL ORDERS

### Card 4
TOTAL CUSTOMERS

### Card 5
AVERAGE BILL

Use real MySQL values.

Do not use hardcoded numbers.

---

# 23. REFRESH REPORTS

Provide:

`[REFRESH]`

When clicked:

- Reload report data
- Refresh cards
- Refresh tables
- Refresh charts

Do not restart the application.

---

# 24. EMPTY DATA HANDLING

If there is no data:

```text
No data available for the selected period.
```

Do not display:

- null
- blank tables
- NaN
- Infinity
- negative zero

Charts must also handle empty datasets gracefully.

---

# 25. ERROR HANDLING

Database failure:

```text
Unable to load report data.
```

Invalid date:

```text
Invalid date range.
```

Unexpected error:

```text
Unable to generate report.
```

Do not expose raw SQL/database stack traces to users.

Log technical details appropriately.

---

# 26. BILLING DATA SOURCE

Reports must use:

- Bills
- Orders
- Order Items
- Food Items
- Customers

according to the existing relationships.

Logical structure:

```text
Bills
  ↓
Orders
  ↓
Order Items
  ↓
Food Items

Customers
  ↓
Orders
```

Use the actual database schema as the source of truth.

---

# 27. HISTORICAL DATA

Historical reports must remain correct.

Do not use current menu prices to reconstruct old sales.

For revenue, use the price/value stored in order-item or bill data according to the existing schema.

Old reports must not change when menu prices are updated.

---

# 28. BILLING AMOUNT

Billing amount must come from generated bill records where appropriate.

Do not create a separate fake sales table.

Use the existing bill data.

---

# 29. ITEM REVENUE

For item revenue:

```text
Item Revenue =
Quantity × Historical Unit Price
```

Use `BigDecimal` where monetary calculations are performed in Java.

Prefer SQL aggregation where appropriate.

---

# 30. REPORT TABLE DESIGN

Use clean `JTable`-based reports.

### Bill Report

```text
Bill Number
Order Number
Customer
Date
Subtotal
Discount
Tax
Grand Total
```

### Item Report

```text
Item
Category
Quantity Sold
Revenue
```

### Order Report

```text
Order Number
Customer
Date
Status
Total
```

---

# 31. TABLE FEATURES

Where appropriate provide:

- Sorting
- Column resizing
- Search
- Scrollbars
- Responsive table layout

Do not overload the UI with unnecessary controls.

---

# 32. EXPORT REPORT

If export is part of the project scope, provide:

```text
[EXPORT PDF]
[PRINT]
```

The exported report should contain:

- Report title
- Date range
- Generated date
- Summary
- Table data
- Totals

Do not export payment information.

If PDF support already exists, reuse it.

---

# 33. PRINT REPORT

Provide printing for important reports.

Printed reports must be readable and professionally formatted.

---

# 34. REPORT PDF

Suggested names:

```text
Daily_Report_YYYY-MM-DD.pdf
Monthly_Report_YYYY-MM.pdf
Yearly_Report_YYYY.pdf
Item_Sales_Report.pdf
```

Do not overwrite existing reports without confirmation or a unique naming strategy.

---

# 35. ROLE-BASED ACCESS

Follow the existing authentication and authorization system.

Recommended:

### ADMIN
- View all reports
- Generate reports
- Export reports
- Print reports

### STAFF
- View operational reports if allowed
- Generate permitted reports

Use the actual project's permission rules if they already exist.

---

# 36. UI PERFORMANCE

The report UI must remain responsive.

Do not execute large database queries on the Swing Event Dispatch Thread if the query may take noticeable time.

Use appropriate background processing such as:

`SwingWorker`

where necessary.

Show a loading state:

```text
Generating report...
```

---

# 37. DATABASE INDEXING

Inspect the existing schema.

If necessary, consider indexes on:

- `bill_date`
- `order_date`
- `order_status`
- `order_id`
- `customer_id`
- `food_item_id`

Do not create duplicate indexes.

Only add indexes when justified by the existing schema and query patterns.

---

# 38. SECURITY

Verify:

- [ ] PreparedStatement used
- [ ] No SQL injection
- [ ] No SQL inside GUI
- [ ] Role permissions enforced
- [ ] No unnecessary customer data exposed
- [ ] Database credentials protected
- [ ] Raw SQL errors not shown to users

---

# 39. PERFORMANCE

Verify:

- [ ] Aggregation performed in MySQL
- [ ] No unnecessary full-table loading
- [ ] Proper indexes considered
- [ ] Report queries are efficient
- [ ] Tables load efficiently
- [ ] Charts do not freeze the UI
- [ ] SwingWorker used where appropriate
- [ ] Database resources closed
- [ ] No duplicate queries
- [ ] No duplicate event listeners

---

# 40. TESTING

## Test 1 — Daily Report

Select a date.

Expected:

Correct bills and billing amount.

PASS/FAIL

---

## Test 2 — Weekly Report

Select a week.

Expected:

Correct daily aggregation.

PASS/FAIL

---

## Test 3 — Monthly Report

Select a month.

Expected:

Correct monthly billing.

PASS/FAIL

---

## Test 4 — Yearly Report

Select a year.

Expected:

Correct monthly aggregation.

PASS/FAIL

---

## Test 5 — Item Sales

Expected:

Correct quantity and revenue.

PASS/FAIL

---

## Test 6 — Top-Selling Items

Expected:

Items sorted correctly.

PASS/FAIL

---

## Test 7 — Order Summary

Expected:

Correct order counts by status.

PASS/FAIL

---

## Test 8 — Customer Summary

Expected:

Correct customer statistics.

PASS/FAIL

---

## Test 9 — Bill Summary

Expected correct:

- Total Bills
- Total Billing
- Average Bill
- Highest Bill
- Lowest Bill

PASS/FAIL

---

## Test 10 — Date Validation

Set:

From Date > To Date

Expected:

Report rejected.

PASS/FAIL

---

## Test 11 — Empty Date Range

Select a period with no records.

Expected:

```text
No data available.
```

PASS/FAIL

---

## Test 12 — Refresh

Change data and click refresh.

Expected:

Updated report.

PASS/FAIL

---

## Test 13 — PDF Export

Expected:

Correct report generated.

PASS/FAIL

---

## Test 14 — Print

Expected:

Readable report printed.

PASS/FAIL

---

## Test 15 — Historical Price

Change a menu price after an old order.

Expected:

Old report remains unchanged.

PASS/FAIL

---

## Test 16 — Large Dataset

Use a large dataset.

Expected:

UI remains responsive.

PASS/FAIL

---

# 41. DATABASE VALIDATION

Verify reports against direct MySQL queries.

Compare:

```text
Application Result
        VS
Database Result
```

Verify:

- Total bills
- Total orders
- Total billing
- Average bill
- Item quantities
- Item revenue
- Status counts

All must match.

---

# 42. PROJECT STRUCTURE

Recommended:

```text
src/
└── main/
    └── java/
        └── com/
            └── restaurantbilling/

                model/
                    report/
                        DailyReportDTO.java
                        MonthlyReportDTO.java
                        ItemSalesDTO.java
                        TopSellingItemDTO.java
                        OrderSummaryDTO.java
                        CustomerSummaryDTO.java
                        BillSummaryDTO.java
                        BillingTrendDTO.java

                dao/
                    ReportDAO.java
                    impl/
                        ReportDAOImpl.java

                service/
                    ReportService.java

                gui/
                    reports/
                        ReportsDashboardPanel.java
                        DailyReportPanel.java
                        MonthlyReportPanel.java
                        ItemSalesPanel.java
                        BillReportPanel.java

                report/
                    ReportGenerator.java
```

Only create classes that are actually required.

Reuse existing utilities and services.

---

# 43. NAVIGATION

Add Reports to the existing dashboard/sidebar.

Example:

```text
Dashboard
Menu
Customers
Orders
Billing
Reports
Settings
Logout
```

Follow the existing navigation structure.

Do not break existing navigation.

---

# 44. BACKWARD COMPATIBILITY

Do not break:

- Login
- Dashboard
- Menu Management
- Customer Management
- Order Management
- Billing
- Invoice Generation
- Bill History

After implementing Phase 11, test all previous modules.

---

# 45. REGRESSION TESTING

Verify:

- [ ] Login works
- [ ] Dashboard works
- [ ] Menu CRUD works
- [ ] Customer CRUD works
- [ ] Order creation works
- [ ] Bill generation works
- [ ] Bill history works
- [ ] Invoice generation works
- [ ] Reports work
- [ ] Logout works

No existing feature should be broken.

---

# 46. STRICTLY FORBIDDEN

Do NOT implement:

- Payment module
- Payment reports
- Cash reports
- Card reports
- UPI reports
- Payment gateway
- Refund reports
- Payment analytics
- Fake sales data
- Hardcoded statistics
- Duplicate billing tables
- Duplicate order tables
- Duplicate customer tables
- Unnecessary modules

Use existing data.

---

# 47. PHASE 11 SUCCESS CRITERIA

Phase 11 is complete only when:

- [ ] Reports dashboard implemented
- [ ] Daily report implemented
- [ ] Weekly report implemented
- [ ] Monthly report implemented
- [ ] Yearly report implemented
- [ ] Item sales report implemented
- [ ] Top-selling items implemented
- [ ] Order summary implemented
- [ ] Customer summary implemented
- [ ] Bill summary implemented
- [ ] Billing trend implemented
- [ ] Date filtering works
- [ ] Quick filters work
- [ ] Refresh works
- [ ] Empty data handled
- [ ] Database aggregation optimized
- [ ] Charts work where implemented
- [ ] PDF export works if required
- [ ] Printing works if required
- [ ] Role restrictions work
- [ ] Historical data remains accurate
- [ ] No payment functionality introduced
- [ ] Previous phases still work
- [ ] Maven build succeeds
- [ ] Application starts successfully
- [ ] MySQL data validated

---

# 48. FINAL REPORT

After implementation provide:

## Files Created/Modified

List every created and modified file.

## Reports Implemented

List all completed reports.

## Database Queries

Explain the major aggregation queries used.

## Dashboard Statistics

List:

- Total Bills
- Total Billing
- Total Orders
- Total Customers
- Average Bill

## Charts

List implemented charts.

## Export

List:

- PDF
- Print

## Test Results

Report PASS/FAIL for every test.

## Performance Results

Report query/UI performance observations.

## Security Results

Report security validation.

## Regression Results

Confirm that all previous phases still work.

## Problems

List unresolved issues.

## Final Status

If all requirements pass:

```text
PHASE 11 COMPLETE

NEXT:
PHASE 12 — WAIT FOR USER INSTRUCTION
```

Do NOT automatically start Phase 12.
Wait for explicit user approval.
