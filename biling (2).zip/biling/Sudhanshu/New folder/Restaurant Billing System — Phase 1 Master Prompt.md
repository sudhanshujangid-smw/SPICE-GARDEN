# PHASE 1 — PROJECT SETUP & FOUNDATION

## Project

Create a completely new **Restaurant Billing System** from scratch.

This is a new project. Do not assume that any previous Restaurant Billing System source code, database, GUI, or project structure exists.

The project specification is provided separately in:

`Restaurant_Billing_System_Complete_Documentation.md`

Treat that documentation as the **master project specification**.

---

# 1. TECHNOLOGY REQUIREMENTS

Use exactly the following primary technologies:

- Java 21
- Java Swing
- MySQL 8.x
- JDBC
- Maven
- IntelliJ IDEA
- MVC + DAO architecture

Do not replace Java Swing with JavaFX, Spring Boot, React, or any web framework.

The application is a desktop-based Java Swing application.

---

# 2. PHASE 1 OBJECTIVE

The objective of this phase is to create the complete project foundation.

At the end of this phase:

1. Maven project must be created.
2. Java 21 must be configured.
3. Correct package structure must exist.
4. MySQL JDBC dependency must be configured.
5. Main application entry point must work.
6. Basic Swing application window must launch.
7. Architecture must be prepared for future phases.
8. Project must compile successfully.
9. Project must run successfully.
10. No unnecessary features should be implemented yet.

---

# 3. PROJECT NAME

Use:

`Restaurant Billing System`

Recommended Maven artifact:

`restaurant-billing-system`

Recommended package:

`com.restaurantbilling`

Use a professional package structure.

---

# 4. MAVEN PROJECT STRUCTURE

Create:

```text
RestaurantBillingSystem/
│
├── src/
│   ├── main/
│   │   ├── java/
│   │   │   └── com/
│   │   │       └── restaurantbilling/
│   │   │           │
│   │   │           ├── Main.java
│   │   │           │
│   │   │           ├── model/
│   │   │           │
│   │   │           ├── dao/
│   │   │           │
│   │   │           ├── service/
│   │   │           │
│   │   │           ├── database/
│   │   │           │
│   │   │           ├── gui/
│   │   │           │
│   │   │           ├── util/
│   │   │           │
│   │   │           └── exception/
│   │   │
│   │   └── resources/
│   │
│   └── test/
│       └── java/
│
├── database/
│   ├── schema.sql
│   └── sample_data.sql
│
├── docs/
│
├── screenshots/
│
├── pom.xml
├── README.md
└── .gitignore
```

Do not create unnecessary packages.

---

# 5. ARCHITECTURE

Prepare the project for:

```text
GUI
 ↓
Service
 ↓
DAO
 ↓
JDBC
 ↓
MySQL
```

Use:

```text
Model
DAO
Service
GUI
Database
Utility
Exception
```

Responsibilities:

### model/

Contains data/entity classes.

Examples for future phases:

```text
User
FoodItem
Customer
Order
OrderItem
Bill
```

Do not fully implement these entities in Phase 1 unless necessary.

### dao/

Database access layer.

Future classes:

```text
UserDAO
FoodItemDAO
CustomerDAO
OrderDAO
BillDAO
```

### service/

Business logic.

Future classes:

```text
AuthenticationService
OrderService
BillingService
ReportService
```

### database/

Database connection and database-related classes.

### gui/

Java Swing screens.

### util/

Reusable utilities.

### exception/

Custom application exceptions where required.

---

# 6. JAVA VERSION

Configure Maven to use:

```text
Java 21
```

Use appropriate Maven compiler properties.

Verify that the project compiles using Java 21.

---

# 7. MYSQL JDBC

Add the appropriate MySQL Connector/J Maven dependency.

Do not manually download JAR files if Maven dependency management can handle it.

The JDBC driver must be available through Maven.

Do not hardcode database credentials into multiple Java classes.

---

# 8. MAIN APPLICATION

Create:

```text
Main.java
```

It should be the application entry point.

The initial application should launch a simple Swing window proving that the Java/Swing environment is working.

Example concept:

```text
Restaurant Billing System
-------------------------

Application initialized successfully.
```

This is only a Phase 1 test window.

Do not create the final dashboard yet.

---

# 9. SWING CONFIGURATION

Use the Swing Event Dispatch Thread.

The application should initialize GUI components safely using the appropriate Swing mechanism.

Prepare the application for future screens such as:

```text
LoginFrame
DashboardFrame
MenuManagementFrame
CustomerFrame
OrderFrame
BillingFrame
BillHistoryFrame
ReportsFrame
```

Do not implement these screens fully in Phase 1.

---

# 10. DATABASE FOLDER

Create:

```text
database/
├── schema.sql
└── sample_data.sql
```

For Phase 1, create the files and prepare them for future implementation.

Do not add unnecessary tables yet unless required for verifying the project foundation.

The complete database implementation will be handled in PHASE 2.

---

# 11. README

Create a professional initial README.md.

Include:

- Project name
- Project description
- Technology stack
- Current development phase
- Basic project structure
- How to open the project in IntelliJ IDEA
- How to run the Maven project
- Future modules

Clearly state:

```text
Current Status: PHASE 1 — Project Setup & Foundation
```

---

# 12. GITIGNORE

Create a proper `.gitignore`.

It should exclude common IntelliJ/Maven generated files such as:

```text
.idea/
*.iml
target/
.classpath
.project
.settings/
```

Do not ignore source code, SQL scripts, documentation, or README files.

---

# 13. CODE QUALITY RULES

Follow these rules from the beginning:

- Use meaningful class names.
- Use meaningful variable names.
- Follow Java naming conventions.
- Keep classes focused.
- Avoid duplicate code.
- Avoid unnecessary global/static state.
- Add comments only where useful.
- Do not create placeholder code that will cause compilation problems.
- Do not add unnecessary dependencies.
- Keep the architecture scalable.

---

# 14. IMPORTANT DEVELOPMENT RULES

These rules apply to the entire project:

### Rule 1 — Do not skip requirements

The master documentation is the source of truth.

### Rule 2 — Do not build everything at once

Work phase-by-phase.

### Rule 3 — Compile after implementation

After completing Phase 1, run a Maven build.

### Rule 4 — Fix errors before continuing

Do not leave compilation errors unresolved.

### Rule 5 — Do not introduce unnecessary technologies

The primary stack remains:

```text
Java 21
Swing
MySQL
JDBC
Maven
```

### Rule 6 — Keep the application desktop-based

Do not convert it into a web application.

### Rule 7 — Future phases must build on this architecture

Do not create disconnected implementations.

---

# 15. PHASE 1 VALIDATION

Before declaring Phase 1 complete, verify all of the following:

```text
[ ] Maven project exists
[ ] Java 21 configured
[ ] pom.xml valid
[ ] MySQL JDBC dependency configured
[ ] Package structure created
[ ] Main.java created
[ ] Swing launches successfully
[ ] database folder created
[ ] docs folder created
[ ] screenshots folder created
[ ] README.md created
[ ] .gitignore created
[ ] Project compiles
[ ] Project runs
[ ] No compilation errors
```

---

# 16. REQUIRED FINAL REPORT

After implementation, provide a concise Phase 1 report containing:

### 1. Files Created

List every important file created.

### 2. Dependencies

List Maven dependencies added.

### 3. Architecture

Show the final package structure.

### 4. Build Result

State whether Maven compilation succeeded.

### 5. Run Result

State whether the Swing application launched successfully.

### 6. Problems

List any remaining problems.

### 7. Next Phase

State:

```text
PHASE 1 COMPLETE

NEXT:
PHASE 2 — MySQL Database Design & Implementation
```

Do not start PHASE 2 automatically.

Wait for explicit approval before continuing.