# PHASE 10 — BILL GENERATION & INVOICE MANAGEMENT

## Project

Continue developing the existing **Restaurant Billing System**.

### Technology
- Java 21
- Java Swing
- MySQL 8.x
- JDBC
- Maven
- IntelliJ IDEA
- MVC + DAO architecture

### Completed Phases
- Phase 1 — Project Setup
- Phase 2 — MySQL Database
- Phase 3 — JDBC Connectivity
- Phase 4 — Model & DAO Foundation
- Phase 5 — Authentication & Login
- Phase 6 — Dashboard & Navigation
- Phase 7 — Menu Management
- Phase 8 — Customer Management
- Phase 9 — Order Management

### Current Phase
**PHASE 10 — BILL GENERATION & INVOICE MANAGEMENT**

---

## IMPORTANT BUSINESS RULE

This Restaurant Billing System **does not collect or process payments from customers**.

There is **NO payment functionality**.

The system is ONLY responsible for:
- Calculating the bill
- Showing bill details
- Generating invoices/receipts
- Printing bills
- Saving bill records
- Viewing previous bills
- Searching bills
- Maintaining bill history

### DO NOT IMPLEMENT
- Cash payment
- Card payment
- UPI payment
- Payment gateway
- Payment method
- Amount received
- Change calculation
- Transaction reference
- Payment status
- Payment table
- Payment DAO
- Payment Service
- Refund system
- Payment processing
- Payment collection

---

# 1. BILLING WORKFLOW

```text
CUSTOMER
   ↓
FOOD ITEMS
   ↓
ORDER
   ↓
BILL CALCULATION
   ↓
GENERATE BILL
   ↓
VIEW BILL
   ↓
PRINT / SAVE BILL
```

The system must **not** proceed into payment processing.

---

# 2. BILLING MANAGEMENT

Create:

`BillingManagementPanel`

Suggested interface:

```text
+-------------------------------------------------------------+
| BILLING / BILL MANAGEMENT                                   |
+-------------------------------------------------------------+
| Search Order [_____________]                                |
|                                                             |
| Order ID | Customer | Date | Total | Status | Action        |
|----------|----------|------|-------|--------|---------------|
| 1001     | Rahul    | ...  | ₹850  | READY  | [VIEW BILL]   |
| 1002     | Amit     | ...  | ₹620  | READY  | [VIEW BILL]   |
+-------------------------------------------------------------+
```

---

# 3. SELECT ORDER

When the user selects an order, load:
- Order ID
- Order Number, if available
- Customer
- Order Date
- Order Items
- Quantity
- Unit Price
- Line Total
- Subtotal

Use the prices stored in the order/order-items records.

**Do NOT use current menu prices to reconstruct historical bills.**

---

# 4. BILL CALCULATION

```text
Subtotal
- Discount
+ Tax
= Grand Total
```

Use `BigDecimal` for every monetary calculation.

Never use `double` or `float` for money.

---

# 5. TAX

If tax is already defined in the project documentation/database:
- Use that configuration.
- Do not hardcode a different rate.

If tax has not been defined:
- Do not invent a tax rate.
- Keep the architecture ready for future tax configuration.

---

# 6. DISCOUNT

If discounts are already defined in the project:
- Use the existing rules.

If discounts are not defined:

```text
Discount = ₹0.00
```

Do not create an unnecessary discount management system.

---

# 7. BILL PREVIEW

Display:

```text
RESTAURANT NAME

Bill Number
Order Number
Date

Customer:
Name
Phone

--------------------------------------------

Item          Qty       Price       Amount

Pizza         2         ₹250        ₹500
Burger        1         ₹150        ₹150

--------------------------------------------

Subtotal:                     ₹650.00
Discount:                     ₹0.00
Tax:                          ₹0.00
--------------------------------------------
GRAND TOTAL:                  ₹650.00
--------------------------------------------

Thank You!
```

### DO NOT DISPLAY
- Payment Method
- Amount Paid
- Amount Received
- Change
- Transaction ID
- Payment Status

---

# 8. BILL GENERATION

```text
Select Order
     ↓
Load Order Details
     ↓
Calculate Bill
     ↓
Create Bill
     ↓
Save Bill
     ↓
Show Bill
     ↓
Print / Save
```

---

# 9. BILL DATABASE

Use the existing bill table if it already exists.

Do not create a duplicate billing table.

If a billing table does not yet exist but is defined in the master documentation, implement it according to the existing database design.

Possible fields may include:
- `bill_id`
- `bill_number`
- `order_id`
- `customer_id`
- `subtotal`
- `discount`
- `tax`
- `grand_total`
- `bill_date`
- `status`

Use **only fields that actually exist in the project schema**.

---

# 10. BILL DAO

Use:
- `BillDAO`
- `BillDAOImpl`

Possible methods:

```text
createBill()
findById()
findByOrderId()
findAll()
searchBills()
```

Do **not** create:
- `PaymentDAO`
- `PaymentDAOImpl`

---

# 11. BILL SERVICE

Create/use:

`BillingService`

Responsibilities:
- Load order
- Calculate subtotal
- Calculate discount
- Calculate tax
- Calculate grand total
- Validate billing
- Save bill
- Retrieve bills
- Search bills
- Generate invoice

Do **NOT** add payment methods to `BillingService`.

---

# 12. DUPLICATE BILL PROTECTION

Before generating a bill:
1. Check whether the order already has a bill.
2. If already billed, show:

```text
This order has already been billed.
```

3. Allow the user to view the existing bill.
4. Do not create a duplicate bill.

---

# 13. BILL NUMBER

If the database already defines a bill number:
- Use it.
- Ensure it is unique.

Do not create a second bill-number system if one already exists.

---

# 14. BILL STATUS

Do not create payment statuses.

If bill status exists in the existing schema, use only the defined bill statuses.

Possible example:

```text
GENERATED
```

Do not add:

```text
PAID
PAYMENT_PENDING
PAYMENT_FAILED
```

because the system does not process payments.

---

# 15. INVOICE GENERATION

Generate a professional invoice/bill containing:
- Restaurant Name
- Restaurant Address/Contact, if configured
- Bill Number
- Order Number
- Bill Date
- Customer Details
- Itemized Order
- Item
- Quantity
- Unit Price
- Amount
- Subtotal
- Discount
- Tax
- Grand Total

Footer:

```text
Thank You
```

---

# 16. PDF INVOICE

Generate a PDF bill if PDF generation is part of the project requirements.

Suggested filename:

```text
Bill_<billNumber>.pdf
```

Example:

```text
Bill_10001.pdf
```

Do not overwrite an existing invoice accidentally.

---

# 17. VIEW BILL

After generating a bill, show:

```text
BILL GENERATED SUCCESSFULLY
```

Buttons:

```text
[VIEW BILL]
[PRINT BILL]
[SAVE PDF]
[CLOSE]
```

Do not show any payment-related button.

---

# 18. PRINT BILL

Implement printing of the formatted bill.

The printed bill must contain:
- Restaurant information
- Bill number
- Order number
- Customer
- Items
- Quantities
- Prices
- Subtotal
- Discount
- Tax
- Grand Total

Do not print payment information.

---

# 19. BILL HISTORY

Create:

`BillHistoryPanel`

Display:
- Bill Number
- Order Number
- Customer
- Bill Date
- Subtotal
- Tax
- Discount
- Grand Total
- Status

---

# 20. BILL SEARCH

Allow searching by:
- Bill Number
- Order Number
- Customer Name

Use `PreparedStatement`.

Do not concatenate search input directly into SQL.

---

# 21. BILL FILTER

If supported by the existing database, filter by:
- Date
- Bill Status

Do not add unnecessary filters.

---

# 22. BILL DETAILS

When the user selects a bill, display complete historical bill information:
- Bill information
- Order information
- Customer information
- Items
- Quantities
- Unit prices
- Line totals
- Subtotal
- Discount
- Tax
- Grand Total

Do not recalculate historical prices using current menu prices.

---

# 23. BILL CALCULATION CONSISTENCY

The calculation logic must have one source of truth.

Do not duplicate billing formulas in:
- GUI
- DAO
- PDF generator

The service/calculation layer should calculate:
- Subtotal
- Discount
- Tax
- Grand Total

---

# 24. DATABASE TRANSACTION

If bill creation uses multiple database operations, use a JDBC transaction.

```text
BEGIN
 ↓
Create Bill
 ↓
COMMIT
```

If creation fails:

```text
ROLLBACK
```

There is **NO payment transaction**.

---

# 25. ROLE-BASED ACCESS

Follow the existing project permissions.

Typical:

### ADMIN
- Generate bills
- View bills
- Print bills
- Search bills

### STAFF
- Generate bills
- View bills
- Print bills
- Search bills

Use the actual project's permission specification if different.

---

# 26. UI DESIGN

Billing UI must match:
- Dashboard
- Menu Management
- Customer Management
- Order Management

Maintain the same:
- Colors
- Typography
- Buttons
- Tables
- Sidebar
- Navigation
- Spacing

---

# 27. PROJECT STRUCTURE

```text
src/
└── main/
    └── java/
        └── com/
            └── restaurantbilling/

                model/
                    Bill.java

                dao/
                    BillDAO.java
                    impl/
                        BillDAOImpl.java

                service/
                    BillingService.java
                    InvoiceService.java

                gui/
                    billing/
                        BillingManagementPanel.java
                        BillDetailsDialog.java
                        BillHistoryPanel.java

                invoice/
                    InvoiceGenerator.java

                database/
                    DatabaseConnection.java

                util/
                    UserSession.java
```

### DO NOT CREATE

```text
Payment.java
PaymentDAO.java
PaymentDAOImpl.java
PaymentService.java
```

---

# 28. TESTING

## Test 1 — Select Order
Expected: Order details displayed.

## Test 2 — Calculate Subtotal
Expected: Correct subtotal.

## Test 3 — Calculate Tax
Expected: Correct according to project configuration.

## Test 4 — Calculate Discount
Expected: Correct according to project configuration.

## Test 5 — Calculate Grand Total
Expected:

```text
Subtotal - Discount + Tax
```

## Test 6 — Generate Bill
Expected: Bill saved in MySQL.

## Test 7 — Generate Bill for Already Billed Order
Expected: Duplicate bill prevented.

## Test 8 — View Bill
Expected: Complete bill displayed.

## Test 9 — Print Bill
Expected: Formatted bill printed.

## Test 10 — Generate PDF
Expected: Professional PDF created.

## Test 11 — Bill History
Expected: Previous bills displayed.

## Test 12 — Search Bill
Expected: Correct bills displayed.

---

# 29. DATABASE VALIDATION

Verify:
- Bill record exists.
- Correct `order_id`.
- Correct `customer_id`.
- Correct subtotal.
- Correct discount.
- Correct tax.
- Correct grand total.
- Correct bill date.
- No payment record is required.

---

# 30. SECURITY

Verify:
- [ ] PreparedStatement used
- [ ] No SQL injection
- [ ] No SQL inside GUI
- [ ] Database credentials protected
- [ ] Role restrictions applied
- [ ] No unnecessary customer data exposed

---

# 31. PERFORMANCE

Verify:
- [ ] Bill history loads quickly
- [ ] Search is responsive
- [ ] Bill generation is responsive
- [ ] PDF generation does not unnecessarily freeze GUI
- [ ] Database resources are closed
- [ ] No duplicate queries
- [ ] No duplicate event listeners

---

# 32. PHASE 10 SUCCESS CRITERIA

- [ ] Billing Management implemented
- [ ] Bill calculation implemented
- [ ] Tax implemented if defined
- [ ] Discount implemented if defined
- [ ] Grand total correct
- [ ] Bill saved in MySQL
- [ ] Duplicate bill prevention implemented
- [ ] Bill details implemented
- [ ] Bill history implemented
- [ ] Bill search implemented
- [ ] Bill filtering implemented where required
- [ ] PDF invoice implemented if required
- [ ] Print bill implemented
- [ ] Historical values preserved
- [ ] Role restrictions implemented
- [ ] No payment functionality exists
- [ ] Maven build succeeds
- [ ] Application runs successfully

---

# 33. STRICTLY FORBIDDEN

Do NOT implement:
- Payment Method
- Cash
- Card
- UPI
- Payment Gateway
- Amount Received
- Change
- Transaction Reference
- Payment Status
- Payment Table
- Payment DAO
- Payment Service
- Refund
- Payment Processing

The application ONLY generates and manages bills/invoices.

---

# 34. FINAL REPORT

After implementation provide:

## Files Created/Modified

List all modified/created files.

## Billing Architecture

```text
Order
 ↓
BillingService
 ↓
BillDAO
 ↓
MySQL
 ↓
InvoiceGenerator
```

## Bill Workflow

```text
Order
 ↓
Bill Calculation
 ↓
Bill Creation
 ↓
Bill Saved
 ↓
View / Print / PDF
```

## Test Results

Report:
- Bill Calculation: PASS/FAIL
- Tax: PASS/FAIL
- Discount: PASS/FAIL
- Grand Total: PASS/FAIL
- Bill Creation: PASS/FAIL
- Duplicate Bill Protection: PASS/FAIL
- Invoice: PASS/FAIL
- PDF: PASS/FAIL
- Print: PASS/FAIL
- Bill History: PASS/FAIL
- Search: PASS/FAIL
- Role Restriction: PASS/FAIL
- Database: PASS/FAIL
- Maven Build: PASS/FAIL

## Problems

List unresolved problems.

## Final Status

If everything passes:

```text
PHASE 10 COMPLETE

NEXT:
PHASE 11 — REPORTS & ANALYTICS
```

Do NOT automatically start Phase 11.
Wait for explicit approval.
