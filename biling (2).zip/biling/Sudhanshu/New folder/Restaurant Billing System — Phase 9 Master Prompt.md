# PHASE 9 — ORDER MANAGEMENT & ORDER CREATION

## Project

Continue developing the new **Restaurant Billing System**.

Completed phases:

- PHASE 1 — Project Setup & Foundation
- PHASE 2 — MySQL Database Design & Implementation
- PHASE 3 — JDBC Database Connectivity
- PHASE 4 — Model Classes & DAO Foundation
- PHASE 5 — Authentication & Login System
- PHASE 6 — Main Dashboard & Application Navigation
- PHASE 7 — Menu Management & Food Item CRUD
- PHASE 8 — Customer Management & Customer CRUD

Current phase:

- PHASE 9 — Order Management & Order Creation

Technology:

- Java 21
- Java Swing
- MySQL 8.x
- JDBC
- Maven
- IntelliJ IDEA
- MVC + DAO architecture

Master documentation:

Restaurant_Billing_System_Complete_Documentation.md

Treat the existing documentation and existing database schema as the source of truth.

---

# 1. PHASE 9 OBJECTIVE

Implement the complete Order Management module.

The module must allow authorized restaurant staff/admin users to:

- Create orders
- Select customer
- Select food items
- Add multiple food items
- Change quantities
- Remove items
- Calculate order subtotal
- Apply applicable discounts if defined
- Calculate taxes if defined
- Calculate final order total
- Save order
- View existing orders
- Search orders
- Filter orders
- Update order status
- Cancel orders where permitted

IMPORTANT:

The actual final BILLING/PAYMENT module will be implemented in a later phase.

This phase creates and manages the restaurant order.

---

# 2. IMPORTANT DATABASE RULE

Use the existing database schema.

Do NOT create duplicate:

- orders table
- order_items table
- customer table
- food_items table

Use the existing models and DAO architecture.

If the existing schema differs from the examples in this prompt, follow the actual schema.

---

# 3. ORDER ARCHITECTURE

Use:

OrderManagementPanel
        ↓
OrderService
        ↓
OrderDAO
        ↓
OrderDAOImpl
        ↓
DatabaseConnection
        ↓
MySQL

Order items should be handled through:

OrderService
        ↓
OrderItemDAO
        ↓
MySQL

Do not execute SQL directly from Swing components.

---

# 4. ORDER CREATION WORKFLOW

Implement this workflow:

Customer Selection
        ↓
Select Food Items
        ↓
Add Items to Cart
        ↓
Set Quantity
        ↓
Calculate Subtotal
        ↓
Apply Discount/Tax if applicable
        ↓
Calculate Total
        ↓
Review Order
        ↓
Save Order
        ↓
Order Confirmation

---

# 5. ORDER MANAGEMENT UI

Replace the Phase 6 placeholder with:

OrderManagementPanel

Recommended layout:

+----------------------------------------------------------------+
| ORDER MANAGEMENT                                               |
+----------------------------------------------------------------+
| Customer: [ Select Customer ▼ ]                               |
|                                                                |
| Search Food [____________] Category [All ▼]                   |
+----------------------------------------------------------------+
| Food Item | Category | Price | Available | Action             |
|-----------|----------|-------|-----------|--------------------|
| Pizza     | Pizza    | 250   | Yes       | [Add]              |
| Burger    | Burger   | 150   | Yes       | [Add]              |
+----------------------------------------------------------------+
| CURRENT ORDER                                                  |
+----------------------------------------------------------------+
| Item | Qty | Price | Amount | Action                           |
|------|-----|-------|--------|---------------------------------|
| Pizza| 2   | 250   | 500    | Remove                          |
| Coke | 1   | 50    | 50     | Remove                          |
+----------------------------------------------------------------+
| Subtotal:                              ₹550.00                 |
| Discount:                              ₹0.00                   |
| Tax:                                   ₹0.00                   |
| TOTAL:                                 ₹550.00                 |
|                                                                |
| [ Clear Order ]              [ PLACE ORDER ]                  |
+----------------------------------------------------------------+

Use a clean professional POS-style layout.

---

# 6. CUSTOMER SELECTION

Customer selection must use existing customers from MySQL.

Provide:

Customer:
[ Select Customer ]

Options may display:

Name
Phone

Do not create a second customer list inside Java.

---

# 7. CUSTOMER SEARCH

If the customer list is large, provide search.

Search by:

- Name
- Phone

Example:

Search:

Rahul

Then display matching customers.

The selected customer should be associated with the order.

---

# 8. WALK-IN CUSTOMER

If the existing project documentation/database supports walk-in customers, implement the defined approach.

If not, do NOT invent a new customer type.

Follow the existing database design.

---

# 9. FOOD ITEM SELECTION

Only food items that are currently available should be selectable for new orders.

Unavailable food items:

- may be displayed
- must not be added to the order

Clearly indicate:

Unavailable

Do not allow the user to bypass this restriction through the GUI.

---

# 10. FOOD SEARCH

Allow searching menu items by:

- Name
- Category

Example:

Search:

Pizza

Results:

Margherita Pizza
Chicken Pizza
Paneer Pizza

Use database-backed searching where appropriate.

---

# 11. CATEGORY FILTER

Provide:

Category [All ▼]

Categories should come from the existing menu data/schema.

Do not hardcode category data unnecessarily.

---

# 12. ADD ITEM TO ORDER

When user clicks:

[ADD]

Flow:

Food Item
    ↓
Check Availability
    ↓
Add to Current Order
    ↓
If Item Already Exists
    ↓
Increase Quantity
OR
Prevent duplicate row

Preferred behavior:

If the item already exists in the cart, increase its quantity rather than adding another duplicate line.

---

# 13. ORDER CART

Maintain a temporary in-memory cart while the order is being created.

Conceptually:

OrderCart
    |
    ├── FoodItem
    ├── Quantity
    ├── Unit Price
    └── Line Total

Do not write every cart click directly to MySQL.

Save the complete order only when the user places the order.

---

# 14. QUANTITY MANAGEMENT

Each order item must support quantity.

Example:

Pizza
Quantity: 2
Price: ₹250

Amount:

₹500

Allow:

[ + ]

and:

[ - ]

or editable quantity field.

Quantity must be:

- numeric
- integer
- greater than 0

---

# 15. QUANTITY VALIDATION

Invalid:

0
-1
1.5
abc

Valid:

1
2
5
10

If quantity becomes zero, either:

- remove the item automatically
OR
- prevent quantity from reaching zero

Choose one consistent behavior.

---

# 16. LINE TOTAL

For each order item:

Line Total = Unit Price × Quantity

Example:

Price = ₹200
Quantity = 3

Line Total:

₹600

Use:

BigDecimal

for all monetary calculations.

Do NOT use float/double.

---

# 17. ORDER SUBTOTAL

Calculate:

Subtotal = Sum of all line totals

Example:

Pizza = ₹500
Burger = ₹300
Drink = ₹100

Subtotal:

₹900

The subtotal must update immediately when:

- item added
- item removed
- quantity increased
- quantity decreased

---

# 18. DISCOUNT

If the existing project documentation/database defines discounts, implement them according to those rules.

If discounts are not defined yet:

Do NOT invent a complex discount system.

Keep:

Discount = ₹0.00

and prepare the architecture for future billing/discount implementation.

---

# 19. TAX

If tax configuration already exists in the project database/documentation, use it.

If tax is not defined yet:

Do not hardcode arbitrary tax rates.

Keep tax handling ready for the later billing phase.

All calculations must remain centralized.

---

# 20. TOTAL CALCULATION

Use:

Total =
Subtotal
- Discount
+ Tax

Example:

Subtotal = ₹1000
Discount = ₹100
Tax = ₹45

Total:

₹945

Use BigDecimal.

Never use floating-point arithmetic for currency.

---

# 21. ORDER STATUS

Use statuses defined by the database/documentation.

Typical example:

PENDING
CONFIRMED
PREPARING
READY
COMPLETED
CANCELLED

Do not add statuses to the database unless required by the existing specification.

---

# 22. CREATE ORDER

When:

[PLACE ORDER]

is clicked:

Validate:

- customer selected if required
- at least one item exists
- all items are still available
- quantities are valid
- calculated total is valid

Then:

Create Order
    ↓
Create Order Items
    ↓
Save transaction
    ↓
Generate order ID
    ↓
Show success

---

# 23. DATABASE TRANSACTION

Saving an order and its order items must be treated as one transaction.

Example:

BEGIN TRANSACTION

Insert Order

Insert Order Item 1
Insert Order Item 2
Insert Order Item 3

COMMIT

If any operation fails:

ROLLBACK

This is extremely important.

Never create an order record without its required order items.

---

# 24. TRANSACTION IMPLEMENTATION

Use JDBC:

Connection

setAutoCommit(false)

Then:

Order INSERT

OrderItem INSERTs

If everything succeeds:

commit()

If anything fails:

rollback()

Finally:

restore auto-commit state

Ensure resources are closed properly.

---

# 25. ORDER ID

Use the existing database-generated order ID strategy.

Do not manually generate conflicting IDs.

If MySQL uses:

AUTO_INCREMENT

use generated keys.

Example concept:

PreparedStatement.RETURN_GENERATED_KEYS

Then retrieve the generated order ID.

---

# 26. ORDER NUMBER

If the existing schema has a separate human-readable order number, use it.

Example:

ORD-2026-0001

Do not invent a new order-number system if the database already defines one.

If there is no such field, do not modify the database unnecessarily.

---

# 27. ORDER DATE/TIME

Use the database/application according to the existing schema.

Order timestamps should be accurate.

Prefer database-generated timestamps if the schema already defines them.

---

# 28. CLEAR CURRENT ORDER

Provide:

[CLEAR ORDER]

Confirmation:

Clear current order?

Yes / No

If confirmed:

- remove cart items
- reset customer selection
- reset totals
- reset filters if appropriate

Do not delete any saved order from the database.

---

# 29. REMOVE CART ITEM

Each cart row should provide:

[REMOVE]

Removing an item should immediately recalculate:

Subtotal
Discount
Tax
Total

---

# 30. ORDER PREVIEW

Before placing the order, show:

Customer
Items
Quantities
Prices
Subtotal
Discount
Tax
Total

The user should be able to review the complete order.

---

# 31. EXISTING ORDERS

The Order Management module should also provide a separate order-list view.

Recommended:

[CREATE NEW ORDER]
[VIEW ORDERS]

Order list:

+------------------------------------------------------------+
| ID | Customer | Date | Total | Status | Actions            |
+------------------------------------------------------------+

---

# 32. ORDER SEARCH

Allow searching existing orders by appropriate fields defined in the schema.

Possible:

- Order ID
- Order Number
- Customer Name
- Customer Phone

Use parameterized queries.

---

# 33. ORDER FILTER

Provide status filtering:

Status [All ▼]

Examples:

All
Pending
Confirmed
Preparing
Ready
Completed
Cancelled

Use only statuses defined by the project.

---

# 34. VIEW ORDER DETAILS

When an existing order is selected:

Show:

Order ID
Order Number if available
Customer
Order Date
Status

Order items:

Item
Quantity
Unit Price
Line Total

Summary:

Subtotal
Discount
Tax
Total

---

# 35. CANCEL ORDER

If cancellation is allowed by the existing business rules:

Provide:

[Cancel Order]

Confirmation:

Are you sure you want to cancel this order?

Do not physically delete completed historical orders.

Prefer status:

CANCELLED

when appropriate.

---

# 36. ORDER STATUS UPDATE

Authorized users may update order status according to the project's role permissions.

Do not allow invalid status transitions if the documentation defines a workflow.

Example:

PENDING
→ CONFIRMED
→ PREPARING
→ READY
→ COMPLETED

Cancelled orders should not return to active states unless explicitly allowed.

---

# 37. ORDER SERVICE

Create:

service/OrderService.java

Responsibilities:

- Create order
- Validate order
- Calculate totals
- Save order transactionally
- Retrieve orders
- Retrieve order details
- Search orders
- Filter orders
- Update status
- Cancel order

Do not put all business logic inside Swing components.

---

# 38. ORDER DAO

Reuse existing:

OrderDAO

OrderDAOImpl

OrderItemDAO

OrderItemDAOImpl

Complete them if required.

Do NOT create duplicate DAO classes.

---

# 39. REQUIRED DAO OPERATIONS

Depending on existing architecture, support operations equivalent to:

OrderDAO:

createOrder()
findById()
findAll()
search()
updateStatus()
cancelOrder()

OrderItemDAO:

createOrderItem()
findByOrderId()
deleteByOrderId()

Prefer transactional coordination in the service layer rather than independent commits.

---

# 40. ORDER MODEL

Use the existing:

Order

and:

OrderItem

models.

Ensure they correctly represent:

Order:

- id
- customer
- date/time
- status
- subtotal
- discount
- tax
- total

OrderItem:

- id
- orderId
- foodItemId
- quantity
- unitPrice
- lineTotal

Only use fields that actually exist in the database.

---

# 41. HISTORICAL PRICE

When an order is saved, preserve the unit price used at the time of ordering.

Do not calculate historical orders using the current menu price.

Example:

Today:

Burger = ₹150

Order created:

Quantity = 2

Unit Price = ₹150

Later menu changes:

Burger = ₹180

The existing order must still show:

Unit Price = ₹150

This is critical for billing/history.

---

# 42. AVAILABILITY RACE CONDITION

Before saving an order:

Re-check that every selected food item is still available.

Reason:

Another user may have disabled an item after it was added to the cart.

If an item is no longer available:

Do not place the order.

Show:

One or more selected items are no longer available. Please review the order.

---

# 43. CONCURRENT ORDER SAFETY

Do not assume that the menu state cannot change while the order is being created.

Use appropriate validation before commit.

Do not introduce unnecessarily complex locking unless required.

---

# 44. ROLE-BASED ACCESS

Follow existing project permissions.

Typical:

ADMIN:

- Create order
- View orders
- Update status
- Cancel order

STAFF:

- Create order
- View orders
- Perform operational status updates

Use the project's actual documentation if it defines different permissions.

---

# 45. UI RESPONSIVENESS

Order creation is an important operational workflow.

The GUI must remain responsive.

Do not perform long database operations directly on the EDT.

Use background processing where appropriate.

The cart calculations themselves should be instant and local.

---

# 46. ORDER CALCULATION DESIGN

Create a centralized calculation mechanism.

For example:

OrderCalculationService

or methods inside:

OrderService

Do not duplicate calculation formulas across:

- UI
- DAO
- billing

The calculation must have one source of truth.

---

# 47. MONEY FORMATTING

Display prices consistently:

₹250.00

₹1,250.00

Use a centralized currency formatter.

Do not use different formats throughout the application.

Internally continue using:

BigDecimal

---

# 48. UI DESIGN

The Order Management UI must match:

- Phase 6 Dashboard
- Phase 7 Menu Management
- Phase 8 Customer Management

Use the same:

- colors
- typography
- button styles
- spacing
- table styles
- sidebar
- top bar

The order screen may use a POS-style two-panel layout, but it must remain visually consistent.

---

# 49. PROJECT STRUCTURE AFTER PHASE 9

Relevant structure:

src/
└── main/
    ├── java/
    │   └── com/
    │       └── restaurantbilling/
    │           │
    │           ├── model/
    │           │   ├── Order.java
    │           │   └── OrderItem.java
    │           │
    │           ├── dao/
    │           │   ├── OrderDAO.java
    │           │   ├── OrderItemDAO.java
    │           │   └── impl/
    │           │       ├── OrderDAOImpl.java
    │           │       └── OrderItemDAOImpl.java
    │           │
    │           ├── service/
    │           │   ├── AuthenticationService.java
    │           │   ├── FoodItemService.java
    │           │   ├── CustomerService.java
    │           │   └── OrderService.java
    │           │
    │           ├── gui/
    │           │   ├── MainFrame.java
    │           │   │
    │           │   └── order/
    │           │       ├── OrderManagementPanel.java
    │           │       ├── OrderCreationPanel.java
    │           │       ├── OrderDetailsDialog.java
    │           │       └── OrderCartPanel.java
    │           │
    │           ├── database/
    │           │   └── DatabaseConnection.java
    │           │
    │           └── util/
    │               └── UserSession.java
    │
    └── resources/

Only create classes that are actually useful.

---

# 50. TESTING

## Test 1 — Load Available Menu

Expected:

PASS

Available food items are displayed.

---

## Test 2 — Select Customer

Expected:

PASS

Customer selected successfully.

---

## Test 3 — Add One Item

Example:

Pizza
Quantity: 1
Price: ₹250

Expected:

PASS

Cart contains one item.

---

## Test 4 — Add Same Item Again

Expected:

PASS

Quantity becomes 2 rather than creating an unnecessary duplicate row.

---

## Test 5 — Increase Quantity

2 → 3

Expected:

PASS

Line total recalculates.

---

## Test 6 — Decrease Quantity

3 → 2

Expected:

PASS

Line total recalculates.

---

## Test 7 — Remove Item

Expected:

PASS

Item removed and totals recalculated.

---

## Test 8 — Multiple Items

Example:

Pizza × 2
Burger × 1
Coke × 2

Expected:

PASS

Correct subtotal.

---

## Test 9 — Total Calculation

Verify:

Subtotal
+
Tax
-
Discount
=
Total

Expected:

PASS

---

## Test 10 — Clear Order

Expected:

PASS

Cart and customer selection reset.

---

## Test 11 — Place Order

Expected:

PASS

Order and all order items saved successfully.

---

## Test 12 — Transaction Failure

Simulate a database failure while saving order items.

Expected:

PASS

Entire transaction rolls back.

No incomplete order remains.

---

## Test 13 — Historical Price

Create order at:

₹150

Change menu price to:

₹180

View existing order.

Expected:

PASS

Existing order remains ₹150.

---

## Test 14 — Unavailable Item

Disable a food item.

Attempt to add it.

Expected:

PASS

Item cannot be added.

---

## Test 15 — Availability Changes Before Checkout

Add item.

Disable item from another flow.

Attempt to place order.

Expected:

PASS

Order is blocked and user receives a clear message.

---

## Test 16 — Search Orders

Search by order/customer information.

Expected:

PASS

Correct orders displayed.

---

## Test 17 — Order Status

Change status according to allowed workflow.

Expected:

PASS

Database updated correctly.

---

## Test 18 — Cancel Order

Expected:

PASS

Order becomes CANCELLED rather than being incorrectly removed from history.

---

# 51. DATABASE VALIDATION

Verify actual MySQL data.

For a successful order:

orders table:

Correct order record.

order_items table:

Correct number of item records.

Relationships:

Correct order ID.

Correct food item IDs.

Correct quantities.

Correct historical unit prices.

Correct line totals.

Correct subtotal/discount/tax/total according to schema.

---

# 52. TRANSACTION VALIDATION

Test:

Order creation:

BEGIN
 ↓
Order INSERT
 ↓
OrderItem INSERT
 ↓
COMMIT

Failure:

BEGIN
 ↓
Order INSERT
 ↓
OrderItem INSERT FAIL
 ↓
ROLLBACK

Expected:

No incomplete order.

---

# 53. SECURITY CHECKLIST

Verify:

[ ] PreparedStatement used
[ ] No SQL injection
[ ] GUI does not execute SQL
[ ] Role restrictions applied
[ ] Unauthorized order actions blocked
[ ] No database credentials exposed
[ ] Raw SQL errors not shown
[ ] Customer information handled appropriately

---

# 54. PERFORMANCE CHECKLIST

Verify:

[ ] Menu search is responsive
[ ] Customer search is responsive
[ ] Cart calculations are instant
[ ] GUI does not freeze
[ ] Database operations are properly managed
[ ] No unnecessary repeated queries
[ ] No duplicate event listeners
[ ] Large order does not break UI

---

# 55. PHASE 9 SUCCESS CRITERIA

Phase 9 is complete only when:

[ ] Order Management implemented
[ ] Customer selection works
[ ] Food selection works
[ ] Available-item restriction works
[ ] Cart implemented
[ ] Multiple items supported
[ ] Quantity controls work
[ ] Remove item works
[ ] Subtotal calculation works
[ ] Discount architecture prepared
[ ] Tax architecture prepared
[ ] Total calculation works
[ ] Order creation works
[ ] Order items saved
[ ] JDBC transaction implemented
[ ] Rollback tested
[ ] Order search works
[ ] Order filtering works
[ ] Order details work
[ ] Order status works
[ ] Cancellation works
[ ] Historical prices preserved
[ ] Role restrictions work
[ ] MySQL validated
[ ] Maven build succeeds
[ ] Application runs successfully

---

# 56. DO NOT START PHASE 10

Do NOT implement:

- Final billing
- Invoice generation
- Payment processing
- Receipt printing
- PDF invoice generation

Those belong to the next phase.

Stop after Phase 9 validation.

---

# 57. REQUIRED FINAL REPORT

After implementation, provide:

## Files Created/Modified

List every file.

## Order Architecture

Show:

OrderManagementPanel
        ↓
OrderService
        ↓
OrderDAO / OrderItemDAO
        ↓
MySQL Transaction

## Order Workflow

Show:

Customer
 ↓
Food Items
 ↓
Cart
 ↓
Calculation
 ↓
Order
 ↓
Order Items
 ↓
COMMIT

## Test Results

Customer Selection: PASS/FAIL

Food Selection: PASS/FAIL

Cart: PASS/FAIL

Quantity: PASS/FAIL

Remove Item: PASS/FAIL

Subtotal: PASS/FAIL

Tax: PASS/FAIL

Discount: PASS/FAIL

Total: PASS/FAIL

Order Save: PASS/FAIL

Transaction Rollback: PASS/FAIL

Historical Price: PASS/FAIL

Search: PASS/FAIL

Filter: PASS/FAIL

Status: PASS/FAIL

Cancellation: PASS/FAIL

Role Restriction: PASS/FAIL

Database: PASS/FAIL

Maven Build: PASS/FAIL

## Problems

List unresolved issues.

## Final Status

If all requirements pass:

PHASE 9 COMPLETE

NEXT:

PHASE 10 — Billing, Invoice & Payment Management

Do NOT automatically start Phase 10.

Wait for explicit approval.