# PHASE 5 — AUTHENTICATION & LOGIN SYSTEM

## Project

Continue developing the new **Restaurant Billing System**.

Completed phases:

- PHASE 1 — Project Setup & Foundation
- PHASE 2 — MySQL Database Design & Implementation
- PHASE 3 — JDBC Database Connectivity
- PHASE 4 — Model Classes & DAO Foundation

Current phase:

- PHASE 5 — Authentication & Login System

Technology stack:

- Java 21
- Java Swing
- MySQL 8.x
- JDBC
- Maven
- IntelliJ IDEA
- MVC + DAO architecture

Master specification:

`Restaurant_Billing_System_Complete_Documentation.md`

Treat the documentation and existing project architecture as the source of truth.

---

# 1. PHASE 5 OBJECTIVE

Implement a complete and professional authentication system.

The authentication flow should be:

```text
Application
    ↓
Login Screen
    ↓
Enter Username + Password
    ↓
AuthenticationService
    ↓
UserDAO
    ↓
JDBC
    ↓
MySQL
    ↓
Validate User
    ↓
Check Role
    ↓
Successful Login
    ↓
Dashboard
```

At the end of this phase:

- Login GUI must work.
- Username/password validation must work.
- Database authentication must work.
- Invalid credentials must be handled correctly.
- ADMIN and STAFF roles must be recognized.
- Logout must be supported.
- Session information must be maintained safely.
- Unauthorized access must be prevented.
- Login UI must be professional.
- No password should be exposed in logs or UI.

---

# 2. IMPORTANT RULES

Do NOT build the complete dashboard yet.

Create only the minimum dashboard placeholder required to verify successful login.

Do NOT implement menu management.

Do NOT implement customer management.

Do NOT implement order management.

Do NOT implement billing.

Do NOT implement reports.

Those belong to later phases.

---

# 3. AUTHENTICATION ARCHITECTURE

Use:

```text
LoginFrame
    ↓
AuthenticationService
    ↓
UserDAO
    ↓
UserDAOImpl
    ↓
DatabaseConnection
    ↓
MySQL
```

Do not allow:

```text
LoginFrame → MySQL
```

The GUI must never directly execute SQL.

---

# 4. AUTHENTICATION SERVICE

Create:

```text
service/
└── AuthenticationService.java
```

Responsibilities:

- Authenticate user.
- Validate username.
- Validate password.
- Retrieve user using `UserDAO`.
- Verify credentials.
- Determine role.
- Create/update user session.
- Return authentication result.

The service should contain authentication-related business logic.

---

# 5. PASSWORD SECURITY

Do NOT compare passwords by putting raw SQL together with user input.

Always use:

```text
PreparedStatement
```

for database operations.

For a real production system, passwords should be stored using a strong password hashing algorithm such as:

```text
BCrypt
```

Do NOT store plaintext production passwords.

If the current Phase 2 sample database contains plaintext demo passwords, treat them as temporary development data and design the authentication layer so password hashing can be used properly.

Do not print passwords.

Do not display passwords in error messages.

Do not include passwords in `toString()`.

---

# 6. LOGIN GUI

Create:

```text
gui/
└── LoginFrame.java
```

The login screen should contain:

```text
-----------------------------------------
       RESTAURANT BILLING SYSTEM

       Username
       [____________________]

       Password
       [____________________]

       [       LOGIN       ]

       [      CLEAR       ]

       Status / Error Message
-----------------------------------------
```

The design should be professional and clean.

Use Java Swing.

---

# 7. LOGIN GUI DESIGN

Use a modern restaurant-oriented desktop UI.

Recommended visual direction:

- clean dark/light restaurant theme
- professional typography
- clear input fields
- rounded-looking controls where feasible with Swing
- consistent spacing
- clear hierarchy
- professional buttons
- subtle hover effects
- responsive resizing where practical

Do not overload the screen with unnecessary animations.

Functionality is more important than decoration.

---

# 8. LOGIN VALIDATION

Before calling the database:

Validate:

### Username

```text
Not empty
```

### Password

```text
Not empty
```

If username is empty:

```text
Please enter your username.
```

If password is empty:

```text
Please enter your password.
```

Do not query the database for obviously invalid empty input.

---

# 9. LOGIN PROCESS

When the user presses LOGIN:

```text
Login Button
     ↓
Validate Input
     ↓
AuthenticationService
     ↓
UserDAO.findByUsername()
     ↓
User Found?
     ↓
Password Verification
     ↓
Role Verification
     ↓
Create Session
     ↓
Open Dashboard Placeholder
```

The login button must not freeze the GUI unnecessarily.

Use Swing-safe execution where appropriate.

---

# 10. INVALID LOGIN

If credentials are incorrect, display a generic message such as:

```text
Invalid username or password.
```

Do NOT reveal:

```text
Username exists but password is wrong.
```

or:

```text
Username does not exist.
```

This avoids unnecessary account enumeration.

---

# 11. SUCCESSFUL LOGIN

After successful authentication:

```text
LoginFrame
     ↓
close/hide login
     ↓
Dashboard placeholder
```

The dashboard should show something similar to:

```text
Welcome, <username>

Role: ADMIN
```

or:

```text
Welcome, <username>

Role: STAFF
```

This is only a temporary Phase 5 dashboard.

The complete dashboard will be implemented later.

---

# 12. USER SESSION

Create a simple session management class:

```text
util/
└── UserSession.java
```

It should maintain the currently authenticated user.

Possible information:

```text
userId
username
role
```

Do NOT store the password in the session.

Example concept:

```text
UserSession
    |
    ├── userId
    ├── username
    └── role
```

---

# 13. SESSION OPERATIONS

Provide functionality conceptually equivalent to:

```text
login(user)
getCurrentUser()
isLoggedIn()
hasRole()
logout()
```

Do not allow multiple unrelated session objects to create inconsistent authentication state.

Keep the implementation simple.

---

# 14. ROLE MANAGEMENT

The database currently supports:

```text
ADMIN
STAFF
```

Authentication must correctly identify the role.

Example:

```text
ADMIN
 ↓
Full administrative access
```

```text
STAFF
 ↓
Operational restaurant features
```

Do not implement every permission rule yet.

However, the architecture must be ready for role-based access control.

---

# 15. ROLE-BASED ACCESS PREPARATION

Create a utility or mechanism that can later support:

```text
isAdmin()
isStaff()
hasRole("ADMIN")
```

Do not scatter role checks throughout random GUI classes.

Prepare a clean authorization mechanism.

---

# 16. LOGOUT

Implement logout in the temporary dashboard.

Flow:

```text
Logout
   ↓
UserSession.logout()
   ↓
Dashboard closes
   ↓
LoginFrame appears
```

After logout:

```text
isLoggedIn() == false
```

The previous user must no longer be treated as authenticated.

---

# 17. MULTIPLE LOGIN TEST

Test:

```text
ADMIN login
    ↓
Dashboard
    ↓
Logout
    ↓
Login screen
    ↓
STAFF login
    ↓
Dashboard
```

Verify that the previous session does not leak into the new login.

---

# 18. AUTHENTICATION DAO

Use the existing:

```text
UserDAO
UserDAOImpl
```

created in Phase 4.

Do NOT create a second database-access implementation.

Authentication should use:

```text
UserDAO.findByUsername()
```

or an equivalent method already defined.

---

# 19. SQL SECURITY

All authentication queries must use parameterized SQL.

Example concept:

```sql
SELECT id, username, password, role, created_at, updated_at
FROM users
WHERE username = ?
```

Use:

```text
PreparedStatement
```

Never concatenate username values into SQL.

---

# 20. PASSWORD FIELD

Use:

```text
JPasswordField
```

instead of:

```text
JTextField
```

for password entry.

Do not unnecessarily retain password characters in memory longer than needed.

---

# 21. LOGIN BUTTON BEHAVIOR

Prevent multiple accidental login submissions.

While authentication is executing:

```text
Login button → temporarily disabled
```

After completion:

```text
Login button → enabled
```

Do not allow the user to accidentally trigger many simultaneous authentication requests.

---

# 22. ENTER KEY

Support pressing:

```text
ENTER
```

to trigger login when the user is inside the password field or appropriate login controls.

This improves usability.

---

# 23. CLEAR BUTTON

Implement:

```text
CLEAR
```

Behavior:

```text
Username → empty
Password → empty
Status → cleared
Focus → username field
```

---

# 24. PASSWORD VISIBILITY

Optionally provide:

```text
☐ Show Password
```

If implemented:

- password can temporarily become visible
- unchecking hides it again

Keep this feature simple.

---

# 25. DATABASE FAILURE HANDLING

If MySQL is unavailable:

Do not show a raw stack trace to the user.

Show a friendly message:

```text
Unable to connect to the database.
Please contact the administrator or verify the database server.
```

Log technical details appropriately for developers.

Do not expose:

```text
password
connection credentials
internal stack traces
```

to normal users.

---

# 26. AUTHENTICATION EXCEPTION HANDLING

If the project uses:

```text
DatabaseException
```

from previous phases, use it consistently.

Authentication failures should be distinguishable from:

```text
Database unavailable
```

For example:

```text
Invalid credentials
```

versus:

```text
Database connection error
```

Do not treat every exception as "Invalid username or password."

---

# 27. LOGIN WINDOW BEHAVIOR

The login window should:

- open correctly
- be centered on screen
- have a reasonable default size
- prevent accidental duplicate login windows
- close cleanly
- not expose internal exceptions
- use the project's application title

Application title:

```text
Restaurant Billing System
```

---

# 28. DASHBOARD PLACEHOLDER

Create a minimal temporary:

```text
DashboardFrame.java
```

It should show:

```text
Restaurant Billing System

Welcome, <username>

Role: <role>

[ Logout ]
```

This is NOT the final dashboard.

Do not implement dashboard statistics yet.

---

# 29. MAIN APPLICATION FLOW

Update `Main.java` so the application starts with:

```text
Main
 ↓
LoginFrame
 ↓
Authentication
 ↓
DashboardFrame
```

Do not automatically log users in.

The user must authenticate.

---

# 30. AUTHENTICATION TEST USERS

Use the demo users from:

```text
database/sample_data.sql
```

Do not hardcode usernames/passwords into:

```text
LoginFrame
AuthenticationService
Main
```

The login system must authenticate against MySQL.

---

# 31. TEST SCENARIOS

Perform at least the following tests.

## Test 1 — Valid ADMIN login

Expected:

```text
PASS
ADMIN dashboard opens.
```

## Test 2 — Valid STAFF login

Expected:

```text
PASS
STAFF dashboard opens.
```

## Test 3 — Wrong password

Expected:

```text
PASS
Invalid username or password.
```

## Test 4 — Unknown username

Expected:

```text
PASS
Invalid username or password.
```

## Test 5 — Empty username

Expected:

```text
PASS
Validation message.
No database query.
```

## Test 6 — Empty password

Expected:

```text
PASS
Validation message.
No database query.
```

## Test 7 — Database unavailable

Expected:

```text
PASS
Friendly database error.
Application does not crash.
```

## Test 8 — Logout

Expected:

```text
PASS
Session cleared.
Login screen displayed.
```

## Test 9 — Login after logout

Expected:

```text
PASS
New user can authenticate.
```

## Test 10 — Password not exposed

Verify:

```text
PASS
No password appears in logs.
No password appears in session.
No password appears in toString().
```

---

# 32. SECURITY CHECKLIST

Verify:

```text
[ ] PreparedStatement used
[ ] No SQL injection vulnerability
[ ] Password not printed
[ ] Password not stored in UserSession
[ ] Password not included in toString()
[ ] Generic invalid-login message
[ ] Database credentials not hardcoded
[ ] Database errors handled safely
[ ] Logout clears session
```

---

# 33. PROJECT STRUCTURE AFTER PHASE 5

The relevant structure should become:

```text
src/
└── main/
    ├── java/
    │   └── com/
    │       └── restaurantbilling/
    │           │
    │           ├── Main.java
    │           │
    │           ├── model/
    │           │   ├── User.java
    │           │   ├── FoodItem.java
    │           │   ├── Customer.java
    │           │   ├── Order.java
    │           │   ├── OrderItem.java
    │           │   └── Bill.java
    │           │
    │           ├── dao/
    │           │   ├── UserDAO.java
    │           │   ├── FoodItemDAO.java
    │           │   ├── CustomerDAO.java
    │           │   ├── OrderDAO.java
    │           │   ├── OrderItemDAO.java
    │           │   ├── BillDAO.java
    │           │   │
    │           │   └── impl/
    │           │
    │           ├── database/
    │           │   └── DatabaseConnection.java
    │           │
    │           ├── service/
    │           │   └── AuthenticationService.java
    │           │
    │           ├── gui/
    │           │   ├── LoginFrame.java
    │           │   └── DashboardFrame.java
    │           │
    │           ├── util/
    │           │   └── UserSession.java
    │           │
    │           └── exception/
    │
    └── resources/
        ├── db.properties
        └── db.properties.example
```

---

# 34. UI QUALITY REQUIREMENTS

The login screen must not look like a basic default Swing form.

Use:

- consistent margins
- proper alignment
- readable fonts
- clear button hierarchy
- professional spacing
- appropriate window sizing
- keyboard accessibility
- clear validation messages

Do not spend excessive time on animations in this phase.

The application must remain fast and stable.

---

# 35. PERFORMANCE

The login process should not unnecessarily block the Swing Event Dispatch Thread for long database operations.

Use an appropriate Swing background mechanism if needed.

After authentication completes, safely update the GUI on the EDT.

Do not create unnecessary threads.

---

# 36. DO NOT IMPLEMENT YET

Do NOT implement:

```text
Food/Menu Management
Customer Management
Order Management
Billing
Bill Printing
Reports
Analytics
Advanced Dashboard
```

Those belong to later phases.

Only create the temporary dashboard needed to prove authentication works.

---

# 37. PHASE 5 VALIDATION CHECKLIST

Before declaring Phase 5 complete:

```text
[ ] AuthenticationService created
[ ] LoginFrame created
[ ] DashboardFrame placeholder created
[ ] UserSession created
[ ] UserDAO reused
[ ] Database authentication works
[ ] ADMIN login works
[ ] STAFF login works
[ ] Invalid login handled
[ ] Empty input validation works
[ ] Database failure handled
[ ] Logout works
[ ] Session clears correctly
[ ] Password not exposed
[ ] PreparedStatement used
[ ] No GUI-to-database direct access
[ ] Maven build succeeds
[ ] Application runs
[ ] All authentication tests pass
```

---

# 38. REQUIRED FINAL REPORT

After completing Phase 5, provide:

## Files Created/Modified

List all files.

## Authentication Architecture

Show:

```text
LoginFrame
    ↓
AuthenticationService
    ↓
UserDAO
    ↓
UserDAOImpl
    ↓
DatabaseConnection
    ↓
MySQL
```

## Session Architecture

Show:

```text
Successful Login
      ↓
UserSession
      ↓
Dashboard
```

## Test Results

Report:

```text
ADMIN login: PASS/FAIL
STAFF login: PASS/FAIL
Wrong password: PASS/FAIL
Unknown username: PASS/FAIL
Empty username: PASS/FAIL
Empty password: PASS/FAIL
Database failure: PASS/FAIL
Logout: PASS/FAIL
Re-login: PASS/FAIL
Password protection: PASS/FAIL
Maven build: PASS/FAIL
```

## Problems

List any unresolved issues.

## Final Status

If all tests pass:

```text
PHASE 5 COMPLETE

NEXT:
PHASE 6 — Main Dashboard & Application Navigation
```

Do NOT automatically start Phase 6.

Wait for explicit approval.