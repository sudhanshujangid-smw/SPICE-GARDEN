============================================================
PHASE 12 — SYSTEM SETTINGS & RESTAURANT CONFIGURATION
============================================================

PROJECT:
Restaurant Billing System

TECHNOLOGY:
- Java 21
- Java Swing
- MySQL 8.x
- JDBC
- Maven
- IntelliJ IDEA
- MVC + DAO architecture

============================================================
PROJECT STATUS
============================================================

Completed:

PHASE 1 — Project Setup & Foundation
PHASE 2 — MySQL Database
PHASE 3 — JDBC Connectivity
PHASE 4 — Model Classes & DAO Foundation
PHASE 5 — Authentication & Login
PHASE 6 — Dashboard & Navigation
PHASE 7 — Menu Management
PHASE 8 — Customer Management
PHASE 9 — Order Management
PHASE 10 — Bill Generation & Invoice Management
PHASE 11 — Reports & Analytics

CURRENT:

PHASE 12 — SYSTEM SETTINGS & RESTAURANT CONFIGURATION


============================================================
IMPORTANT BUSINESS RULE
============================================================

THIS RESTAURANT BILLING SYSTEM DOES NOT PROCESS PAYMENTS.

There is NO payment functionality.

DO NOT add any payment-related functionality during this phase.

STRICTLY FORBIDDEN:

- Payment Settings
- Payment Methods
- Cash Payment
- Card Payment
- UPI Payment
- Payment Gateway
- Payment Credentials
- Payment Transactions
- Payment Status
- Refunds
- Payment Reports
- Payment Analytics
- Payment Configuration

The system is ONLY responsible for restaurant configuration and application settings.


============================================================
1. PHASE OBJECTIVE
============================================================

Implement a centralized:

SYSTEM SETTINGS & RESTAURANT CONFIGURATION

module.

The module should allow authorized administrators to configure restaurant information and settings that are reused throughout the application.

Settings must be stored in MySQL and loaded dynamically.

DO NOT hardcode restaurant information inside Java source code.

DO NOT create a separate application.

Modify the existing Restaurant Billing System.


============================================================
2. SETTINGS NAVIGATION
============================================================

Add Settings to the existing application navigation.

Recommended:

Dashboard
Menu
Customers
Orders
Billing
Reports
Settings
Logout

Do not break the existing navigation.

Follow the existing UI architecture.


============================================================
3. SETTINGS ACCESS
============================================================

Use the existing authentication and authorization system.

Recommended:

ADMIN:
- View settings
- Edit settings
- Save settings
- Update settings

STAFF:
- No modification access unless existing permissions explicitly allow it.

Do not create a completely new authentication system.

Do not rely only on hiding the Settings button.

Authorization must also be enforced in application logic.


============================================================
4. SETTINGS PANEL
============================================================

Create:

SettingsPanel

Recommended UI:

+--------------------------------------------------------------+
| SYSTEM SETTINGS                                              |
+--------------------------------------------------------------+
|                                                              |
| [Restaurant] [Invoice] [Application]                        |
|                                                              |
+--------------------------------------------------------------+
| Restaurant Name: [____________________________]              |
| Address:         [____________________________]              |
| City:            [____________________________]              |
| State:           [____________________________]              |
| PIN Code:        [____________________________]              |
| Phone:           [____________________________]              |
| Email:           [____________________________]              |
| Website:         [____________________________]              |
|                                                              |
| Logo:            [Choose Logo] [Preview]                    |
|                                                              |
|                         [SAVE] [RESET]                       |
+--------------------------------------------------------------+

Use tabs/cards according to the existing application's UI design.


============================================================
5. RESTAURANT INFORMATION
============================================================

Implement a Restaurant Information section.

Fields may include:

- Restaurant Name
- Restaurant Address
- City
- State
- PIN/Postal Code
- Phone Number
- Email Address
- Website

Use only fields appropriate for the existing project.

Example:

Restaurant Name:
[____________________________]

Address:
[____________________________]

City:
[____________________________]

State:
[____________________________]

PIN Code:
[____________________________]

Phone:
[____________________________]

Email:
[____________________________]

Website:
[____________________________]


============================================================
6. RESTAURANT LOGO
============================================================

If supported by the existing application, allow the administrator to configure a restaurant logo.

Features:

- Choose Logo
- Preview Logo
- Save Logo
- Update Logo
- Display Logo where appropriate
- Use Logo in invoice generation if supported

Do not store unnecessarily large images directly in MySQL.

Prefer a safe application-managed image/resource path if compatible with the current architecture.

Do not break invoice generation.


============================================================
7. INVOICE CONFIGURATION
============================================================

Create an Invoice Configuration section.

Possible settings:

- Invoice Header
- Invoice Restaurant Name
- Invoice Address
- Invoice Contact
- Invoice Footer
- Thank You Message
- Bill Number Prefix, ONLY if already supported by the existing design

Example:

Invoice Footer:

[Thank you for visiting our restaurant!]

Thank You Message:

[Thank you for your visit.]

These values must be used dynamically by the existing invoice generator.

DO NOT create a second invoice generator.

Reuse the Phase 10 invoice system.


============================================================
8. TAX CONFIGURATION
============================================================

ONLY implement tax configuration if tax is already part of the project's billing/database requirements.

If tax already exists:

Allow authorized admin to configure the applicable tax rate.

Example:

Tax Rate:
[____] %

Validation:

Tax Rate >= 0

Do not allow negative values.

IMPORTANT:

If the project has NOT defined tax configuration, DO NOT invent a tax system or tax rate.

Keep the existing billing behavior unchanged.


============================================================
9. DISCOUNT CONFIGURATION
============================================================

ONLY implement discount configuration if discount functionality already exists in the project.

If discounts are not currently part of the project:

DO NOT create a new discount management module.

Do not expand the project scope unnecessarily.


============================================================
10. APPLICATION SETTINGS
============================================================

Only add application settings that are actually useful and compatible with the existing project.

Possible settings:

- Date Format
- Time Format
- Currency Display
- Default Screen
- Auto Refresh Preference

Do not create unnecessary settings.

Do not add payment settings.


============================================================
11. CURRENCY
============================================================

If currency display is configurable:

Default:

INR

Currency symbol:

₹

IMPORTANT:

Currency is ONLY for displaying billing amounts.

Currency configuration must NOT be interpreted as payment functionality.

Do not create payment processing.


============================================================
12. DATABASE DESIGN
============================================================

FIRST inspect the existing MySQL schema.

Before creating a new settings table:

1. Check whether a settings/configuration table already exists.
2. Reuse the existing table if possible.
3. Do not create duplicate configuration tables.
4. Follow the existing database naming conventions.

If a settings table is genuinely required and does not exist, a centralized structure may be used:

system_settings

Possible fields:

setting_id
setting_key
setting_value
description
updated_at
updated_by

IMPORTANT:

Do not blindly create these fields.

Use the actual project's database architecture as the source of truth.


============================================================
13. SETTINGS MODEL
============================================================

If required, create:

SystemSetting.java

Optional:

RestaurantSettings.java
InvoiceSettings.java

Only create these if they are actually required.

Do not create duplicate models if equivalent classes already exist.


============================================================
14. SETTINGS DAO
============================================================

Create/use:

SettingsDAO

Implementation:

SettingsDAOImpl

Possible methods:

getSetting()
getAllSettings()
saveSetting()
updateSetting()

Only implement methods that are actually needed.

Use PreparedStatement for every database operation.


============================================================
15. SETTINGS SERVICE
============================================================

Create/use:

SettingsService

Responsibilities:

- Load settings
- Validate settings
- Save settings
- Update settings
- Provide restaurant settings to invoice generation
- Provide invoice settings to invoice generation
- Provide application settings where required

Do not put SQL queries inside Swing UI classes.


============================================================
16. SETTINGS VALIDATION
============================================================

Validate before saving.

Restaurant Name:

- Cannot be empty.

Email:

- Validate email format if provided.

Phone:

- Validate appropriate phone format if provided.

PIN Code:

- Validate appropriate format if provided.

Tax:

- Must not be negative if tax exists.

Website:

- Validate only if website configuration is enabled.

IMPORTANT:

Do not make optional fields mandatory without a project requirement.


============================================================
17. SAVE WORKFLOW
============================================================

When user clicks:

[SAVE]

Workflow:

Validate
   ↓
Save to MySQL
   ↓
Refresh application settings
   ↓
Show success message

Success:

"Settings saved successfully."

Failure:

"Unable to save settings."

Do not show raw SQL exceptions to users.


============================================================
18. UPDATE WORKFLOW
============================================================

When existing settings are changed:

Validate
   ↓
Update MySQL
   ↓
Refresh application configuration
   ↓
Update relevant UI
   ↓
Show success message

Do not require application restart unless absolutely necessary.


============================================================
19. RESET BUTTON
============================================================

The:

[RESET]

button must restore the form to the LAST SAVED VALUES.

It must NOT delete settings.

It must NOT reset the entire database.

It must NOT create default values unless no saved configuration exists.


============================================================
20. DEFAULT SETTINGS
============================================================

If no settings exist, provide safe defaults.

Example:

Restaurant Name:
Restaurant Billing System

Currency:
₹

Invoice Footer:
Thank you for visiting us!

IMPORTANT:

Do not create fake restaurant information.

Do not use fake address, phone number, email, GST number, etc.


============================================================
21. SETTINGS CACHE
============================================================

If appropriate, create a lightweight application-level settings object.

Example:

ApplicationSettings

Purpose:

- Avoid querying MySQL repeatedly.
- Provide settings to different modules.
- Keep invoice generation efficient.

When settings are changed:

MySQL
 ↓
SettingsService
 ↓
Refresh ApplicationSettings
 ↓
Application

Do not query MySQL unnecessarily every time a screen loads.


============================================================
22. PHASE 10 INVOICE INTEGRATION
============================================================

Integrate Settings with the existing Phase 10 billing/invoice module.

Invoice generation should dynamically use:

- Restaurant Name
- Address
- Phone
- Email
- Logo
- Footer Message
- Currency Display
- Tax Configuration if already supported

Example:

Configured Restaurant Name
Configured Address
Configured Contact

--------------------------------
Bill Details
--------------------------------

Subtotal
Discount
Tax
Grand Total

--------------------------------
Configured Footer Message
--------------------------------

IMPORTANT:

Do not create a new invoice generator.

Modify/reuse the existing invoice generation system.


============================================================
23. PHASE 10 BILLING INTEGRATION
============================================================

Do not break existing billing.

Verify:

- Bill generation
- Bill history
- Bill details
- Invoice generation
- PDF generation
- Printing

continue to work after Settings implementation.

DO NOT add:

- Payment Method
- Payment Status
- Amount Paid
- Amount Received
- Change
- Transaction ID


============================================================
24. PHASE 11 REPORT INTEGRATION
============================================================

Do not break Reports & Analytics.

Reports must continue using real:

- Bills
- Orders
- Order Items
- Customers

Currency formatting may use the configured display currency.

Do not change actual report calculations because of a display setting.

Do not create payment analytics.


============================================================
25. UI DESIGN
============================================================

The Settings UI MUST match the existing application.

Reuse:

- Existing colors
- Existing typography
- Existing buttons
- Existing sidebar
- Existing cards
- Existing tables
- Existing spacing
- Existing icons
- Existing dialogs
- Existing animations if already implemented

Do NOT redesign the entire application.

Only add the Settings functionality.


============================================================
26. SECURITY
============================================================

Verify:

[ ] PreparedStatement used
[ ] No SQL injection
[ ] No SQL inside GUI
[ ] Role permissions enforced
[ ] Database credentials protected
[ ] Sensitive configuration not exposed
[ ] Raw SQL exceptions hidden from users

Never store passwords, payment credentials, API secrets, or database credentials as normal restaurant settings.


============================================================
27. AUDIT INFORMATION
============================================================

If the project already supports audit information, record:

- Updated By
- Updated At

Do not create a complete audit system unless already required by the project.

Reuse existing audit functionality if available.


============================================================
28. PERFORMANCE
============================================================

Verify:

- Settings load quickly
- No repeated unnecessary queries
- Logo loading does not freeze the UI
- Settings update immediately
- Invoice generation remains responsive
- Reports remain responsive

Use SwingWorker/background processing where necessary for potentially slow operations.


============================================================
29. PROJECT STRUCTURE
============================================================

Recommended structure:

src/
└── main/
    └── java/
        └── com/
            └── restaurantbilling/

                model/
                    SystemSetting.java
                    RestaurantSettings.java
                    InvoiceSettings.java

                dao/
                    SettingsDAO.java
                    impl/
                        SettingsDAOImpl.java

                service/
                    SettingsService.java

                gui/
                    settings/
                        SettingsPanel.java
                        RestaurantSettingsPanel.java
                        InvoiceSettingsPanel.java

                util/
                    ApplicationSettings.java

Only create files that are actually required.

Reuse existing classes whenever possible.


============================================================
30. DO NOT CREATE
============================================================

DO NOT create:

PaymentSettings.java
PaymentSettingsDAO.java
PaymentSettingsService.java
PaymentConfig.java
PaymentMethod.java
PaymentTransaction.java

There is NO payment system.


============================================================
31. TESTING
============================================================

TEST 1 — Open Settings

Expected:

Authorized administrator can open Settings.

PASS/FAIL


TEST 2 — Unauthorized Access

Expected:

Unauthorized user cannot modify settings.

PASS/FAIL


TEST 3 — Load Existing Settings

Expected:

Previously saved values appear correctly.

PASS/FAIL


TEST 4 — Save Restaurant Information

Expected:

Values saved to MySQL.

PASS/FAIL


TEST 5 — Update Settings

Expected:

Updated values replace previous values.

PASS/FAIL


TEST 6 — Reset Form

Expected:

Form returns to last saved values.

PASS/FAIL


TEST 7 — Invalid Email

Expected:

Validation error.

PASS/FAIL


TEST 8 — Invalid Tax

Only if tax exists.

Expected:

Negative tax rejected.

PASS/FAIL


TEST 9 — Invoice Integration

Change restaurant name.

Generate invoice.

Expected:

New restaurant name appears.

PASS/FAIL


TEST 10 — Logo Integration

Change logo.

Generate invoice if supported.

Expected:

Configured logo appears.

PASS/FAIL


TEST 11 — Billing Regression

Generate a bill.

Expected:

Billing still works.

PASS/FAIL


TEST 12 — Reports Regression

Open Reports.

Expected:

Reports still work correctly.

PASS/FAIL


TEST 13 — Application Restart

Save settings.

Restart application.

Expected:

Settings remain saved.

PASS/FAIL


TEST 14 — Database Validation

Check MySQL.

Expected:

Correct settings are stored.

PASS/FAIL


============================================================
32. REGRESSION TESTING
============================================================

After implementation verify:

Login
 ↓
Dashboard
 ↓
Menu
 ↓
Customers
 ↓
Orders
 ↓
Billing
 ↓
Reports
 ↓
Settings
 ↓
Logout

Every existing module must continue working.


============================================================
33. STRICTLY FORBIDDEN
============================================================

DO NOT implement:

- Payment settings
- Payment methods
- Cash configuration
- Card configuration
- UPI configuration
- Payment gateway
- Refund settings
- Payment credentials
- Payment transactions
- Payment status
- Payment reports
- Payment analytics
- Fake restaurant data
- Hardcoded restaurant details
- Duplicate settings tables
- Duplicate invoice systems
- Duplicate configuration systems
- Unnecessary modules


============================================================
34. PHASE 12 SUCCESS CRITERIA
============================================================

Phase 12 is complete only when:

[ ] Settings Panel implemented
[ ] Restaurant information implemented
[ ] Restaurant information saved to MySQL
[ ] Restaurant information loaded dynamically
[ ] Invoice configuration implemented where required
[ ] Logo configuration implemented where required
[ ] Tax configuration implemented only if already required
[ ] Validation implemented
[ ] Settings DAO implemented
[ ] Settings Service implemented
[ ] Role-based protection implemented
[ ] Settings persist after application restart
[ ] Invoice integration works
[ ] Billing integration works
[ ] Reports integration works
[ ] No payment functionality introduced
[ ] No duplicate configuration system created
[ ] Maven build succeeds
[ ] Application starts successfully
[ ] Previous phases pass regression testing


============================================================
35. FINAL REPORT
============================================================

After implementation provide:

## Files Created/Modified

List every created and modified file.

## Database Changes

List:

- Tables created/modified
- Columns added
- Indexes added

Only report actual changes.

## Settings Implemented

List all implemented settings.

## Invoice Integration

Explain how settings are used by invoice generation.

## Security

Report authorization and validation results.

## Testing

Provide PASS/FAIL results for every test.

## Regression Testing

Confirm:

- Login
- Dashboard
- Menu
- Customers
- Orders
- Billing
- Reports
- Settings
- Logout

## Problems

List unresolved issues.

## Final Status

If everything passes:

PHASE 12 COMPLETE

NEXT:
PHASE 13 — WAIT FOR USER INSTRUCTION

DO NOT automatically start Phase 13.

Wait for explicit user approval.


============================================================
FINAL INSTRUCTION TO ANTIGRAVITY
============================================================

Before modifying code:

1. Inspect the existing project structure.
2. Inspect the existing database schema.
3. Inspect the existing authentication/authorization system.
4. Inspect Phase 10 invoice/billing implementation.
5. Inspect Phase 11 reports implementation.
6. Reuse existing architecture and components.
7. Do not duplicate existing classes or tables.
8. Do not remove existing features.
9. Do not introduce payment functionality.
10. Implement only Phase 12.
11. Test all affected modules.
12. Run Maven build.
13. Fix compilation/runtime errors.
14. Perform regression testing.
15. Provide the final implementation report.

DO NOT START PHASE 13 AUTOMATICALLY.
"""